"""
4R022 Python Learning - Giriş Noktası.

Çalıştırma:
    python main.py

Gereksinimler için requirements.txt dosyasına bakın.
"""
from __future__ import annotations

import os
import sys

# Main/main.py, proje kökünün bir alt klasöründe olduğu için core/ ve ui/
# paketlerinin bulunabilmesi adına proje kökünü sys.path'e ekliyoruz.
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# ÖNEMLİ: QtWebEngine modülü, QApplication oluşturulmadan ÖNCE içe
# aktarılmalıdır (aksi halde Qt bir ImportError fırlatır). Bu yüzden
# bu import, dosyanın en başında ve diğer tüm Qt importlarından önce
# yer alır - sıralaması kasıtlıdır, değiştirilmemelidir.
from PyQt6.QtWebEngineWidgets import QWebEngineView  # noqa: F401

from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QApplication

from core import i18n
from core.config import (
    APP_NAME, APP_ORG, STATE_FILE, base_font_point_size, screen_geometry_fraction,
)
from core.state_manager import StateManager
from ui.splash_screen import SplashScreen
from ui.main_window import MainWindow


def _saved_ui_language() -> str:
    """Splash için kayıtlı dil (yoksa İngilizce)."""
    try:
        st = StateManager(STATE_FILE).state
        if st.last_language:
            return i18n.lang_code_for_package(st.last_language)
    except Exception:
        pass
    return i18n.DEFAULT_LANG


def main() -> int:
    # Chromium: GPU ile çizim, gereksiz arka plan işleri/ağ trafiği ve günlük kapalı
    # (CPU + bellek tasarrufu). Kullanıcının kendi bayrakları korunur.
    _flags = ("--enable-gpu-rasterization --ignore-gpu-blocklist --disable-logging --log-level=3 "
              "--disable-background-networking --disable-sync --no-pings --disable-breakpad "
              "--disable-features=TranslateUI,MediaRouter,OptimizationHints")
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "") + " " + _flags).strip()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(APP_ORG)

    font = QFont("Segoe UI")
    font.setPointSize(base_font_point_size(app))
    app.setFont(font)

    screen_geo = screen_geometry_fraction(app, width_frac=1.0, height_frac=1.0)

    main_window_holder: dict = {}

    def show_main_window():
        window = MainWindow(app)
        main_window_holder["window"] = window
        window.show()

    splash = SplashScreen(app, screen_geo, lang_code=_saved_ui_language())
    splash.finished.connect(show_main_window)
    splash.run(hold_ms=800)

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
