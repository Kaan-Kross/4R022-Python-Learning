# 1. Eş Zamanlılık: Threading, Multiprocessing, Asyncio

## Neden Gerekli?

Bazı işler **bekleme** gerektirir (ağ isteği, dosya G/Ç), bazıları
**yoğun hesaplama** gerektirir (görüntü işleme, matematik). Bu iki
durum farklı araçlarla çözülür.

## `threading` — G/Ç Bağımlı İşler İçin

```python
# ✅ Bu kod çalışır
import threading
import time

def indir(dosya_no):
    print(f"{dosya_no}. dosya indiriliyor...")
    time.sleep(2)
    print(f"{dosya_no}. dosya tamamlandı.")

threadler = []
for i in range(3):
    t = threading.Thread(target=indir, args=(i,))
    threadler.append(t)
    t.start()

for t in threadler:
    t.join()   # tüm threadlerin bitmesini bekle

print("Tüm indirmeler tamamlandı.")
```

## GIL (Global Interpreter Lock) — Önemli Kısıtlama

```python
# ❌ Bu, BEKLENENDEN YAVAŞ çalışır — CPython'da GIL yüzünden,
# CPU-yoğun (hesaplama ağırlıklı) işlerde threading gerçek bir
# paralellik sağlamaz (aynı anda tek bir thread Python kodu çalıştırır):
import threading

def yogun_hesap():
    toplam = 0
    for i in range(50_000_000):
        toplam += i

threadler = [threading.Thread(target=yogun_hesap) for _ in range(4)]
for t in threadler:
    t.start()
for t in threadler:
    t.join()
# Bu, tek thread'le yapmaktan neredeyse hiç hızlı değildir!
```

CPU-yoğun işler için doğru araç `multiprocessing`'tir — çünkü her
process kendi Python yorumlayıcısına (ve kendi GIL'ine) sahiptir.

```python
# ✅ Bu kod çalışır — gerçek paralellik sağlar (birden fazla CPU çekirdeği)
import multiprocessing

def yogun_hesap(sinir):
    return sum(range(sinir))

if __name__ == "__main__":
    with multiprocessing.Pool(4) as havuz:
        sonuclar = havuz.map(yogun_hesap, [10_000_000] * 4)
    print(sonuclar)
```

## `asyncio` — Çok Sayıda Bekleme Gerektiren İşler İçin

```python
# ✅ Bu kod çalışır — yüzlerce ağ isteğini verimli şekilde yönetir
import asyncio

async def veri_getir(id_no):
    print(f"{id_no} isteği başladı")
    await asyncio.sleep(1)   # gerçek bir ağ isteğini simüle eder
    print(f"{id_no} isteği bitti")
    return id_no

async def main():
    gorevler = [veri_getir(i) for i in range(5)]
    sonuclar = await asyncio.gather(*gorevler)
    print(sonuclar)

asyncio.run(main())
```

```python
# ❌ Bu kod ÇALIŞMAZ — 'await', async olmayan bir fonksiyon içinde kullanılmış
def normal_fonksiyon():
    await asyncio.sleep(1)   # SyntaxError: 'await' outside async function
```

## Ne Zaman Hangisi?

| Senaryo | Doğru Araç |
|---|---|
| Dosya indirme, API isteği (bekleme ağırlıklı, az sayıda) | `threading` |
| Yüzlerce eşzamanlı ağ isteği | `asyncio` |
| Görüntü işleme, ağır matematik (CPU ağırlıklı) | `multiprocessing` |

---
⬅️ [Geri](./README.md) &nbsp;|&nbsp; ➡️ [İleri OOP Kavramları](./02-Ileri-OOP-Kavramlari.md)
