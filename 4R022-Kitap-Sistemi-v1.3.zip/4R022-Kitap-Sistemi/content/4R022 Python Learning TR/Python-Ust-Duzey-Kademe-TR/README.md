# Python Üst Düzey Kademe (TR) — İleri Seviye

Bu kademe, gerçek dünyada büyük ve performanslı uygulamalar
geliştirmek isteyenler içindir. Artık dilin kendisini değil, dille
**profesyonel yazılım üretmeyi** öğreniyoruz.

## Bölümler

1. [Eş Zamanlılık: Threading, Multiprocessing, Asyncio](./01-Es-Zamanlilik.md)
2. [İleri OOP: Context Manager'lar, `__slots__`, Metaclass](./02-Ileri-OOP-Kavramlari.md)
3. [Performans ve Optimizasyon](./03-Performans-ve-Optimizasyon.md)
4. [Tasarım Desenleri (Design Patterns)](./04-Tasarim-Desenleri.md)
5. [Profesyonel Masaüstü Uygulama Geliştirme (PyQt6)](./05-Masaustu-Uygulama-Gelistirme.md)
6. [GUI, UI/UX ve Çapraz Platform Arayüz Bilgisi](./06-GUI-UI-UX-ve-Capraz-Platform.md)

Bitirince ➡️ [Veri Kavramları](../Python-Veri-Kavramlari-TR/README.md)
