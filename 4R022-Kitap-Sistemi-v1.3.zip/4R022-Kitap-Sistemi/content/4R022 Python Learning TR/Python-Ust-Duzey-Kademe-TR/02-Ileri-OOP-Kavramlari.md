# 2. İleri OOP Kavramları

## Context Manager (`with` Bloğunu Kendin Yazmak)

`with open(...)` yapısının arkasındaki mantığı kendi sınıflarında da
kurabilirsin:

```python
# ✅ Bu kod çalışır
class VeriTabaniBaglantisi:
    def __enter__(self):
        print("Bağlantı açıldı")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        print("Bağlantı kapatıldı")
        return False   # oluşan hatayı bastırma, dışarı ilet

with VeriTabaniBaglantisi() as baglanti:
    print("Sorgu çalıştırılıyor...")
# çıkışta otomatik olarak "Bağlantı kapatıldı" yazdırılır
```

Alternatif, daha kısa yol — `contextlib`:

```python
# ✅ Bu kod çalışır
from contextlib import contextmanager

@contextmanager
def veritabani_baglantisi():
    print("Bağlantı açıldı")
    yield "baglanti_nesnesi"
    print("Bağlantı kapatıldı")

with veritabani_baglantisi() as b:
    print("Sorgu çalıştırılıyor...")
```

## `__slots__` ile Bellek Optimizasyonu

```python
# ✅ Bu kod çalışır — __slots__ tanımlı nesneler daha az bellek kullanır
class Nokta:
    __slots__ = ("x", "y")   # sadece bu iki nitelik izinlidir

    def __init__(self, x, y):
        self.x = x
        self.y = y

n = Nokta(1, 2)
```

```python
# ❌ Bu kod ÇALIŞMAZ — __slots__ tanımlıyken listelenmemiş bir
# niteliğe değer atamaya çalışılıyor
n.z = 5
```

Bu, `AttributeError: 'Nokta' object has no attribute 'z'` verir.
Binlerce nesne oluşturulan uygulamalarda (örneğin oyun motorları)
`__slots__` ciddi bellek tasarrufu sağlar.

## Metaclass — Sınıfların Sınıfı

Normalde bir sınıf, `type` adlı bir metaclass'tan üretilir. Kendi
metaclass'ını yazarak, sınıfların **nasıl oluşturulduğunu**
özelleştirebilirsin (ileri seviye bir kavramdır, framework/kütüphane
yazarken işine yarar).

```python
# ✅ Bu kod çalışır — her sınıf oluşturulduğunda otomatik loglar
class LogluMeta(type):
    def __new__(mcs, isim, taban_siniflar, sozluk):
        print(f"Yeni sınıf oluşturuluyor: {isim}")
        return super().__new__(mcs, isim, taban_siniflar, sozluk)

class Ornek(metaclass=LogluMeta):
    pass
# çıktı: "Yeni sınıf oluşturuluyor: Ornek"
```

> 🧑‍🏫 **Öğretmen notu:** Metaclass'lar günlük kodlamada nadiren
> gerekir — Django ve SQLAlchemy gibi büyük framework'lerin içinde
> yoğun kullanılır. "Var olduğunu bilmek" bu aşamada yeterlidir.

### 🎯 Mini Alıştırma
Bir dosyayı açıp kapatmayı otomatikleştiren kendi context manager'ını
(`__enter__`/`__exit__` ile) yaz.

---
⬅️ [Eş Zamanlılık](./01-Es-Zamanlilik.md) &nbsp;|&nbsp; ➡️ [Performans ve Optimizasyon](./03-Performans-ve-Optimizasyon.md)
