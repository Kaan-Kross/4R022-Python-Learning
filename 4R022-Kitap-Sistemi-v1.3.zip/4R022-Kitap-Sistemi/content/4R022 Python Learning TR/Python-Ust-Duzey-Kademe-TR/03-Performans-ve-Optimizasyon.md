# 3. Performans ve Optimizasyon

## Ölçmeden Optimize Etme!

> 🧑‍🏫 **Altın kural:** "Önce ölç, sonra optimize et." Sezgiyle
> "bu yavaştır" diye tahmin etmek çoğu zaman yanlış çıkar.

```python
# ✅ Bu kod çalışır — bir fonksiyonun ne kadar sürdüğünü ölçer
import timeit

sure = timeit.timeit("sum(range(1000))", number=10000)
print(sure)
```

```python
# ✅ Bu kod çalışır — cProfile ile tüm programın "nerede zaman
# harcadığını" ayrıntılı görürsün
import cProfile

def yavas_fonksiyon():
    return sum(i * i for i in range(1_000_000))

cProfile.run("yavas_fonksiyon()")
```

## `functools.lru_cache` ile Önbellekleme (Memoization)

```python
# ❌ Bu kod ÇALIŞIR ama ÇOK YAVAŞTIR — her çağrı aynı hesabı tekrar tekrar yapar
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(35))   # birkaç saniye sürebilir
```

```python
# ✅ Bu kod çalışır — sonuçlar önbelleğe alınır, aynı girdi tekrar
# hesaplanmaz, işlem saniyenin çok altına düşer
from functools import lru_cache

@lru_cache(maxsize=None)
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(35))   # anında sonuç verir
```

## Liste Anlama (List Comprehension) — Daha Hızlı ve Okunaklı

```python
# ❌ Bu kod ÇALIŞIR ama daha yavaş ve daha uzun
kareler = []
for i in range(1000):
    kareler.append(i * i)
```

```python
# ✅ Bu kod çalışır — daha hızlı (Python içinde optimize edilmiştir)
# ve daha okunaklıdır
kareler = [i * i for i in range(1000)]
```

## `join()` ile String Birleştirme

```python
# ❌ Bu kod ÇALIŞIR ama büyük döngülerde YAVAŞTIR — her '+=' işleminde
# Python YENİ bir string nesnesi oluşturur (string'ler değiştirilemez!)
sonuc = ""
for kelime in ["Python", "çok", "hızlı"]:
    sonuc += kelime + " "
```

```python
# ✅ Bu kod çalışır — tek seferde birleştirir, çok daha performanslı
sonuc = " ".join(["Python", "çok", "hızlı"])
```

## Ne Zaman C Uzantısına / Cython'a Geçilir?

Saf Python'da bile darboğaz varsa (görüntü işleme, sayısal simülasyon
gibi ağır matematik), **NumPy** (C ile yazılmış, vektörize işlemler
sunar) veya **Cython** (Python'a çok benzeyen ama C'ye derlenen bir
dil) devreye girer. Bu, "Modüller ve Kullanımları" bölümünde daha
ayrıntılı ele alınır.

### 🎯 Mini Alıştırma
`fibonacci` fonksiyonunu hem `@lru_cache` ile hem de klasik bir
`for` döngüsüyle (rekürsiyonsuz) yaz ve `timeit` ile ikisinin hızını
karşılaştır.

---
⬅️ [İleri OOP Kavramları](./02-Ileri-OOP-Kavramlari.md) &nbsp;|&nbsp; ➡️ [Tasarım Desenleri](./04-Tasarim-Desenleri.md)
