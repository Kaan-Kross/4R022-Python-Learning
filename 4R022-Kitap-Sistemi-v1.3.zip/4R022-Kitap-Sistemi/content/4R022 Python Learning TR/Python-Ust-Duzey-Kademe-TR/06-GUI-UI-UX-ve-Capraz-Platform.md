# 6. GUI, UI/UX ve Çapraz Platform Arayüz Bilgisi

## UI ve UX Nedir, Farkı Ne?

**UI (User Interface / Kullanıcı Arayüzü)**, kullanıcının gördüğü ve
dokunduğu her şeydir: butonlar, renkler, yazı tipleri, ikonlar.
**UX (User Experience / Kullanıcı Deneyimi)** ise kullanıcının bu
arayüzü kullanırken **hissettikleridir**: ne kadar kolay anladı, kaç
tıklamada işini bitirdi, hata yaptığında ne kadar kolay geri döndü.
Güzel görünen (iyi UI) bir uygulama, yine de kullanımı zor (kötü UX)
olabilir — ikisi birbirinden farklı ama tamamlayıcı kavramlardır.

### Temel UX İlkeleri (Kısaca)

- **Tutarlılık:** Aynı işlem her zaman aynı yerde, aynı şekilde
  yapılmalı (örneğin "Kaydet" butonu her ekranda aynı yerde olmalı).
- **Geri bildirim (feedback):** Kullanıcı bir butona bastığında,
  bir şeyin olduğunu **görmeli** (yükleniyor animasyonu, renk
  değişimi, mesaj).
- **Hata toleransı:** Kullanıcı hata yaptığında ("emin misiniz?"
  gibi) geri dönebilmeli; yıkıcı işlemler (silme gibi) onay istemeli.
- **Basitlik:** Az sayıda net seçenek, çok sayıda dağınık seçenekten
  iyidir.

## Ekran Boyutunu ve Çözünürlüğü Almak (Çapraz Platform)

Bir masaüstü uygulaması tasarlarken, kullanıcının ekran boyutuna göre
pencereyi ortalamak/boyutlandırmak yaygın bir ihtiyaçtır.

```python
# ✅ Bu kod çalışır — Windows, Linux, macOS'ta ÇALIŞIR (platform bağımsız)
import tkinter as tk
gecici = tk.Tk()
genislik = gecici.winfo_screenwidth()
yukseklik = gecici.winfo_screenheight()
gecici.destroy()
print(f"Ekran: {genislik}x{yukseklik}")
```

```python
# ✅ Bu kod çalışır — SADECE Windows'ta (platforma özgü, ctypes ile)
import ctypes
user32 = ctypes.windll.user32
genislik = user32.GetSystemMetrics(0)
yukseklik = user32.GetSystemMetrics(1)
print(f"Ekran: {genislik}x{yukseklik}")
```

```python
# ✅ Bu kod çalışır (PyQt6 kurulu ise) — PyQt6 uygulamalarında
from PyQt6.QtWidgets import QApplication
import sys
app = QApplication(sys.argv)
ekran = app.primaryScreen().geometry()
print(f"Ekran: {ekran.width()}x{ekran.height()}")
```

```python
# ❌ Bu kod ÇALIŞMAZ (SADECE Windows'ta çalışır ama Linux/macOS'ta çöker)
import ctypes
genislik = ctypes.windll.user32.GetSystemMetrics(0)   # 'windll' Windows'a özgüdür!
```

- **Neden yanlış?** `ctypes.windll`, yalnızca Windows'ta bulunan bir
  arayüzdür; Linux veya macOS'ta böyle bir modül/öznitelik yoktur.
- **Hata nerede?** `AttributeError: module 'ctypes' has no attribute
  'windll'` verir (Linux/macOS'ta).
- **Ne kullanmalısın?** Çapraz platform (cross-platform) bir
  uygulama yazıyorsan `tkinter.winfo_screenwidth()/height()` gibi
  platform bağımsız yöntemleri tercih et; yalnızca Windows'a özel bir
  araç yazıyorsan `ctypes.windll` kullanmakta sorun yoktur.

### DPI Farkındalığı (Yüksek Çözünürlüklü Ekranlar)

Yüksek DPI'lı (4K, Retina gibi) ekranlarda, işletim sistemi arayüzü
otomatik ölçeklendirebilir — bu, Python'ın algıladığı "ekran boyutu"
ile gerçek piksel sayısının **farklı** görünmesine yol açabilir.

```python
# ✅ Bu kod çalışır (yalnızca Windows) — uygulamayı DPI'a duyarlı yapar,
# böylece bulanık/yanlış boyutlu arayüz sorunları azalır
import ctypes
ctypes.windll.user32.SetProcessDPIAware()
```

## Dosya Seçme Penceresi (File Dialog) — "Dosya Ekleme Yeri"

Kullanıcının bir dosya/fotoğraf seçmesini sağlayan standart pencere,
işletim sisteminin **kendi** dosya gezginini açar — bunu sıfırdan
yazman gerekmez, GUI kütüphaneleri hazır sunar:

```python
# ✅ Bu kod çalışır — Tkinter ile dosya seçme penceresi
import tkinter as tk
from tkinter import filedialog

pencere = tk.Tk()
pencere.withdraw()   # ana pencereyi gizle, sadece dialog göster
dosya_yolu = filedialog.askopenfilename(
    title="Bir resim seç",
    filetypes=[("Resim Dosyaları", "*.png *.jpg *.jpeg")]
)
print("Seçilen dosya:", dosya_yolu)
```

```python
# ✅ Bu kod çalışır — PyQt6 ile dosya seçme penceresi
from PyQt6.QtWidgets import QApplication, QFileDialog
import sys

app = QApplication(sys.argv)
dosya_yolu, _ = QFileDialog.getOpenFileName(
    None, "Bir resim seç", "", "Resim Dosyaları (*.png *.jpg *.jpeg)"
)
print("Seçilen dosya:", dosya_yolu)
```

```python
# ❌ Bu kod ÇALIŞMAZ — Tkinter'da dosya dialogunu ana pencere
# oluşturmadan/gizlemeden doğrudan çağırmaya çalışmak
from tkinter import filedialog
dosya_yolu = filedialog.askopenfilename()   # bazı sistemlerde hata/boş pencere
```

- **Neden yanlış?** `filedialog`, arka planda bir Tkinter kök
  penceresine (`Tk()`) ihtiyaç duyar; bu oluşturulmadan çağrılırsa
  bazı platformlarda beklenmedik davranış veya hata görülebilir.
- **Hata nerede?** `tk.Tk()` örneği hiç oluşturulmamış.
- **Ne kullanmalısın?** Yukarıdaki "Çalışan Örnek"teki gibi önce
  gizli bir `tk.Tk()` penceresi oluştur, sonra `filedialog` çağır.

## Bir Fotoğraf/Resim Nasıl "Aratılır" veya Gösterilir?

Bir masaüstü uygulamasında kullanıcıya resim göstermek (örneğin bir
seçim önizlemesi) için resmi bir widget'a yüklersin:

```python
# ✅ Bu kod çalışır (Pillow kurulu ise: pip install pillow) — Tkinter'da resim gösterme
import tkinter as tk
from PIL import Image, ImageTk

pencere = tk.Tk()
resim = Image.open("ornek.png")
resim_tk = ImageTk.PhotoImage(resim)
etiket = tk.Label(pencere, image=resim_tk)
etiket.pack()
pencere.mainloop()
```

> 🧑‍🏫 **Not:** "Resim arama" özelliği (bir arama motoruna sorgu
> gönderip görsel sonuç almak) ayrı bir konudur — bu, genelde bir
> arama API'sine `requests` ile istek atmayı ve dönen sonuçları
> yukarıdaki gibi göstermeyi içerir; teknik olarak "dosya ekleme" ve
> "resim gösterme" ile aynı temel araçları (dosya sistemi + GUI
> widget'ı) kullanır, sadece veri kaynağı yereldeki bir dosya yerine
> bir ağ isteğidir.

## Çapraz Platform Geliştirirken Genel Tavsiyeler

- Platforma özgü kod (`ctypes.windll` gibi) yazman gerekiyorsa,
  mutlaka `sys.platform` ile önce kontrol et:
  ```python
  import sys
  if sys.platform.startswith("win"):
      # Windows'a özel kod
      pass
  else:
      # Linux/macOS için alternatif
      pass
  ```
- Mümkün olduğunca `tkinter`, `PyQt6` gibi **kütüphanenin kendi**
  platform bağımsız API'lerini tercih et; yalnızca gerçekten
  platforma özel bir şeye ihtiyacın varsa (örneğin Windows görev
  çubuğu efektleri) `ctypes`/`pywin32` gibi araçlara in.
- Farklı işletim sistemlerinde **gerçekten test et** — bir özelliğin
  Windows'ta çalışması, Linux/macOS'ta da çalışacağı anlamına gelmez.

### 🎯 Mini Alıştırma
Kullanıcının ekranının ortasında açılan (ekran boyutuna göre
otomatik konumlanan), içinde bir "Dosya Seç" butonu olan ve seçilen
resmi gösteren küçük bir Tkinter veya PyQt6 uygulaması yaz.

---
⬅️ [Masaüstü Uygulama Geliştirme](./05-Masaustu-Uygulama-Gelistirme.md) &nbsp;|&nbsp; ➡️ [Veri Kavramlarına Geç](../Python-Veri-Kavramlari-TR/README.md)

🎉 **Tebrikler — Üst Düzey Kademe'yi tamamladın!**
