# 5. Profesyonel Masaüstü Uygulama Geliştirme (PyQt6)

## Neden Tkinter Değil de PyQt6?

`tkinter` standart kütüphanede gelir, küçük araçlar için hızlıdır.
`PyQt6` ise daha modern görünüm, sinyal/slot mimarisi ve büyük
uygulamalar için daha sağlam bir mimari sunar — 4R022'nin çoğu
masaüstü ürünü bu yüzden PyQt6 ile geliştirilir.

## Minimal Bir PyQt6 Uygulaması

```python
# ✅ Bu kod çalışır (PyQt6 kurulu ise: pip install PyQt6)
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout

class AnaPencere(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4R022 Örnek Uygulama")
        self.resize(400, 200)

        duzen = QVBoxLayout()
        etiket = QLabel("Merhaba, 4R022 Python Learning!")
        duzen.addWidget(etiket)
        self.setLayout(duzen)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    pencere = AnaPencere()
    pencere.show()
    sys.exit(app.exec())
```

```python
# ❌ Bu kod ÇALIŞMAZ — QApplication oluşturulmadan pencere gösterilmeye
# çalışılıyor:
pencere = AnaPencere()
pencere.show()
# RuntimeError: Please create QApplication before QWidget'
```

Her PyQt6 uygulamasında **önce** `QApplication`, **sonra** pencereler
oluşturulmalıdır.

## Önerilen Proje Mimarisi: `core/` + `ui/`

```
proje/
├── main.py
├── core/              # iş mantığı, veri işleme (arayüzden bağımsız)
│   ├── __init__.py
│   └── veri_yoneticisi.py
└── ui/                # sadece görünüm ve kullanıcı etkileşimi
    ├── __init__.py
    └── ana_pencere.py
```

Bu ayrımın amacı: iş mantığını (`core/`) arayüzden (`ui/`) bağımsız
tutmak, böylece iş mantığını test etmek için pencere açmana gerek
kalmaz.

## Sinyal / Slot ile Buton Tıklama

```python
# ✅ Bu kod çalışır
from PyQt6.QtWidgets import QPushButton

buton = QPushButton("Tıkla")
buton.clicked.connect(lambda: print("Butona tıklandı!"))
```

## PyInstaller ile Paketleme (Kısa Bakış)

```bash
# ✅ Bu komut çalışır — .py dosyasını tek bir .exe'ye dönüştürür
pip install pyinstaller
pyinstaller --onefile --windowed main.py
```

Kaynak dosyalarına (ikon, resim vb.) PyInstaller ile paketlenmiş bir
uygulamada erişmek için `resource_path()` yardımcı fonksiyonu
kullanılır — bu, 4R022 projelerinde standart bir pratiktir:

```python
# ✅ Bu kod çalışır
import sys, os

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS   # PyInstaller'ın geçici klasörü
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
```

### 🎯 Mini Alıştırma
Bir metin kutusu (`QLineEdit`) ve bir buton (`QPushButton`) içeren,
butona basınca metin kutusundaki yazıyı bir `QLabel`'de gösteren
küçük bir PyQt6 uygulaması yaz.

---
⬅️ [Tasarım Desenleri](./04-Tasarim-Desenleri.md) &nbsp;|&nbsp; ➡️ [GUI, UI/UX ve Çapraz Platform](./06-GUI-UI-UX-ve-Capraz-Platform.md)
