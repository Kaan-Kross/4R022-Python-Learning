# 4. Tasarım Desenleri (Design Patterns)

Tasarım desenleri, tekrar tekrar karşılaşılan yazılım problemlerine
"kanıtlanmış" çözüm şablonlarıdır. Burada 4R022 tarzı masaüstü
uygulamalarında en çok işine yarayacak üç deseni işliyoruz.

## 1. Singleton — "Tek Nesne" Deseni

Bir sınıftan **yalnızca bir tane** nesne oluşmasını garanti eder
(örneğin tek bir ayar/config nesnesi, tek bir veritabanı bağlantısı).

```python
# ✅ Bu kod çalışır
class Ayarlar:
    _ornek = None

    def __new__(cls):
        if cls._ornek is None:
            cls._ornek = super().__new__(cls)
            cls._ornek.tema = "koyu"
        return cls._ornek

a1 = Ayarlar()
a2 = Ayarlar()
print(a1 is a2)   # True — ikisi de AYNI nesne
```

```python
# ❌ Bu kod YANLIŞ SONUÇ verir — __new__ yerine normal __init__
# kullanılırsa her çağrıda YENİ bir nesne oluşturulur:
class AyarlarYanlis:
    def __init__(self):
        self.tema = "koyu"

a1 = AyarlarYanlis()
a2 = AyarlarYanlis()
print(a1 is a2)   # False — bunlar İKİ farklı nesne, Singleton değil!
```

## 2. Factory — "Üretici" Deseni

Nesne oluşturma mantığını tek bir yerde toplar; hangi sınıfın
oluşturulacağına çalışma zamanında karar verilir.

```python
# ✅ Bu kod çalışır
class Kopek:
    def ses(self):
        return "Hav hav"

class Kedi:
    def ses(self):
        return "Miyav"

def hayvan_uret(tur):
    if tur == "kopek":
        return Kopek()
    elif tur == "kedi":
        return Kedi()
    raise ValueError(f"Bilinmeyen tür: {tur}")

hayvan = hayvan_uret("kedi")
print(hayvan.ses())   # "Miyav"
```

## 3. Observer — "Gözlemci" Deseni

Bir nesnedeki değişikliği, ona bağlı diğer nesnelere otomatik olarak
bildirir. PyQt6'daki **sinyal/slot (signal/slot)** sistemi, bu
desenin hazır bir uygulamasıdır.

```python
# ✅ Bu kod çalışır — Observer deseninin saf Python ile uygulanışı
class Yayinci:
    def __init__(self):
        self._dinleyiciler = []

    def dinleyici_ekle(self, fonksiyon):
        self._dinleyiciler.append(fonksiyon)

    def bildir(self, veri):
        for dinleyici in self._dinleyiciler:
            dinleyici(veri)

def ekrana_yazdir(veri):
    print("Yeni veri geldi:", veri)

yayinci = Yayinci()
yayinci.dinleyici_ekle(ekrana_yazdir)
yayinci.bildir("Merhaba!")   # "Yeni veri geldi: Merhaba!"
```

PyQt6'da bunun karşılığı:

```python
# ✅ Bu kod çalışır (PyQt6 kurulu ise)
from PyQt6.QtCore import QObject, pyqtSignal

class Yayinci(QObject):
    veri_geldi = pyqtSignal(str)   # sinyal tanımı

yayinci = Yayinci()
yayinci.veri_geldi.connect(lambda veri: print("Yeni veri:", veri))
yayinci.veri_geldi.emit("Merhaba PyQt6!")
```

### 🎯 Mini Alıştırma
Bir `Loglayici` Singleton sınıfı yaz; uygulamanın her yerinden aynı
log dosyasına yazsın.

---
⬅️ [Performans ve Optimizasyon](./03-Performans-ve-Optimizasyon.md) &nbsp;|&nbsp; ➡️ [Masaüstü Uygulama Geliştirme](./05-Masaustu-Uygulama-Gelistirme.md)
