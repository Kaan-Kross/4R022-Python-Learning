# 3. Yasal Sınırlar ve Sorumluluk Reddi

## Genel Çerçeve (Ülkeden Ülkeye Değişir)

Aşağıdakiler **genel bir farkındalık** amaçlıdır, hukuki tavsiye
değildir. Yasalar ülkeden ülkeye, hatta eyaletten eyalete farklılık
gösterir; Türkiye'de **5651 sayılı kanun** ve **Türk Ceza Kanunu'nun
bilişim suçlarına ilişkin maddeleri (243-245. maddeler)** izinsiz
sisteme girme, veri değiştirme/silme ve banka/kredi kartı verisiyle
ilgili suçları düzenler. Diğer ülkelerde de benzer düzenlemeler
vardır (örn. ABD'de CFAA — Computer Fraud and Abuse Act, AB'de
GDPR'nin veri ihlali hükümleri).

## Genel Olarak Yasa Dışı Kabul Edilen Eylemler

- Sahibinin izni olmadan bir bilgisayar sistemine, ağa veya hesaba
  erişmek (izinsiz erişim/"unauthorized access").
- Başkasına ait veriyi izinsiz kopyalamak, değiştirmek veya silmek.
- Bir hizmeti kasıtlı olarak erişilemez hale getirmek (DDoS gibi).
- Kötü amaçlı yazılım (malware, ransomware, virüs) geliştirmek,
  dağıtmak veya bulundurmak.
- Kimlik avı (phishing) veya sahte kimlikle dolandırıcılık yapmak.
- İzinsiz elde edilen verileri satmak, paylaşmak veya şantaj amacıyla
  kullanmak.

## Genel Olarak Yasal Kabul Edilen Eylemler

- Yazılı, açık izinle yapılan sızma testleri (pentest sözleşmeleri).
- Bug bounty programları kapsamında, programın kurallarına uygun
  şekilde açık bulma ve bildirme.
- Kendi sistemin/ağın/verinin güvenliğini test etmek.
- Halka açık, `robots.txt` ve kullanım şartlarına uygun web scraping.
- Güvenlik araştırması amaçlı, kontrollü ve izole ortamlarda (kendi
  sanal makinelerinde, CTF — Capture The Flag yarışmalarında) zararlı
  yazılım analizi.

## "Ama Ben Sadece Öğreniyordum" Savunması İşe Yarar mı?

Genelde **hayır.** Çoğu ülkenin bilişim suçları mevzuatı, "izinsiz
erişim" fiilinin kendisini suç sayar — niyetin "öğrenmek" olması,
izinsizliği ortadan kaldırmaz. Bu yüzden pratik ve güvenli yol:
**öğrenmeyi her zaman izinli ortamlarda yap** — kendi bilgisayarında
kurduğun sanal makinelerde, yasal CTF platformlarında (HackTheBox,
TryHackMe gibi, bunlar **izinli** test ortamlarıdır) veya kendi
yazdığın/kurduğun sistemlerde.

## 4R022 Python Learning'in Duruşu

Bu kaynak:
- **Nasıl saldırı yapılır** diye bir rehber DEĞİLDİR.
- Python'ın ağ, otomasyon ve şifreleme yeteneklerini **meşru
  kullanım senaryolarıyla** öğretir.
- "Hacker kültürünü" romantikleştirmeden veya kötülemeden,
  **olduğu gibi** tanıtır.
- Etik ve yasal sınırları öğrencinin kendi araştırmasıyla
  derinleştirmesini teşvik eder — burada verilenler bir başlangıç
  noktasıdır, hukuki tavsiye yerine geçmez.

## Sorumluluk Reddi (Disclaimer)

Bu depodaki (repository) hiçbir kod veya açıklama, izinsiz sistemlere
erişim, veri hırsızlığı veya herhangi bir yasa dışı faaliyet için
teşvik veya rehber olarak sunulmamaktadır. İçerik yalnızca **eğitim
amaçlıdır.** Bu materyalin kötüye kullanılmasından doğacak her türlü
hukuki sonuçtan yalnızca kullanıcı sorumludur; 4R022 ve Kaan Kross
hiçbir sorumluluk kabul etmez.

### 🎯 Son Düşünme Sorusu
Bir arkadaşın CTF (Capture The Flag) yarışmasına katılmak istiyor
ama "gerçek bir siteyi hacklemenin daha eğlenceli olacağını"
düşünüyor. Ona bu bölümdeki hangi noktaları hatırlatırdın?

---
⬅️ [White/Grey/Black Hat Hackerlar](./02-White-Grey-Black-Hat-Hackerlar.md) &nbsp;|&nbsp; ⬆️ [Ana Sayfaya Dön](../README.md)

🎓 **Tebrikler — 4R022 Python Learning (TR) eğitiminin tamamını bitirdin!**
