# Python ile Etik ve Güvenlik (TR)

Bu klasör, teknik bir bölüm değil, bir **farkındalık** bölümüdür.
Python gibi güçlü bir dille neredeyse her şeyi otomatikleştirebilir,
ağlarla konuşabilir, dosya sistemlerine dokunabilirsin — bu güç
beraberinde sorumluluk getirir.

4R022 Python Learning olarak burada **taraf tutmuyoruz**: ne "hacklemeyi
öğren, her şey mubah" diyoruz, ne de bu alandan tamamen korkarak
uzak durmanı öneriyoruz. Amacımız, bu kavramları **doğru, tarafsız ve
gerçekçi** şekilde tanıtmak; kararı ve sorumluluğu sana bırakmak.

## Bölümler

1. [Etik Kullanım ve Sorumluluklar](./01-Etik-Kullanim-ve-Sorumluluklar.md)
2. [White / Grey / Black Hat Hackerlar Nedir?](./02-White-Grey-Black-Hat-Hackerlar.md)
3. [Yasal Sınırlar ve Sorumluluk Reddi](./03-Yasal-Sinirlar-ve-Sorumluluk-Reddi.md)

Bu bölümü bitirdiğinde, tüm eğitim kademeleri tamamlanmış olur. 🎓
