# 2. White / Grey / Black Hat Hackerlar Nedir?

> Bu bölüm tamamen **tanımlayıcı ve bilgilendirici** amaçlıdır; hiçbir
> saldırı tekniği öğretmez. Amaç, medyada sıkça duyduğun bu terimlerin
> ne anlama geldiğini ve neden var olduklarını doğru anlamandır.

## Ortak Kök: "Hacker" Kelimesi Aslında Ne Demek?

"Hacker" kelimesi, popüler kültürde genelde "bilgisayar suçlusu"
anlamında kullanılsa da, orijinal anlamı **bir sistemi derinlemesine
anlayan, sınırlarını zorlayan, yaratıcı çözümler üreten kişi**dir.
1960'ların MIT kültüründe "hacker", meraklı ve yetenekli bir
programcıya verilen olumlu bir sıfattı. Zamanla, medya bu kelimeyi
neredeyse tamamen "siber suçlu" anlamıyla özdeşleştirdi. Güvenlik
camiası, bu yüzden "hat renkleri" ile ayrım yapmaya başladı.

## ⚪ White Hat (Beyaz Şapka)

**Kimdir?** Sistemleri, **sahibinin yazılı izniyle**, güvenlik
açıklarını bulup düzeltmek amacıyla test eden kişilerdir.

**Ne iş yaparlar?**
- Sızma testi (penetration testing) — şirketlerin kendi istekleriyle
  sistemlerine "izinli saldırı" düzenlerler.
- Bug bounty (hata avcılığı) programlarına katılırlar (Google,
  Microsoft, birçok şirket, açık bulana ödül verir).
- Güvenlik danışmanlığı, sızma testi raporları, savunma sistemleri
  (firewall, IDS/IPS) geliştirme.

**Neden varlar?** Bir sistemi en iyi kırabilecek kişi genelde onu en
iyi savunabilecek kişidir de. Şirketler, açığı **kötü niyetli biri
bulmadan önce** kendi bünyelerinde veya izinli uzmanlarla bulmayı
tercih eder.

## ⚫ Black Hat (Siyah Şapka)

**Kimdir?** İzinsiz, kötü niyetle sistemlere sızan, veri çalan, zarar
veren veya bunları maddi/siyasi çıkar için kullanan kişilerdir.

**Ne iş yaparlar?** (bilgi amaçlı, teknik detay verilmeden)
Fidye yazılımı (ransomware) dağıtımı, veri hırsızlığı, kimlik avı
(phishing) kampanyaları, DDoS saldırıları düzenleme, çalınan veriyi
karanlık ağda (dark web) satma gibi **yasa dışı** faaliyetler
yürütürler.

**Neden var oluyorlar?** Motivasyonları genelde maddi kazanç, siyasi
aktivizm ("hacktivism"), casusluk (devlet destekli gruplar) veya
sadece "meydan okuma"dır. Bu faaliyetler, hemen hemen her ülkede ağır
hapis cezaları ve tazminatlarla sonuçlanan **suçlardır.**

## ⚪⚫ Grey Hat (Gri Şapka)

**Kimdir?** Beyaz ile siyah arasında kalan, genellikle **izin
almadan** bir sistemde açık bulan ama bunu **kötüye kullanmak
yerine** genelde sahibine bildiren (bazen de kamuya açıklayan)
kişilerdir.

**Ne iş yaparlar?** Örneğin bir şirketin sitesinde izinsizce bir
güvenlik açığı bulup, şirkete "açığınız var, düzeltin" diye e-posta
atarlar — bazen karşılığında teşekkür/ödül alırlar, bazen de "izinsiz
erişim" suçlamasıyla karşı karşıya kalırlar (çünkü izin **almamışlardır**).

**Neden bu bölgede kalırlar?** Niyetleri genelde kötü değildir
(sistemi savunmaya yardım etmek isterler) ama **yöntem** (izinsiz
erişim) çoğu ülkede yine de yasa dışıdır. Bu yüzden "grey" (gri)
denir — niyet iyi, yöntem tartışmalı/yasa dışı olabilir.

## Karşılaştırma Tablosu

| | White Hat | Grey Hat | Black Hat |
|---|---|---|---|
| İzin | Var (yazılı sözleşme) | Yok | Yok |
| Niyet | İyi (savunma) | Genelde iyi | Kötü (çıkar/zarar) |
| Yasallık | Yasal | Belirsiz / genelde yasa dışı | Yasa dışı |
| Örnek faaliyet | Bug bounty, pentest | İzinsiz açık bulup bildirme | Fidye yazılımı, veri hırsızlığı |
| Sonuç | Ödül, kariyer, itibar | Teşekkür veya dava, değişken | Hapis cezası, tazminat |

## Diğer Renkler (Kısaca)

- **Red Hat:** Black hat saldırganlara karşı **agresif** karşı
  saldırılarla (onların sistemlerini de hedef alarak) karşılık veren,
  tartışmalı bir yaklaşımdır.
- **Blue Team:** Kurumların **savunma** (defense) tarafında çalışan,
  sürekli izleme ve müdahale yapan güvenlik ekipleridir (white hat'e
  yakın ama daha çok "günlük operasyon" odaklıdır).
- **Script Kiddie:** Kendi bilgisi olmadan, internetten bulduğu hazır
  araçlarla saldırı denemesi yapan, genelde deneyimsiz kişilere
  verilen (küçümseyici) bir isimdir — hem etik hem teknik olarak
  saygı görmez.

## Neden Bu Ayrım Önemli?

Python'da öğrendiğin `socket`, `requests`, `selenium`, `cryptography`
gibi araçlar, teknik olarak hem white hat hem black hat tarafından
kullanılabilir. Seni bu araçlardan uzak tutmak yerine, **hangi
tarafta durduğunun yalnızca izin ve niyetle belirlendiğini**
anlamanı istiyoruz — kod aynıdır, fark kararındadır.

---
⬅️ [Etik Kullanım ve Sorumluluklar](./01-Etik-Kullanim-ve-Sorumluluklar.md) &nbsp;|&nbsp; ➡️ [Yasal Sınırlar ve Sorumluluk Reddi](./03-Yasal-Sinirlar-ve-Sorumluluk-Reddi.md)
