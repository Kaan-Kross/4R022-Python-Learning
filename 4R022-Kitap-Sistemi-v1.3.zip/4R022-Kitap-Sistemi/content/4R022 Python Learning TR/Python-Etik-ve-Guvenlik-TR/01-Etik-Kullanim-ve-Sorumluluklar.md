# 1. Etik Kullanım ve Sorumluluklar

## Kod Nötrdür, Niyet Değildir

Bu kaynak boyunca öğrendiğin her şey — dosya okuma/yazma, ağ
programlama (`socket`), tarayıcı otomasyonu (`selenium`), şifreleme
(`cryptography`) — **kendi başına ne iyi ne kötüdür.** Aynı `socket`
kodu, hem bir öğrencinin ödevinde hem de kötü niyetli bir araçta
kullanılabilir. Farkı yaratan, **kimin, neye izniyle, hangi amaçla**
kullandığıdır.

## Üç Basit Soru

Yazdığın bir script'i çalıştırmadan önce kendine şunu sor:

1. **İzin var mı?** — Bu sistemi/veriyi/hesabı test etmek/kullanmak
   için sahibinden veya yetkili kişiden açık izin aldın mı?
2. **Zarar veriyor mu?** — Bu kod, birinin verisine, gizliliğine,
   sistemine, itibarına veya cüzdanına zarar verir mi?
3. **Şeffaf mısın?** — Bu kodu ne yaptığını gizlemeden, gerektiğinde
   ilgili kişilere açıklayabilir misin?

Üçüne de rahatça "evet" diyemiyorsan, muhtemelen etik ve/veya yasal
bir sınırın yakınındasındır.

## Gerçek Hayattan Meşru Kullanım Örnekleri

| Teknik | Meşru Kullanım | Sınır Aşımı |
|---|---|---|
| Web scraping (`requests`, `BeautifulSoup`) | Kendi sitenin verisini toplamak, halka açık ve `robots.txt`'e uygun veri çekmek | Bir sitenin kullanım şartlarını (ToS) hiçe sayarak kişisel veri toplamak |
| Otomasyon botları | Kendi hesabında tekrarlayan işleri otomatikleştirmek | Sahte hesaplarla platform kurallarını (spam, manipülasyon) ihlal etmek |
| Ağ tarama araçları | Kendi ağını/şirketinin sistemini, yazılı izinle test etmek (pentest) | İzinsiz başka bir kuruma/kişiye ait sistemi taramak |
| Şifre kırma/deneme araçları | Kendi unuttuğun şifreni kurtarmak, izinli güvenlik testi | Başkasının hesabına izinsiz erişmeye çalışmak |

## Sorumluluklar

- **Yasal sorumluluk** senindir — "bilmiyordum" savunması genelde
  işe yaramaz; birçok ülkede izinsiz sisteme erişim, veri hırsızlığı
  ve hizmet aksatma suçları ağır cezalar içerir.
- **Etik sorumluluk**, yasanın "izin verdiği ama doğru olmayan" gri
  alanları da kapsar (örn. bir açığı bulup rapor etmeden karanlık
  ağda satmak yasa dışıdır; ama bulup sessizce, kamuoyuna açıklamadan
  saklamak da tartışmalı bir etik konudur).
- **Topluluk sorumluluğu** — bu alanda öğrendiklerini paylaşırken
  (blog, GitHub, video), başkalarının bunu kötüye kullanabileceğini
  unutma; "nasıl savunulur" ile "nasıl saldırılır" arasında ayrım
  gözet.

### 🎯 Düşünme Alıştırması
Bir arkadaşın senden, eski sevgilisinin sosyal medya şifresini
"deneme amaçlı" kırmanı istese, yukarıdaki üç soruyu ona sorardın —
cevapları ne olurdu?

---
⬅️ [Geri](./README.md) &nbsp;|&nbsp; ➡️ [White/Grey/Black Hat Hackerlar](./02-White-Grey-Black-Hat-Hackerlar.md)
