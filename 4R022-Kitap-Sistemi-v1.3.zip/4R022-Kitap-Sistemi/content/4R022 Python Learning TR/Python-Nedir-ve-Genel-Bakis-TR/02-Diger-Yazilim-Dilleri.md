# Python ile Diğer Yazılım Dilleri Arasındaki Farklar

> 🧑‍🏫 Bir dili gerçekten anlamanın en iyi yolu, onu başkalarıyla
> kıyaslamaktır. Bu bölümde Python'ı en çok karşılaştırılan dillerle
> yan yana koyuyoruz.

## 1. Python vs C / C++

C ve C++ **derlenen (compiled)** ve **statik tipli** dillerdir.
Donanıma çok yakın çalıştıkları için hızlıdırlar ama bellek yönetimini
(memory management) genelde geliştirici kendi elleriyle yapar.

```c
// C dilinde toplama fonksiyonu — tip belirtmek zorunludur
int topla(int a, int b) {
    return a + b;
}
```

```python
# ✅ Python'da aynı iş — tip belirtmen gerekmez
def topla(a, b):
    return a + b
```

**Fark:** C, hız ve düşük seviyeli kontrol ister (işletim sistemi,
oyun motoru, gömülü sistem); Python, hız yerine geliştirme sürati ve
okunabilirlik ister (otomasyon, veri bilimi, web backend).

## 2. Python vs Java

Java da statik tipli ve derlenen (bytecode'a) bir dildir; "her şey bir
sınıf içinde olmalı" kuralı vardır.

```java
public class Main {
    public static void main(String[] args) {
        System.out.println("Merhaba Dünya");
    }
}
```

```python
# ✅ Python'da sınıf zorunlu değil, tek satır yeter
print("Merhaba Dünya")
```

**Fark:** Java, büyük kurumsal sistemlerde ve Android geliştirmede
güçlüdür; Python, hızlı prototipleme ve script yazmada üstündür.

## 3. Python vs JavaScript

JavaScript tarayıcıda ve Node.js ile sunucuda çalışan, dinamik tipli
bir dildir — bu yönüyle Python'a benzer.

```javascript
// JavaScript
function topla(a, b) {
    return a + b;
}
```

```python
# Python — neredeyse aynı mantık, farklı söz dizimi
def topla(a, b):
    return a + b
```

**Fark:** JavaScript web tarayıcısının "resmi dili"dir (tarayıcıda
başka bir dil çalışmaz); Python tarayıcıda çalışmaz ama backend,
otomasyon, veri bilimi ve masaüstü uygulamalarında çok daha rahattır.

## 4. Python vs C#

C#, Microsoft'un .NET ekosistemi için geliştirdiği, Java'ya çok benzeyen
statik tipli bir dildir. Windows masaüstü uygulamaları (WPF, WinForms)
ve oyun geliştirme (Unity) için yaygındır.

**Fark:** C#, Windows/.NET dünyasında entegrasyonu güçlüdür; Python
platform bağımsızlığı ve hızlı geliştirmesiyle öne çıkar.

## 5. Hangi Dili Ne Zaman Seçmeli? (Karşılaştırma Tablosu)

| İhtiyaç | Önerilen Dil |
|---|---|
| Veri analizi, yapay zeka, otomasyon | **Python** |
| Web tarayıcısı arayüzü | JavaScript (+ HTML/CSS) |
| Yüksek performanslı oyun motoru / işletim sistemi | C / C++ |
| Büyük kurumsal backend / Android | Java |
| Windows masaüstü / Unity oyun | C# |
| Hızlı script, prototip, öğrenme | **Python** |

## 6. Özet

Hiçbir dil "en iyisi" değildir — her dilin var olma sebebi farklıdır.
Python'ı özel kılan şey, **hız değil, geliştirici verimliliği ve
öğrenme eğrisinin düşük olmasıdır.** Bu yüzden bu kaynakta Python'la
başlıyoruz.

---
⬅️ Önceki: [Python Nedir?](./01-Python-Nedir.md) &nbsp;|&nbsp; ➡️ Sonraki: [Pythonla Neler Yapılır?](./03-Pythonla-Neler-Yapilir.md)
