# Python Nedir?

> 🧑‍🏫 **Öğretmen notu:** Bu bölümü bir sohbet gibi düşün. Amacımız Python'u
> ezberletmek değil, "bu dil neden var, ne işe yarar, neden bu kadar
> popüler" sorularına gerçekten cevap vermek.

## 1. Kısaca Python

Python, 1991 yılında **Guido van Rossum** tarafından geliştirilen,
**yorumlanan (interpreted)**, **yüksek seviyeli** ve **genel amaçlı**
bir programlama dilidir. "Yüksek seviyeli" demek, bilgisayarın anladığı
0-1'lere yakın değil, insanın okuyup anlayabileceği bir söz dizimine
(syntax) sahip demektir.

Python'ın felsefesi tek bir cümlede özetlenebilir:

> **"Kodun okunabilirliği her şeyden önce gelir."**

Bunu kanıtlayan küçük bir örnek:

```python
# ✅ Bu kod çalışır — ve neredeyse İngilizce gibi okunur
isim = "Kaan"
if isim == "Kaan":
    print("Merhaba, 4R022!")
```

Aynı işi C dilinde yapmak, süslü parantezler, noktalı virgüller ve
tip tanımlamaları gerektirir. Python bunların çoğunu senin yerine
halleder.

## 2. Neden "Yorumlanan" Dil?

Python kodu doğrudan makine diline **derlenmez (compile)**; satır satır
bir **yorumlayıcı (interpreter)** tarafından çalıştırılır (CPython —
en yaygın Python yorumlayıcısı). Bu, geliştirmeyi hızlandırır ama
çalışma hızını (runtime performance) C/C++ gibi derlenen dillere göre
biraz yavaşlatır. Bu, dengeli bir tercih: hız yerine geliştirme
kolaylığı ve okunabilirlik kazanılır.

## 3. Python'ın Temel Özellikleri

| Özellik | Açıklama |
|---|---|
| Dinamik tipleme | Değişkenin tipini önceden belirtmene gerek yok |
| Okunabilir söz dizimi | Girinti (indentation) tabanlı blok yapısı |
| Geniş standart kütüphane | "Piller dahil" (batteries included) felsefesi |
| Çok paradigmalı | Prosedürel, nesne yönelimli (OOP), fonksiyonel yazılabilir |
| Platform bağımsız | Windows, Linux, macOS üzerinde aynı kodla çalışır |
| Devasa topluluk | PyPI'de 500.000'den fazla paket |

Dinamik tiplemeye örnek:

```python
# ✅ Bu kod çalışır
x = 5        # x şu an bir tam sayı (int)
x = "beş"    # şimdi aynı değişken bir metin (str) oldu, hata vermez
print(x)
```

```python
# ❌ Bu kod ÇALIŞMAZ — C/Java gibi statik tipli bir dilde bu normaldir,
# ama Python'da böyle bir tip zorunluluğu YAZMAZSIN, bu satır Python
# söz dizimine aykırıdır:
int x = 5;
```

Yukarıdaki ikinci örnek aslında C/Java sözdizimidir; Python'a kopyalanıp
çalıştırılırsa `SyntaxError` verir. Bunu bilerek koydum çünkü
başlangıçta öğrenciler en çok bu karışıklığı yaşıyor.

## 4. Girinti (Indentation) Neden Bu Kadar Önemli?

Python'da blokları `{}` ile değil **girinti (boşluk/tab)** ile
belirtiriz. Bu, dilin en özgün ve en çok hataya yol açan tarafıdır.

```python
# ✅ Bu kod çalışır — girinti doğru
def selamla():
    print("Merhaba")
    print("4R022 Python Learning'e hoş geldin")

selamla()
```

```python
# ❌ Bu kod ÇALIŞMAZ — IndentationError verir
def selamla():
print("Merhaba")   # bu satırın girintili olması gerekiyordu
```

## 5. Özet

- Python; okunabilir, dinamik tipli, yorumlanan, çok amaçlı bir dildir.
- Kod bloklarını girinti ile ayırır — bu hem artısı hem en sık hata
  kaynağıdır.
- Devasa bir standart kütüphaneye ve topluluk paketine (PyPI) sahiptir.

### 🎯 Küçük Alıştırma

Aşağıdaki kodda bilerek bırakılmış hatayı bul ve düzelt:

```python
def toplama(a, b):
return a + b

print(toplama(3, 4))
```

<details>
<summary>Cevabı gör</summary>

`return a + b` satırı girintisiz yazılmış, bu yüzden `IndentationError`
alırsın. Doğrusu:

```python
def toplama(a, b):
    return a + b

print(toplama(3, 4))
```

</details>

---
⬅️ [Genel Bakış'a Dön](./README.md) &nbsp;|&nbsp; ➡️ Sonraki: [Diğer Yazılım Dilleri](./02-Diger-Yazilim-Dilleri.md)
