# Pythonla Neler Yapılır?

> 🧑‍🏫 Öğrencilerin en sık sorduğu soru: "Bunu öğrenip ne yapacağım?"
> Cevap: neredeyse her şeyi. Aşağıda gerçek kullanım alanlarını,
> kullanılan araçları ve birer örnek kod satırıyla görelim.

## 1. Web Geliştirme (Backend)
**Araçlar:** Django, Flask, FastAPI

```python
# ✅ Bu kod çalışır (Flask kurulu ise): basit bir web sunucusu
from flask import Flask
app = Flask(__name__)

@app.route("/")
def anasayfa():
    return "4R022 Python Learning'e hoş geldin!"
```

## 2. Veri Bilimi ve Analiz
**Araçlar:** pandas, numpy, matplotlib

```python
# ✅ Bu kod çalışır (pandas kurulu ise)
import pandas as pd
veri = {"isim": ["Ali", "Ayşe"], "yas": [23, 30]}
df = pd.DataFrame(veri)
print(df)
```

## 3. Yapay Zeka ve Makine Öğrenmesi
**Araçlar:** TensorFlow, PyTorch, scikit-learn

Python, yapay zeka dünyasının fiili standart dilidir. Neredeyse tüm
büyük dil modelleri (LLM) ve makine öğrenmesi kütüphaneleri Python
arayüzü sunar.

## 4. Otomasyon ve Script Yazımı
**Araçlar:** os, shutil, pyautogui, selenium

```python
# ✅ Bu kod çalışır — bir klasördeki tüm dosyaları listeler
import os
for dosya in os.listdir("."):
    print(dosya)
```

## 5. Masaüstü Uygulama Geliştirme
**Araçlar:** Tkinter (standart kütüphane), PyQt6, Kivy

4R022 markası altındaki birçok proje (örneğin masaüstü araçlar) tam
olarak bu kategoriye girer — Python + PyQt6/Tkinter ile profesyonel
Windows uygulamaları üretilir.

## 6. Siber Güvenlik ve Ağ Programlama
**Araçlar:** socket, scapy, cryptography, requests

Güvenlik araştırmacıları ve sistem yöneticileri, ağ trafiği analizi,
şifreleme, otomatik güvenlik taramaları için sıkça Python kullanır.
Bu konuyu ayrıca **etik** boyutuyla
[Etik ve Güvenlik](../Python-Etik-ve-Guvenlik-TR/README.md) bölümünde
ele alıyoruz.

## 7. Oyun Geliştirme (Hafif Ölçekli)
**Araçlar:** Pygame

## 8. Betik / Yapıştırıcı Dil (Glue Language)
Python, farklı sistemleri (C kütüphaneleri, veritabanları, API'ler)
birbirine bağlamada da çok kullanılır — bu yüzden "yapıştırıcı dil"
olarak da anılır.

## Özet Tablo

| Alan | Popüler Kütüphaneler |
|---|---|
| Web (backend) | Django, Flask, FastAPI |
| Veri bilimi | pandas, numpy, matplotlib |
| Yapay zeka | TensorFlow, PyTorch, scikit-learn |
| Otomasyon | os, selenium, pyautogui |
| Masaüstü uygulama | Tkinter, PyQt6, Kivy |
| Ağ / güvenlik | socket, scapy, cryptography |
| Oyun | Pygame |

---
⬅️ Önceki: [Diğer Yazılım Dilleri](./02-Diger-Yazilim-Dilleri.md) &nbsp;|&nbsp; ➡️ Sonraki: [Temel Eğitime Başla](../Python-Temel-Egitim-TR/README.md)
