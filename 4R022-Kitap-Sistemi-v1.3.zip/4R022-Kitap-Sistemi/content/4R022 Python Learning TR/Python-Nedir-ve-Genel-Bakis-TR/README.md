# Python Nedir ve Genel Bakış (TR)

Bu klasör, Python öğrenmeye başlamadan önce "bu dil nedir, diğer
dillerden farkı ne, ne işe yarar" sorularını cevaplar.

## İçindekiler

1. [Python Nedir?](./01-Python-Nedir.md)
2. [Diğer Yazılım Dilleri ile Karşılaştırma](./02-Diger-Yazilim-Dilleri.md)
3. [Pythonla Neler Yapılır?](./03-Pythonla-Neler-Yapilir.md)

Bittiğinde ➡️ [Python Temel Eğitim TR](../Python-Temel-Egitim-TR/README.md) klasörüne geç.
