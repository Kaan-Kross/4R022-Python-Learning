# 5. Test Yazımı ve Hata Ayıklama

## Neden Test Yazarız?

Kod büyüdükçe, bir değişikliğin başka bir yeri bozup bozmadığını
elle kontrol etmek imkânsız hale gelir. Testler bunu otomatikleştirir.

## `unittest` (Standart Kütüphane)

```python
# ✅ Bu kod çalışır — hesap_makinesi.py
def topla(a, b):
    return a + b

def bol(a, b):
    if b == 0:
        raise ValueError("Sıfıra bölünemez")
    return a / b
```

```python
# ✅ Bu kod çalışır — test_hesap_makinesi.py
import unittest
from hesap_makinesi import topla, bol

class TestHesapMakinesi(unittest.TestCase):
    def test_topla(self):
        self.assertEqual(topla(2, 3), 5)

    def test_bol_sifira(self):
        with self.assertRaises(ValueError):
            bol(10, 0)

if __name__ == "__main__":
    unittest.main()
```

```bash
python -m unittest test_hesap_makinesi.py
```

```python
# ❌ Bu kod ÇALIŞMAZ (test başarısız olur, hata değil ama YANLIŞ
# beklenti) — 2 + 3 aslında 5'tir, 6 değil:
self.assertEqual(topla(2, 3), 6)   # AssertionError: 5 != 6
```

## `pytest` (Popüler Üçüncü Parti Kütüphane)

```bash
pip install pytest
```

```python
# ✅ Bu kod çalışır — pytest, 'unittest.TestCase' bile gerektirmez
# test_hesap.py
from hesap_makinesi import topla

def test_topla():
    assert topla(2, 3) == 5

def test_topla_negatif():
    assert topla(-1, -1) == -2
```

```bash
pytest test_hesap.py -v
```

## Hata Ayıklama (Debugging) İpuçları

```python
# ✅ Bu kod çalışır — print ile "nerede ne var" izlemek
def hesapla(veri):
    print("DEBUG: gelen veri ->", veri)   # geçici debug satırı
    sonuc = sum(veri) / len(veri)
    return sonuc
```

```python
# ✅ Bu kod çalışır — Python'ın yerleşik hata ayıklayıcısı (breakpoint)
def hesapla(veri):
    breakpoint()   # program burada durur, değişkenleri incelersin
    return sum(veri) / len(veri)
```

> 🧑‍🏫 **Öğretmen notu:** `print()` ile debug yapmak "amatörce" değildir
> — gerçek yazılımcılar da hızlı kontrol için sık sık kullanır. Ama
> büyük projelerde `logging` modülü ve gerçek bir debugger (VS Code'un
> içindeki gibi) çok daha güçlüdür.

### 🎯 Mini Alıştırma
`hesap_makinesi.py` modülüne bir `cikar(a, b)` fonksiyonu ekle, sonra
onun için hem `unittest` hem `pytest` ile birer test yaz.

---
⬅️ [Modüller, Paketler, Sanal Ortamlar](./04-Moduller-Paketler-Sanal-Ortamlar.md) &nbsp;|&nbsp; ➡️ [Üst Düzey Kademeye Geç](../Python-Ust-Duzey-Kademe-TR/README.md)

🎉 **Tebrikler — Orta Kademe'yi tamamladın!**
