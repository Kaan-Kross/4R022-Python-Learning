# 1. İleri Nesne Yönelimli Programlama

## `@property` ile Kontrollü Erişim

```python
# ✅ Bu kod çalışır
class Dikdortgen:
    def __init__(self, en, boy):
        self._en = en
        self._boy = boy

    @property
    def alan(self):
        return self._en * self._boy

d = Dikdortgen(4, 5)
print(d.alan)   # 20 — metod gibi tanımlanır ama değişken gibi çağrılır (parantez yok!)
```

```python
# ❌ Bu kod ÇALIŞMAZ — property parantezle çağrılamaz
print(d.alan())
```

Bu, `TypeError: 'int' object is not callable` verir; çünkü `d.alan`
zaten hesaplanmış bir değerdir, bir fonksiyon değildir.

## Özel Metodlar (Dunder Methods)

```python
# ✅ Bu kod çalışır — __str__ ve __eq__ nesnenin davranışını özelleştirir
class Nokta:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __str__(self):
        return f"Nokta({self.x}, {self.y})"

    def __eq__(self, diger):
        return self.x == diger.x and self.y == diger.y

n1 = Nokta(1, 2)
n2 = Nokta(1, 2)
print(n1)          # Nokta(1, 2) — __str__ sayesinde okunaklı
print(n1 == n2)    # True — __eq__ sayesinde içerik karşılaştırılır
```

```python
# ❌ Bu kod farklı davranır — __eq__ tanımlanmasaydı,
# Python varsayılan olarak sadece "aynı bellek adresi mi?" diye
# bakardı, bu yüzden aşağıdaki False dönerdi (mantık hatası):
class NoktaBasit:
    def __init__(self, x, y):
        self.x, self.y = x, y

a = NoktaBasit(1, 2)
b = NoktaBasit(1, 2)
print(a == b)   # False! (__eq__ tanımlanmadığı için)
```

## Çoklu Kalıtım ve `super()`

```python
# ✅ Bu kod çalışır
class Calisan:
    def __init__(self, isim, maas):
        self.isim = isim
        self.maas = maas

class Yazilimci(Calisan):
    def __init__(self, isim, maas, dil):
        super().__init__(isim, maas)   # üst sınıfın __init__'ini çağırır
        self.dil = dil

y = Yazilimci("Kaan", 50000, "Python")
print(y.isim, y.maas, y.dil)
```

## Soyut Sınıflar (Abstract Base Class)

```python
# ✅ Bu kod çalışır
from abc import ABC, abstractmethod

class Sekil(ABC):
    @abstractmethod
    def alan_hesapla(self):
        pass

class Kare(Sekil):
    def __init__(self, kenar):
        self.kenar = kenar

    def alan_hesapla(self):
        return self.kenar ** 2

print(Kare(4).alan_hesapla())   # 16
```

```python
# ❌ Bu kod ÇALIŞMAZ — soyut sınıf doğrudan örneklenemez
sekil = Sekil()
```

Bu, `TypeError: Can't instantiate abstract class Sekil with abstract
method alan_hesapla` verir. `ABC`'nin amacı tam olarak budur: alt
sınıfları belirli metodları uygulamaya **zorlar**.

---
⬅️ [Geri](./README.md) &nbsp;|&nbsp; ➡️ [Dekoratörler ve Generatörler](./02-Dekoratorler-ve-Generatorler.md)
