# Python Orta Kademe (TR)

Temel kademeyi bitirdiysen artık gerçek projelere daha yakın konulara
geçiyoruz: ileri OOP, dekoratörler/generatörler, dosya formatları,
paket yönetimi ve test yazımı.

## Bölümler

1. [İleri Nesne Yönelimli Programlama](./01-Ileri-OOP.md)
2. [Dekoratörler ve Generatörler](./02-Dekoratorler-ve-Generatorler.md)
3. [Veri Formatları: JSON ve CSV](./03-JSON-ve-CSV.md)
4. [Modüller, Paketler ve Sanal Ortamlar](./04-Moduller-Paketler-Sanal-Ortamlar.md)
5. [Test Yazımı ve Hata Ayıklama](./05-Test-Yazimi-ve-Hata-Ayiklama.md)

Bitirince ➡️ [Üst Düzey Kademe](../Python-Ust-Duzey-Kademe-TR/README.md)
