# 4. Modüller, Paketler ve Sanal Ortamlar

## Modül Nedir?

Herhangi bir `.py` dosyası bir **modüldür**. Kodu farklı dosyalara
bölmek, projeyi düzenli ve yeniden kullanılabilir yapar.

```python
# ✅ Bu kod çalışır — matematik.py adlı bir dosya oluştur:
# ---- matematik.py ----
def topla(a, b):
    return a + b

def carp(a, b):
    return a * b
```

```python
# ✅ Bu kod çalışır — ana dosyada (main.py) o modülü içe aktar:
# ---- main.py ----
import matematik

print(matematik.topla(3, 4))     # 7
print(matematik.carp(3, 4))      # 12

# Alternatif kullanım şekilleri:
from matematik import topla
print(topla(1, 2))                # 3
```

```python
# ❌ Bu kod ÇALIŞMAZ — dosya adı yanlış yazılmış (typo)
import matematikk
```

Bu, `ModuleNotFoundError: No module named 'matematikk'` verir.

## Paket (Package) Nedir?

Bir **paket**, içinde `__init__.py` bulunan bir klasördür; birden
fazla modülü bir araya toplamayı sağlar.

```
proje/
├── main.py
└── yardimcilar/
    ├── __init__.py
    ├── matematik.py
    └── metin.py
```

```python
# ✅ Bu kod çalışır
from yardimcilar import matematik
from yardimcilar.metin import buyuk_harf_yap
```

Bu yapı, 4R022 PyQt6 projelerindeki `core/` + `ui/` modüler mimarisinin
temelidir.

## pip ile Paket Yönetimi

```bash
# ✅ Bu komutlar çalışır
pip install requests          # tek paket kurar
pip install requests numpy    # birden fazla paket kurar
pip freeze > requirements.txt # kurulu paketleri dosyaya kaydeder
pip install -r requirements.txt  # o dosyadaki tüm paketleri kurar
```

## Sanal Ortam (Virtual Environment) Neden Gerekli?

Her projenin kendi bağımsız paket kütüphanesi olmasını sağlar; bir
projede `flask==2.0`, başka bir projede `flask==3.0` kullanman
gerektiğinde çakışmayı önler.

```bash
# ✅ Bu komutlar çalışır (terminalde, proje klasöründe)
python -m venv venv              # 'venv' adlı sanal ortam oluşturur

# Windows'ta etkinleştirme:
venv\Scripts\activate

# macOS / Linux'ta etkinleştirme:
source venv/bin/activate

# Artık bu ortamdaki pip install'lar sadece bu projeyi etkiler
pip install requests
```

```bash
# ❌ Bu ÇALIŞMAZ — sanal ortam aktifleştirilmeden 'deactivate' çağrılmış
# gibi bir işlem yapılırsa ya da yanlış script çalıştırılırsa hata alınır;
# en sık hata: Windows'ta yanlışlıkla Linux komutunu kullanmak:
source venv/bin/activate    # Windows cmd'de bu komut tanınmaz
```

Windows `cmd`'de doğrusu `venv\Scripts\activate` veya PowerShell'de
`venv\Scripts\Activate.ps1`'dir.

### 🎯 Mini Alıştırma
`sekiller.py` adlı bir modül oluştur (daire ve kare alanı hesaplayan
fonksiyonlarla), sonra `main.py`'den içe aktarıp kullan. Ardından bir
sanal ortam kurup içine `requests` paketini kur.

---
⬅️ [JSON ve CSV](./03-JSON-ve-CSV.md) &nbsp;|&nbsp; ➡️ [Test Yazımı ve Hata Ayıklama](./05-Test-Yazimi-ve-Hata-Ayiklama.md)
