# 2. Dekoratörler ve Generatörler

## Dekoratör Nedir?

Bir dekoratör, başka bir fonksiyonu "sarmalayan" ve onun davranışını
değiştiren/genişleten bir fonksiyondur.

```python
# ✅ Bu kod çalışır
import time

def zaman_olc(fonksiyon):
    def sarmalayici(*args, **kwargs):
        baslangic = time.time()
        sonuc = fonksiyon(*args, **kwargs)
        bitis = time.time()
        print(f"{fonksiyon.__name__} {bitis - baslangic:.4f} saniye sürdü")
        return sonuc
    return sarmalayici

@zaman_olc
def uzun_islem():
    time.sleep(1)
    return "bitti"

uzun_islem()
```

`@zaman_olc`, `uzun_islem = zaman_olc(uzun_islem)` yazmanın kısa
yoludur.

```python
# ❌ Bu kod ÇALIŞMAZ — iç fonksiyon (sarmalayici) bir değer döndürmüyor,
# bu yüzden dekore edilen fonksiyonun asıl sonucu kayboluyor:
def loglayici(fonksiyon):
    def sarmalayici(*args, **kwargs):
        fonksiyon(*args, **kwargs)   # 'return' unutulmuş!
    return sarmalayici

@loglayici
def carp(a, b):
    return a * b

sonuc = carp(3, 4)
print(sonuc)   # None yazdırır, 12 DEĞİL — bu bir mantık hatası
```

## Generatör (`yield`) Nedir?

Normal bir fonksiyon `return` ile biter ve tüm sonucu tek seferde
hafızaya koyar. Bir **generatör**, `yield` ile değerleri **teker
teker**, istendikçe üretir — büyük veri setlerinde hafızadan tasarruf
sağlar.

```python
# ✅ Bu kod çalışır
def sayilar_uret(n):
    for i in range(n):
        yield i * i

for kare in sayilar_uret(5):
    print(kare)   # 0, 1, 4, 9, 16 — teker teker üretilir
```

```python
# ✅ Bu kod çalışır — generatör ifadesi (generator expression)
# köşeli parantez yerine parantez kullanılır
kareler = (x * x for x in range(1_000_000))
print(next(kareler))   # 0 — sadece istenen değer hesaplanır
print(next(kareler))   # 1
```

```python
# ❌ Bu kod, milyonlarca elemanı ANINDA hafızaya koyar (verimsiz)
# generatöre göre çok daha fazla RAM tüketir:
kareler_liste = [x * x for x in range(10_000_000)]  # tüm liste hafızada!
```

Yukarıdaki kod "çalışır" ama büyük veri setlerinde ciddi bellek
sorununa yol açabilir — bu yüzden büyük/sonsuz veri akışlarında
generatör tercih edilir.

### 🎯 Mini Alıştırma
`fibonacci(n)` adlı bir generatör fonksiyon yaz; ilk `n` Fibonacci
sayısını `yield` ile teker teker üretsin.

---
⬅️ [İleri OOP](./01-Ileri-OOP.md) &nbsp;|&nbsp; ➡️ [JSON ve CSV](./03-JSON-ve-CSV.md)
