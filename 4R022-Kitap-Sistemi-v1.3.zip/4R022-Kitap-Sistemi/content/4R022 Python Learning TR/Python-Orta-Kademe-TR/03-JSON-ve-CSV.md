# 3. Veri Formatları: JSON ve CSV

## JSON — Yapılandırılmış Veri Değişimi

JSON (JavaScript Object Notation), web API'leri ve konfigürasyon
dosyalarında en yaygın kullanılan veri formatıdır; Python `dict`
yapısına çok benzer.

```python
# ✅ Bu kod çalışır — Python dict'i JSON dosyasına yazar
import json

ayarlar = {"tema": "koyu", "dil": "tr", "surum": 2}

with open("ayarlar.json", "w", encoding="utf-8") as f:
    json.dump(ayarlar, f, ensure_ascii=False, indent=4)

# ✅ Bu kod çalışır — JSON dosyasını okuyup Python dict'ine çevirir
with open("ayarlar.json", "r", encoding="utf-8") as f:
    okunan = json.load(f)
    print(okunan["tema"])   # "koyu"
```

```python
# ❌ Bu kod ÇALIŞMAZ — bozuk (geçersiz) bir JSON string'i çözümlenmeye
# çalışılıyor (tek tırnak, JSON'da geçerli değildir!)
import json
veri = json.loads("{'tema': 'koyu'}")   # tek tırnak hatalı!
```

Bu, `json.decoder.JSONDecodeError` verir. JSON standardı **çift
tırnak** ister; Python dict söz dizimiyle karıştırmamak gerekir.

Bu desen, 4R022'nin arşiv ve ayar sistemlerinde de kullanılan
**atomik JSON yazma** (`.bak` yedeğiyle) prensibinin temelidir.

## CSV — Tablo Verisi

```python
# ✅ Bu kod çalışır — CSV dosyasına satır satır yazar
import csv

ogrenciler = [
    ["isim", "not"],
    ["Kaan", 95],
    ["Ayşe", 88],
]

with open("notlar.csv", "w", newline="", encoding="utf-8") as f:
    yazici = csv.writer(f)
    yazici.writerows(ogrenciler)

# ✅ Bu kod çalışır — CSV dosyasını okur
with open("notlar.csv", "r", encoding="utf-8") as f:
    okuyucu = csv.reader(f)
    for satir in okuyucu:
        print(satir)
```

```python
# ❌ Bu kod ÇALIŞMAZ (Windows'ta) — 'newline=""' unutulursa
# CSV dosyasında satırlar arasında fazladan boş satırlar oluşur
# (bu bir çalışma zamanı hatası değil, sinsi bir biçim hatasıdır):
with open("notlar.csv", "w", encoding="utf-8") as f:   # newline="" eksik!
    yazici = csv.writer(f)
    yazici.writerows(ogrenciler)
```

### 🎯 Mini Alıştırma
Bir öğrenci listesini (`isim`, `not`) hem JSON hem CSV olarak kaydeden,
sonra geri okuyup ortalamayı hesaplayan bir program yaz.

---
⬅️ [Dekoratörler ve Generatörler](./02-Dekoratorler-ve-Generatorler.md) &nbsp;|&nbsp; ➡️ [Modüller, Paketler, Sanal Ortamlar](./04-Moduller-Paketler-Sanal-Ortamlar.md)
