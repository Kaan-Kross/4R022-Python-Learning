# Python ile Veri Kavramları (TR)

Bu bölüm, [Modüller ve Kullanımları](../Python-Moduller-ve-Kullanimlari-TR/README.md)
bölümünden **kasıtlı olarak ayrıdır.** Modüller bölümü "bu modülü
Python'da nasıl kullanırım?" sorusuna cevap verirken, bu bölüm daha
temel bir soruya odaklanır: **"Bu veri türü/sistemi aslında nedir,
nasıl çalışır, gerçek dünyada nasıl entegre edilir, otomatikleştirilir,
içeri/dışarı nasıl aktarılır?"** Yani burada `json` veya `sqlite3`
modülünün fonksiyonlarını değil, **JSON'ın, CSV'nin, veritabanının
kendisinin** ne olduğunu, neden var olduğunu ve gerçek sistemlerde
nasıl kullanıldığını anlatıyoruz.

## Bölümler

1. [JSON Verisi Nedir?](./01-JSON-Verisi-Nedir.md)
2. [CSV Verisi Nedir?](./02-CSV-Verisi-Nedir.md)
3. [Veritabanı ve SQLite Nedir?](./03-Veritabani-ve-SQLite-Nedir.md)

Kodlama tarafını (Python'da nasıl okur/yazarım) öğrenmek için
[Modüller ve Kullanımları](../Python-Moduller-ve-Kullanimlari-TR/README.md)
bölümündeki [json](../Python-Moduller-ve-Kullanimlari-TR/03-json/README.md),
[csv](../Python-Moduller-ve-Kullanimlari-TR/04-csv/README.md) ve
[sqlite3](../Python-Moduller-ve-Kullanimlari-TR/15-sqlite3/README.md)
klasörlerine bakabilirsin.

⬅️ [Üst Düzey Kademe](../Python-Ust-Duzey-Kademe-TR/README.md) &nbsp;|&nbsp; ➡️ [Modüller ve Kullanımları](../Python-Moduller-ve-Kullanimlari-TR/README.md)
