# 3. Veritabanı ve SQLite Nedir?

## Veritabanı Nedir, Neden Gerekir?

Bir veritabanı, veriyi **düzenli, sorgulanabilir ve tutarlı** şekilde
saklayan bir sistemdir. "Neden bir JSON/CSV dosyası yeterli değil?"
sorusunun cevabı şudur: veri büyüdükçe (binlerce/milyonlarca kayıt),
düz dosyalarda **arama yapmak yavaşlaşır**, **aynı anda birden fazla
kullanıcının güvenli şekilde yazması zorlaşır**, ve **veri tutarlılığı
(örneğin "bu sipariş var olmayan bir müşteriye ait olamaz" gibi
kurallar) garanti edilemez.** Veritabanları tam olarak bu sorunları
çözmek için tasarlanmıştır.

## İlişkisel Veritabanı Mantığı (Kısaca)

En yaygın veritabanı türü **ilişkisel (relational)** veritabanıdır —
veri, birbirine bağlı **tablolar** halinde tutulur:

```
ogrenciler tablosu:          notlar tablosu:
+----+-------+              +----+---------------+-------+
| id | isim  |              | id | ogrenci_id    | not   |
+----+-------+              +----+---------------+-------+
| 1  | Kaan  |              | 1  | 1             | 95    |
| 2  | Ayşe  |              | 2  | 2             | 88    |
+----+-------+              +----+---------------+-------+
```

`notlar` tablosundaki `ogrenci_id`, `ogrenciler` tablosundaki `id`'ye
**bağlanır (foreign key)** — bu bağlantı sayesinde "Kaan'ın tüm
notlarını getir" gibi sorgular hızlı ve tutarlı şekilde yapılabilir.
Bu sorgular **SQL (Structured Query Language)** ile yazılır.

## SQLite Nedir, Diğer Veritabanlarından Farkı Nedir?

SQLite, **sunucu gerektirmeyen**, tüm veritabanının **tek bir dosyada**
tutulduğu hafif bir ilişkisel veritabanı motorudur. PostgreSQL veya
MySQL gibi veritabanlarının aksine, ayrı bir "veritabanı sunucusu"
kurup çalıştırmana gerek yoktur — Python'ın `sqlite3` modülü
üzerinden doğrudan bir `.db` dosyasına bağlanırsın.

| Kriter | SQLite | PostgreSQL / MySQL |
|---|---|---|
| Kurulum | Gerekmez (dosya tabanlı) | Sunucu kurulumu gerekir |
| Eşzamanlı çoklu kullanıcı | Sınırlı | Güçlü |
| Kullanım alanı | Masaüstü uygulamalar, mobil, prototip | Web siteleri, büyük ölçekli sistemler |
| Veri boyutu | GB seviyesine kadar rahat | TB seviyesine kadar ölçeklenir |

## Sistemler Veritabanını Nasıl Entegre Eder?

1. **Masaüstü uygulamaları:** 4R022 Arşiv ve Cüzdanım gibi
   projelerde, kullanıcı verisi (kayıtlar, işlemler) doğrudan yerel
   bir SQLite dosyasında tutulur — internet bağlantısı gerekmez.
2. **Web uygulamaları:** Bir web sitesinin backend'i (Flask/Django),
   kullanıcı hesaplarını, siparişlerini genelde PostgreSQL/MySQL gibi
   sunucu tabanlı bir veritabanında tutar.
3. **ORM (Object-Relational Mapping):** SQLAlchemy gibi araçlar, SQL
   yazmadan Python nesneleriyle veritabanını yönetmeni sağlar — "veri
   ile kod arasındaki köprü" görevi görür.

## Veri Nasıl Güncellenir, Yenilenir, Yedeklenir?

- **CRUD işlemleri:** Veritabanı verisi `INSERT` (ekle), `SELECT`
  (oku), `UPDATE` (güncelle), `DELETE` (sil) komutlarıyla değişir —
  bu dört işlem, hemen her uygulamanın temelidir.
- **Migrasyon (schema migration):** Bir uygulama güncellendiğinde
  veritabanı yapısı da değişebilir (yeni bir sütun eklemek gibi);
  bu değişiklikler "migration" script'leriyle kontrollü şekilde
  uygulanır.
- **Yedekleme:** SQLite'ta yedekleme genelde `.db` dosyasının
  kopyalanması kadar basittir; sunucu tabanlı veritabanlarında
  `pg_dump` (PostgreSQL) gibi özel araçlar kullanılır.

## Dışa/İçe Aktarım ve Otomasyon

- Bir veritabanındaki tabloyu CSV'ye "dışa aktarmak", raporlama
  araçlarına veri sağlamanın en yaygın yoludur.
- Otomatik yedekleme script'leri, her gece veritabanını yedekleyip
  eski yedekleri (örneğin 30 günden eski olanları) otomatik silecek
  şekilde zamanlanabilir (bkz.
  [datetime](../Python-Moduller-ve-Kullanimlari-TR/05-datetime/README.md) modülü).

## Sınırları Nelerdir?

- SQLite, **çok sayıda eşzamanlı yazma işlemi** gerektiren büyük web
  uygulamaları için uygun değildir (aynı anda tek bir yazma
  işlemine izin verir).
- İlişkisel veritabanları, esnek/değişken yapıdaki veriler
  (örneğin her kaydın farklı alanlara sahip olabildiği durumlar)
  için bazen fazla katı kalabilir — bu durumlarda "NoSQL"
  veritabanları (MongoDB gibi) tercih edilebilir.

---
⬅️ [CSV Verisi Nedir?](./02-CSV-Verisi-Nedir.md) &nbsp;|&nbsp; ⬆️ [Veri Kavramları Ana Sayfa](./README.md)

🎓 Bu bölümü bitirdiysen, kodlama tarafı için
[Modüller ve Kullanımları](../Python-Moduller-ve-Kullanimlari-TR/README.md)
bölümündeki `json`, `csv` ve `sqlite3` klasörlerine göz atabilirsin.
