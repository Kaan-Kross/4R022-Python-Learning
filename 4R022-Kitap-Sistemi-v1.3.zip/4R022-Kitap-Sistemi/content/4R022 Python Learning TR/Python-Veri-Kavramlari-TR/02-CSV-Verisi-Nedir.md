# 2. CSV Verisi Nedir?

## Kökeni ve Ne Olduğu

CSV (Comma-Separated Values / Virgülle Ayrılmış Değerler), 1970'lerden
beri kullanılan, tablo verisini **düz metin** olarak temsil eden en
eski ve en basit veri formatlarından biridir. Karmaşık bir standardı
yoktur (RFC 4180 bir öneri niteliğindedir, zorunlu değildir) — bu
yüzden hem en kolay öğrenilen hem de en çok "küçük farklılık"
sorunları yaşanan formatlardan biridir.

## Yapısı Nasıldır?

Her satır bir kayıt, her satırdaki değerler bir ayraçla (genelde
virgül, bazen noktalı virgül veya tab) ayrılmış sütunlardır:

```csv
isim,yas,sehir
Kaan,25,Sakarya
Ayşe,22,İstanbul
"Mehmet, Ali",30,Ankara
```

Dikkat: üçüncü satırda isim virgül içerdiği için **tırnak içine**
alınmış — bu, CSV ayrıştırıcılarının (parser) anlaması gereken temel
kurallardan biridir (bu yüzden ham `split(",")` yerine gerçek bir CSV
kütüphanesi kullanılması gerekir).

## Neden Hâlâ Bu Kadar Yaygın?

- **Excel/Google Sheets'in evrensel değişim formatı** — hemen her
  tablo programı CSV'yi içe/dışa aktarabilir.
- **İnsan gözüyle de okunabilir** (küçük dosyalarda) — bir metin
  editörüyle bile açılıp incelenebilir.
- **Veritabanlarının standart aktarım formatı** — çoğu veritabanı
  yönetim aracı, tabloları CSV olarak dışa aktarabilir/içe alabilir.

## Sistemler CSV'yi Nasıl Entegre Eder?

1. **Muhasebe/ERP sistemleri:** Bir şirketin muhasebe yazılımı,
   aylık satış raporunu CSV olarak dışa aktarır; bu dosya başka bir
   analiz aracına (Excel, Python script'i, Power BI) aktarılır.
2. **Veri bilimi iş akışları:** Ham veri genelde CSV olarak
   toplanır, `pandas` ile okunur, temizlenir ve analiz edilir.
3. **Toplu içe aktarma (bulk import):** Bir web sitesine yüzlerce
   ürünü tek tek elle girmek yerine, bir CSV şablonu doldurulup
   sisteme "toplu yükle" özelliğiyle aktarılır.

## Nasıl Güncellenir / Otomatikleştirilir?

- **Zamanlanmış dışa aktarım:** Birçok sistem, her gece/hafta
  otomatik olarak güncel veriyi bir CSV dosyasına "damgalar"
  (örneğin `satislar_2026-09-15.csv`).
- **CSV izleme script'leri:** Bir otomasyon script'i, belirli bir
  klasörü izleyip yeni bir CSV dosyası düştüğünde onu otomatik
  olarak işleyip bir veritabanına aktarabilir (ETL — Extract,
  Transform, Load — sürecinin basit bir örneği).
- **E-tablo entegrasyonları:** Google Sheets, bir CSV'yi "bağlantılı
  sayfa" olarak tutup periyodik yenileyebilir.

## Dışa/İçe Aktarım Pratikleri

- **Dışa aktarma:** `pandas.DataFrame.to_csv()` gibi araçlarla bir
  tablo, tek satırlık kodla CSV'ye dönüştürülebilir.
- **İçe aktarma:** Farklı sistemler farklı ayraç/kodlama (encoding)
  kullanabilir (Türkçe kaynaklı CSV'lerde sık görülen `windows-1254`
  kodlaması gibi) — içe aktarırken bunu göz önünde bulundurmak,
  "bozuk Türkçe karakter" sorununu önler.

## Sınırları Nelerdir?

- **Veri tipi bilgisi taşımaz** — her şey metindir; `"95"` sayı mı
  yoksa metin mi, CSV'nin kendisi bunu belirtmez, okuyan program
  tahmin eder/yorumlar.
- **İç içe (nested) veri temsil edemez** — JSON'daki gibi bir
  nesnenin içinde başka bir nesne/liste barındıramaz; yalnızca düz
  tablolar için uygundur.
- **Standart tutarsızlığı** — ayraç (virgül mü noktalı virgül mü),
  satır sonu karakteri (Windows `\r\n` vs Unix `\n`) ve kodlama
  (encoding) farklılıkları, sistemler arası aktarımda en sık
  karşılaşılan sorun kaynağıdır.

---
⬅️ [JSON Verisi Nedir?](./01-JSON-Verisi-Nedir.md) &nbsp;|&nbsp; ➡️ [Veritabanı ve SQLite Nedir?](./03-Veritabani-ve-SQLite-Nedir.md)
