# 1. JSON Verisi Nedir?

## JSON'ın Kökeni ve Ne Olduğu

JSON (JavaScript Object Notation), adından da anlaşılacağı gibi
JavaScript dilinin nesne söz diziminden doğmuş, ama zamanla **dil
bağımsız, evrensel bir veri değişim formatı** haline gelmiş bir metin
formatıdır. 2001 civarında Douglas Crockford tarafından
popülerleştirilmiş, bugün RFC 8259 standardıyla tanımlanmıştır. JSON,
insan tarafından okunabilir olmasıyla (XML'e göre çok daha sade) ve
neredeyse her programlama dilinin onu doğal olarak okuyup
yazabilmesiyle öne çıkar.

## Yapısı Nasıldır?

JSON, yalnızca **6 temel yapı taşından** oluşur:

| Yapı | Örnek |
|---|---|
| Nesne (object) | `{"isim": "Kaan"}` |
| Dizi (array) | `[1, 2, 3]` |
| Metin (string) | `"merhaba"` |
| Sayı (number) | `42`, `3.14` |
| Boolean | `true`, `false` |
| Boş değer | `null` |

Bunlar iç içe geçerek her türlü karmaşık veriyi temsil edebilir:

```json
{
  "kullanici": "Kaan",
  "aktif": true,
  "yas": 25,
  "roller": ["yazilimci", "ogrenci"],
  "adres": {
    "sehir": "Sakarya",
    "ulke": "Türkiye"
  },
  "ikinci_telefon": null
}
```

## Neden Bu Kadar Yaygın?

- **Web API'lerinin ortak dili** — bir mobil uygulama, bir web
  sitesi ve bir sunucu farklı dillerle (Swift, JavaScript, Python)
  yazılmış olsa bile, JSON sayesinde birbirleriyle sorunsuz veri
  alışverişi yapabilir.
- **İnsan tarafından okunabilir** — bir geliştirici, ham JSON
  dosyasını açıp neredeyse hiç belge okumadan içeriği anlayabilir.
- **Hafif** — XML'e göre daha az "gürültü" (etiket tekrarı) içerir.

## Sistemler JSON'ı Nasıl Entegre Eder?

1. **API iletişimi:** Bir mobil uygulama, sunucuya "kullanıcı
   girişi" isteği gönderir → sunucu, kullanıcı bilgisini JSON olarak
   geri döndürür → uygulama bu JSON'ı ayrıştırıp ekrana kullanıcı
   adını yazdırır.
2. **Konfigürasyon dosyaları:** Birçok uygulama (VS Code, npm
   projeleri) ayarlarını `.json` dosyalarında saklar — insan
   elle düzenleyebilir, program da kolayca okuyabilir.
3. **Veri gölü/log sistemleri:** Sunucu logları genelde
   "JSON Lines" (her satır ayrı bir JSON nesnesi) formatında
   tutulur; bu, log analiz araçlarının (Elasticsearch gibi) veriyi
   kolayca ayrıştırmasını sağlar.

## Nasıl Güncellenir / Yenilenir (Refresh)?

JSON, kendi başına "canlı" bir veri değildir — bir **anlık görüntü
(snapshot)**dür. Bir uygulamanın JSON verisini güncel tutması için
genelde şu desenlerden biri kullanılır:

- **Periyodik çekme (polling):** İstemci, belirli aralıklarla
  ("her 30 saniyede bir") sunucudan yeni JSON ister.
- **Anlık bildirim (webhook/websocket):** Sunucu, veri değiştiğinde
  istemciye kendisi yeni JSON gönderir (daha verimli, gerçek
  zamanlıya yakın).
- **Dosya tabanlı:** Yerel bir uygulama (4R022 masaüstü araçları
  gibi), ayarları her değiştiğinde JSON dosyasını yeniden yazar
  (atomik yazma deseniyle, veri kaybını önleyerek).

## Otomasyon ve Dışa/İçe Aktarım

- **Dışa aktarma (export):** Bir uygulama, kullanıcı verisini
  "yedekle" dediğinde genelde tüm veriyi tek bir JSON dosyasına
  yazar — bu dosya, taşınabilir ve okunabilir bir yedektir.
- **İçe aktarma (import):** Başka bir sistemden (örneğin eski bir
  uygulamadan) veri taşırken, kaynak sistem veriyi JSON'a döker,
  hedef sistem bu JSON'ı okuyup kendi veritabanına/yapısına aktarır.
- **Otomasyon script'leri:** Bir script, her gece çalışıp bir API'den
  veri çekip yerel bir JSON dosyasına kaydedebilir (örneğin döviz
  kurlarını günlük olarak arşivlemek).

## Sınırları Nelerdir?

- **Yorum satırı desteklemez** — resmi JSON standardında `//` veya
  `/* */` ile yorum yazamazsın (bu yüzden bazı araçlar "JSON5" veya
  "JSONC" gibi genişletilmiş varyantlar kullanır).
- **Büyük veri için verimsiz olabilir** — milyonlarca satırlık tablo
  verisi için CSV veya bir veritabanı genelde daha uygundur.
- **Şema (schema) zorunluluğu yoktur** — bir JSON dosyasının
  "doğru" yapıda olduğunu garanti eden bir mekanizma standart olarak
  yoktur (JSON Schema gibi ek araçlar bunun için geliştirilmiştir).

---
⬅️ [Geri](./README.md) &nbsp;|&nbsp; ➡️ [CSV Verisi Nedir?](./02-CSV-Verisi-Nedir.md)
