<div align="center">

<img src="./assets/4r022-logo.png" alt="4R022 Python Learning Logo" width="220"/>

# 4R022 Python Learning (TR)

**Sıfırdan uzman seviyeye, öğretmen üslubuyla kapsamlı Python eğitim kaynağı**

Marka: **4R022** &nbsp;•&nbsp; Yazar: **Kaan Kross**

</div>

---

## Bu Kaynak Nedir?

**4R022 Python Learning**, bilişim öğrencileri ve Python'a yeni
başlayanlar için sıfırdan tasarlanmış, adım adım ilerleyen, örnek kod
odaklı bir öğrenim kaynağıdır. Bu, internetten derlenmiş rastgele bir
proje değildir — bkz. [`HAKKINDA-4R022.txt`](./HAKKINDA-4R022.txt).

> 🌍 Bu proje 5 dili destekler: Türkçe (bu paket — tam), İngilizce,
> Rusça, Fransızca, Almanca. Her dil kendi ayrı ZIP paketinde sunulur;
> bu yüzden bu pakette yalnızca Türkçe içerik bulunur.

## Klasör Yapısı

```
4R022 Python Learning TR/
├── Python-Nedir-ve-Genel-Bakis-TR/      → Python nedir, diğer diller, kullanım alanları
├── Python-Temel-Egitim-TR/              → Temel Kademe (Başlangıç)
├── Python-Orta-Kademe-TR/               → Orta Kademe
├── Python-Ust-Duzey-Kademe-TR/          → Üst Düzey Kademe (İleri)
├── Python-Veri-Kavramlari-TR/           → JSON, CSV, Veritabanı/SQLite kavramları (modüllerden bağımsız, kavramsal)
├── Python-Moduller-ve-Kullanimlari-TR/  → Her modül kendi klasöründe (30+ modül)
├── Python-Etik-ve-Guvenlik-TR/          → Etik, sorumluluk, hacker tipleri
├── LICENSE.txt
└── HAKKINDA-4R022.txt
```

## Nasıl Kullanılır?

1. Hiç Python bilmiyorsan → `Python-Nedir-ve-Genel-Bakis-TR/` ile başla.
2. Sonra → `Python-Temel-Egitim-TR/` klasöründeki bölümleri sırayla takip et.
3. Temelleri bitirdikten sonra → `Python-Orta-Kademe-TR/` → `Python-Ust-Duzey-Kademe-TR/`.
4. Veri formatlarını (JSON/CSV/veritabanı) kavramsal olarak anlamak istiyorsan → `Python-Veri-Kavramlari-TR/`.
5. Belirli bir modülü (numpy, flask, PyQt6 vb.) öğrenmek istiyorsan → `Python-Moduller-ve-Kullanimlari-TR/`.
6. Etik, hukuki sınırlar ve "hacker" kavramlarını doğru anlamak istiyorsan → `Python-Etik-ve-Guvenlik-TR/`.

Her bölümde:
- ✅ **Birden fazla çalışan kod örneği**
- ❌ **Birden fazla yanlış/çalışmayan örnek** — her biri "Neden
  yanlış? Hata nerede? Ne kullanmalısın?" açıklamasıyla
- 🧑‍🏫 Öğretmen üslubuyla, kullanıcı dostu anlatım
- 🎯 Bölüm sonu küçük alıştırmalar

## Lisans

Bu kaynak **eğitim amaçlı** ücretsiz kullanılabilir, çatallanabilir
(fork) ve okunabilir. Ticari amaçla yeniden satılamaz veya "4R022"
markası kaldırılarak kendi eserin gibi dağıtılamaz. Ayrıntı için
[`LICENSE.txt`](./LICENSE.txt).

---

<div align="center">

Made with 🖤 by **Kaan Kross** — brand **4R022**

</div>
