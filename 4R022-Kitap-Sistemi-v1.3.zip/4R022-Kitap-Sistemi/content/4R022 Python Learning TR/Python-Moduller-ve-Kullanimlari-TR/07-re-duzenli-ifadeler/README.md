# `re` Modülü (Düzenli İfadeler / Regular Expressions)

## Nedir ve Çalışma Prensibi Nedir?

`re` modülü, metin içinde **desen (pattern) arama** yapmanı sağlar.
Düzenli ifadeler (regex), belirli bir kuralı tanımlayan özel bir
mini-dildir (örneğin "önce rakam, sonra @ işareti, sonra harfler").
Python, bu deseni bir **durum makinesine (state machine)** çevirir ve
metni bu makineyle karakter karakter tarar.

## Ne Zaman / Nerede Kullanılır?

- E-posta, telefon numarası, URL gibi formatları doğrulamak
- Log dosyalarından belirli bilgileri (hata kodları, IP adresleri)
  ayıklamak
- Metinde bul-değiştir işlemleri (basit `str.replace()`'in yetersiz
  kaldığı, desen bazlı değiştirmeler)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit desen arama
import re
metin = "İletişim: kaan@4r022.com"
sonuc = re.search(r"[\w.]+@[\w.]+", metin)
print(sonuc.group())   # kaan@4r022.com
```

```python
# Örnek 2: Tüm eşleşmeleri bulma
import re
metin = "Telefon: 0555 111 22 33, Yedek: 0532 999 88 77"
numaralar = re.findall(r"0\d{3} \d{3} \d{2} \d{2}", metin)
print(numaralar)
```

```python
# Örnek 3: Bul-değiştir
import re
metin = "2026-09-15"
yeni = re.sub(r"-", "/", metin)
print(yeni)   # 2026/09/15
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Ters Eğik Çizgiyi Kaçış (Escape) Karakteri Sanmamak

```python
import re
desen = re.compile("\d+")   # 'r' öneki yok!
```

- **Neden yanlış?** Kod genelde "çalışır" ama karmaşık desenlerde
  Python'ın kendi kaçış karakterleri (`\n`, `\t` gibi) ile regex'in
  kaçış karakterleri **çakışabilir**, bu da sinsi hatalara yol açar.
- **Hata nerede?** String'in başına `r` (raw string) öneki
  eklenmemiş.
- **Ne kullanmalısın?** Düzenli ifadelerde her zaman `r"\d+"` gibi
  **raw string** kullan — bu, Python'ın kaçış karakteri yorumlamasını
  devre dışı bırakır.

### Yanlış Örnek 2 — `match()` ile `search()`'ü Karıştırmak

```python
import re
metin = "Merhaba, benim numaram 12345"
sonuc = re.match(r"\d+", metin)
print(sonuc.group())
```

- **Neden yanlış?** `re.match()` yalnızca **string'in başından**
  eşleşme arar; burada string "Merhaba" ile başlıyor, sayı ile değil.
- **Hata nerede?** `sonuc` `None` döner, `.group()` çağrısı
  `AttributeError: 'NoneType' object has no attribute 'group'` verir.
- **Ne kullanmalısın?** String'in **herhangi bir yerinde** arama
  yapmak için `re.search(r"\d+", metin)` kullan.

### Yanlış Örnek 3 — Aşırı Karmaşık, Okunmaz Tek Satır Regex Yazmak

```python
import re
# E-posta doğrulamak için "her şeyi çözen" dev bir regex yazmaya çalışmak
desen = r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
```

- **Neden yanlış?** Teknik olarak çalışabilir ama **bakımı ve
  hata ayıklaması neredeyse imkânsızdır** — bu bir "kod kokusu"dur
  (code smell), syntax hatası değil.
- **Hata nerede?** Tek bir regex'e gerçek dünyanın tüm e-posta
  kurallarını sıkıştırmaya çalışmak.
- **Ne kullanmalısın?** Basit bir kontrol için `"@" in metin and "."
  in metin` yeterli olabilir; tam doğrulama gerekiyorsa `email-
  validator` gibi hazır, test edilmiş bir kütüphane kullan.

## 🔗 İlgili Modüller
[collections](../08-collections/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
