# `qrcode` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`qrcode`, verilen bir metni (URL, kimlik bilgisi, ödeme linki) bir
**QR kod görseline** dönüştüren üçüncü parti bir kütüphanedir
(`pip install qrcode[pil]`). Arka planda, metni QR kod standardının
hata düzeltme algoritmalarıyla (Reed-Solomon) kodlayıp bunu siyah-
beyaz bir piksel matrisine (görsele) çevirir.

## Ne Zaman / Nerede Kullanılır?

- Bir Wi-Fi şifresini veya bağlantı bilgisini kolayca paylaşmak
- Etkinlik biletlerinde, menülerde bağlantı/veri paylaşımı
- İki faktörlü kimlik doğrulama (2FA) kurulum ekranları

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit QR kod oluşturma
import qrcode
img = qrcode.make("https://github.com/4R022")
img.save("qr.png")
```

```python
# Örnek 2: Özelleştirilmiş QR kod (renk, boyut)
import qrcode
qr = qrcode.QRCode(box_size=10, border=4)
qr.add_data("4R022 Python Learning")
qr.make(fit=True)
img = qr.make_image(fill_color="black", back_color="white")
img.save("ozel_qr.png")
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `pip install qrcode` Yaparken `[pil]` Eklentisini Unutmak

```bash
pip install qrcode
```
```python
import qrcode
img = qrcode.make("test")
img.save("qr.png")
```

- **Neden yanlış?** Görsel üretimi Pillow (PIL) kütüphanesine
  dayanır; `[pil]` eklentisi olmadan kurulursa görsel oluşturma
  başarısız olabilir.
- **Hata nerede?** `ImportError` veya benzeri bir hata, Pillow
  bağımlılığının eksik olduğunu gösterir.
- **Ne kullanmalısın?** `pip install "qrcode[pil]"` ile Pillow'u da
  birlikte kur.

### Yanlış Örnek 2 — Çok Uzun Metni Küçük Bir QR Koda Sığdırmaya Çalışmak

```python
import qrcode
cok_uzun_metin = "A" * 5000
img = qrcode.make(cok_uzun_metin)   # varsayılan versiyon/boyutla
```

- **Neden yanlış?** QR kod standardının bir **kapasite sınırı**
  vardır; varsayılan ayarlarla aşırı uzun veri, hata versiyonunun
  otomatik büyümesine rağmen belirli bir noktadan sonra sığmayabilir.
- **Hata nerede?** `qrcode.exceptions.DataOverflowError` verebilir.
- **Ne kullanmalısın?** Uzun veri için `version` parametresini
  manuel artır (`qrcode.QRCode(version=None)` ile otomatik en uygun
  boyutu seçtir) veya veriyi kısaltıp yalnızca bir bağlantı (URL)
  paylaş.

## 🔗 İlgili Modüller
[hashlib](../30-hashlib/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
