# `csv` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`csv` (Comma-Separated Values) modülü, satır ve sütunlardan oluşan
tablo verisini okuyup yazmanı sağlar. Excel'de açabileceğin basit,
düz metin tabanlı bir tablo formatıdır. `csv` modülü, virgül/nokta-
virgül gibi ayraçları, tırnak içindeki metinleri ve satır sonlarını
senin yerine doğru şekilde yönetir — bunu elle yapmaya çalışmak
(sadece `split(",")` kullanmak) hatalara açıktır.

## Ne Zaman / Nerede Kullanılır?

- Excel/Google Sheets ile veri alışverişi
- Öğrenci notları, envanter listeleri, log kayıtları gibi tablo
  verilerini saklamak
- `pandas` kurmadan hafif tablo işlemleri yapmak

## ✅ Çalışan Örnekler

```python
# Örnek 1: CSV'ye yazma
import csv
with open("notlar.csv", "w", newline="", encoding="utf-8") as f:
    yazici = csv.writer(f)
    yazici.writerow(["isim", "not"])
    yazici.writerow(["Kaan", 95])
    yazici.writerow(["Ayşe", 88])
```

```python
# Örnek 2: CSV okuma (liste olarak)
import csv
with open("notlar.csv", "r", encoding="utf-8") as f:
    for satir in csv.reader(f):
        print(satir)
```

```python
# Örnek 3: DictReader/DictWriter ile sütun isimli okuma/yazma
import csv
with open("notlar.csv", "r", encoding="utf-8") as f:
    for satir in csv.DictReader(f):
        print(satir["isim"], "->", satir["not"])
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `newline=""` Parametresini Unutmak (Windows)

```python
import csv
with open("notlar.csv", "w", encoding="utf-8") as f:
    yazici = csv.writer(f)
    yazici.writerow(["isim", "not"])
```

- **Neden yanlış?** Kod çalışır, hata vermez — ama Windows'ta CSV
  dosyasında satırlar arasında **fazladan boş satırlar** oluşur.
  Bu, en sinsi CSV hatasıdır çünkü program çökmez.
- **Hata nerede?** `open()` çağrısında `newline=""` parametresi eksik.
- **Ne kullanmalısın?** `open("notlar.csv", "w", newline="",
  encoding="utf-8")`

### Yanlış Örnek 2 — Virgül İçeren Veriyi Elle `split(",")` ile Ayırmak

```python
satir = 'Kaan,"Sakarya, Türkiye",95'
parcalar = satir.split(",")
print(parcalar)   # ['Kaan', '"Sakarya', ' Türkiye"', '95'] — YANLIŞ!
```

- **Neden yanlış?** Adresin içindeki virgül, `split(",")` tarafından
  da bir ayraç sanılıyor; veri 4 parçaya bölünüyor, oysa aslında 3
  sütun olmalıydı.
- **Hata nerede?** Tırnak içindeki virgülü akıllıca yok sayan bir
  mantık yok; basit `split` bunu bilmiyor.
- **Ne kullanmalısın?** `csv.reader()` — bu, tırnak içindeki
  virgülleri doğru şekilde tek bir alan olarak tanır:
  ```python
  import csv, io
  print(next(csv.reader(io.StringIO(satir))))
  # ['Kaan', 'Sakarya, Türkiye', '95']  — DOĞRU
  ```

### Yanlış Örnek 3 — Sütun Sayısı Tutmayan Satır Yazmak

```python
import csv
with open("notlar.csv", "w", newline="") as f:
    yazici = csv.writer(f)
    yazici.writerow(["isim", "not", "sube"])
    yazici.writerow(["Kaan", 95])   # 'sube' eksik!
```

- **Neden yanlış?** Kod çalışır (CSV, sütun sayısını zorunlu kılmaz)
  ama sonradan `DictReader` ile okurken eksik sütun `None` olur —
  bu bir mantık/veri tutarlılığı hatasıdır, syntax hatası değil.
- **Hata nerede?** İkinci `writerow` çağrısında sütun sayısı ilk
  satırla (başlıkla) uyuşmuyor.
- **Ne kullanmalısın?** Her satırı yazmadan önce sütun sayısını
  kontrol et veya `DictWriter` kullanarak eksik alanları açıkça
  varsayılan bir değerle doldur.

## 🔗 İlgili Modüller
[json](../03-json/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
