# `collections` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`collections`, temel `list`/`dict` yapılarının **özelleşmiş, daha
performanslı veya daha okunaklı** versiyonlarını sunar. Örneğin
`Counter`, bir listedeki eleman sayılarını tutmak için optimize
edilmiş bir `dict` alt sınıfıdır; `deque`, hem baştan hem sondan
hızlı ekleme/çıkarma yapabilen bir liste türevidir.

## Ne Zaman / Nerede Kullanılır?

- Bir metindeki kelime frekansını saymak (`Counter`)
- Bir kuyruk (queue) veya "son N öğe" mantığı kurmak (`deque`)
- Anahtarı olmayan bir sözlük erişiminde otomatik varsayılan değer
  atamak (`defaultdict`)
- Sabit alanlı, hafif veri kayıtları oluşturmak (`namedtuple`)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Counter ile eleman sayma
from collections import Counter
kelimeler = "elma armut elma muz elma armut".split()
sayac = Counter(kelimeler)
print(sayac)                    # Counter({'elma': 3, 'armut': 2, 'muz': 1})
print(sayac.most_common(1))     # [('elma', 3)]
```

```python
# Örnek 2: defaultdict ile KeyError'suz gruplama
from collections import defaultdict
gruplar = defaultdict(list)
gruplar["meyve"].append("elma")   # anahtar yoksa otomatik boş liste açar
gruplar["meyve"].append("armut")
print(gruplar)
```

```python
# Örnek 3: deque ile hızlı "son N kayıt" mantığı
from collections import deque
son_islemler = deque(maxlen=3)   # en fazla 3 eleman tutar
for islem in ["giriş", "kayıt", "çıkış", "yeniden giriş"]:
    son_islemler.append(islem)
print(son_islemler)   # ['kayıt', 'çıkış', 'yeniden giriş'] — ilk eleman düştü
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Normal `dict` ile Var Olmayan Anahtara Ekleme

```python
gruplar = {}
gruplar["meyve"].append("elma")
```

- **Neden yanlış?** Normal bir `dict`'te `"meyve"` anahtarı henüz
  yoksa, ona `.append()` çağırmak mümkün değildir.
- **Hata nerede?** `KeyError: 'meyve'` verir çünkü anahtar hiç
  oluşturulmamış.
- **Ne kullanmalısın?** `from collections import defaultdict` ile
  `gruplar = defaultdict(list)` kullan — anahtar olmasa bile otomatik
  boş bir liste ile başlar.

### Yanlış Örnek 2 — `namedtuple`'ın Alanlarını Değiştirmeye Çalışmak

```python
from collections import namedtuple
Nokta = namedtuple("Nokta", ["x", "y"])
n = Nokta(1, 2)
n.x = 5
```

- **Neden yanlış?** `namedtuple`, normal `tuple` gibi
  **değiştirilemezdir (immutable)** — bir kez oluşturulduktan sonra
  alanları değiştirilemez.
- **Hata nerede?** `n.x = 5` ataması — `AttributeError: can't set
  attribute` verir.
- **Ne kullanmalısın?** Değiştirilebilir bir kayıt gerekiyorsa
  normal bir `class` ya da `dataclass` kullan; `namedtuple`'da
  değişiklik gerekiyorsa `n._replace(x=5)` ile **yeni bir** nesne
  üret (orijinali değişmez).

### Yanlış Örnek 3 — `Counter`'ı Sıralı Olduğunu Varsayarak Kullanmak

```python
from collections import Counter
sayac = Counter(["b", "a", "c", "a"])
ilk_eleman = list(sayac.keys())[0]
print("En çok geçen ilk anahtar bu mu?", ilk_eleman)
```

- **Neden yanlış?** `Counter`'ın anahtar sırası, **eklenme sırasını**
  yansıtır — "en çok geçen" anlamına gelmez. Bu, çalışan ama yanlış
  sonuca götüren bir mantık hatasıdır.
- **Hata nerede?** "İlk anahtar = en sık geçen" varsayımı yanlış.
- **Ne kullanmalısın?** En sık geçeni bulmak için özel olarak
  tasarlanmış `sayac.most_common(1)` metodunu kullan.

## 🔗 İlgili Modüller
[itertools ve functools](../09-itertools-ve-functools/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
