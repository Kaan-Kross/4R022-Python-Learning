# `logging` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`logging`, `print()`'in profesyonel yerini alan bir günlükleme
sistemidir. Farkı: mesajları **seviyelere** ayırır (DEBUG, INFO,
WARNING, ERROR, CRITICAL), bu mesajları hem ekrana hem dosyaya aynı
anda yazabilir, ve her mesaja otomatik zaman damgası ekler — büyük
uygulamalarda (4R022 masaüstü araçlarında olduğu gibi) "ne zaman ne
oldu" sorusuna cevap verir.

## Ne Zaman / Nerede Kullanılır?

- Üretim (production) uygulamalarında hata/olay takibi
- Kullanıcıya gösterilmeyen ama geliştiriciye lazım olan detaylı
  bilgi kaydı
- `print()` ile debug yapmanın "büyümüş" ve kalıcı hale gelmiş biçimi

## ✅ Çalışan Örnekler

```python
# Örnek 1: Temel kullanım
import logging
logging.basicConfig(level=logging.INFO)
logging.info("Uygulama başladı")
logging.warning("Ayar dosyası bulunamadı, varsayılanlar kullanılıyor")
```

```python
# Örnek 2: Hem dosyaya hem ekrana loglama
import logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("uygulama.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logging.debug("Bu detaylı bir hata ayıklama mesajıdır")
```

```python
# Örnek 3: try/except içinde hatayı loglamak
import logging
try:
    1 / 0
except ZeroDivisionError:
    logging.exception("Bölme hatası oluştu")   # hatanın tam izini de loglar
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `basicConfig()`'i Birden Fazla Kez Çağırmak

```python
import logging
logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.ERROR)   # bu çağrı YOK SAYILIR!
logging.debug("Bu mesaj görünmeyebilir")
```

- **Neden yanlış?** `logging.basicConfig()`, varsayılan olarak
  **yalnızca ilk çağrıldığında** etkilidir; sonraki çağrılar sessizce
  yok sayılır. Bu bir hata mesajı vermez, bu yüzden fark etmesi zordur.
- **Hata nerede?** İkinci `basicConfig()` çağrısının etkili olacağı
  varsayılmış.
- **Ne kullanmalısın?** Ayarları tek seferde, doğru şekilde belirle;
  değiştirmek gerekiyorsa `logging.getLogger().setLevel(...)` gibi
  daha ayrıntılı API'leri kullan.

### Yanlış Örnek 2 — DEBUG Seviyesindeki Mesajın Görünmemesi

```python
import logging
logging.basicConfig(level=logging.WARNING)
logging.debug("Bu mesaj hiç görünmeyecek")
```

- **Neden yanlış?** Kod hata vermez ama beklenen mesaj **hiç
  yazdırılmaz** — bu bir mantık/konfigürasyon hatasıdır.
- **Hata nerede?** Seviye `WARNING` olarak ayarlanmış; `DEBUG`,
  `WARNING`'den **daha düşük önemde** kabul edilir ve gösterilmez.
- **Ne kullanmalısın?** `DEBUG` mesajlarını görmek istiyorsan
  `level=logging.DEBUG` ayarla — seviyeler önem sırasına göre
  filtrelenir: DEBUG < INFO < WARNING < ERROR < CRITICAL.

### Yanlış Örnek 3 — Hassas Veriyi Log Dosyasına Yazmak

```python
import logging
logging.info(f"Kullanıcı girişi: sifre={kullanici_sifresi}")
```

- **Neden yanlış?** Kod teknik olarak çalışır ama bu **ciddi bir
  güvenlik hatasıdır** — log dosyaları genelde daha az korumalı
  saklanır ve şifre gibi hassas veriler burada asla bulunmamalı.
- **Hata nerede?** Şifre, log mesajının içine doğrudan yazılmış.
- **Ne kullanmalısın?** Hassas verileri asla loglama; gerekiyorsa
  maskele: `logging.info(f"Kullanıcı girişi: {kullanici_adi}")`
  (şifre olmadan).

## 🔗 İlgili Modüller
[datetime](../05-datetime/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
