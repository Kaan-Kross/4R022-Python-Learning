# `subprocess` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`subprocess`, Python programından **başka bir programı/komutu**
çalıştırmanı sağlar (örneğin bir terminal komutu, başka bir script,
harici bir araç). Yeni bir işletim sistemi süreci (process) başlatır,
onun çıktısını yakalayabilir ve bitmesini bekleyebilirsin.

## Ne Zaman / Nerede Kullanılır?

- `ffmpeg`, `git` gibi harici komut satırı araçlarını Python'dan
  tetiklemek
- Bir script'in çıktısını başka bir Python programında işlemek
- Build/otomasyon script'lerinde birden fazla adımı zincirlemek

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit komut çalıştırma ve çıktı alma
import subprocess
sonuc = subprocess.run(["python", "--version"], capture_output=True, text=True)
print(sonuc.stdout)
```

```python
# Örnek 2: Hata kontrolü ile çalıştırma
import subprocess
try:
    subprocess.run(["git", "status"], check=True)
except subprocess.CalledProcessError as hata:
    print("Komut başarısız oldu:", hata)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Kullanıcı Girdisini `shell=True` ile Doğrudan Çalıştırmak

```python
import subprocess
dosya_adi = input("Silinecek dosya: ")
subprocess.run(f"del {dosya_adi}", shell=True)
```

- **Neden yanlış?** Kod çalışır ama **ciddi bir güvenlik açığıdır**
  — kullanıcı `dosya_adi` olarak `"gecici.txt & format C:"` gibi bir
  şey girerse, `shell=True` bunu **ayrı bir komut olarak da**
  çalıştırabilir (komut enjeksiyonu / command injection).
- **Hata nerede?** Kullanıcı girdisi doğrudan bir kabuk (shell)
  komutuna, kontrolsüzce eklenmiş.
- **Ne kullanmalısın?** `shell=True` kullanmaktan kaçın; komutu ve
  argümanlarını ayrı bir liste olarak ver:
  `subprocess.run(["del", dosya_adi])` — bu, argümanı bir kabuk
  komutu olarak yorumlamaz, sadece bir dosya adı olarak geçirir.

### Yanlış Örnek 2 — Çıktının Büyük Olacağını Hesaba Katmadan `capture_output` Kullanmak

```python
import subprocess
sonuc = subprocess.run(["find", "/", "-name", "*.log"], capture_output=True, text=True)
```

- **Neden yanlış?** Eğer komut **devasa** bir çıktı üretiyorsa
  (örneğin tüm disk taraması), bu çıktı tamamen belleğe alınmaya
  çalışılır — bu, bellek tüketimine ve yavaşlamaya yol açabilir.
- **Hata nerede?** Çıktı boyutu öngörülmeden `capture_output=True`
  kullanılmış.
- **Ne kullanmalısın?** Çok büyük çıktılar için `subprocess.Popen`
  ile çıktıyı **satır satır, akış halinde** oku, tamamının belleğe
  alınmasını bekleme.

## 🔗 İlgili Modüller
[os](../01-os/README.md), [threading](../12-threading/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
