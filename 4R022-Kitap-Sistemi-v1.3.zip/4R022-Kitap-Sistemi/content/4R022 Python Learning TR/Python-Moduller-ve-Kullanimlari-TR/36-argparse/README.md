# `argparse` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`argparse`, komut satırından çalıştırılan script'lere **profesyonel
bir argüman arayüzü** kazandırır. `sys.argv`'yi elle ayrıştırmak
yerine (bkz. [sys](../02-sys/README.md)), `argparse` otomatik olarak
`--help` mesajı, tip dönüşümü, zorunlu/opsiyonel argüman ayrımı ve
hata mesajları üretir.

## Ne Zaman / Nerede Kullanılır?

- Birden fazla seçenek/parametre alan komut satırı araçları yazmak
- 4R022 gibi araçların "headless" (arayüzsüz) komut satırı modlarını
  desteklemesi

## ✅ Çalışan Örnekler

```python
# Örnek 1: Temel argüman ayrıştırma
import argparse

parser = argparse.ArgumentParser(description="4R022 örnek aracı")
parser.add_argument("dosya", help="İşlenecek dosyanın yolu")
parser.add_argument("--detayli", action="store_true", help="Detaylı çıktı ver")

args = parser.parse_args()
print("Dosya:", args.dosya)
if args.detayli:
    print("Detaylı mod aktif")
```

```bash
python arac.py notlar.txt --detayli
```

```python
# Örnek 2: Tip dönüşümü ve varsayılan değer
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--tekrar", type=int, default=1, help="Kaç kez çalıştırılsın")
args = parser.parse_args()
print(args.tekrar)   # otomatik olarak int'e çevrilmiştir
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Zorunlu Argümanı Vermeden Script'i Çalıştırmak

```bash
python arac.py
```
```python
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("dosya")   # pozisyonel, zorunlu argüman
args = parser.parse_args()
```

- **Neden yanlış?** `dosya`, pozisyonel bir argüman olarak
  tanımlandığı için **zorunludur**; verilmezse `argparse` kendi
  hatasını üretir.
- **Hata nerede?** Terminalde `error: the following arguments are
  required: dosya` mesajıyla program sonlanır (bu, `argparse`'ın
  **beklenen ve faydalı** davranışıdır, bir bug değildir).
- **Ne kullanmalısın?** Argümanı ver: `python arac.py notlar.txt`;
  gerçekten opsiyonel olmasını istiyorsan `nargs="?"` veya
  `default=...` ekle.

### Yanlış Örnek 2 — `--bayrak` Argümanına Değer Vermeye Çalışmak (`store_true` ile)

```bash
python arac.py --detayli evet
```
```python
parser.add_argument("--detayli", action="store_true")
```

- **Neden yanlış?** `action="store_true"` ile tanımlanan bir
  argüman **değer almaz** — sadece var/yok (True/False) bilgisi
  taşır; `"evet"` kelimesi ayrı, tanımlanmamış bir argüman olarak
  algılanır.
- **Hata nerede?** `error: unrecognized arguments: evet` verir.
- **Ne kullanmalısın?** Bayrak (flag) argümanlarını değersiz kullan:
  `python arac.py --detayli`; bir değer almasını istiyorsan
  `action="store_true"` yerine normal bir argüman tanımı
  (`parser.add_argument("--seviye")`) kullan.

## 🔗 İlgili Modüller
[sys](../02-sys/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
