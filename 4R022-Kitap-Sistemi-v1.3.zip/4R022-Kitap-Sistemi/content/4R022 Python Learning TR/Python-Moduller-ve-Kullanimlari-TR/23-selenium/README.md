# `selenium` Modülü

> ⚠️ Bu modül güçlüdür ve kötüye kullanılabilir. Kullanmadan önce
> [Etik ve Güvenlik](../../Python-Etik-ve-Guvenlik-TR/README.md)
> bölümünü okumanı öneririz. Aşağıdaki örnekler yalnızca **kendi
> sitenin/uygulamanın** test/otomasyonu içindir.

## Nedir ve Çalışma Prensibi Nedir?

`selenium`, bir gerçek web tarayıcısını (Chrome, Firefox) **program
aracılığıyla** kontrol etmeni sağlar (`pip install selenium`).
Arka planda, tarayıcıyla "WebDriver Protokolü" adlı bir arayüz
üzerinden konuşur — tıpkı bir insan gibi tıklar, yazar, sayfa
kaydırır; ama bunu kod satırlarıyla otomatik yapar.

## Ne Zaman / Nerede Kullanılır?

- Kendi web sitenin otomatik testlerini yazmak (her yayında elle
  tıklamak yerine)
- Tekrarlayan form doldurma işlerini otomatikleştirmek (kendi
  hesabında/izinli ortamda)
- JavaScript ile dinamik oluşturulan, `requests` ile çekilemeyen
  sayfa içeriğini almak

## ✅ Çalışan Örnekler

```python
# Örnek 1: Sayfa açma ve başlık okuma
from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://example.com")
print(driver.title)
driver.quit()
```

```python
# Örnek 2: Bir elemanı bulup metnini okuma
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://example.com")
baslik = driver.find_element(By.TAG_NAME, "h1")
print(baslik.text)
driver.quit()
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Sayfa Tam Yüklenmeden Elemana Erişmeye Çalışmak

```python
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://ornek-yavas-site.com")
eleman = driver.find_element(By.ID, "sonuclar")   # sayfa henüz yüklenmemiş olabilir
```

- **Neden yanlış?** Modern web siteleri içeriği JavaScript ile
  **sonradan** yükler; `get()` çağrısı sayfanın **tamamen** JS
  içeriğiyle yüklendiğini garanti etmez.
- **Hata nerede?** `NoSuchElementException` verebilir çünkü
  `"sonuclar"` ID'li eleman henüz DOM'da oluşmamış olabilir.
- **Ne kullanmalısın?** `WebDriverWait` ile elemanın oluşmasını
  bekle:
  ```python
  from selenium.webdriver.support.ui import WebDriverWait
  from selenium.webdriver.support import expected_conditions as EC
  eleman = WebDriverWait(driver, 10).until(
      EC.presence_of_element_located((By.ID, "sonuclar"))
  )
  ```

### Yanlış Örnek 2 — `driver.quit()` Çağırmayı Unutmak

```python
from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://example.com")
print(driver.title)
# driver.quit() hiç çağrılmamış
```

- **Neden yanlış?** Kod "çalışır" ama tarayıcı süreci **açık
  kalır** — script'i defalarca çalıştırırsan, arka planda onlarca
  Chrome penceresi/işlemi birikir ve bilgisayarı yavaşlatır.
- **Hata nerede?** Kaynak temizliği (`driver.quit()`) eksik.
- **Ne kullanmalısın?** `try/finally` ile garanti et:
  ```python
  driver = webdriver.Chrome()
  try:
      driver.get("https://example.com")
  finally:
      driver.quit()
  ```

### Yanlış Örnek 3 — Bir Sitenin Kullanım Şartlarını Görmezden Gelerek Otomasyon Kurmak

```python
# Bir sitenin ToS'unda "otomatik erişim yasaktır" yazmasına rağmen
# saatte binlerce istek atan bir bot yazmak
```

- **Neden yanlış?** Teknik olarak "çalışabilir" ama bu bir **kullanım
  şartları ihlali ve olası hukuki sorundur**; ayrıca hedef sunucuya
  aşırı yük bindirerek bir tür hizmet aksatma etkisi yaratabilir.
- **Hata nerede?** Bu bir kod hatası değil, bir **izin/etik**
  hatasıdır (bkz. [Etik ve Güvenlik](../../Python-Etik-ve-Guvenlik-TR/README.md)).
- **Ne kullanmalısın?** Bir sitenin `robots.txt` ve kullanım
  şartlarına uy; yoğun veri ihtiyacın varsa sitenin resmi API'sini
  kullan veya izin iste.

## 🔗 İlgili Modüller
[requests](../16-requests/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
