# `matplotlib` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`matplotlib`, Python'da grafik ve veri görselleştirme oluşturan temel
kütüphanedir (`pip install matplotlib`). En çok kullanılan alt
modülü `pyplot`, MATLAB'a benzer, adım adım bir çizim arayüzü sunar:
önce veriyi çizersin, sonra eksen/başlık gibi detayları eklersin, en
son gösterir veya kaydedersin.

## Ne Zaman / Nerede Kullanılır?

- Veri analizinde eğilimleri (trend) görselleştirmek
- Raporlarda kullanılacak grafik/çizim üretmek
- 4R022 Steam Analiz gibi araçlarda kullanıcıya görsel özet sunmak

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit çizgi grafiği
import matplotlib.pyplot as plt
x = [1, 2, 3, 4]
y = [10, 20, 25, 30]
plt.plot(x, y, marker="o")
plt.title("Örnek Grafik")
plt.savefig("grafik.png")
```

```python
# Örnek 2: Birden fazla veri serisi ve etiketler
import matplotlib.pyplot as plt
plt.plot([1,2,3], [1,4,9], label="kareler")
plt.plot([1,2,3], [1,8,27], label="küpler")
plt.legend()
plt.savefig("karsilastirma.png")
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Sunucu/Headless Ortamda `plt.show()` Kullanmak

```python
import matplotlib.pyplot as plt
plt.plot([1, 2, 3])
plt.show()
```

- **Neden yanlış?** Ekranı (GUI) olmayan bir sunucuda veya CI/CD
  ortamında `plt.show()` bir pencere açmaya çalışır; bu genelde
  hataya veya sessiz bir donmaya yol açar.
- **Hata nerede?** `plt.show()`, ekranı olan bir ortam varsayıyor.
- **Ne kullanmalısın?** Sunucu ortamlarında `plt.savefig("grafik.png")`
  kullan — dosyaya kaydeder, ekran gerektirmez.

### Yanlış Örnek 2 — Önceki Grafiğin Üzerine Çizmeye Devam Etmek

```python
import matplotlib.pyplot as plt
plt.plot([1, 2, 3], [1, 4, 9])
plt.savefig("grafik1.png")

plt.plot([1, 2, 3], [3, 2, 1])   # aynı figürün üstüne eklenir!
plt.savefig("grafik2.png")        # grafik2.png İKİ çizgiyi de içerir
```

- **Neden yanlış?** `matplotlib`, açıkça temizlenmediği sürece
  **aynı figür (figure) nesnesi üzerinde** çizmeye devam eder;
  "grafik2.png"nin sadece ikinci çizgiyi içereceği varsayılmış ama
  ikisini de içerir.
- **Hata nerede?** İki çizim arasında `plt.clf()` (figürü temizle)
  veya `plt.figure()` (yeni figür aç) çağrısı eksik.
- **Ne kullanmalısın?** Her yeni grafikten önce `plt.figure()` çağır
  veya `plt.clf()` ile mevcut figürü temizle.

### Yanlış Örnek 3 — Boyutu Uyuşmayan X/Y Verisi Vermek

```python
import matplotlib.pyplot as plt
x = [1, 2, 3, 4, 5]
y = [10, 20, 30]   # x'ten 2 eleman eksik!
plt.plot(x, y)
```

- **Neden yanlış?** `plt.plot()`, `x` ve `y` dizilerinin **aynı
  uzunlukta** olmasını bekler; her x noktasının bir y karşılığı
  olmalıdır.
- **Hata nerede?** `ValueError: x and y must have same first
  dimension` verir.
- **Ne kullanmalısın?** İki listenin uzunluğunu eşitle, ya da
  veriyi üretirken (örneğin bir döngüde) her adımda hem x hem y'ye
  aynı anda ekleme yaptığından emin ol.

## 🔗 İlgili Modüller
[numpy](../18-numpy/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
