# Python Modülleri ve Kullanımları (TR)

Bu bölüm, "hangi işi yaparken hangi modülü kullanırım?" sorusuna
cevap veren, **her modülün kendi klasöründe** ayrıntılı olarak
anlatıldığı bir referans kitaplığıdır. Her modül klasöründe:

- 📖 Modülün ne olduğu ve **çalışma prensibi**
- 🎯 Ne için, ne zaman, nerede kullanıldığı (kullanım alanları)
- ✅ Birden fazla çalışan kod örneği
- ❌ Birden fazla **çalışmayan/yanlış** kod örneği — her biri için:
  **"Neden yanlış? Hata nerede? Doğrusu ne olmalı?"** açıklamalı
- 🔗 İlgili/tamamlayıcı modüllere bağlantılar

## 🟢 Standart Kütüphane (Kurulum Gerektirmez)

| Modül | Ne İşe Yarar |
|---|---|
| [os](./01-os/README.md) | İşletim sistemi, dosya/klasör işlemleri |
| [sys](./02-sys/README.md) | Yorumlayıcı ile etkileşim, komut satırı argümanları |
| [json](./03-json/README.md) | JSON verisi okuma/yazma |
| [csv](./04-csv/README.md) | CSV (tablo) verisi okuma/yazma |
| [datetime](./05-datetime/README.md) | Tarih ve saat işlemleri |
| [math ve random](./06-math-ve-random/README.md) | Matematiksel işlemler, rastgele sayı üretimi |
| [re (Düzenli İfadeler)](./07-re-duzenli-ifadeler/README.md) | Metin desenleri arama/değiştirme |
| [collections](./08-collections/README.md) | Gelişmiş veri yapıları (Counter, defaultdict, deque) |
| [itertools ve functools](./09-itertools-ve-functools/README.md) | Döngü ve fonksiyon araçları |
| [pathlib](./10-pathlib/README.md) | Modern, nesne tabanlı dosya yolu yönetimi |
| [logging](./11-logging/README.md) | Profesyonel günlükleme (loglama) |
| [threading](./12-threading/README.md) | Çoklu iş parçacığı (G/Ç ağırlıklı işler) |
| [multiprocessing](./13-multiprocessing/README.md) | Çoklu işlem (CPU ağırlıklı işler) |
| [asyncio](./14-asyncio/README.md) | Eşzamansız (async) programlama |
| [sqlite3](./15-sqlite3/README.md) | Yerleşik hafif veritabanı |
| [unittest ve pytest](./26-unittest-ve-pytest/README.md) | Otomatik test yazımı |

## 🔵 Popüler Üçüncü Parti Kütüphaneler (`pip install` gerekir)

| Modül | Ne İşe Yarar |
|---|---|
| [requests](./16-requests/README.md) | HTTP istekleri, dış API'lerle konuşma |
| [Flask ve FastAPI](./17-flask-ve-fastapi/README.md) | Web sunucusu / API geliştirme |
| [numpy](./18-numpy/README.md) | Hızlı sayısal dizi işlemleri |
| [pandas](./19-pandas/README.md) | Tablo/tabular veri analizi |
| [matplotlib](./20-matplotlib/README.md) | Grafik ve veri görselleştirme |
| [tkinter](./21-tkinter/README.md) | Standart masaüstü arayüz kütüphanesi |
| [PyQt6](./22-PyQt6/README.md) | Profesyonel masaüstü arayüz kütüphanesi |
| [selenium](./23-selenium/README.md) | Tarayıcı otomasyonu |
| [socket](./24-socket/README.md) | Düşük seviyeli ağ programlama |
| [cryptography](./25-cryptography/README.md) | Şifreleme ve veri güvenliği |

## 🟣 Yeni Eklenen Modüller

| Modül | Ne İşe Yarar |
|---|---|
| [queue](./27-queue/README.md) | Thread'ler arası güvenli veri kuyruğu |
| [tempfile](./28-tempfile/README.md) | Geçici dosya/klasör yönetimi |
| [qrcode](./29-qrcode/README.md) | QR kod oluşturma |
| [hashlib](./30-hashlib/README.md) | Özet (hash) fonksiyonları |
| [shutil](./31-shutil/README.md) | Yüksek seviyeli dosya/klasör işlemleri, arşivleme |
| [subprocess](./32-subprocess/README.md) | Harici komut/program çalıştırma |
| [enum](./33-enum/README.md) | Okunaklı sabit kümeleri (enumeration) |
| [dataclasses](./34-dataclasses/README.md) | Az kodla veri sınıfları yazma |
| [typing](./35-typing/README.md) | Tip ipuçları (type hints) |
| [argparse](./36-argparse/README.md) | Profesyonel komut satırı arayüzleri |

## 🟡 Az Bilinen Ama Faydalı / Yol Haritasında Olan Modüller

Aşağıdaki modüller için ayrıntılı klasörler **planlanmaktadır** ve
zamanla bu listeye eklenecektir (şu an içerikleri hazır değildir,
bu bilerek burada yol haritası olarak belirtiliyor — okuyucuyu
yanıltmamak için):

- `venv` — sanal ortam yönetimi (Orta Kademe'de işlendi, ayrı klasör planlı)
- `pytest-mock`, `httpx`, `pydantic`, `sqlalchemy`, `openpyxl` — ileri seviye üçüncü parti araçlar

> 🧑‍🏫 **Neden hem popüler hem az bilinen modülleri listeliyoruz?**
> Amacımız yalnızca "trend" olanları değil, gerçek bir yazılımcının
> araç kutusunda bulunması gereken **her şeyi** tanıtmak. Bazı
> modüller (örneğin `pathlib`, `dataclasses`) yeni başlayanlar
> tarafından bilinmez ama günlük kodda ciddi zaman kazandırır.

Etik ve hukuki sınırlar için ➡️ [Etik ve Güvenlik](../Python-Etik-ve-Guvenlik-TR/README.md) bölümüne bakmayı unutma.

⬅️ [Veri Kavramları](../Python-Veri-Kavramlari-TR/README.md) &nbsp;|&nbsp; ➡️ [Etik ve Güvenlik](../Python-Etik-ve-Guvenlik-TR/README.md)
