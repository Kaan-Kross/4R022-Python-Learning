# `cryptography` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`cryptography`, Python'da güvenli şifreleme işlemleri yapmak için
kullanılan, endüstri standardı bir üçüncü parti kütüphanedir
(`pip install cryptography`). Kendi şifreleme algoritmanı yazmak son
derece risklidir (küçük bir hata tüm güvenliği çökertebilir); bu
kütüphane, uzmanlarca test edilmiş, kanıtlanmış algoritmaları
(AES, Fernet gibi) kullanıma sunar.

## Ne Zaman / Nerede Kullanılır?

- Uygulama içinde kullanıcı verisini/şifrelerini güvenli saklamak
- Dosyaları şifrelemek/çözmek (4R022 Arşiv gibi projelerde şifreli
  giriş sistemleri)
- İki sistem arasında güvenli veri iletimi

## ✅ Çalışan Örnekler

```python
# Örnek 1: Fernet ile basit simetrik şifreleme
from cryptography.fernet import Fernet
anahtar = Fernet.generate_key()
f = Fernet(anahtar)

sifreli = f.encrypt(b"Gizli mesaj")
cozulmus = f.decrypt(sifreli)
print(cozulmus.decode())   # "Gizli mesaj"
```

```python
# Örnek 2: Anahtarı güvenli şekilde saklama/yükleme
from cryptography.fernet import Fernet

# Anahtarı bir kere üret ve dosyaya kaydet:
anahtar = Fernet.generate_key()
with open("anahtar.key", "wb") as f:
    f.write(anahtar)

# Sonraki çalıştırmalarda aynı anahtarı yükle:
with open("anahtar.key", "rb") as f:
    yuklenen_anahtar = f.read()
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Her Çalıştırmada Yeni Anahtar Üretmek

```python
from cryptography.fernet import Fernet
f = Fernet(Fernet.generate_key())
sifreli = f.encrypt(b"Gizli veri")
# ... program kapanır ...
# Sonraki çalıştırmada:
f2 = Fernet(Fernet.generate_key())   # FARKLI, yeni bir anahtar!
cozulmus = f2.decrypt(sifreli)
```

- **Neden yanlış?** Her `generate_key()` çağrısı **tamamen farklı**
  bir anahtar üretir; şifrelemede kullanılan anahtarla çözmede
  kullanılan anahtar **aynı olmak zorundadır.**
- **Hata nerede?** `cryptography.fernet.InvalidToken` hatası verir
  çünkü `f2`'nin anahtarı, veriyi şifrelemek için kullanılan `f`'nin
  anahtarıyla eşleşmiyor.
- **Ne kullanmalısın?** Anahtarı **bir kez üret**, güvenli bir yerde
  (dosya, ortam değişkeni) sakla ve her çalıştırmada **aynı**
  anahtarı yükle.

### Yanlış Örnek 2 — Şifreleme Anahtarını Kaynak Koduna Sabit Yazmak

```python
from cryptography.fernet import Fernet
ANAHTAR = b"gAAAAABhZ...(gercek-anahtar-buraya)..."   # kod içinde sabit!
f = Fernet(ANAHTAR)
```

- **Neden yanlış?** Kod çalışır ama bu **ciddi bir güvenlik açığıdır**
  — bu kodu GitHub'a (özellikle açık bir depoya) yüklersen, şifreleme
  anahtarın herkese açık olur; artık şifrelenmiş verinin hiçbir
  koruması kalmaz.
- **Hata nerede?** Anahtar, kaynak kodun içine gömülmüş.
- **Ne kullanmalısın?** Anahtarı ortam değişkeninde veya
  `.gitignore`'a eklenmiş ayrı bir dosyada sakla; kod içine
  **asla** gerçek anahtar/şifre yazma.

### Yanlış Örnek 3 — `bytes` Yerine `str` ile Şifrelemeye Çalışmak

```python
from cryptography.fernet import Fernet
f = Fernet(Fernet.generate_key())
sifreli = f.encrypt("Gizli mesaj")   # str, bytes değil!
```

- **Neden yanlış?** `Fernet.encrypt()` yalnızca **bytes** türünde
  veri kabul eder; düz bir `str` kabul edilmez.
- **Hata nerede?** `TypeError` verir çünkü fonksiyon `str` yerine
  `bytes` bekliyor.
- **Ne kullanmalısın?** String'i `.encode()` ile bytes'a çevir:
  `f.encrypt("Gizli mesaj".encode())` — çözerken de `.decode()`
  ile tekrar string'e çevir.

## 🔗 İlgili Modüller
[hashlib (planlanan)](../README.md), [socket](../24-socket/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
