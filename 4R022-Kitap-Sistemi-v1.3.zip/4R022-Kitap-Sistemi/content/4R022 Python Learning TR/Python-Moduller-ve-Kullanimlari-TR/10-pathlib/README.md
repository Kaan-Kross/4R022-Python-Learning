# `pathlib` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`pathlib`, dosya yollarını **string olarak değil, nesne olarak**
ele alan modern bir modüldür (Python 3.4+). `os.path.join()` gibi
fonksiyonlarla string birleştirmek yerine, `Path` nesneleri üzerinde
`/` operatörünü kullanarak yol oluşturursun — bu hem daha okunaklı
hem daha az hataya açıktır.

## Ne Zaman / Nerede Kullanılır?

- Yeni yazılan projelerde `os.path` yerine (modern standart budur)
- Dosya var mı, klasör mü kontrol etmek
- Bir klasördeki belirli uzantılı dosyaları bulmak (`.glob()`)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Yol oluşturma — os.path.join yerine
from pathlib import Path
yol = Path("proje") / "veri" / "ayarlar.json"
print(yol)   # proje/veri/ayarlar.json (platforma uygun ayraçla)
```

```python
# Örnek 2: Dosya/klasör kontrolü ve okuma
from pathlib import Path
dosya = Path("notlar.txt")
if dosya.exists():
    icerik = dosya.read_text(encoding="utf-8")
    print(icerik)
```

```python
# Örnek 3: Belirli uzantılı dosyaları bulma
from pathlib import Path
for py_dosyasi in Path(".").glob("*.py"):
    print(py_dosyasi.name)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `Path` Nesnesini `str` Fonksiyonlarıyla Karıştırmak

```python
from pathlib import Path
yol = Path("dosya.txt")
print(yol.replace(".txt", ".csv"))
```

- **Neden yanlış?** `str.replace()`, `Path` nesnelerinde farklı bir
  anlama gelir — `Path.replace()` aslında dosyayı **taşımak/yeniden
  adlandırmak** için kullanılır, metin değiştirmek için değil.
- **Hata nerede?** `.replace(".txt", ".csv")` çağrısı, Path'i
  gerçekten "dosya.csv" adlı (var olmayan) bir konuma taşımaya
  çalışır ve `FileNotFoundError` verebilir.
- **Ne kullanmalısın?** Uzantı değiştirmek için özel metod:
  `yol.with_suffix(".csv")` — bu, yeni bir `Path` nesnesi döndürür,
  dosyayı taşımaz.

### Yanlış Örnek 2 — `Path` ile `os.path` Fonksiyonlarını Doğrudan Karıştırmak

```python
import os
from pathlib import Path
yol = Path("veri") / "dosya.txt"
print(os.path.join(yol, "ek"))
```

- **Neden yanlış?** Çoğu zaman çalışır (Path, string'e
  dönüştürülebilir) ama tutarsız bir kod stili yaratır ve bazı
  eski `os.path` fonksiyonları `Path` nesnesini beklediği gibi
  işlemeyebilir.
- **Hata nerede?** İki farklı API (`os.path` ve `pathlib`) bilinçsizce
  karıştırılmış.
- **Ne kullanmalısın?** Bir projede **birini seç** — yeni kodda
  `pathlib` kullan: `yol / "ek"` yeterlidir, `os.path.join()`'e
  gerek yoktur.

### Yanlış Örnek 3 — Var Olmayan Bir Klasörde Dosya Oluşturmaya Çalışmak

```python
from pathlib import Path
dosya = Path("olmayan_klasor/notlar.txt")
dosya.write_text("merhaba")
```

- **Neden yanlış?** `olmayan_klasor` diskte yoksa, içine dosya
  yazılamaz — üst klasör önce var olmalıdır.
- **Hata nerede?** `FileNotFoundError: [Errno 2] No such file or
  directory` verir çünkü ebeveyn klasör oluşturulmamış.
- **Ne kullanmalısın?**
  ```python
  dosya.parent.mkdir(parents=True, exist_ok=True)
  dosya.write_text("merhaba", encoding="utf-8")
  ```

## 🔗 İlgili Modüller
[os](../01-os/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
