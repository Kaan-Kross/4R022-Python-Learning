# `hashlib` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`hashlib`, veriyi **sabit uzunlukta, tek yönlü bir özet (hash)**
değerine dönüştüren algoritmaları (MD5, SHA-256, SHA-512 vb.) sunar.
"Tek yönlü" demek, özetten orijinal veriye geri dönmenin (teorik
olarak) imkânsız olması demektir — küçük bir değişiklik bile
tamamen farklı bir özet üretir.

## Ne Zaman / Nerede Kullanılır?

- Bir dosyanın bozulup bozulmadığını doğrulamak (indirilen dosyanın
  hash'i, resmi siteninkiyle eşleşiyor mu?)
- Şifreleri **doğrudan değil**, özetlerini saklamak (gerçek üretim
  sistemlerinde `bcrypt`/`argon2` gibi özel olarak şifre için
  tasarlanmış algoritmalar tercih edilir, düz `hashlib` değil)
- Büyük dosyaların içeriğini hızlıca karşılaştırmak (aynı dosya mı?)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Metnin SHA-256 özetini alma
import hashlib
metin = "4R022 Python Learning"
ozet = hashlib.sha256(metin.encode()).hexdigest()
print(ozet)
```

```python
# Örnek 2: Bir dosyanın özetini alma (büyük dosyalar için parça parça)
import hashlib
def dosya_ozeti(yol):
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for parca in iter(lambda: f.read(8192), b""):
            h.update(parca)
    return h.hexdigest()
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Kullanıcı Şifrelerini Düz `hashlib.md5()` ile Saklamak

```python
import hashlib
sifre_ozeti = hashlib.md5("123456".encode()).hexdigest()
# bu özeti veritabanında "kullanıcı şifresi" olarak saklamak
```

- **Neden yanlış?** Kod çalışır ama **ciddi bir güvenlik hatasıdır**
  — MD5 hem kriptografik olarak kırılmıştır hem de şifre saklamak
  için **hızlıdır** (kötü niyetli biri milyonlarca olası şifreyi
  saniyeler içinde deneyebilir, "brute-force").
- **Hata nerede?** Şifre saklama için yanlış araç seçilmiş.
- **Ne kullanmalısın?** Şifre saklamak için özel olarak yavaş ve
  "salt" (tuz) eklenmiş tasarlanmış `bcrypt`, `argon2` veya
  `hashlib.pbkdf2_hmac()` gibi fonksiyonları kullan.

### Yanlış Örnek 2 — `str` ile Doğrudan Hash Almaya Çalışmak

```python
import hashlib
ozet = hashlib.sha256("merhaba")
```

- **Neden yanlış?** `hashlib` fonksiyonları yalnızca **bytes** kabul
  eder, düz `str` kabul etmez.
- **Hata nerede?** `TypeError: Unicode-objects must be encoded
  before hashing` verir.
- **Ne kullanmalısın?** `.encode()` ile önce bytes'a çevir:
  `hashlib.sha256("merhaba".encode())`

## 🔗 İlgili Modüller
[cryptography](../25-cryptography/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
