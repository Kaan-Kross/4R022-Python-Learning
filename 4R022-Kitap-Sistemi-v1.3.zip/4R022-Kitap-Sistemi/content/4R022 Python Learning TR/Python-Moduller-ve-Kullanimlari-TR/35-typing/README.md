# `typing` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`typing`, Python'a **tip ipuçları (type hints)** eklemeni sağlar —
bir değişkenin/parametrenin/dönüş değerinin "ne tür" olması
**beklendiğini** belirtirsin. Önemli bir nokta: Python bu ipuçlarını
**çalışma zamanında zorlamaz** (dinamik tipli bir dil olarak kalır);
bunlar esas olarak editörler (VS Code gibi) ve statik analiz
araçları (`mypy`) için birer "sözleşme" görevi görür.

## Ne Zaman / Nerede Kullanılır?

- Büyük, çok kişili projelerde kodun okunabilirliğini artırmak
- Editörde otomatik tamamlama (autocomplete) ve hata tespiti almak
- FastAPI gibi framework'lerde otomatik veri doğrulaması sağlamak
  (bkz. [Flask ve FastAPI](../17-flask-ve-fastapi/README.md))

## ✅ Çalışan Örnekler

```python
# Örnek 1: Temel tip ipuçları
def selamla(isim: str) -> str:
    return f"Merhaba, {isim}!"

yas: int = 25
```

```python
# Örnek 2: Karmaşık tipler
from typing import List, Dict, Optional

def ogrenci_ozeti(isimler: List[str]) -> Dict[str, int]:
    return {isim: len(isim) for isim in isimler}

def kullanici_bul(id_no: int) -> Optional[str]:
    veritabani = {1: "Kaan"}
    return veritabani.get(id_no)   # None dönebilir, bu yüzden Optional
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Tip İpucunun Çalışma Zamanında Kontrol Edileceğini Sanmak

```python
def topla(a: int, b: int) -> int:
    return a + b

sonuc = topla("5", "3")   # str verilmiş, hata beklenir ama...
print(sonuc)
```

- **Neden yanlış?** Kod **çalışır** — `"5" + "3"` Python'da geçerli
  bir string birleştirme işlemidir (`"53"` sonucunu verir); `int`
  tip ipucu bunu **engellemez.**
- **Hata nerede?** Aslında hata yok; yanlış olan, tip ipucunun
  otomatik doğrulama sağladığını düşünmek. Sonuç `"53"` olur,
  `8` değil — bu sessiz bir mantık hatasıdır.
- **Ne kullanmalısın?** Gerçek zamanlı doğrulama istiyorsan `mypy`
  gibi bir statik analiz aracını CI/CD sürecine ekle, ya da
  fonksiyon içinde elle `isinstance()` kontrolü yap.

### Yanlış Örnek 2 — Eski Python Sürümlerinde Yeni Söz Dizimini Kullanmak

```python
def ilk_eleman(liste: list[int]) -> int:   # Python 3.9 öncesi ÇALIŞMAZ
    return liste[0]
```

- **Neden yanlış?** `list[int]` gibi "yerleşik jenerik" söz dizimi
  Python 3.9'da eklendi; daha eski sürümlerde bu geçersizdir.
- **Hata nerede?** Python 3.8 ve öncesinde `TypeError: 'type' object
  is not subscriptable` verir.
- **Ne kullanmalısın?** Eski sürümlerde `from typing import List`
  ile `List[int]` kullan; 3.9+ hedefliyorsan doğrudan `list[int]`
  kullanabilirsin.

## 🔗 İlgili Modüller
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
