# `requests` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`requests`, HTTP protokolü üzerinden web sunucularına/API'lere
istek göndermeni sağlayan, Python'ın standart kütüphanesindeki daha
karmaşık `urllib`'e göre çok daha okunaklı bir üçüncü parti
kütüphanedir (`pip install requests`). Arka planda TCP bağlantısı
kurar, HTTP başlıklarını (headers) oluşturur ve sunucudan gelen
yanıtı senin için ayrıştırır.

## Ne Zaman / Nerede Kullanılır?

- Bir web API'sinden veri çekmek (hava durumu, döviz kuru, haberler)
- Kendi backend'ine (Flask/FastAPI) istek atan bir istemci yazmak
- Web sitelerinden veri toplamak (scraping — meşru ve izinli sınırlar
  içinde, bkz. [Etik ve Güvenlik](../../Python-Etik-ve-Guvenlik-TR/README.md))

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit GET isteği
import requests
yanit = requests.get("https://api.github.com", timeout=5)
print(yanit.status_code)   # 200
print(yanit.json())
```

```python
# Örnek 2: POST isteği ile veri gönderme
import requests
veri = {"kullanici": "Kaan", "mesaj": "Merhaba"}
yanit = requests.post("https://httpbin.org/post", json=veri, timeout=5)
print(yanit.json())
```

```python
# Örnek 3: Hata kontrolü ile güvenli istek
import requests
try:
    yanit = requests.get("https://api.github.com", timeout=5)
    yanit.raise_for_status()
    print("Başarılı:", yanit.status_code)
except requests.RequestException as hata:
    print("İstek başarısız:", hata)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `timeout` Belirtmemek

```python
import requests
yanit = requests.get("https://cok-yavas-bir-sunucu.com")
```

- **Neden yanlış?** `timeout` belirtilmezse, sunucu hiç yanıt
  vermezse **program sonsuza kadar bekler** — bu, kullanıcı arayüzü
  olan bir uygulamada tamamen donmuş gibi görünür.
- **Hata nerede?** `requests.get()` çağrısında `timeout` parametresi
  eksik.
- **Ne kullanmalısın?** Her zaman `timeout=5` (veya işine uygun bir
  süre) belirt: `requests.get(url, timeout=5)`

### Yanlış Örnek 2 — Durum Kodunu Kontrol Etmeden JSON Okumak

```python
import requests
yanit = requests.get("https://api.example.com/veri-olmayan-uc-nokta")
veri = yanit.json()   # sunucu 404 döndürmüş olabilir!
```

- **Neden yanlış?** Sunucu 404/500 gibi bir hata kodu döndürse bile
  `requests` bunu otomatik olarak bir Python hatasına çevirmez;
  `.json()` çağrısı, yanıt JSON değilse (örneğin bir HTML hata
  sayfasıysa) sessizce yanlış veri döndürebilir veya çöker.
- **Hata nerede?** `yanit.raise_for_status()` veya `yanit.status_code`
  kontrolü hiç yapılmamış.
- **Ne kullanmalısın?**
  ```python
  yanit.raise_for_status()   # 4xx/5xx durumunda hata fırlatır
  veri = yanit.json()
  ```

### Yanlış Örnek 3 — API Anahtarını Kod İçine Sabit Olarak Yazmak

```python
import requests
API_ANAHTARI = "sk-gercek-anahtar-12345"   # kaynak kodda sabit!
yanit = requests.get(f"https://api.example.com/veri?key={API_ANAHTARI}")
```

- **Neden yanlış?** Kod çalışır ama bu **ciddi bir güvenlik
  hatasıdır** — bu kodu GitHub'a (özellikle açık bir depoya)
  gönderirsen, API anahtarın herkese açık hale gelir ve kötüye
  kullanılabilir.
- **Hata nerede?** Gizli/hassas anahtar, doğrudan kaynak kodun içine
  yazılmış.
- **Ne kullanmalısın?** Anahtarları ortam değişkenlerinde (`os.getenv
  ("API_ANAHTARI")`) veya `.env` dosyalarında sakla ve bu dosyaları
  `.gitignore`'a ekleyerek GitHub'a göndermekten kaçın.

## 🔗 İlgili Modüller
[Flask ve FastAPI](../17-flask-ve-fastapi/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
