# `os` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`os` modülü, Python programının **işletim sistemiyle** (Windows,
Linux, macOS) konuşmasını sağlar. Arka planda, işletim sisteminin
sunduğu sistem çağrılarını (system calls) Python fonksiyonlarına
sarmalar (wrap eder) — yani `os.listdir(".")` çağırdığında, Python
senin adına işletim sistemine "bu klasördeki dosyaları söyle" der ve
sonucu sana bir Python listesi olarak döndürür. Standart kütüphanenin
parçasıdır, **ek kurulum gerekmez.**

## Ne Zaman / Nerede Kullanılır?

- Dosya ve klasör oluşturma, silme, yeniden adlandırma
- Bir klasördeki dosyaları listeleme
- Ortam değişkenlerine (environment variables) erişme
- Platformlar arası (Windows/Linux) uyumlu dosya yolu oluşturma
- 4R022 masaüstü uygulamalarında kullanıcı veri klasörünü
  (`%APPDATA%`, `~/.config` gibi) platforma göre bulma

## ✅ Çalışan Örnekler

```python
# Örnek 1: Mevcut çalışma klasörünü ve içeriğini görme
import os
print(os.getcwd())
print(os.listdir("."))
```

```python
# Örnek 2: Klasör oluşturma (varsa hata vermeden)
import os
os.makedirs("cikti/gunluk", exist_ok=True)
```

```python
# Örnek 3: Platforma uygun dosya yolu oluşturma
import os
yol = os.path.join("proje", "veri", "ayarlar.json")
print(yol)   # Windows'ta: proje\veri\ayarlar.json
             # Linux/macOS'ta: proje/veri/ayarlar.json
```

```python
# Örnek 4: Ortam değişkenine erişme (kullanıcı veri klasörü)
import os
appdata = os.getenv("APPDATA", os.path.expanduser("~"))
print(appdata)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Var Olmayan Klasörü Silmeye Çalışmak

```python
import os
os.rmdir("olmayan_klasor")
```

- **Neden yanlış?** `olmayan_klasor` diskte gerçekten yoksa, işletim
  sistemi Python'a "böyle bir dizin yok" bilgisini döndürür.
- **Hata nerede?** `os.rmdir()` çağrısında — bu fonksiyon var olan,
  **boş** bir klasörü siler; olmayan bir klasörde çalışmaz.
- **Ne kullanmalısın?** Önce kontrol et:
  ```python
  if os.path.isdir("olmayan_klasor"):
      os.rmdir("olmayan_klasor")
  else:
      print("Klasör zaten yok.")
  ```

### Yanlış Örnek 2 — Dolu Bir Klasörü `rmdir()` ile Silmeye Çalışmak

```python
import os
os.rmdir("dolu_klasor")   # içinde dosyalar var
```

- **Neden yanlış?** `os.rmdir()` **yalnızca boş** klasörleri siler;
  güvenlik amacıyla içi doluysa reddeder.
- **Hata nerede?** `dolu_klasor` içinde en az bir dosya/alt klasör
  olduğu için `OSError: [Errno 39] Directory not empty` verir.
- **Ne kullanmalısın?** İçi dolu klasörü tüm içeriğiyle silmek için
  `os` değil `shutil` modülünü kullan: `shutil.rmtree("dolu_klasor")`.

### Yanlış Örnek 3 — Elle Yol Birleştirme (Platform Bağımlılığı)

```python
import os
yol = "veri" + "/" + "ayarlar.json"
dosya = open(yol)
```

- **Neden yanlış?** Kod "çalışır" ama **taşınabilir değildir** — bu
  bir çalışma zamanı hatası değil, gizli bir platform bağımlılığı
  hatasıdır.
- **Hata nerede?** `/` karakteri elle yazılmış; Windows'ta bazı eski
  API'lerde veya karışık yol senaryolarında sorun çıkarabilir.
- **Ne kullanmalısın?** `os.path.join("veri", "ayarlar.json")` — bu,
  hangi işletim sisteminde çalıştığını otomatik algılar ve doğru
  ayıracı (`/` veya `\`) kullanır.

## 🔗 İlgili Modüller
[pathlib](../10-pathlib/README.md) (daha modern alternatif), [sys](../02-sys/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
