# `queue` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`queue`, thread'ler arasında **güvenli veri aktarımı** için tasarlanmış
bir kuyruk (FIFO — First In, First Out) yapısıdır. Normal bir `list`
kullanıp threadler arasında veri paylaşmak yarış durumlarına (race
condition) açıktır; `queue.Queue` bunu içeride otomatik kilitleme
(locking) ile güvenli hale getirir.

## Ne Zaman / Nerede Kullanılır?

- Bir "üretici-tüketici (producer-consumer)" deseni kurmak (bir
  thread veri üretir, başka bir thread işler)
- Arka planda çalışan bir işin sonucunu ana thread'e (örneğin GUI
  thread'ine) güvenle iletmek

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit kuyruk kullanımı
import queue
q = queue.Queue()
q.put("görev-1")
q.put("görev-2")
print(q.get())   # "görev-1" (ilk giren ilk çıkar)
print(q.get())   # "görev-2"
```

```python
# Örnek 2: Thread'ler arası güvenli veri aktarımı
import threading, queue

def uret(q):
    q.put("Sonuç hazır!")

q = queue.Queue()
t = threading.Thread(target=uret, args=(q,))
t.start()
t.join()
print(q.get())
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Boş Kuyruktan Bloklamadan Veri Almaya Çalışmak

```python
import queue
q = queue.Queue()
sonuc = q.get_nowait()
```

- **Neden yanlış?** Kuyruk boşken `get_nowait()`, beklemeden hemen
  bir hata fırlatır.
- **Hata nerede?** `queue.Empty` istisnası verir çünkü kuyrukta hiç
  eleman yok.
- **Ne kullanmalısın?** Beklemesi sorun değilse `q.get()` kullan (bu,
  eleman gelene kadar bekler); beklemek istemiyorsan
  `try/except queue.Empty` ile yakala.

### Yanlış Örnek 2 — Normal `list`'i Thread'ler Arası Kuyruk Gibi Kullanmak

```python
import threading
liste = []

def uret():
    liste.append("veri")

def tuket():
    if liste:
        print(liste.pop(0))

threading.Thread(target=uret).start()
threading.Thread(target=tuket).start()
```

- **Neden yanlış?** `list.append()`/`list.pop()` atomik değildir;
  iki thread aynı anda listeye erişirse veri kaybı/çökme riski
  vardır (bkz. [threading](../12-threading/README.md)).
- **Hata nerede?** Paylaşılan veri yapısı olarak kilitlenmeyen bir
  `list` seçilmiş.
- **Ne kullanmalısın?** `queue.Queue()` — thread-safe olduğu
  garantilidir.

## 🔗 İlgili Modüller
[threading](../12-threading/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
