# `asyncio` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`asyncio`, **tek bir thread içinde**, çok sayıda bekleme gerektiren
işi (ağ isteği, dosya G/Ç) verimli şekilde yönetmeni sağlar. Mantığı
şudur: bir görev `await` ile "beklemeye" geçtiğinde, `asyncio` o
görevi askıya alır ve **aynı thread üzerinde** başka bir görevi
çalıştırır — thread veya process açmadan "eşzamanlılık" sağlar.

## Ne Zaman / Nerede Kullanılır?

- Yüzlerce/binlerce eşzamanlı ağ isteği yapan araçlar (web scraper,
  API istemcileri)
- Modern web sunucuları (FastAPI, aiohttp) arka planında
- Discord botları gibi sürekli çok sayıda olayı bekleyen uygulamalar

## ✅ Çalışan Örnekler

```python
# Örnek 1: Temel async fonksiyon
import asyncio

async def selamla(isim):
    await asyncio.sleep(1)
    print(f"Merhaba, {isim}!")

asyncio.run(selamla("Kaan"))
```

```python
# Örnek 2: Birden fazla görevi eşzamanlı çalıştırma
import asyncio

async def indir(dosya_no):
    print(f"{dosya_no} indiriliyor...")
    await asyncio.sleep(2)
    return f"{dosya_no} tamamlandı"

async def main():
    sonuclar = await asyncio.gather(indir(1), indir(2), indir(3))
    print(sonuclar)   # hepsi ~2 saniyede biter, 6 saniyede değil!

asyncio.run(main())
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `await` Olmadan Async Fonksiyon Çağırmak

```python
import asyncio

async def selamla():
    print("Merhaba!")

selamla()   # 'await' veya asyncio.run() olmadan
```

- **Neden yanlış?** Bir `async def` fonksiyonunu doğrudan çağırmak,
  onu **çalıştırmaz** — sadece bir "coroutine nesnesi" oluşturur.
- **Hata nerede?** Python bunu bir hata olarak göstermez ama
  `RuntimeWarning: coroutine 'selamla' was never awaited` uyarısı
  verir ve fonksiyon içindeki kod **hiç çalışmaz.**
- **Ne kullanmalısın?** Ya `asyncio.run(selamla())` ile çalıştır, ya
  da başka bir async fonksiyon içindeyse `await selamla()` kullan.

### Yanlış Örnek 2 — Async Fonksiyon İçinde Bloklayan (Senkron) Kod Kullanmak

```python
import asyncio, time

async def yavas_islem():
    time.sleep(3)   # BU, tüm event loop'u dondurur!
    print("Bitti")

async def main():
    await asyncio.gather(yavas_islem(), yavas_islem())

asyncio.run(main())
```

- **Neden yanlış?** `time.sleep()` senkron (bloklayan) bir
  fonksiyondur — event loop'un **kendisini** durdurur, sadece o
  görevi değil. Bu, `asyncio`'nun tüm amacını (paralel bekleme)
  boşa çıkarır.
- **Hata nerede?** `time.sleep(3)` kullanılmış, `await
  asyncio.sleep(3)` değil.
- **Ne kullanmalısın?** Async kodda her zaman async uyumlu
  fonksiyonları kullan: `await asyncio.sleep(3)`. Gerçek G/Ç
  işlemlerinde de (dosya, ağ) `aiofiles`, `aiohttp` gibi async
  uyumlu kütüphaneler tercih edilmelidir.

### Yanlış Örnek 3 — `asyncio.run()`'ı Zaten Çalışan Bir Döngü İçinde Çağırmak

```python
import asyncio

async def ana_gorev():
    await asyncio.sleep(1)

async def diger_gorev():
    asyncio.run(ana_gorev())   # zaten bir event loop içindeyken!

asyncio.run(diger_gorev())
```

- **Neden yanlış?** `asyncio.run()`, **yeni bir event loop**
  başlatmak için tasarlanmıştır; zaten çalışan bir loop'un içinden
  tekrar çağrılamaz.
- **Hata nerede?** `RuntimeError: asyncio.run() cannot be called
  from a running event loop` verir.
- **Ne kullanmalısın?** Zaten bir async fonksiyonun içindeysen,
  başka bir async fonksiyonu `asyncio.run()` ile değil `await
  ana_gorev()` ile çağır.

## 🔗 İlgili Modüller
[threading](../12-threading/README.md), [requests](../16-requests/README.md) (senkron alternatif)

---
⬅️ [Modüller Ana Sayfa](../README.md)
