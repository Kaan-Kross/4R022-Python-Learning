# Flask ve FastAPI

## Nedir ve Çalışma Prensibi Nedir?

Her ikisi de Python ile **web sunucusu / API** yazmanı sağlayan
üçüncü parti kütüphanelerdir (`pip install flask` / `pip install
fastapi uvicorn`). Flask, gelen HTTP isteklerini URL'lere (route'lara)
göre eşleştiren minimal bir "mikro-framework"tür. FastAPI ise aynı
mantığı, Python tip ipuçlarından (type hints) otomatik veri
doğrulaması ve otomatik API dokümantasyonu (Swagger UI) üreterek
genişletir; içi async (asyncio) destekli çalışır.

## Ne Zaman / Nerede Kullanılır?

- Kendi masaüstü/mobil uygulamana veri sağlayan bir backend kurmak
- Basit bir web sitesi veya iç araç (dashboard) yapmak (Flask)
- Yüksek performanslı, tip güvenli, otomatik dokümantasyonlu bir API
  yazmak (FastAPI)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Flask ile minimal API
from flask import Flask, jsonify
app = Flask(__name__)

@app.route("/ogrenciler")
def ogrenciler():
    return jsonify([{"isim": "Kaan", "not": 95}])

if __name__ == "__main__":
    app.run(debug=True)
```

```python
# Örnek 2: FastAPI ile tip güvenli bir uç nokta
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Ogrenci(BaseModel):
    isim: str
    not_: int

@app.post("/ogrenci-ekle")
def ogrenci_ekle(ogrenci: Ogrenci):
    return {"mesaj": f"{ogrenci.isim} eklendi"}
# Çalıştırma: uvicorn dosya_adi:app --reload
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `debug=True` ile Üretime (Production) Çıkmak

```python
app.run(debug=True, host="0.0.0.0")
```

- **Neden yanlış?** `debug=True`, hata oluştuğunda tarayıcıda
  **etkileşimli bir Python konsolu (Werkzeug debugger)** açar — bu
  konsol, gerçek kullanıcılara açık bir sunucuda **rastgele kod
  çalıştırma** imkânı verebilir; ciddi bir güvenlik açığıdır.
- **Hata nerede?** Geliştirme (development) ayarı, canlıya
  (production) taşınmış.
- **Ne kullanmalısın?** Üretimde `debug=False` kullan ve Flask'ı
  doğrudan değil, `gunicorn` gibi bir WSGI sunucusu arkasında
  çalıştır.

### Yanlış Örnek 2 — Route Fonksiyonuna Yanlış HTTP Metoduyla İstek Atmak

```python
# Flask tarafı:
@app.route("/veri", methods=["GET"])
def veri_getir():
    return jsonify({"durum": "ok"})

# İstemci tarafı:
import requests
requests.post("http://localhost:5000/veri")
```

- **Neden yanlış?** Route yalnızca `GET` metodunu kabul edecek
  şekilde tanımlanmış; `POST` isteği bu route ile eşleşmez.
- **Hata nerede?** Sunucu `405 Method Not Allowed` döndürür çünkü
  `methods` listesinde `"POST"` yok.
- **Ne kullanmalısın?** Ya isteği `requests.get(...)` olarak gönder,
  ya da route tanımını `methods=["GET", "POST"]` yaparak genişlet.

### Yanlış Örnek 3 — Pydantic Modeline Uymayan Veri Göndermek (FastAPI)

```python
import requests
requests.post("http://localhost:8000/ogrenci-ekle",
              json={"isim": "Kaan", "not_": "doksan beş"})   # str, int değil!
```

- **Neden yanlış?** `Ogrenci` modeli `not_: int` bekliyor; `"doksan
  beş"` bir tam sayıya çevrilemeyen bir string.
- **Hata nerede?** FastAPI, isteği otomatik olarak reddeder —
  `422 Unprocessable Entity` hatası döner (bu FastAPI'nin **avantajı**
  aslında: hatalı veri sunucuya hiç ulaşmadan yakalanır).
- **Ne kullanmalısın?** İstemciden doğru tipte veri gönder:
  `{"isim": "Kaan", "not_": 95}`

## 🔗 İlgili Modüller
[requests](../16-requests/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
