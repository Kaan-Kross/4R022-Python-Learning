# `shutil` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`shutil` (shell utilities), `os` modülünün tekil dosya işlemlerinin
(oluşturma, silme) üstüne, **yüksek seviyeli** dosya/klasör
işlemlerini ekler: kopyalama, taşıma, tüm klasörü silme, arşiv
(zip/tar) oluşturma. `os` "tuğlaları" verirken, `shutil` bu
tuğlalardan "hazır duvarlar" sunar.

## Ne Zaman / Nerede Kullanılır?

- Bir klasörü, tüm alt klasör/dosyalarıyla birlikte kopyalamak
- Dolu bir klasörü toptan silmek (`os.rmdir()` bunu yapamaz)
- Uygulama çıktısını `.zip` olarak paketlemek

## ✅ Çalışan Örnekler

```python
# Örnek 1: Dosya kopyalama
import shutil
shutil.copy("kaynak.txt", "hedef.txt")
```

```python
# Örnek 2: Dolu klasörü tamamen silme
import shutil
shutil.rmtree("dolu_klasor")   # os.rmdir()'in yapamadığını yapar
```

```python
# Örnek 3: Klasörü zip'e paketleme
import shutil
shutil.make_archive("cikti", "zip", "cikti_klasoru")
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `shutil.copy()` ile Klasör Kopyalamaya Çalışmak

```python
import shutil
shutil.copy("kaynak_klasor", "hedef_klasor")
```

- **Neden yanlış?** `shutil.copy()` yalnızca **dosyalar** içindir,
  klasörleri kopyalamaz.
- **Hata nerede?** `IsADirectoryError` verir.
- **Ne kullanmalısın?** Tüm klasörü (alt klasörleriyle) kopyalamak
  için `shutil.copytree("kaynak_klasor", "hedef_klasor")` kullan.

### Yanlış Örnek 2 — `shutil.rmtree()`'yi Geri Alınabilir Sanmak

```python
import shutil
shutil.rmtree("onemli_veriler")   # "geri alırım" diye düşünmek
```

- **Neden yanlış?** `shutil.rmtree()`, klasörü ve içindeki HER ŞEYİ
  **kalıcı olarak, geri dönüşü olmadan** siler — çöp kutusuna
  taşımaz.
- **Hata nerede?** Bu bir kod hatası değil, bir **güvenlik/dikkat**
  hatasıdır — geri alma mekanizması yoktur.
- **Ne kullanmalısın?** Silmeden önce mutlaka yedek al veya
  `send2trash` gibi üçüncü parti bir kütüphaneyle "çöp kutusuna
  taşı" mantığını kullan.

## 🔗 İlgili Modüller
[os](../01-os/README.md), [tempfile](../28-tempfile/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
