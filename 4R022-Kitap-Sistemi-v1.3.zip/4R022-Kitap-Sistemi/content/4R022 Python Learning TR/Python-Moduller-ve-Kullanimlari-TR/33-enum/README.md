# `enum` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`enum`, sabit bir kümeye ait değerleri (örneğin "Pazartesi, Salı,
Çarşamba...") düz string veya sayı yerine, **okunaklı ve hataya
dayanıklı** isimlendirilmiş sabitler olarak tanımlamanı sağlar. Arka
planda her üye, benzersiz bir isim-değer çiftidir ve karşılaştırmalar
kimlik (identity) bazlı, hızlı ve güvenlidir.

## Ne Zaman / Nerede Kullanılır?

- Sabit bir durum kümesi tanımlamak (örneğin `Durum.BEKLIYOR`,
  `Durum.TAMAMLANDI`, `Durum.IPTAL`)
- "Sihirli string" (magic string) kullanımını önlemek — yanlış
  yazılmış bir string yerine, yanlış yazılan bir enum adı hemen
  hata verir
- Bir uygulamanın temasını, diline (`Dil.TR`, `Dil.EN`) göre yönetmek

## ✅ Çalışan Örnekler

```python
# Örnek 1: Temel enum tanımı
from enum import Enum

class Durum(Enum):
    BEKLIYOR = 1
    ISLENIYOR = 2
    TAMAMLANDI = 3

siparis_durumu = Durum.BEKLIYOR
print(siparis_durumu)          # Durum.BEKLIYOR
print(siparis_durumu.name)     # 'BEKLIYOR'
print(siparis_durumu.value)    # 1
```

```python
# Örnek 2: Enum ile karşılaştırma
from enum import Enum

class Durum(Enum):
    BEKLIYOR = 1
    TAMAMLANDI = 2

def islem_yap(durum):
    if durum == Durum.TAMAMLANDI:
        print("Zaten tamamlanmış.")
    else:
        print("İşleniyor...")

islem_yap(Durum.BEKLIYOR)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Enum Üyesini Düz Sayı ile Karşılaştırmak

```python
from enum import Enum

class Durum(Enum):
    BEKLIYOR = 1
    TAMAMLANDI = 2

if Durum.BEKLIYOR == 1:
    print("Bekliyor")
```

- **Neden yanlış?** Bir `Enum` üyesi, `.value`'su aynı olsa bile
  düz bir sayıya (`1`) **eşit değildir**; `Enum`, kendi tipiyle
  karşılaştırma yapar.
- **Hata nerede?** `Durum.BEKLIYOR == 1` ifadesi `False` döner —
  bu bir hata mesajı vermez, sessizce yanlış sonuç üretir.
- **Ne kullanmalısın?** `Durum.BEKLIYOR == Durum.BEKLIYOR` ya da
  değeri karşılaştırmak istiyorsan açıkça
  `Durum.BEKLIYOR.value == 1` yaz.

### Yanlış Örnek 2 — Aynı Değere Sahip İki Üye Tanımlayıp Farklı Olmalarını Beklemek

```python
from enum import Enum

class Renk(Enum):
    KIRMIZI = 1
    AL = 1   # aynı değer!

print(Renk.KIRMIZI is Renk.AL)
```

- **Neden yanlış?** Aynı değere sahip iki üye tanımlarsan, `enum`
  bunları **takma ad (alias)** sayar — `AL`, aslında `KIRMIZI`'nın
  başka bir ismidir, ayrı bir üye değildir.
- **Hata nerede?** `Renk.KIRMIZI is Renk.AL` beklenmedik şekilde
  `True` döner (iki farklı üye olması beklenirken).
- **Ne kullanmalısın?** Gerçekten farklı üyeler istiyorsan farklı
  değerler ver (`KIRMIZI = 1`, `AL = 2`); takma ad davranışını
  engellemek istiyorsan `@enum.unique` dekoratörünü kullan — bu,
  tekrar eden değer varsa hata fırlatır.

## 🔗 İlgili Modüller
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
