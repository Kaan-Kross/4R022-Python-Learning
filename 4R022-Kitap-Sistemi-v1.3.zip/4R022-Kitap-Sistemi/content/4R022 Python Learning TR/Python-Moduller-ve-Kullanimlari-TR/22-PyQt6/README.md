# `PyQt6` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`PyQt6`, güçlü ve profesyonel bir C++ GUI kütüphanesi olan **Qt6**'nın
Python bağlayıcısıdır (`pip install PyQt6`). Çalışma mantığı, tıpkı
tkinter gibi bir olay döngüsüne (`app.exec()`) dayanır, ama en
belirleyici özelliği **sinyal/slot (signal/slot)** mimarisidir: bir
bileşende bir şey olduğunda (sinyal), buna bağlı bir fonksiyon (slot)
otomatik olarak tetiklenir.

## Ne Zaman / Nerede Kullanılır?

- Profesyonel görünümlü, ölçeklenebilir masaüstü uygulamaları
  (4R022'nin çoğu masaüstü ürünü PyQt6 ile yazılır)
- Karmaşık arayüzler (çoklu pencere, özel widget'lar, tema desteği)
- `core/` + `ui/` mimarisiyle büyük projeler

## ✅ Çalışan Örnekler

```python
# Örnek 1: Minimal pencere
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel

app = QApplication(sys.argv)
pencere = QWidget()
pencere.setWindowTitle("4R022 Örnek")
etiket = QLabel("Merhaba!", pencere)
pencere.show()
sys.exit(app.exec())
```

```python
# Örnek 2: Sinyal/slot ile buton bağlama
from PyQt6.QtWidgets import QPushButton
buton = QPushButton("Tıkla")
buton.clicked.connect(lambda: print("Tıklandı!"))
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `QApplication`'dan Önce Widget Oluşturmak

```python
from PyQt6.QtWidgets import QWidget, QApplication
import sys

pencere = QWidget()   # QApplication henüz yok!
app = QApplication(sys.argv)
pencere.show()
```

- **Neden yanlış?** Her PyQt6 uygulamasında **önce** `QApplication`
  oluşturulmalıdır; widget'lar, uygulamanın temel altyapısına
  ihtiyaç duyar.
- **Hata nerede?** `QWidget()` çağrısı, `QApplication(sys.argv)`'den
  **önce** yapılmış.
- **Ne kullanmalısın?** Sıralamayı düzelt: önce `app =
  QApplication(sys.argv)`, sonra widget'ları oluştur.

### Yanlış Örnek 2 — Sinyali Parantezle Bağlamaya Çalışmak

```python
from PyQt6.QtWidgets import QPushButton
def tiklandi():
    print("Tıklandı")

buton = QPushButton("Tıkla")
buton.clicked.connect(tiklandi())   # parantez var!
```

- **Neden yanlış?** `tiklandi()` yazmak, fonksiyonu **hemen** çağırır
  ve dönüş değerini (`None`) `.connect()`'e verir — tıklama olayına
  hiçbir fonksiyon gerçekten bağlanmaz.
- **Hata nerede?** `TypeError: connect() failed` benzeri bir hata
  verebilir çünkü `None`, `.connect()`'in beklediği bir "çağrılabilir
  (callable)" değildir.
- **Ne kullanmalısın?** `buton.clicked.connect(tiklandi)` —
  parantezsiz, fonksiyonun referansını ver.

### Yanlış Örnek 3 — Ana Thread Dışından Widget Güncellemek

```python
import threading
def arka_plan_isi():
    etiket.setText("Bitti!")   # ana thread dışından widget güncelleme

threading.Thread(target=arka_plan_isi).start()
```

- **Neden yanlış?** Tıpkı tkinter'da olduğu gibi, Qt widget'ları
  yalnızca **ana (GUI) thread'inden** güvenle güncellenebilir.
- **Hata nerede?** `etiket.setText(...)` çağrısı arka plan thread'i
  içinden yapılmış — bu çökmelere veya tanımsız davranışlara yol
  açabilir.
- **Ne kullanmalısın?** PyQt6'nın kendi `QThread` sınıfını ve
  **sinyal** mekanizmasını kullan: arka plan işin bitince bir sinyal
  yayınla (`emit`), ana thread'deki bir slot bu sinyali dinleyip
  arayüzü güncellesin.

## 🔗 İlgili Modüller
[tkinter](../21-tkinter/README.md), [threading](../12-threading/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
