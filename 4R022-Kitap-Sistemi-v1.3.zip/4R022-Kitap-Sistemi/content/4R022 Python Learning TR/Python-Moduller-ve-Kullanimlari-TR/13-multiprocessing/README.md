# `multiprocessing` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`multiprocessing`, birden fazla **tam bağımsız Python işlemi
(process)** başlatır — her birinin kendi belleği ve kendi GIL'i
vardır. Bu yüzden `threading`'in aksine, CPU-yoğun işlerde
**gerçek paralellik** sağlar (bilgisayarının birden fazla çekirdeğini
gerçekten aynı anda kullanır).

## Ne Zaman / Nerede Kullanılır?

- Görüntü/video işleme, büyük matematiksel hesaplamalar
- Birden fazla dosyayı paralel olarak analiz etmek
- CPU'nun tüm çekirdeklerini kullanmak isteyen veri işleme script'leri

## ✅ Çalışan Örnekler

```python
# Örnek 1: Pool ile paralel hesaplama
import multiprocessing

def kare_al(n):
    return n * n

if __name__ == "__main__":
    with multiprocessing.Pool(4) as havuz:
        sonuclar = havuz.map(kare_al, [1, 2, 3, 4, 5])
    print(sonuclar)   # [1, 4, 9, 16, 25]
```

```python
# Örnek 2: Process ve paylaşılan veri (Queue ile)
import multiprocessing

def uret(kuyruk):
    kuyruk.put("İşlemden gelen sonuç")

if __name__ == "__main__":
    kuyruk = multiprocessing.Queue()
    p = multiprocessing.Process(target=uret, args=(kuyruk,))
    p.start()
    p.join()
    print(kuyruk.get())
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `if __name__ == "__main__":` Korumasını Unutmak (Windows)

```python
import multiprocessing

def isle(n):
    return n * 2

havuz = multiprocessing.Pool(4)
print(havuz.map(isle, [1, 2, 3]))
```

- **Neden yanlış?** Windows'ta (ve macOS'ta belirli durumlarda),
  her yeni process, ana script'i **yeniden içe aktarır** — bu koruma
  olmadan, her alt process kendi `Pool`'unu tekrar tekrar oluşturmaya
  çalışır ve sonsuz process döngüsüne/çökmeye yol açar.
- **Hata nerede?** Kod, `if __name__ == "__main__":` bloğu içine
  alınmamış.
- **Ne kullanmalısın?**
  ```python
  if __name__ == "__main__":
      havuz = multiprocessing.Pool(4)
      print(havuz.map(isle, [1, 2, 3]))
  ```

### Yanlış Örnek 2 — İşlemler Arasında Normal Değişken Paylaşmaya Çalışmak

```python
import multiprocessing

sayac = 0

def artir():
    global sayac
    sayac += 1

if __name__ == "__main__":
    p = multiprocessing.Process(target=artir)
    p.start()
    p.join()
    print(sayac)   # hâlâ 0! (thread'den farklı olarak)
```

- **Neden yanlış?** Her process **kendi ayrı belleğine** sahiptir;
  bir process içinde değiştirilen `sayac`, ana programın belleğini
  ETKİLEMEZ. Bu, `threading`'den en büyük farktır ve sık karıştırılır.
- **Hata nerede?** `global sayac` kullanımı, processler arasında
  paylaşım sağlamaz — bu sadece o process'in kendi kopyasını etkiler.
- **Ne kullanmalısın?** Processler arası veri paylaşımı için
  `multiprocessing.Queue`, `multiprocessing.Value` veya
  `multiprocessing.Manager()` kullan.

### Yanlış Örnek 3 — Küçük İşler İçin Process Açmak (Aşırı Kaynak Tüketimi)

```python
import multiprocessing

def topla(a, b):
    return a + b

if __name__ == "__main__":
    with multiprocessing.Pool(4) as havuz:
        print(havuz.map(lambda x: topla(x, 1), range(10)))
```

- **Neden yanlış?** Process başlatmanın kendi maliyeti (yeni bellek
  alanı, işletim sistemi kaynak ayırma) vardır; bu kadar küçük bir
  iş için process açmak, doğrudan hesaplamaktan **daha yavaş**
  olabilir. (Ayrıca `lambda`, `multiprocessing` ile genelde
  picklenemez ve hataya da yol açar.)
- **Hata nerede?** İşin boyutu, process başlatma maliyetini
  karşılamıyor; ayrıca `lambda` kullanımı `PicklingError` verebilir.
- **Ne kullanmalısın?** Küçük/basit işlemler için düz bir `for`
  döngüsü veya liste anlama yeterlidir; `multiprocessing`'i yalnızca
  gerçekten ağır hesaplamalar için sakla, `lambda` yerine adlandırılmış
  bir fonksiyon tanımla.

## 🔗 İlgili Modüller
[threading](../12-threading/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
