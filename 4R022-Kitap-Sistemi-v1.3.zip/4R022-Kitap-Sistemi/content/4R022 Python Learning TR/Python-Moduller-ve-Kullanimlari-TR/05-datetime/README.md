# `datetime` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`datetime` modülü, tarih ve saat verisini **doğru şekilde temsil
etmeni, karşılaştırmanı ve biçimlendirmeni** sağlar. Tarihleri
"2026-09-15" gibi düz string olarak tutmak yerine, `datetime` nesnesi
kullanmak; gün/ay farkı hesaplama, sıralama, zaman dilimi gibi
işlemleri güvenli hale getirir.

## Ne Zaman / Nerede Kullanılır?

- Log kayıtlarına zaman damgası (timestamp) eklemek
- Hatırlatıcı/alarm uygulamalarında ("2 saat sonra hatırlat" gibi)
  hesaplama yapmak — 4R022 SAAT projesinin temel mantığı
- Yaş, süre, geri sayım hesaplamaları

## ✅ Çalışan Örnekler

```python
# Örnek 1: Şu anki tarih/saat ve biçimlendirme
from datetime import datetime
simdi = datetime.now()
print(simdi.strftime("%d.%m.%Y %H:%M"))   # 15.09.2026 14:30
```

```python
# Örnek 2: Tarih farkı hesaplama
from datetime import datetime
dogum = datetime(2000, 5, 20)
fark = datetime.now() - dogum
print(fark.days, "gün yaşandı")
```

```python
# Örnek 3: Belirli bir süre sonrasını hesaplama (hatırlatıcı mantığı)
from datetime import datetime, timedelta
hatirlatma = datetime.now() + timedelta(hours=2, minutes=30)
print("Hatırlatma zamanı:", hatirlatma.strftime("%H:%M"))
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Format Dizesi Gerçek Veriyle Uyuşmuyor

```python
from datetime import datetime
tarih = datetime.strptime("2026-09-15", "%d/%m/%Y")
```

- **Neden yanlış?** `strptime`'a verilen format (`%d/%m/%Y`, yani
  gün/ay/yıl ile `/` ayracı), string'in gerçek biçimiyle
  (`yıl-ay-gün`, `-` ayracı) **birebir eşleşmiyor.**
- **Hata nerede?** Format string'i yanlış: `-` yerine `/`, sıra
  yanlış (yıl-ay-gün yerine gün-ay-yıl yazılmış).
- **Ne kullanmalısın?** `datetime.strptime("2026-09-15", "%Y-%m-%d")`

### Yanlış Örnek 2 — İki Farklı Tipi Karşılaştırmaya Çalışmak

```python
from datetime import datetime
tarih1 = datetime.now()
tarih2 = "2026-09-15"
print(tarih1 > tarih2)
```

- **Neden yanlış?** Bir `datetime` nesnesi ile bir `str` doğrudan
  karşılaştırılamaz; ikisi farklı tiptedir.
- **Hata nerede?** `tarih2` bir string olarak bırakılmış, `datetime`
  nesnesine çevrilmemiş.
- **Ne kullanmalısın?**
  `tarih2 = datetime.strptime("2026-09-15", "%Y-%m-%d")` ile önce
  çevir, sonra karşılaştır.

### Yanlış Örnek 3 — Zaman Dilimini (Timezone) Yok Saymak

```python
from datetime import datetime
toplanti_saati = datetime(2026, 9, 15, 14, 0)   # hangi saat dilimi?
```

- **Neden yanlış?** Kod çalışır ama **"naive" (saat dilimsiz)** bir
  `datetime` nesnesi oluşturur; farklı saat dilimlerindeki
  kullanıcılar arasında karşılaştırma yapılırsa yanlış sonuç verir.
- **Hata nerede?** Saat dilimi bilgisi hiç belirtilmemiş.
- **Ne kullanmalısın?** Çok kullanıcılı/global uygulamalarda
  `zoneinfo` (Python 3.9+ standart kütüphane) ile saat dilimi
  belirt: `datetime(2026, 9, 15, 14, 0, tzinfo=ZoneInfo("Europe/Istanbul"))`

## 🔗 İlgili Modüller
[os](../01-os/README.md) (dosya değiştirilme zamanı için), [logging](../11-logging/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
