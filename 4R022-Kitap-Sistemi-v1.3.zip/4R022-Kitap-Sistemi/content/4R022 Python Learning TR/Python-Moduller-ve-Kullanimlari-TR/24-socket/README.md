# `socket` Modülü

> ⚠️ Ağ programlamasının temelidir; meşru kullanım (kendi sunucun,
> öğrenme amaçlı yerel ağ) ile izinsiz kullanım arasındaki fark için
> [Etik ve Güvenlik](../../Python-Etik-ve-Guvenlik-TR/README.md)
> bölümüne bak.

## Nedir ve Çalışma Prensibi Nedir?

`socket`, işletim sisteminin ağ katmanına doğrudan erişim sağlayan,
standart kütüphanenin en düşük seviyeli ağ modülüdür. `requests`
gibi kütüphaneler aslında arka planda `socket`'i kullanır — sen bu
modülle, HTTP gibi hazır bir protokolün **altına inip**, ham TCP/UDP
bağlantıları kurabilirsin.

## Ne Zaman / Nerede Kullanılır?

- Kendi basit istemci-sunucu (client-server) uygulamanı yazmak
- Ağ programlamasının temellerini öğrenmek (HTTP, FTP gibi
  protokollerin altında ne olduğunu anlamak)
- Yerel ağda (LAN) iki program arasında doğrudan veri alışverişi

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit TCP sunucu (localhost)
import socket
sunucu = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sunucu.bind(("localhost", 5000))
sunucu.listen(1)
baglanti, adres = sunucu.accept()
baglanti.send(b"Merhaba, istemci!")
baglanti.close()
```

```python
# Örnek 2: Basit TCP istemci
import socket
istemci = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
istemci.connect(("localhost", 5000))
mesaj = istemci.recv(1024)
print(mesaj.decode())
istemci.close()
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Yönetici İzni Gerektiren Düşük Port Kullanmak

```python
import socket
sunucu = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sunucu.bind(("localhost", 80))
```

- **Neden yanlış?** 1024'ün altındaki portlar (80, 443 gibi) çoğu
  işletim sisteminde **yönetici/root izni** gerektirir.
- **Hata nerede?** `PermissionError: [Errno 13] Permission denied`
  verebilir (özellikle Linux/macOS'ta normal kullanıcıyla).
- **Ne kullanmalısın?** Geliştirme/test için 1024'ün üzerinde bir
  port kullan (örn. `8080`, `5000`).

### Yanlış Örnek 2 — Bayt (bytes) ile String'i Karıştırmak

```python
import socket
sunucu = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
baglanti, adres = sunucu.accept()
baglanti.send("Merhaba")   # str, bytes değil!
```

- **Neden yanlış?** `socket.send()`, yalnızca **bytes** tipi veri
  kabul eder; düz bir `str` göndermeye çalışmak hataya yol açar.
- **Hata nerede?** `TypeError: a bytes-like object is required, not
  'str'` verir.
- **Ne kullanmalısın?** String'i `.encode()` ile bytes'a çevir:
  `baglanti.send("Merhaba".encode())` veya doğrudan `b"Merhaba"`.

### Yanlış Örnek 3 — Portu Kapatmadan Sunucuyu Yeniden Başlatmaya Çalışmak

```python
import socket
sunucu = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sunucu.bind(("localhost", 5000))
# ... program bir şekilde çöküyor, socket kapanmıyor ...
# script tekrar çalıştırılıyor:
sunucu2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sunucu2.bind(("localhost", 5000))   # aynı port hâlâ meşgul!
```

- **Neden yanlış?** Önceki çalıştırmadan kalan soket, işletim
  sistemi tarafından bir süre "TIME_WAIT" durumunda tutulur; aynı
  portu hemen tekrar kullanmak çakışmaya yol açabilir.
- **Hata nerede?** `OSError: [Errno 98] Address already in use`
  verir.
- **Ne kullanmalısın?** `sunucu.setsockopt(socket.SOL_SOCKET,
  socket.SO_REUSEADDR, 1)` ekleyerek portun hemen yeniden
  kullanılabilmesini sağla; ayrıca `finally` bloğunda mutlaka
  `sunucu.close()` çağır.

## 🔗 İlgili Modüller
[threading](../12-threading/README.md), [cryptography](../25-cryptography/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
