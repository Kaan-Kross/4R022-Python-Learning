# `itertools` ve `functools` Modülleri

## Nedir ve Çalışma Prensibi Nedir?

`itertools`, döngüler için **bellekten tasarruflu, hızlı** araçlar
sunar — sonuçları anında tek bir listeye koymak yerine, generatör
mantığıyla (bkz. Orta Kademe) teker teker üretir. `functools` ise
fonksiyonları "fonksiyon olarak" işlemeni sağlayan araçlar sunar
(önbellekleme, kısmi uygulama, azaltma/reduce işlemleri).

## Ne Zaman / Nerede Kullanılır?

- Büyük veri kümelerinde kombinasyon/permütasyon üretmek (`itertools`)
- Sonsuz veya çok büyük döngüleri bellek dostu şekilde yönetmek
- Fonksiyon sonuçlarını önbelleğe almak (`functools.lru_cache`)
- Bir listeyi tek bir değere indirgemek (`functools.reduce`)

## ✅ Çalışan Örnekler

```python
# Örnek 1: itertools.permutations — tüm sıralamalar
from itertools import permutations
for p in permutations(["A", "B", "C"]):
    print(p)
```

```python
# Örnek 2: itertools.chain — birden fazla listeyi zincirlemek
from itertools import chain
liste1 = [1, 2, 3]
liste2 = [4, 5, 6]
for eleman in chain(liste1, liste2):
    print(eleman)   # 1,2,3,4,5,6 — tek liste oluşturmadan
```

```python
# Örnek 3: functools.reduce — listeyi tek değere indirgemek
from functools import reduce
sayilar = [1, 2, 3, 4]
carpim = reduce(lambda a, b: a * b, sayilar)
print(carpim)   # 24 (1*2*3*4)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Sonsuz Bir `itertools.count()` Üzerinde Normal `for` Kullanmak

```python
from itertools import count
for i in count(1):
    print(i)   # asla durmaz!
```

- **Neden yanlış?** `count()`, adından da anlaşılacağı gibi
  **sonsuz** bir sayaçtır; `break` olmadan asla durmaz.
- **Hata nerede?** Döngü içinde bir çıkış koşulu (`break`) yok.
- **Ne kullanmalısın?**
  ```python
  from itertools import count
  for i in count(1):
      if i > 10:
          break
      print(i)
  ```

### Yanlış Örnek 2 — `lru_cache`'i Değiştirilebilir (Mutable) Argümanla Kullanmak

```python
from functools import lru_cache

@lru_cache(maxsize=None)
def toplam_hesapla(liste):
    return sum(liste)

toplam_hesapla([1, 2, 3])
```

- **Neden yanlış?** `lru_cache`, önbellekleme yapmak için
  argümanları "hashlenebilir" olmasını gerektirir; `list` gibi
  değiştirilebilir tipler hashlenemez.
- **Hata nerede?** `TypeError: unhashable type: 'list'` verir çünkü
  parametre olarak bir `list` verilmiş.
- **Ne kullanmalısın?** Listeyi `tuple`'a çevirerek çağır:
  `toplam_hesapla((1, 2, 3))` — `tuple` hashlenebilir bir tiptir.

### Yanlış Örnek 3 — `itertools.permutations` ile Aşırı Büyük Girdi Kullanmak

```python
from itertools import permutations
buyuk_liste = list(range(15))
tum_permutasyonlar = list(permutations(buyuk_liste))
```

- **Neden yanlış?** 15 elemanın permütasyon sayısı `15! ≈ 1.3
  trilyon`dur — bu, RAM'i tüketip programın donmasına/çökmesine yol
  açar. Bu bir syntax hatası değil, bir **kapasite/algoritma
  hatasıdır.**
- **Hata nerede?** Sonuç, `list()` ile **anında ve tamamen** hafızaya
  alınmaya çalışılıyor.
- **Ne kullanmalısın?** Sonucu `list()`'e çevirmeden, generatörü
  doğrudan bir `for` döngüsüyle **teker teker** işle; ya da girdi
  boyutunu gerçekçi bir sınıra (örn. 8-10 eleman) indir.

## 🔗 İlgili Modüller
[collections](../08-collections/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
