# `tkinter` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`tkinter`, Python'ın standart kütüphanesiyle birlikte gelen masaüstü
arayüz (GUI) kütüphanesidir — Tcl/Tk adlı eski ama sağlam bir GUI
araç setine ince bir Python sarmalayıcıdır. Çalışma mantığı bir
**olay döngüsüne (event loop)** dayanır: `mainloop()` çağrıldığında
program, kullanıcı bir şeye tıklayana/yazana kadar bekler ve olaylara
tepki verir.

## Ne Zaman / Nerede Kullanılır?

- Ek kurulum istemeyen, hızlı, küçük masaüstü araçları
- Prototipleme — bir fikri hızlıca test etmek
- Okul/öğrenim projeleri (kurulum gerektirmemesi büyük avantaj)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Minimal pencere
import tkinter as tk
pencere = tk.Tk()
pencere.title("4R022 Örnek")
tk.Label(pencere, text="Merhaba!").pack()
pencere.mainloop()
```

```python
# Örnek 2: Buton ile etkileşim
import tkinter as tk
def tiklandi():
    etiket.config(text="Tıklandı!")

pencere = tk.Tk()
etiket = tk.Label(pencere, text="Bekleniyor...")
etiket.pack()
tk.Button(pencere, text="Tıkla", command=tiklandi).pack()
pencere.mainloop()
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `mainloop()` Çağırmayı Unutmak

```python
import tkinter as tk
pencere = tk.Tk()
tk.Label(pencere, text="Bu görünmeyecek").pack()
```

- **Neden yanlış?** `mainloop()` olmadan olay döngüsü hiç başlamaz;
  program anında sonlanır, pencere ya hiç görünmez ya da anında
  kapanır.
- **Hata nerede?** `pencere.mainloop()` satırı hiç yazılmamış.
- **Ne kullanmalısın?** Her tkinter programının **son satırı**
  `pencere.mainloop()` olmalıdır.

### Yanlış Örnek 2 — `command=` İçinde Fonksiyonu Çağırıp Parantez Koymak

```python
import tkinter as tk
def tiklandi():
    print("Tıklandı")

pencere = tk.Tk()
tk.Button(pencere, text="Tıkla", command=tiklandi()).pack()  # parantez var!
pencere.mainloop()
```

- **Neden yanlış?** `command=tiklandi()` yazmak, fonksiyonu **hemen,
  pencere açılırken** çağırır ve fonksiyonun **dönüş değerini**
  (`None`) butona bağlar — böylece butona hiçbir zaman gerçekten
  tıklanmış gibi çalışmaz.
- **Hata nerede?** Parantez fazladan eklenmiş: `tiklandi()` yerine
  `tiklandi` (parantezsiz, fonksiyonun kendisi) verilmeliydi.
- **Ne kullanmalısın?** `command=tiklandi` — parantezsiz, fonksiyonun
  referansını ver, tkinter tıklandığında kendisi çağırır.

### Yanlış Örnek 3 — Ana Thread Dışından Arayüzü Güncellemek

```python
import tkinter as tk
import threading, time

def uzun_islem():
    time.sleep(3)
    etiket.config(text="Bitti!")   # başka thread'den arayüz güncelleme!

pencere = tk.Tk()
etiket = tk.Label(pencere, text="Bekleniyor...")
etiket.pack()
threading.Thread(target=uzun_islem).start()
pencere.mainloop()
```

- **Neden yanlış?** Tkinter (çoğu GUI kütüphanesi gibi) **thread-safe
  değildir** — arayüz elemanlarını yalnızca ana thread'den güncellemek
  güvenlidir; başka bir thread'den doğrudan güncellemek çökmelere
  veya tuhaf davranışlara yol açabilir.
- **Hata nerede?** `etiket.config(...)` çağrısı, ana thread değil,
  arka plan thread'i içinden yapılmış.
- **Ne kullanmalısın?** Arka plan işleminden sonucu almak için
  `pencere.after(...)` ile ana thread'e "mesaj" gönder, ya da bir
  `queue.Queue` kullanarak sonucu ana döngüde işleyerek arayüzü
  güncelle.

## 🔗 İlgili Modüller
[PyQt6](../22-PyQt6/README.md), [threading](../12-threading/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
