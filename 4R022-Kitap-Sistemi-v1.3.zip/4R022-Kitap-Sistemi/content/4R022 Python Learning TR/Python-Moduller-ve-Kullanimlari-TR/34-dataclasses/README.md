# `dataclasses` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`dataclasses`, esasen **veri tutmak** için yazılan sınıflarda
(`__init__`, `__repr__`, `__eq__` gibi) tekrar eden kalıp kodu
otomatik oluşturan bir dekoratördür. `@dataclass` eklediğin bir
sınıfta, bu metodları elle yazmana gerek kalmaz — Python, sınıf
tanımındaki alanlara bakarak bunları otomatik üretir.

## Ne Zaman / Nerede Kullanılır?

- Basit, çoğunlukla veri taşıyan sınıflar yazarken (bir koordinat,
  bir kullanıcı kaydı, bir ayar bloğu)
- `namedtuple`'a benzer ama **değiştirilebilir (mutable)** bir yapı
  gerektiğinde

## ✅ Çalışan Örnekler

```python
# Örnek 1: Klasik sınıf yerine dataclass
from dataclasses import dataclass

@dataclass
class Nokta:
    x: int
    y: int

n1 = Nokta(1, 2)
print(n1)           # Nokta(x=1, y=2) — __repr__ otomatik!
n2 = Nokta(1, 2)
print(n1 == n2)      # True — __eq__ otomatik!
```

```python
# Örnek 2: Varsayılan değerler ve tip ipuçları
from dataclasses import dataclass, field

@dataclass
class Ogrenci:
    isim: str
    notlar: list = field(default_factory=list)   # değiştirilebilir varsayılan

ogrenci = Ogrenci("Kaan")
ogrenci.notlar.append(95)
print(ogrenci)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Değiştirilebilir Varsayılan Değeri Doğrudan Vermek

```python
from dataclasses import dataclass

@dataclass
class Ogrenci:
    isim: str
    notlar: list = []   # doğrudan boş liste vermek!
```

- **Neden yanlış?** Python (normal fonksiyonlarda olduğu gibi)
  değiştirilebilir (mutable) bir varsayılan değeri (`list`, `dict`)
  doğrudan vermene izin vermez — bu, tüm nesnelerin **aynı** listeyi
  paylaşmasına yol açabilecek klasik bir tuzaktır.
- **Hata nerede?** `ValueError: mutable default <class 'list'> for
  field notlar is not allowed` verir — `dataclasses` bunu bilerek
  engeller.
- **Ne kullanmalısın?** `field(default_factory=list)` kullan — bu,
  her yeni nesne için **taze bir liste** oluşturur.

### Yanlış Örnek 2 — Tip İpucunu (Type Hint) Zorunlu Sanmak

```python
from dataclasses import dataclass

@dataclass
class Nokta:
    x: int
    y: int

n = Nokta("bir", "iki")   # str verilmiş, int değil!
print(n)
```

- **Neden yanlış?** `dataclasses`'taki tip ipuçları (`x: int`)
  **çalışma zamanında zorlanmaz** — bu sadece bir dokümantasyon/
  IDE yardımıdır. Python, `"bir"` gibi bir string'i `x`'e atamana
  izin verir, hata vermez.
- **Hata nerede?** Aslında bir "hata" yoktur — bu bir **yanlış
  varsayımdır**: tip ipucu vermenin otomatik doğrulama sağladığını
  düşünmek.
- **Ne kullanmalısın?** Gerçek tip doğrulaması istiyorsan
  `pydantic` gibi bir kütüphane kullan (bkz.
  [Flask ve FastAPI](../17-flask-ve-fastapi/README.md) bölümündeki
  Pydantic örneği) — o, tipleri gerçekten çalışma zamanında kontrol
  eder.

## 🔗 İlgili Modüller
[typing](../35-typing/README.md), [collections](../08-collections/README.md) (namedtuple)

---
⬅️ [Modüller Ana Sayfa](../README.md)
