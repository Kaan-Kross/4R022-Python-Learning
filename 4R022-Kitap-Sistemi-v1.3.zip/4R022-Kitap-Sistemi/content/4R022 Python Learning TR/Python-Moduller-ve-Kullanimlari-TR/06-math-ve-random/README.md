# `math` ve `random` Modülleri

## Nedir ve Çalışma Prensibi Nedir?

`math`, temel Python operatörlerinin (`+ - * /`) kapsamadığı ileri
matematiksel fonksiyonları (karekök, trigonometri, logaritma, sabitler)
sağlar — C'nin matematik kütüphanesine ince bir Python sarmalayıcıdır.
`random` ise **sözde-rastgele (pseudo-random)** sayı üretir: aslında
matematiksel bir formülle üretilir, gerçek/rastgele değildir, ama
pratik amaçlar için yeterince öngörülemezdir.

## Ne Zaman / Nerede Kullanılır?

- Geometri, fizik simülasyonları, oyun mekanikleri (`math`)
- Zar atma, kart karıştırma, örnek veri üretme, şifre/kod oluşturma
  taslakları (`random`) — **güvenlik amaçlı değil!**

## ✅ Çalışan Örnekler

```python
# Örnek 1: Temel math fonksiyonları
import math
print(math.sqrt(16))     # 4.0
print(math.pi)            # 3.14159...
print(math.ceil(4.1))     # 5  (yukarı yuvarla)
print(math.floor(4.9))    # 4  (aşağı yuvarla)
```

```python
# Örnek 2: Rastgele sayı ve seçim
import random
print(random.randint(1, 6))          # zar: 1-6 arası (ikisi de dahil)
print(random.choice(["taş", "kağıt", "makas"]))
```

```python
# Örnek 3: Liste karıştırma
import random
kart_destesi = list(range(1, 53))
random.shuffle(kart_destesi)   # yerinde (in-place) karıştırır
print(kart_destesi[:5])
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Negatif Sayının Karekökünü Almak

```python
import math
print(math.sqrt(-16))
```

- **Neden yanlış?** Negatif sayıların karekökü gerçek sayılar
  kümesinde tanımsızdır; `math` sadece gerçek sayılarla çalışır.
- **Hata nerede?** `math.sqrt()`'e negatif bir değer verilmiş —
  `ValueError: math domain error` verir.
- **Ne kullanmalısın?** Karmaşık (complex) sayı desteği gerekiyorsa
  `cmath.sqrt(-16)` kullan (sonuç: `4j`).

### Yanlış Örnek 2 — `random.randint()`'in Sınırlarını Yanlış Anlamak

```python
import random
zar = random.randint(1, 6)
# "en fazla 5 kere dene, 6 gelmeyecek sanıyorum" diye kod yazmak
```

- **Neden yanlış?** `random.randint(a, b)`, **hem `a` hem `b`
  dahil** rastgele tam sayı döndürür — `randrange(a, b)`'nin aksine
  üst sınırı da içine alır. Bunu bilmemek, olasılık hesaplarında
  mantık hatasına yol açar.
- **Hata nerede?** Fonksiyonun sınır davranışı yanlış varsayılmış.
- **Ne kullanmalısın?** Üst sınırı **dahil etmek istemiyorsan**
  `random.randrange(1, 6)` kullan (bu, 1-5 arası döner, 6 hariç).

### Yanlış Örnek 3 — `random`'ı Güvenlik/Şifreleme Amacıyla Kullanmak

```python
import random
sifre = "".join(random.choice("abcdefg12345") for _ in range(8))
# bu şifreyi bir kullanıcı hesabı için üretmek
```

- **Neden yanlış?** `random` modülü **kriptografik olarak güvenli
  değildir** — üretim algoritması (Mersenne Twister) tahmin
  edilebilir olduğu için gerçek güvenlik senaryolarında
  kullanılmamalıdır.
- **Hata nerede?** Güvenlik gerektiren bir bağlamda yanlış modül
  seçilmiş; bu bir çalışma zamanı hatası değil, **güvenlik
  açığıdır.**
- **Ne kullanmalısın?** Şifre/token/anahtar üretimi için
  `secrets` modülünü kullan: `secrets.token_urlsafe(16)` veya
  `secrets.choice(...)`.

## 🔗 İlgili Modüller
[secrets (planlanan)](../README.md), [cryptography](../25-cryptography/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
