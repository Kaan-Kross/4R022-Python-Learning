# `unittest` ve `pytest`

## Nedir ve Çalışma Prensibi Nedir?

`unittest`, Python'ın standart kütüphanesinde gelen test
çerçevesidir; test fonksiyonlarını `TestCase` sınıflarının içinde
`self.assertEqual(...)` gibi doğrulama (assertion) metodlarıyla
yazarsın. `pytest` ise üçüncü parti, daha az "tören" (boilerplate)
gerektiren, düz Python `assert` ifadelerini kullanabilen, çok daha
popüler bir alternatiftir (`pip install pytest`).

## Ne Zaman / Nerede Kullanılır?

- Bir fonksiyonun/sınıfın beklenen şekilde çalıştığını otomatik
  doğrulamak
- Kod değişikliği yaptıktan sonra "hiçbir şeyi bozmadım mı?" diye
  hızlıca kontrol etmek (regresyon testi)
- CI/CD (GitHub Actions gibi) süreçlerinde otomatik test çalıştırmak

## ✅ Çalışan Örnekler

```python
# Örnek 1: unittest ile test
import unittest

def topla(a, b):
    return a + b

class TestTopla(unittest.TestCase):
    def test_pozitif_sayilar(self):
        self.assertEqual(topla(2, 3), 5)

if __name__ == "__main__":
    unittest.main()
```

```python
# Örnek 2: pytest ile test (daha az kod)
def carp(a, b):
    return a * b

def test_carp():
    assert carp(3, 4) == 12
# Çalıştırma: pytest test_dosyasi.py -v
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Test Dosyasının/Fonksiyonunun Adını Yanlış Yazmak (pytest)

```python
# dosya adı: kontroller.py (pytest'in aradığı "test_" öneki yok!)
def kontrol_carpma():   # fonksiyon adı da "test_" ile başlamıyor
    assert 2 * 2 == 4
```

- **Neden yanlış?** `pytest`, testleri **otomatik keşfetmek** için
  dosya adının `test_` ile başlamasını (veya `_test` ile bitmesini)
  ve fonksiyon adının `test_` ile başlamasını **bekler.**
- **Hata nerede?** Ne dosya adı ne fonksiyon adı bu kurala uyuyor;
  `pytest` bu dosyayı tarayıp hiç test bulamaz, sessizce "0 test
  toplandı" der — bu bir hata mesajı değil ama beklenmedik bir
  sonuçtur.
- **Ne kullanmalısın?** Dosyayı `test_kontroller.py`, fonksiyonu
  `test_carpma()` olarak yeniden adlandır.

### Yanlış Örnek 2 — Yanlış `assert` Karşılaştırması (Başarısız Test)

```python
def kare_al(n):
    return n * n

def test_kare_al():
    assert kare_al(4) == 15   # 4*4 = 16, 15 değil!
```

- **Neden yanlış?** `4 * 4` matematiksel olarak `16`dır, `15` değil
  — bu bir kod hatası değil, **testin kendisinde** bir beklenti
  hatasıdır.
- **Hata nerede?** `assert` ifadesindeki beklenen değer yanlış
  yazılmış; test "başarısız (failed)" olarak raporlanır
  (`AssertionError`).
- **Ne kullanmalısın?** Beklenen değeri düzelt: `assert kare_al(4) ==
  16`. (Bu örnek aynı zamanda şunu gösteriyor: bir testin başarısız
  olması her zaman kodun hatalı olduğu anlamına gelmez — bazen testin
  kendisi yanlış yazılmıştır!)

### Yanlış Örnek 3 — Testler Arasında Paylaşılan Durumu (State) Sıfırlamamak

```python
sepet = []

def sepete_ekle(urun):
    sepet.append(urun)

def test_bir_urun_ekle():
    sepete_ekle("elma")
    assert len(sepet) == 1   # ilk çalıştığında doğru

def test_baska_urun_ekle():
    sepete_ekle("armut")
    assert len(sepet) == 1   # YANLIŞ! artık sepette 2 ürün var
```

- **Neden yanlış?** `sepet` listesi, testler arasında **paylaşılan**
  global bir durumdur; ilk test onu değiştirir, ikinci test bunu
  hesaba katmaz. Testler **birbirinden bağımsız** olmalıdır.
- **Hata nerede?** İkinci testte `len(sepet)` aslında `2`dir çünkü
  ilk testten kalan "elma" hâlâ listede duruyor.
- **Ne kullanmalısın?** Her testten önce durumu sıfırlayan bir
  "fixture" kullan (`pytest`'te `@pytest.fixture` ile), ya da her
  testte taze bir `sepet = []` oluştur.

## 🔗 İlgili Modüller
[logging](../11-logging/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
