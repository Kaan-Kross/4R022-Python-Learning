# `json` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`json` modülü, Python nesnelerini (`dict`, `list`, `str`, `int`...)
**JSON metin formatına** çevirir (serileştirme/serialization) ve bu
formatı geri Python nesnesine çevirir (deserileştirme). JSON, web
API'leri ve konfigürasyon dosyaları için evrensel bir "ortak dil"dir
— hemen her programlama dili JSON okuyup yazabilir.

## Ne Zaman / Nerede Kullanılır?

- Uygulama ayarlarını (tema, dil, pencere boyutu) dosyada saklamak
- Web API'lerinden gelen veya API'ye giden veriyi işlemek
- 4R022 arşiv/ayar sistemlerinde **atomik JSON yazma** (`.bak`
  yedeğiyle birlikte) — veri kaybını önlemek için

## ✅ Çalışan Örnekler

```python
# Örnek 1: dict -> JSON dosyası
import json
ayarlar = {"tema": "koyu", "dil": "tr"}
with open("ayarlar.json", "w", encoding="utf-8") as f:
    json.dump(ayarlar, f, ensure_ascii=False, indent=4)
```

```python
# Örnek 2: JSON dosyası -> dict
import json
with open("ayarlar.json", "r", encoding="utf-8") as f:
    ayarlar = json.load(f)
print(ayarlar["tema"])
```

```python
# Örnek 3: Atomik yazma deseni (4R022 standardı — veri kaybını önler)
import json, os
def guvenli_kaydet(veri, dosya_adi):
    gecici = dosya_adi + ".tmp"
    with open(gecici, "w", encoding="utf-8") as f:
        json.dump(veri, f, ensure_ascii=False, indent=4)
    if os.path.exists(dosya_adi):
        os.replace(dosya_adi, dosya_adi + ".bak")
    os.replace(gecici, dosya_adi)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Tek Tırnaklı "JSON" String'i Çözümlemek

```python
import json
veri = json.loads("{'tema': 'koyu'}")
```

- **Neden yanlış?** JSON standardı **çift tırnak** ister; tek tırnak
  Python dict söz dizimidir, JSON değildir.
- **Hata nerede?** `json.loads()`'a verilen string'de `'` kullanılmış.
- **Ne kullanmalısın?** `json.loads('{"tema": "koyu"}')` — çift
  tırnakla.

### Yanlış Örnek 2 — Türkçe Karakterlerin Bozulması

```python
import json
veri = {"sehir": "İstanbul"}
with open("veri.json", "w") as f:   # encoding belirtilmemiş!
    json.dump(veri, f)
```

- **Neden yanlış?** `encoding="utf-8"` belirtilmezse, bazı Windows
  sistemlerinde varsayılan kodlama Türkçe karakterleri (İ, ş, ğ)
  bozabilir.
- **Hata nerede?** `open()` çağrısında `encoding="utf-8"` eksik.
- **Ne kullanmalısın?**
  `open("veri.json", "w", encoding="utf-8")` ve
  `json.dump(veri, f, ensure_ascii=False)` — `ensure_ascii=False`
  olmazsa Türkçe karakterler `\u0130` gibi kod dizilerine çevrilir
  (bu bir hata değildir ama dosyayı elle okumayı zorlaştırır).

### Yanlış Örnek 3 — Bozuk/Eksik JSON Dosyasını Kontrolsüz Okumak

```python
import json
with open("bozuk.json", "r") as f:
    veri = json.load(f)   # dosya boşsa veya bozuksa çöker
```

- **Neden yanlış?** Dosya boşsa, bozuksa veya hiç yoksa program
  çöker; gerçek uygulamalarda dosyalar bozulabilir (yarım kalan
  yazma, disk hatası vb.).
- **Hata nerede?** Hata yönetimi (`try/except`) hiç yok.
- **Ne kullanmalısın?**
  ```python
  try:
      with open("bozuk.json", "r", encoding="utf-8") as f:
          veri = json.load(f)
  except (json.JSONDecodeError, FileNotFoundError):
      veri = {}   # varsayılan boş veri ile devam et
  ```

## 🔗 İlgili Modüller
[csv](../04-csv/README.md), [os](../01-os/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
