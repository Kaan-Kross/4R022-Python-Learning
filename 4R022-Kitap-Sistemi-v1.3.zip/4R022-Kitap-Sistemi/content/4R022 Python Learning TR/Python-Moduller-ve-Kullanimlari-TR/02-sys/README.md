# `sys` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`sys` modülü, doğrudan **Python yorumlayıcısının kendisiyle**
etkileşim kurmanı sağlar: komut satırı argümanları, yorumlayıcı
sürümü, programın çıkış kodu, modül arama yolları gibi. `os` işletim
sistemiyle, `sys` ise **Python'ın çalışma zamanı ortamıyla** ilgilenir
— aradaki fark budur.

## Ne Zaman / Nerede Kullanılır?

- Terminalden çalıştırılan script'lere parametre geçmek
- Programı belirli bir çıkış koduyla sonlandırmak (`sys.exit()`)
- PyInstaller ile paketlenmiş uygulamalarda kaynak dosya yolunu bulmak
  (`sys._MEIPASS`) — 4R022 projelerinde standart bir teknik
- Python sürümünü kontrol etmek

## ✅ Çalışan Örnekler

```python
# Örnek 1: Komut satırı argümanlarını okuma
import sys
print(sys.argv)   # ['dosya.py', 'arg1', 'arg2'] gibi
if len(sys.argv) > 1:
    print("İlk argüman:", sys.argv[1])
```

```python
# Örnek 2: Belirli bir hata koduyla çıkış yapma
import sys
def dosya_isle(yol):
    if not yol:
        print("Hata: dosya yolu boş!", file=sys.stderr)
        sys.exit(1)   # 0 dışı kodlar "hata ile bitti" anlamına gelir
    print("İşleniyor:", yol)
```

```python
# Örnek 3: PyInstaller uyumlu kaynak yolu (4R022 standardı)
import sys, os
def resource_path(relative_path):
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, relative_path)
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `sys.argv[0]`'ı Kullanıcı Argümanı Sanmak

```python
import sys
kullanici_adi = sys.argv[0]
print("Merhaba", kullanici_adi)
```

- **Neden yanlış?** `sys.argv[0]` her zaman **script'in kendi dosya
  adıdır**, kullanıcının verdiği ilk argüman değildir.
- **Hata nerede?** İndeks `0` yerine `1` kullanılmalıydı.
- **Ne kullanmalısın?** `sys.argv[1]` — ve mutlaka uzunluk kontrolü
  ekle: `if len(sys.argv) > 1: kullanici_adi = sys.argv[1]`

### Yanlış Örnek 2 — `sys.exit()`'i `try/except` ile Yanlışlıkla Yakalamak

```python
import sys
try:
    sys.exit(1)
except Exception:
    print("Hata yakalandı, devam ediyoruz")
```

- **Neden yanlış?** `sys.exit()` aslında `SystemExit` adlı özel bir
  istisna fırlatır; geniş bir `except Exception` bloğu bunu da
  yakalayabilir ve programın **kapanmasını engelleyebilir** — bu,
  niyet edilenin tam tersidir.
- **Hata nerede?** `except Exception` çok geniş kapsamlı yazılmış.
- **Ne kullanmalısın?** `SystemExit`'i özellikle yakalamıyorsan,
  `except Exception` yerine daha spesifik hata tiplerini yakala
  (örn. `except ValueError`), böylece `sys.exit()` beklendiği gibi
  programı sonlandırır.

### Yanlış Örnek 3 — `sys.path`'i Bilmeden Değiştirmek

```python
import sys
sys.path = ["/yanlis/klasor"]
import json
```

- **Neden yanlış?** `sys.path`, Python'ın modülleri **nerede
  arayacağını** belirtir; listeyi tamamen değiştirmek (üzerine
  yazmak), standart kütüphanenin bile bulunamamasına yol açabilir.
- **Hata nerede?** `sys.path =` ile **tüm liste** değiştiriliyor.
- **Ne kullanmalısın?** Listeyi değiştirmek yerine sonuna ekle:
  `sys.path.append("/ekstra/klasor")`

## 🔗 İlgili Modüller
[os](../01-os/README.md), [logging](../11-logging/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
