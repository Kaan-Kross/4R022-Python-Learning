# `threading` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`threading`, bir programın birden fazla "iş parçacığını" (thread)
aynı anda çalıştırmasını sağlar. CPython'da **GIL (Global Interpreter
Lock)** yüzünden threadler aynı anda Python **bayt kodu**
çalıştıramaz, ama bir thread bir şey **beklerken** (dosya okuma, ağ
isteği gibi) diğer threadler çalışabilir — bu yüzden threading, "G/Ç
bağımlı" (I/O-bound) işlerde gerçekten fayda sağlar. Ayrıntılı
karşılaştırma için Üst Düzey Kademe'deki
[Eş Zamanlılık](../../Python-Ust-Duzey-Kademe-TR/01-Es-Zamanlilik.md)
bölümüne bakabilirsin.

## Ne Zaman / Nerede Kullanılır?

- Birden fazla dosya/URL'i aynı anda indirmek
- Arayüzü (GUI) dondurmadan arka planda uzun süren bir işlem yapmak
  (4R022 PyQt6 uygulamalarında `QThread` bu mantığın PyQt6 karşılığıdır)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Basit thread oluşturma
import threading, time

def bekle_ve_yazdir(isim):
    time.sleep(1)
    print(f"{isim} tamamlandı")

t = threading.Thread(target=bekle_ve_yazdir, args=("Görev-1",))
t.start()
t.join()   # ana program, thread bitene kadar burada bekler
```

```python
# Örnek 2: Kilit (Lock) ile paylaşılan veriyi güvenli değiştirme
import threading

sayac = 0
kilit = threading.Lock()

def artir():
    global sayac
    with kilit:      # aynı anda sadece bir thread bu bloğa girebilir
        sayac += 1

threadler = [threading.Thread(target=artir) for _ in range(100)]
for t in threadler: t.start()
for t in threadler: t.join()
print(sayac)   # her zaman 100 — Lock olmasaydı garanti olmazdı
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `join()` Çağırmayı Unutmak

```python
import threading, time

def uzun_islem():
    time.sleep(2)
    print("İşlem bitti")

t = threading.Thread(target=uzun_islem)
t.start()
print("Program bitti")   # bu, "İşlem bitti"den ÖNCE yazdırılabilir
```

- **Neden yanlış?** `t.start()` thread'i başlatır ama **beklemez**;
  ana program hemen devam eder. Bu bir hata mesajı vermez ama
  beklenen sırayı bozar.
- **Hata nerede?** `t.join()` çağrısı eksik.
- **Ne kullanmalısın?** Thread'in bitmesini beklemen gerekiyorsa
  `t.start()`'tan sonra `t.join()` ekle.

### Yanlış Örnek 2 — Kilit (Lock) Olmadan Paylaşılan Veriyi Değiştirmek

```python
import threading

sayac = 0

def artir():
    global sayac
    sayac += 1   # bu işlem 'atomik' değildir!

threadler = [threading.Thread(target=artir) for _ in range(100000)]
for t in threadler: t.start()
for t in threadler: t.join()
print(sayac)   # 100000 BEKLENİR ama genelde DAHA AZ bir sayı çıkar!
```

- **Neden yanlış?** `sayac += 1` aslında üç adımdır (oku, artır,
  yaz); iki thread aynı anda bu adımları iç içe geçirirse bir artış
  "kaybolabilir" — buna **race condition (yarış durumu)** denir.
- **Hata nerede?** Paylaşılan `sayac` değişkeni bir `Lock` ile
  korunmamış.
- **Ne kullanmalısın?** Yukarıdaki "Çalışan Örnek 2"deki gibi
  `threading.Lock()` kullanarak kritik bölgeyi koru.

### Yanlış Örnek 3 — CPU-Yoğun İş İçin Threading Kullanmak

```python
import threading

def agir_hesap():
    toplam = sum(i * i for i in range(50_000_000))

threadler = [threading.Thread(target=agir_hesap) for _ in range(4)]
for t in threadler: t.start()
for t in threadler: t.join()
```

- **Neden yanlış?** Bu, "çalışır" ama **beklenen hızlanmayı
  sağlamaz** — GIL yüzünden CPU-yoğun işlerde threadler gerçek
  paralellik sağlamaz.
- **Hata nerede?** Yanlış araç seçilmiş; bu iş G/Ç değil, hesaplama
  ağırlıklıdır.
- **Ne kullanmalısın?** CPU-yoğun işler için `multiprocessing`
  kullan (bkz. [multiprocessing](../13-multiprocessing/README.md)).

## 🔗 İlgili Modüller
[multiprocessing](../13-multiprocessing/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
