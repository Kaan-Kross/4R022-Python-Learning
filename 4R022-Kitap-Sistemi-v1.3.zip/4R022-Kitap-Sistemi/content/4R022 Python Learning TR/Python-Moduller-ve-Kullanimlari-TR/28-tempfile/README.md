# `tempfile` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`tempfile`, işletim sisteminin geçici dosya klasöründe (Windows'ta
`%TEMP%`, Linux'ta `/tmp`) **otomatik olarak benzersiz isimli geçici
dosya/klasörler** oluşturur ve genellikle program bittiğinde bunları
otomatik temizler.

## Ne Zaman / Nerede Kullanılır?

- Bir dosyayı işlerken ara adımlarda geçici bir kopya tutmak
- Testlerde gerçek dosya sistemine dokunmadan geçici veri oluşturmak
- Büyük indirmeleri geçici olarak diske yazıp işledikten sonra silmek

## ✅ Çalışan Örnekler

```python
# Örnek 1: Geçici dosya oluşturma (otomatik silinir)
import tempfile
with tempfile.NamedTemporaryFile(mode="w", delete=True, suffix=".txt") as f:
    f.write("geçici veri")
    print(f.name)   # dosyanın geçici yolu
# 'with' bloğu bitince dosya otomatik silinir
```

```python
# Örnek 2: Geçici klasör oluşturma
import tempfile, os
with tempfile.TemporaryDirectory() as gecici_klasor:
    yol = os.path.join(gecici_klasor, "veri.txt")
    with open(yol, "w") as f:
        f.write("test")
# blok bitince tüm klasör silinir
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — `delete=True` Olan Dosyayı Kapattıktan Sonra Tekrar Açmaya Çalışmak

```python
import tempfile
f = tempfile.NamedTemporaryFile(mode="w", delete=True)
f.write("veri")
f.close()
with open(f.name) as tekrar:   # dosya artık silinmiş olabilir!
    print(tekrar.read())
```

- **Neden yanlış?** `delete=True` (varsayılan), dosya **kapatılır
  kapatılmaz** siler; kapatıldıktan sonra aynı yola tekrar erişmeye
  çalışmak başarısız olur.
- **Hata nerede?** `FileNotFoundError` verir çünkü dosya `close()`
  anında silinmiş.
- **Ne kullanmalısın?** Dosyayı kapattıktan sonra da kullanman
  gerekiyorsa `delete=False` ver ve işin bitince kendin
  `os.remove(f.name)` ile sil.

### Yanlış Örnek 2 — Windows'ta Açıkken Aynı Dosyayı Başka Bir İşlemle Açmaya Çalışmak

```python
import tempfile
f = tempfile.NamedTemporaryFile(mode="w")
with open(f.name, "r") as baska_islem:   # Windows'ta sorun çıkarabilir
    print(baska_islem.read())
```

- **Neden yanlış?** Windows'ta bir dosya bir işlem tarafından açıkken
  (özellikle `NamedTemporaryFile` varsayılan modunda), başka bir
  işlemin aynı anda açması engellenebilir.
- **Hata nerede?** `PermissionError` verebilir (platforma özgü bir
  davranıştır, Linux'ta genelde sorun çıkarmaz).
- **Ne kullanmalısın?** Windows'ta çapraz erişim gerekiyorsa
  `NamedTemporaryFile(delete=False)` kullan ve dosyayı elle yönet.

## 🔗 İlgili Modüller
[os](../01-os/README.md), [pathlib](../10-pathlib/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
