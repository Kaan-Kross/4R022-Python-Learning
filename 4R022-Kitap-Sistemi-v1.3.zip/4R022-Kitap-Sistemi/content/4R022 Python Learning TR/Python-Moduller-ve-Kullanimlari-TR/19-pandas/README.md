# `pandas` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`pandas`, tablo (satır-sütun) verisiyle çalışmak için tasarlanmış bir
kütüphanedir (`pip install pandas`), arka planda `numpy` dizilerini
kullanır. Ana veri yapısı **DataFrame**'dir — Excel'deki bir sayfaya
çok benzer: satırlar, isimlendirilmiş sütunlar ve bir indeks içerir.

## Ne Zaman / Nerede Kullanılır?

- CSV/Excel dosyalarını okuyup analiz etmek
- Veri temizleme (eksik değerleri doldurma, filtreleme)
- Gruplama, özetleme, pivot tablo oluşturma
- Veri bilimi ve makine öğrenmesi projelerinin veri hazırlama aşaması

## ✅ Çalışan Örnekler

```python
# Örnek 1: CSV okuma ve temel analiz
import pandas as pd
df = pd.read_csv("notlar.csv")
print(df.head())          # ilk 5 satır
print(df["not"].mean())   # sütun ortalaması
```

```python
# Örnek 2: Filtreleme ve gruplama
import pandas as pd
df = pd.DataFrame({"sube": ["A", "B", "A", "B"], "satis": [100, 200, 150, 250]})
print(df[df["satis"] > 120])                # filtreleme
print(df.groupby("sube")["satis"].sum())    # şubeye göre toplam
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Var Olmayan Sütun Adıyla Erişim

```python
import pandas as pd
df = pd.DataFrame({"isim": ["Kaan"], "not": [95]})
print(df["notlar"])
```

- **Neden yanlış?** Gerçek sütun adı `"not"`dur, `"notlar"` değil —
  büyük/küçük harf ve yazım tam olarak eşleşmelidir.
- **Hata nerede?** `KeyError: 'notlar'` verir.
- **Ne kullanmalısın?** Önce `print(df.columns)` ile gerçek sütun
  adlarını kontrol et, sonra doğru adı kullan: `df["not"]`

### Yanlış Örnek 2 — Zincirleme Atama (Chained Assignment) Uyarısı

```python
import pandas as pd
df = pd.DataFrame({"not": [50, 90, 70]})
df[df["not"] < 60]["not"] = 60   # geçenleri 60'a yükseltmeye çalışıyor
```

- **Neden yanlış?** Bu satır, pandas'ın **bir kopya üzerinde**
  çalışıp çalışmadığını garanti edemediği bir "zincirleme atama"
  yapısıdır; çoğu zaman **orijinal `df` değişmez**, sessiz bir
  `SettingWithCopyWarning` uyarısı verir.
- **Hata nerede?** İki ayrı köşeli parantez erişimi zincirlenmiş
  (`df[...][...] =`).
- **Ne kullanmalısın?** `.loc` ile tek adımda, açıkça değiştir:
  `df.loc[df["not"] < 60, "not"] = 60`

### Yanlış Örnek 3 — Eksik (NaN) Değerleri Kontrolsüz Bırakmak

```python
import pandas as pd
df = pd.read_csv("eksik_veri.csv")
ortalama = df["not"].sum() / len(df)
```

- **Neden yanlış?** CSV'de eksik hücreler `NaN` olarak okunur;
  `len(df)` **tüm satırları** sayar (eksik olanlar dahil), bu da
  ortalamayı yanlış hesaplar. Kod hata vermez ama **sessizce yanlış
  sonuç** üretir.
- **Hata nerede?** `NaN` değerler filtrelenmeden/doldurulmadan
  doğrudan hesaba dahil edilmiş.
- **Ne kullanmalısın?** `df["not"].mean()` kullan (pandas'ın
  `.mean()` metodu `NaN` değerleri otomatik yok sayar) ya da
  önce `df = df.dropna(subset=["not"])` ile eksik satırları çıkar.

## 🔗 İlgili Modüller
[numpy](../18-numpy/README.md), [matplotlib](../20-matplotlib/README.md), [csv](../04-csv/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
