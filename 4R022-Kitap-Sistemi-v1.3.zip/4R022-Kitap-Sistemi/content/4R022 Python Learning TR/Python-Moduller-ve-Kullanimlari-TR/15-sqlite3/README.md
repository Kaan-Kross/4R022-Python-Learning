# `sqlite3` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`sqlite3`, Python ile birlikte gelen, **tek bir dosyada** çalışan
hafif bir ilişkisel veritabanı motorudur. Sunucu kurmana gerek yoktur
— tüm veritabanı `.db` uzantılı tek bir dosyadır. SQL (Structured
Query Language) komutlarıyla veri ekler, sorgular, güncellersin.

## Ne Zaman / Nerede Kullanılır?

- Masaüstü uygulamalarında yerel veri saklama (4R022 Arşiv ve Cüzdanım
  projelerindeki SQLite kullanımı tam olarak bu amaçladır)
- Büyük ölçekli sunucu veritabanı (PostgreSQL, MySQL) gerektirmeyen,
  tek kullanıcılı uygulamalar
- Prototipleme ve öğrenme amaçlı veritabanı deneyleri

## ✅ Çalışan Örnekler

```python
# Örnek 1: Veritabanı oluşturma ve tablo açma
import sqlite3

baglanti = sqlite3.connect("uygulama.db")
imlec = baglanti.cursor()
imlec.execute("""
    CREATE TABLE IF NOT EXISTS ogrenciler (
        id INTEGER PRIMARY KEY,
        isim TEXT NOT NULL,
        not_ INTEGER
    )
""")
baglanti.commit()
```

```python
# Örnek 2: Veri ekleme (parametreli — güvenli yöntem)
imlec.execute("INSERT INTO ogrenciler (isim, not_) VALUES (?, ?)", ("Kaan", 95))
baglanti.commit()
```

```python
# Örnek 3: Veri sorgulama
imlec.execute("SELECT isim, not_ FROM ogrenciler WHERE not_ > ?", (80,))
for satir in imlec.fetchall():
    print(satir)
baglanti.close()
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — SQL Enjeksiyonuna Açık Kod (String Birleştirme)

```python
isim = "Kaan"
imlec.execute(f"SELECT * FROM ogrenciler WHERE isim = '{isim}'")
```

- **Neden yanlış?** Kod çalışır ama **ciddi bir güvenlik açığıdır**
  — eğer `isim` değişkeni kullanıcıdan geliyorsa, biri
  `isim = "x'; DROP TABLE ogrenciler; --"` gibi bir girdi vererek
  tüm tabloyu silebilir (SQL Injection saldırısı).
- **Hata nerede?** SQL sorgusu, kullanıcı girdisiyle **doğrudan
  string birleştirme** yoluyla oluşturulmuş.
- **Ne kullanmalısın?** Her zaman parametreli sorgu kullan:
  `imlec.execute("SELECT * FROM ogrenciler WHERE isim = ?", (isim,))`
  — `sqlite3` bu değeri güvenli şekilde işler.

### Yanlış Örnek 2 — `commit()` Çağırmayı Unutmak

```python
imlec.execute("INSERT INTO ogrenciler (isim, not_) VALUES (?, ?)", ("Ayşe", 88))
baglanti.close()   # commit() unutuldu!
```

- **Neden yanlış?** SQLite, değişiklikleri varsayılan olarak bir
  **işlem (transaction)** içinde tutar; `commit()` çağrılmadan
  bağlantı kapatılırsa değişiklik **diske kalıcı olarak yazılmaz.**
- **Hata nerede?** `baglanti.commit()` satırı hiç çağrılmamış.
- **Ne kullanmalısın?** Her yazma işleminden (`INSERT`, `UPDATE`,
  `DELETE`) sonra `baglanti.commit()` çağır; ya da `with baglanti:`
  bloğu kullanarak otomatik commit/rollback'ten faydalan.

### Yanlış Örnek 3 — Aynı Bağlantıyı Farklı Threadlerden Kontrolsüz Kullanmak

```python
import sqlite3, threading

baglanti = sqlite3.connect("uygulama.db")

def veri_ekle(isim):
    baglanti.execute("INSERT INTO ogrenciler (isim) VALUES (?)", (isim,))
    baglanti.commit()

threading.Thread(target=veri_ekle, args=("Mehmet",)).start()
```

- **Neden yanlış?** Varsayılan olarak, bir `sqlite3` bağlantısı
  **yalnızca onu oluşturan thread'de** güvenle kullanılabilir.
- **Hata nerede?** `ProgrammingError: SQLite objects created in a
  thread can only be used in that same thread` verebilir.
- **Ne kullanmalısın?** Ya her thread için ayrı bağlantı aç, ya da
  `sqlite3.connect("uygulama.db", check_same_thread=False)`
  kullanıp erişimi kendi kilit mekanizman (`threading.Lock`) ile
  senkronize et.

## 🔗 İlgili Modüller
[threading](../12-threading/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
