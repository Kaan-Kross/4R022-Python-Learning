# `numpy` Modülü

## Nedir ve Çalışma Prensibi Nedir?

`numpy` (Numerical Python), C dilinde yazılmış, sayısal dizilerle
(array) çok hızlı çalışan bir kütüphanedir (`pip install numpy`).
Saf Python listelerinin aksine, bir numpy dizisi bellekte **ardışık
ve sabit tipte** tutulur; bu sayede matematik işlemleri tek tek
Python döngüsüyle değil, C seviyesinde **vektörize** (tüm elemanlara
aynı anda uygulanan) şekilde çalışır — bu da onu saf Python'dan
onlarca-yüzlerce kat hızlı yapar.

## Ne Zaman / Nerede Kullanılır?

- Büyük veri kümeleri üzerinde matematiksel işlemler
- Görüntü işleme (bir görüntü, aslında sayı dizisidir)
- Makine öğrenmesi ve bilimsel hesaplamanın temeli (pandas, scikit-
  learn, TensorFlow gibi kütüphaneler numpy üzerine kuruludur)

## ✅ Çalışan Örnekler

```python
# Örnek 1: Dizi oluşturma ve vektörize işlem
import numpy as np
dizi = np.array([1, 2, 3, 4, 5])
print(dizi * 2)        # [2 4 6 8 10] — tüm elemanlara uygulanır
print(dizi.mean())     # 3.0
```

```python
# Örnek 2: Çok boyutlu dizi (matris) işlemleri
import numpy as np
matris = np.array([[1, 2], [3, 4]])
print(matris.T)             # transpoze
print(matris @ matris)      # matris çarpımı
```

## ❌ Çalışmayan / Yanlış Örnekler

### Yanlış Örnek 1 — Saf Python Listesiyle "numpy Gibi" Davranış Beklemek

```python
liste = [1, 2, 3, 4, 5]
print(liste * 2)
```

- **Neden yanlış?** Kod çalışır ama **beklenen sonucu vermez** —
  `*` operatörü, saf Python listesinde elemanları çarpmaz, listeyi
  **tekrarlar**: `[1,2,3,4,5,1,2,3,4,5]`.
- **Hata nerede?** `numpy` dizisi ile saf Python listesi
  karıştırılmış; ikisi `*` operatörüne farklı tepki verir.
- **Ne kullanmalısın?** Eleman bazlı çarpma istiyorsan
  `np.array(liste) * 2` kullan.

### Yanlış Örnek 2 — Farklı Boyuttaki Dizileri Birleştirmeye Çalışmak

```python
import numpy as np
a = np.array([1, 2, 3])
b = np.array([1, 2])
print(a + b)
```

- **Neden yanlış?** `numpy`, elemanları birebir eşleştirerek toplar;
  3 elemanlı bir dizi ile 2 elemanlı bir diziyi bu şekilde toplayamaz
  (broadcasting kuralları buna izin vermez).
- **Hata nerede?** `ValueError: operands could not be broadcast
  together with shapes (3,) (2,)` verir.
- **Ne kullanmalısın?** Dizilerin boyutlarının uyumlu (aynı veya
  broadcasting kurallarına uygun) olduğundan emin ol; gerekiyorsa
  `b`'yi 3 elemanlı yap veya `np.pad()` ile doldur.

### Yanlış Örnek 3 — Çok Büyük Diziler İçin Yetersiz Veri Tipi Seçmek

```python
import numpy as np
dizi = np.array([200, 100, 50], dtype=np.int8)
print(dizi + 100)   # taşma (overflow) olabilir!
```

- **Neden yanlış?** `int8` tipi yalnızca -128 ile 127 arasını
  tutabilir; `200 + 100 = 300` bu aralığın dışına taşar ve **sessizce
  yanlış bir değere döner** (hata vermez!), bu en tehlikeli hata
  türlerinden biridir.
- **Hata nerede?** Veri tipi (`dtype`) veri aralığına göre yetersiz
  seçilmiş.
- **Ne kullanmalısın?** Değer aralığına uygun bir tip seç
  (`dtype=np.int32` veya `np.int64`), özellikle toplama/çarpma
  işlemleri büyük değerler üretebiliyorsa.

## 🔗 İlgili Modüller
[pandas](../19-pandas/README.md), [matplotlib](../20-matplotlib/README.md)

---
⬅️ [Modüller Ana Sayfa](../README.md)
