# 4. Koşullu İfadeler (if / elif / else)

## Temel Yapı

```python
# ✅ Bu kod çalışır
yas = 20

if yas >= 18:
    print("Reşitsin.")
else:
    print("Reşit değilsin.")
```

## Birden Fazla Koşul: `elif`

```python
# ✅ Bu kod çalışır
not_ = 75

if not_ >= 85:
    print("AA")
elif not_ >= 70:
    print("BA")
elif not_ >= 50:
    print("CC")
else:
    print("FF")
```

```python
# ❌ Bu kod ÇALIŞMAZ — "elif" yerine yanlışlıkla "else if" yazılmış
# (bu, C/Java/JavaScript'in söz dizimidir, Python'da geçersizdir)
if not_ >= 85:
    print("AA")
else if not_ >= 70:
    print("BA")
```

Python'da `else if` diye bir anahtar kelime yoktur; doğrusu tek
kelime olan `elif`'tir.

## İç İçe Koşullar (Nested if)

```python
# ✅ Bu kod çalışır
yas = 20
ehliyeti_var = True

if yas >= 18:
    if ehliyeti_var:
        print("Araç kullanabilirsin.")
    else:
        print("Ehliyet almalısın.")
else:
    print("Henüz araç kullanamazsın.")
```

## Kısa (Tek Satır) Koşul — Ternary İfade

```python
# ✅ Bu kod çalışır
yas = 16
durum = "reşit" if yas >= 18 else "reşit değil"
print(durum)
```

## Değer Doğruluğu (Truthy / Falsy)

Python'da yalnızca `True`/`False` değil, birçok değer de bir koşulda
otomatik olarak "doğru" veya "yanlış" sayılır:

```python
# ✅ Bu kod çalışır
if "":        # boş metin -> Falsy
    print("bu yazdırılmaz")
if "merhaba": # dolu metin -> Truthy
    print("bu yazdırılır")
if 0:         # sıfır -> Falsy
    print("bu yazdırılmaz")
if []:        # boş liste -> Falsy
    print("bu yazdırılmaz")
```

### 🎯 Mini Alıştırma
Kullanıcıdan bir not (0-100) al; 85 ve üzeri "AA", 70-84 arası "BA",
50-69 arası "CC", altı "FF" yazdıran bir program yaz.

---
⬅️ [Operatörler](./03-Operatorler.md) &nbsp;|&nbsp; ➡️ [Döngüler](./05-Donguler.md)
