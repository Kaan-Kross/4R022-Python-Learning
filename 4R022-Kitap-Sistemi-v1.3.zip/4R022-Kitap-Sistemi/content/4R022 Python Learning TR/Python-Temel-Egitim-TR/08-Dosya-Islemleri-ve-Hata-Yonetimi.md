# 8. Dosya İşlemleri ve Hata Yönetimi

## Dosya Okuma / Yazma

```python
# ✅ Bu kod çalışır — dosyaya yazar (yoksa oluşturur, varsa üzerine yazar)
with open("notlar.txt", "w", encoding="utf-8") as dosya:
    dosya.write("Merhaba 4R022!\n")
    dosya.write("Python öğreniyorum.\n")

# ✅ Bu kod çalışır — dosyayı okur
with open("notlar.txt", "r", encoding="utf-8") as dosya:
    icerik = dosya.read()
    print(icerik)
```

`with` kullanmanın sebebi: dosya işi bitince otomatik olarak
**kapatılır**, elle `dosya.close()` çağırmayı unutma riskini ortadan
kaldırır.

```python
# ❌ Bu kod ÇALIŞMAZ — olmayan bir dosyayı okumaya çalışıyor
with open("hic_olmayan_dosya.txt", "r") as dosya:
    print(dosya.read())
```

Bu, `FileNotFoundError: [Errno 2] No such file or directory` verir.

## Hata Yönetimi: `try / except`

Yukarıdaki gibi hatalar programı çökertir. Bunu önlemek için hatayı
"yakalarız":

```python
# ✅ Bu kod çalışır — hatayı yakalar, program çökmez
try:
    with open("hic_olmayan_dosya.txt", "r") as dosya:
        print(dosya.read())
except FileNotFoundError:
    print("Dosya bulunamadı, yeni bir tane oluşturuluyor...")
```

```python
# ✅ Bu kod çalışır — birden fazla hata tipi yakalanabilir
try:
    sayi = int(input("Bir sayı girin: "))
    print(10 / sayi)
except ValueError:
    print("Geçerli bir sayı girmediniz.")
except ZeroDivisionError:
    print("Sıfıra bölemezsiniz.")
```

```python
# ❌ Bu kod ÇALIŞMAZ (mantık hatası) — 'except' bloğu, hata tipini
# yanlış eşleştiriyor, bu yüzden hata yine de programı çökertir:
try:
    sayi = int("abc")
except ZeroDivisionError:   # yanlış hata tipi yakalanmış
    print("hata yakalandı")
# Gerçekte oluşan hata ValueError'dur, ZeroDivisionError DEĞİL.
# Python bu ValueError'u yakalamaz ve program çöker.
```

## `finally` ve `else`

```python
# ✅ Bu kod çalışır — 'finally' her durumda çalışır (hata olsa da olmasa da)
try:
    x = 10 / 2
except ZeroDivisionError:
    print("Hata oluştu")
else:
    print("Hata olmadı, sonuç:", x)
finally:
    print("İşlem tamamlandı.")
```

## Kendi Hatanı Fırlatmak: `raise`

```python
# ✅ Bu kod çalışır
def yas_kontrol(yas):
    if yas < 0:
        raise ValueError("Yaş negatif olamaz!")
    return yas

try:
    yas_kontrol(-5)
except ValueError as hata:
    print("Hata yakalandı:", hata)
```

### 🎯 Mini Alıştırma
Kullanıcıdan bir dosya adı ve içine yazılacak metni al; dosyayı
oluştururken oluşabilecek hataları (`PermissionError` dahil) `try/except`
ile yönet.

---
⬅️ [Veri Yapıları](./07-Veri-Yapilari.md) &nbsp;|&nbsp; ➡️ [OOP'ye Giriş](./09-OOP-Giris.md)
