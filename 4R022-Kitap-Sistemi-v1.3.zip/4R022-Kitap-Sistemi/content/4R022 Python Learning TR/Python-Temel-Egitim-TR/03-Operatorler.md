# 3. Operatörler

## Aritmetik Operatörler

```python
# ✅ Bu kod çalışır
print(5 + 3)   # 8   toplama
print(5 - 3)   # 2   çıkarma
print(5 * 3)   # 15  çarpma
print(5 / 3)   # 1.666... bölme (her zaman float döner)
print(5 // 3)  # 1   tam bölme (ondalığı atar)
print(5 % 3)   # 2   mod (kalan)
print(5 ** 3)  # 125 üs alma
```

```python
# ❌ Bu kod ÇALIŞMAZ — sıfıra bölme matematiksel olarak tanımsızdır
print(5 / 0)
```

Bu, `ZeroDivisionError: division by zero` hatası verir. Python bunu
"belki hatalıdır" diye tahmin etmez, doğrudan programı durdurur —
bu yüzden ileride "Hata Yönetimi" bölümünde bunu nasıl yakalayacağımızı
öğreneceğiz.

## Karşılaştırma Operatörleri

```python
# ✅ Bu kod çalışır — hepsi True/False döner
print(5 == 5)   # True   eşit mi?
print(5 != 3)   # True   eşit değil mi?
print(5 > 3)    # True
print(5 < 3)    # False
print(5 >= 5)   # True
print(5 <= 4)   # False
```

```python
# ❌ Bu kod ÇALIŞMAZ — atama (=) ile karşılaştırma (==) karıştırılmış
if x = 5:
    print("beş")
```

Bu satır `SyntaxError` verir. Tek `=` **atama** yapar, çift `==`
**karşılaştırma** yapar. Bu, yeni başlayanların en klasik hatasıdır.

## Mantıksal Operatörler

```python
# ✅ Bu kod çalışır
yas = 20
ogrenci = True

print(yas >= 18 and ogrenci)   # True  — ikisi de doğru olmalı
print(yas >= 18 or ogrenci)    # True  — biri doğru olması yeter
print(not ogrenci)             # False — tersini alır
```

## Atama Operatörleri (Kısayollar)

```python
# ✅ Bu kod çalışır
sayac = 0
sayac += 1   # sayac = sayac + 1  -> 1
sayac -= 1   # -> 0
sayac *= 5   # -> 0
sayac += 10  # -> 10
print(sayac)
```

### 🎯 Mini Alıştırma
Bir sayının hem 2'ye hem 3'e tam bölünüp bölünmediğini `%` ve `and`
operatörlerini kullanarak kontrol eden bir ifade yaz.

---
⬅️ [Değişkenler](./02-Degiskenler-ve-Veri-Tipleri.md) &nbsp;|&nbsp; ➡️ [Koşullu İfadeler](./04-Kosullu-Ifadeler.md)
