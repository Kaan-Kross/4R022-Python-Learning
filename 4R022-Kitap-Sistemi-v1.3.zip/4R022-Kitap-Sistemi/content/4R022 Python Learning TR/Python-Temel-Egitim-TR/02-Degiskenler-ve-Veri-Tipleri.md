# 2. Değişkenler ve Veri Tipleri

## Değişken Nedir?

Bir değişken, bir değeri hafızada saklayıp bir isimle çağırmanı sağlar.

```python
# ✅ Bu kod çalışır
yas = 25
isim = "Kaan"
boy = 1.80
ogrenci_mi = True

print(isim, yas, boy, ogrenci_mi)
```

```python
# ❌ Bu kod ÇALIŞMAZ — değişken ismi sayı ile başlayamaz
1yas = 25
```

Bu satır `SyntaxError: invalid decimal literal` verir. Python'da
değişken isimleri harf veya alt çizgi (`_`) ile başlamalı, sayı ile
başlayamaz.

## Temel Veri Tipleri

| Tip | Örnek | Açıklama |
|---|---|---|
| `int` | `5`, `-12` | Tam sayı |
| `float` | `3.14`, `-0.5` | Ondalıklı sayı |
| `str` | `"merhaba"` | Metin (string) |
| `bool` | `True`, `False` | Mantıksal değer |
| `NoneType` | `None` | "Değer yok" anlamına gelir |

Tipini kontrol etmek için `type()`:

```python
# ✅ Bu kod çalışır
print(type(5))        # <class 'int'>
print(type(5.0))      # <class 'float'>
print(type("5"))      # <class 'str'>
print(type(True))     # <class 'bool'>
```

## Tip Dönüşümü (Type Casting)

```python
# ✅ Bu kod çalışır
metin_sayi = "42"
gercek_sayi = int(metin_sayi)     # str -> int
print(gercek_sayi + 8)            # 50
```

```python
# ❌ Bu kod ÇALIŞMAZ — "kırk iki" bir sayıya çevrilemez
sayi = int("kırk iki")
```

Bu, `ValueError: invalid literal for int()` hatası verir. `int()`
fonksiyonu, yalnızca rakamlardan oluşan metinleri sayıya çevirebilir.

## Girdi Almak: `input()`

```python
# ✅ Bu kod çalışır
isim = input("Adınız nedir? ")
print("Merhaba " + isim + "!")
```

> ⚠️ **Dikkat:** `input()` her zaman bir **string (metin)** döndürür.
> Sayısal işlem yapacaksan mutlaka `int()` veya `float()` ile
> dönüştürmen gerekir:

```python
# ✅ Bu kod çalışır
yas = int(input("Yaşınız nedir? "))
print("5 yıl sonra", yas + 5, "yaşında olacaksınız.")
```

### 🎯 Mini Alıştırma
Kullanıcıdan iki sayı al, `input()` ile alınan bu sayıları `int()`'e
çevirip topla ve sonucu ekrana yazdır.

---
⬅️ [Kurulum](./01-Kurulum-ve-Ilk-Adimlar.md) &nbsp;|&nbsp; ➡️ [Operatörler](./03-Operatorler.md)
