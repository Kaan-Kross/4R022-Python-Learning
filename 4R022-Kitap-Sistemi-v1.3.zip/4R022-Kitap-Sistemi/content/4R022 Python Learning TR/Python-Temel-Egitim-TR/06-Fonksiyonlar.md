# 6. Fonksiyonlar

## Neden Fonksiyon?

Aynı kodu tekrar tekrar yazmak yerine, onu bir isim altında paketleyip
istediğin zaman çağırabilirsin. Bu, "DRY" (Don't Repeat Yourself)
ilkesinin temelidir.

```python
# ✅ Bu kod çalışır
def selamla(isim):
    print(f"Merhaba, {isim}!")

selamla("Kaan")
selamla("4R022")
```

```python
# ❌ Bu kod ÇALIŞMAZ — fonksiyon tanımlanmadan önce çağrılmış
selamla("Kaan")

def selamla(isim):
    print(f"Merhaba, {isim}!")
```

Bu, `NameError: name 'selamla' is not defined` verir. Python kodu
yukarıdan aşağıya çalıştırır; bir fonksiyonu çağırmadan önce
tanımlamış olman gerekir.

## `return` ile Değer Döndürme

```python
# ✅ Bu kod çalışır
def kare_al(sayi):
    return sayi ** 2

sonuc = kare_al(5)
print(sonuc)   # 25
```

> ⚠️ `print()` ekrana yazar ama değer **döndürmez**; `return` ise
> değeri fonksiyonun dışına taşır ve bir değişkende saklanabilir.

## Varsayılan Parametreler

```python
# ✅ Bu kod çalışır
def selamla(isim, mesaj="Hoş geldin"):
    print(f"{mesaj}, {isim}!")

selamla("Kaan")               # "Hoş geldin, Kaan!"
selamla("Kaan", "Merhaba")    # "Merhaba, Kaan!"
```

## `*args` ve `**kwargs`

```python
# ✅ Bu kod çalışır — sınırsız sayıda argüman alabilir
def topla(*sayilar):
    return sum(sayilar)

print(topla(1, 2, 3, 4))   # 10
```

```python
# ✅ Bu kod çalışır — isimli, sınırsız argüman alabilir
def bilgi_yazdir(**bilgiler):
    for anahtar, deger in bilgiler.items():
        print(f"{anahtar}: {deger}")

bilgi_yazdir(isim="Kaan", meslek="Yazılımcı")
```

## Değişken Kapsamı (Scope)

```python
# ❌ Bu kod ÇALIŞMAZ (beklenmedik şekilde) — fonksiyon içindeki 'x'
# fonksiyon dışındaki 'x'i etkilemez:
x = 10

def degistir():
    x = 20   # bu, fonksiyona ÖZEL yeni bir x'tir (local scope)

degistir()
print(x)   # hâlâ 10 yazar, 20 değil
```

```python
# ✅ Bu kod çalışır — global anahtar kelimesiyle dış x değiştirilir
x = 10

def degistir():
    global x
    x = 20

degistir()
print(x)   # 20 yazar
```

### 🎯 Mini Alıştırma
Bir listedeki en büyük sayıyı bulan `en_buyuk(liste)` adlı bir
fonksiyon yaz (hazır `max()` fonksiyonunu kullanmadan, bir `for`
döngüsüyle).

---
⬅️ [Döngüler](./05-Donguler.md) &nbsp;|&nbsp; ➡️ [Veri Yapıları](./07-Veri-Yapilari.md)
