# Python Temel Eğitim (TR) — Başlangıç Seviyesi

Bu kademe, hiç programlama bilmeyen birinin Python'da küçük ama
gerçek programlar yazabilir hale gelmesini hedefler.

## Bölümler (sırayla takip et)

1. [Kurulum ve İlk Adımlar](./01-Kurulum-ve-Ilk-Adimlar.md)
2. [Değişkenler ve Veri Tipleri](./02-Degiskenler-ve-Veri-Tipleri.md)
3. [Operatörler](./03-Operatorler.md)
4. [Koşullu İfadeler (if / elif / else)](./04-Kosullu-Ifadeler.md)
5. [Döngüler (for / while)](./05-Donguler.md)
6. [Fonksiyonlar](./06-Fonksiyonlar.md)
7. [Veri Yapıları: Liste, Demet, Sözlük, Küme](./07-Veri-Yapilari.md)
8. [Dosya İşlemleri ve Hata Yönetimi](./08-Dosya-Islemleri-ve-Hata-Yonetimi.md)
9. [Nesne Yönelimli Programlamaya Giriş (OOP)](./09-OOP-Giris.md)

Her bölümde ✅ çalışan ve ❌ çalışmayan kod örnekleri, açıklamaları ve
sonunda bir mini alıştırma bulunur.

Bitirince ➡️ [Orta Kademe](../Python-Orta-Kademe-TR/README.md)'ye geç.
