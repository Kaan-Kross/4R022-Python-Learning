# 7. Veri Yapıları: Liste, Demet, Sözlük, Küme

## Liste (`list`) — Sıralı, Değiştirilebilir

```python
# ✅ Bu kod çalışır
meyveler = ["elma", "armut", "muz"]
meyveler.append("çilek")       # sona ekler
meyveler[0] = "kayısı"         # ilk elemanı değiştirir
print(meyveler)                # ['kayısı', 'armut', 'muz', 'çilek']
print(meyveler[1])             # 'armut'
print(meyveler[-1])            # son eleman: 'çilek'
print(meyveler[0:2])           # dilimleme (slicing): ilk iki eleman
```

```python
# ❌ Bu kod ÇALIŞMAZ — liste sınırının dışına erişim
meyveler = ["elma", "armut"]
print(meyveler[5])
```

Bu, `IndexError: list index out of range` verir. Liste 2 elemanlıysa
geçerli indeksler yalnızca `0` ve `1`'dir.

## Demet (`tuple`) — Sıralı, DEĞİŞTİRİLEMEZ

```python
# ✅ Bu kod çalışır
koordinat = (10, 20)
print(koordinat[0])   # 10
```

```python
# ❌ Bu kod ÇALIŞMAZ — demetler oluşturulduktan sonra değiştirilemez
koordinat = (10, 20)
koordinat[0] = 99
```

Bu, `TypeError: 'tuple' object does not support item assignment` verir.
Demet, "bu veri değişmesin" garantisi istediğinde tercih edilir
(örneğin sabit bir koordinat, RGB renk değeri).

## Sözlük (`dict`) — Anahtar–Değer Çiftleri

```python
# ✅ Bu kod çalışır
ogrenci = {"isim": "Kaan", "yas": 25, "bolum": "Bilişim"}
print(ogrenci["isim"])       # 'Kaan'
ogrenci["yas"] = 26          # değer güncelleme
ogrenci["sehir"] = "Sakarya" # yeni anahtar ekleme

for anahtar, deger in ogrenci.items():
    print(anahtar, "->", deger)
```

```python
# ❌ Bu kod ÇALIŞMAZ — olmayan bir anahtara erişim
ogrenci = {"isim": "Kaan"}
print(ogrenci["soyad"])
```

Bu, `KeyError: 'soyad'` verir. Güvenli erişim için `.get()` kullanılır:

```python
# ✅ Bu kod çalışır — anahtar yoksa hata vermez, None döner
print(ogrenci.get("soyad"))          # None
print(ogrenci.get("soyad", "Yok"))   # "Yok" (varsayılan değer)
```

## Küme (`set`) — Sırasız, Tekrarsız

```python
# ✅ Bu kod çalışır — kümeler tekrar eden elemanları otomatik siler
sayilar = {1, 2, 2, 3, 3, 3}
print(sayilar)   # {1, 2, 3}

a = {1, 2, 3}
b = {2, 3, 4}
print(a & b)   # kesişim: {2, 3}
print(a | b)   # birleşim: {1, 2, 3, 4}
print(a - b)   # fark: {1}
```

## Karşılaştırma Tablosu

| Yapı | Sıralı mı? | Değiştirilebilir mi? | Tekrar eden eleman? | Söz Dizimi |
|---|---|---|---|---|
| `list` | ✅ | ✅ | ✅ | `[1, 2, 3]` |
| `tuple` | ✅ | ❌ | ✅ | `(1, 2, 3)` |
| `dict` | ✅ (3.7+) | ✅ | anahtar tekilleşir | `{"a": 1}` |
| `set` | ❌ | ✅ | ❌ | `{1, 2, 3}` |

### 🎯 Mini Alıştırma
Bir öğrenci listesindeki isimleri tutan bir `list` oluştur, sonra her
öğrencinin notunu tutan bir `dict` oluştur (`{"isim": not}`), ortalamayı
hesapla.

---
⬅️ [Fonksiyonlar](./06-Fonksiyonlar.md) &nbsp;|&nbsp; ➡️ [Dosya İşlemleri ve Hata Yönetimi](./08-Dosya-Islemleri-ve-Hata-Yonetimi.md)
