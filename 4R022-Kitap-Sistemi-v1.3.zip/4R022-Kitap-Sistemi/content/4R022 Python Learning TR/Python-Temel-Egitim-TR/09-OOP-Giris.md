# 9. Nesne Yönelimli Programlamaya Giriş (OOP)

## Sınıf (`class`) ve Nesne (`object`)

Bir **sınıf**, bir "kalıp/şablon"dur. Bir **nesne (instance)** ise bu
kalıptan üretilmiş, gerçek bir örnektir.

```python
# ✅ Bu kod çalışır
class Ogrenci:
    def __init__(self, isim, yas):
        self.isim = isim   # nitelik (attribute)
        self.yas = yas

    def tanit(self):       # metod (method)
        print(f"Ben {self.isim}, {self.yas} yaşındayım.")

ogrenci1 = Ogrenci("Kaan", 25)
ogrenci2 = Ogrenci("Ayşe", 22)

ogrenci1.tanit()   # "Ben Kaan, 25 yaşındayım."
ogrenci2.tanit()   # "Ben Ayşe, 22 yaşındayım."
```

`__init__`, bir nesne oluşturulduğunda **otomatik çalışan** özel bir
metoddur (yapıcı / constructor). `self`, o anki nesnenin kendisini
temsil eder.

```python
# ❌ Bu kod ÇALIŞMAZ — 'self' parametresi unutulmuş
class Ogrenci:
    def __init__(isim, yas):     # 'self' eksik!
        isim = isim
        yas = yas

ogrenci1 = Ogrenci("Kaan", 25)
```

Bu, `TypeError: __init__() takes 2 positional arguments but 3 were
given` verir. Python, her metoda otomatik olarak nesnenin kendisini
(`self`) ilk parametre olarak gönderir; bunu unutmak en klasik OOP
hatasıdır.

## Kalıtım (Inheritance)

```python
# ✅ Bu kod çalışır
class Hayvan:
    def __init__(self, isim):
        self.isim = isim

    def ses_cikar(self):
        print(f"{self.isim} bir ses çıkarıyor.")

class Kopek(Hayvan):              # Hayvan sınıfından miras alır
    def ses_cikar(self):          # metodu ezer (override)
        print(f"{self.isim}: Hav hav!")

hayvan = Hayvan("Bilinmeyen")
kopek = Kopek("Karabaş")

hayvan.ses_cikar()   # "Bilinmeyen bir ses çıkarıyor."
kopek.ses_cikar()    # "Karabaş: Hav hav!"
```

## Kapsülleme (Encapsulation) — Basit Giriş

```python
# ✅ Bu kod çalışır — başına _ konan nitelikler "özel" kabul edilir
# (Python'da gerçek bir erişim engeli yoktur, bu bir konvansiyondur)
class BankaHesabi:
    def __init__(self, bakiye):
        self._bakiye = bakiye

    def para_yatir(self, miktar):
        if miktar > 0:
            self._bakiye += miktar

    def bakiye_goster(self):
        return self._bakiye

hesap = BankaHesabi(100)
hesap.para_yatir(50)
print(hesap.bakiye_goster())   # 150
```

## Neden OOP?

Programın büyüdüğü noktada, ilgili veriyi (nitelikler) ve o veri
üzerinde çalışan davranışı (metodlar) bir arada tutmak, kodu okunur ve
yönetilebilir kılar. 4R022'nin masaüstü uygulamalarında (PyQt6
projelerinde) `core/` ve `ui/` ayrımı da bu mantığın büyütülmüş halidir.

### 🎯 Mini Alıştırma
`Arac` adlı bir sınıf yaz (`marka`, `hiz` niteliklerine sahip), sonra
bundan miras alan bir `SporArac` sınıfı yaz ve `hizlan()` metodunu
`SporArac` içinde farklı davransın diye ezerek (override) yeniden yaz.

---
⬅️ [Dosya İşlemleri ve Hata Yönetimi](./08-Dosya-Islemleri-ve-Hata-Yonetimi.md) &nbsp;|&nbsp; ➡️ [Orta Kademeye Geç](../Python-Orta-Kademe-TR/README.md)

🎉 **Tebrikler — Temel Kademe'yi tamamladın!**
