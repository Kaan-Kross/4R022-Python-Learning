# 5. Döngüler (for / while)

## `for` Döngüsü

```python
# ✅ Bu kod çalışır — 0'dan 4'e kadar sayar (5 dahil değil)
for i in range(5):
    print(i)
```

```python
# ✅ Bu kod çalışır — bir liste üzerinde gezinir
meyveler = ["elma", "armut", "muz"]
for meyve in meyveler:
    print(meyve)
```

```python
# ❌ Bu kod ÇALIŞMAZ — range() son sayıyı DAHİL ETMEZ, bu bir
# yanlış varsayımdır, hata vermez ama beklenen çıktıyı vermez:
for i in range(1, 5):
    print(i)   # 1,2,3,4 yazdırır — 5 dahil DEĞİLDİR, bu sık yapılan
               # bir kavram yanılgısıdır (mantık hatası, syntax hatası
               # değil — kod çalışır ama beklediğinden farklı sonuç verir)
```

## `while` Döngüsü

```python
# ✅ Bu kod çalışır
sayac = 0
while sayac < 5:
    print(sayac)
    sayac += 1
```

```python
# ❌ Bu kod ÇALIŞMAZ (asla durmaz — sonsuz döngü!)
sayac = 0
while sayac < 5:
    print(sayac)
    # sayac += 1 satırı unutulmuş, sayac hiç artmıyor,
    # bu yüzden koşul hep True kalır ve program sonsuza dek çalışır
```

> ⚠️ Sonsuz döngüye girersen terminalde **Ctrl + C** ile durdurabilirsin.

## `break` ve `continue`

```python
# ✅ Bu kod çalışır — 3'e ulaşınca döngüyü tamamen durdurur
for i in range(10):
    if i == 3:
        break
    print(i)   # 0, 1, 2 yazdırır
```

```python
# ✅ Bu kod çalışır — sadece 3'ü atlar, döngü devam eder
for i in range(5):
    if i == 3:
        continue
    print(i)   # 0, 1, 2, 4 yazdırır (3 atlanır)
```

## İç İçe Döngüler

```python
# ✅ Bu kod çalışır — 3x3'lük bir çarpım tablosu benzeri çıktı
for i in range(1, 4):
    for j in range(1, 4):
        print(i * j, end=" ")
    print()  # her dış döngüde yeni satıra geç
```

### 🎯 Mini Alıştırma
1'den 100'e kadar olan sayılardan 3'e veya 5'e bölünenlerin toplamını
bir `for` döngüsü ile hesapla.

---
⬅️ [Koşullu İfadeler](./04-Kosullu-Ifadeler.md) &nbsp;|&nbsp; ➡️ [Fonksiyonlar](./06-Fonksiyonlar.md)
