# 1. Kurulum ve İlk Adımlar

## Python'ı Kurmak

1. [python.org/downloads](https://python.org/downloads) adresinden
   işletim sistemine uygun sürümü indir (Windows için **"Add Python
   to PATH"** kutucuğunu mutlaka işaretle).
2. Kurulumu doğrulamak için terminal/cmd'ye yaz:

```bash
python --version
```

3. Bir kod editörü kur: **VS Code** (tavsiye edilen), PyCharm veya
   basitçe IDLE (Python ile birlikte gelir).

## İlk Programın

```python
# ✅ Bu kod çalışır — dosyayı "merhaba.py" olarak kaydet ve çalıştır
print("Merhaba, 4R022 Python Learning!")
```

Terminalde çalıştırmak için:

```bash
python merhaba.py
```

```python
# ❌ Bu kod ÇALIŞMAZ — "print" kelimesi yanlış yazılmış (typo)
prnt("Merhaba")
```

Yukarıdaki hata `NameError: name 'prnt' is not defined` verir. Python,
tanımadığı her ismi böyle bildirir — hata mesajlarını okumak, hata
almaktan korkmaktan çok daha faydalıdır.

## Python Yorumlayıcısı (Interactive Shell)

Terminale sadece `python` yazarsan, satır satır kod çalıştırabileceğin
etkileşimli bir kabuk açılır (`>>>` işareti görürsün). Küçük şeyleri
hızlıca denemek için idealdir.

```python
>>> 2 + 2
4
>>> print("test")
test
```

## Yorum Satırları (Comments)

```python
# Bu bir tek satırlık yorumdur, Python tarafından çalıştırılmaz
print("Bu satır çalışır")  # satır sonuna da yorum eklenebilir

"""
Bu, birden fazla satır süren
bir yorum bloğudur (docstring olarak da kullanılır).
"""
```

### 🎯 Mini Alıştırma
Adını ekrana yazdıran ve altına "Python öğreniyorum!" yazan iki satırlık
bir program yaz.

---
⬅️ [Geri](./README.md) &nbsp;|&nbsp; ➡️ [Değişkenler ve Veri Tipleri](./02-Degiskenler-ve-Veri-Tipleri.md)
