# Python Data Concepts (EN)

This section is deliberately separate from
[Modules and Usage](../Python-Modules-and-Usage-ENG/README.md). While
that section answers "how do I use this module in Python?", this one
answers a more fundamental question: **"what actually is this data
format/system, how does it work, and how is it integrated,
automated, exported, and imported in real systems?"**

## Chapters

1. [What Is JSON Data?](./01-What-Is-JSON.md)
2. [What Is CSV Data?](./02-What-Is-CSV.md)
3. [What Are Databases and SQLite?](./03-Databases-and-SQLite.md)

For the coding side (how do I read/write this in Python), see the
[json](../Python-Modules-and-Usage-ENG/03-json/README.md),
[csv](../Python-Modules-and-Usage-ENG/04-csv/README.md), and
[sqlite3](../Python-Modules-and-Usage-ENG/15-sqlite3/README.md)
folders once translated in Modules and Usage.

⬅️ [Advanced Level](../Python-Advanced-Education-ENG/README.md) &nbsp;|&nbsp; ➡️ [Modules and Usage](../Python-Modules-and-Usage-ENG/README.md)
