# 1. What Is JSON Data?

## Origin and Nature of JSON

JSON (JavaScript Object Notation) grew out of JavaScript's object
syntax but has since become a **language-independent, universal data
exchange format**. Popularized around 2001 by Douglas Crockford, it's
now defined by the RFC 8259 standard. JSON stands out for being
human-readable (much simpler than XML) and for being natively
readable/writable by nearly every programming language.

## What Does Its Structure Look Like?

JSON is built from just **6 basic building blocks**:

| Structure | Example |
|---|---|
| Object | `{"name": "Kaan"}` |
| Array | `[1, 2, 3]` |
| String | `"hello"` |
| Number | `42`, `3.14` |
| Boolean | `true`, `false` |
| Null | `null` |

These nest to represent arbitrarily complex data:

```json
{
  "user": "Kaan",
  "active": true,
  "age": 25,
  "roles": ["developer", "student"],
  "address": {
    "city": "Sakarya",
    "country": "Turkey"
  },
  "secondary_phone": null
}
```

## Why Is It So Widespread?

- **The common language of web APIs** — a mobile app, a website, and
  a server can be written in totally different languages (Swift,
  JavaScript, Python) and still exchange data seamlessly via JSON.
- **Human-readable** — a developer can open a raw JSON file and
  understand its content almost without documentation.
- **Lightweight** — less "noise" (repeated tags) than XML.

## How Do Systems Integrate JSON?

1. **API communication:** A mobile app sends a "log in" request to a
   server → the server returns user info as JSON → the app parses
   that JSON and displays the username.
2. **Configuration files:** Many apps (VS Code, npm projects) store
   their settings in `.json` files — humans can edit them by hand,
   programs can read them easily.
3. **Log/data-lake systems:** Server logs are often stored as "JSON
   Lines" (each line is its own JSON object), letting log analysis
   tools (like Elasticsearch) parse the data easily.

## How Is It Refreshed / Kept Up To Date?

JSON isn't "live" data on its own — it's a **snapshot**. To keep an
app's JSON data current, one of these patterns is typically used:

- **Polling:** The client periodically ("every 30 seconds") asks the
  server for fresh JSON.
- **Push (webhook/websocket):** The server sends new JSON to the
  client itself whenever data changes — more efficient, closer to
  real time.
- **File-based:** A local app (like 4R022's desktop tools) rewrites
  its settings JSON file whenever settings change (using the atomic
  write pattern to avoid data loss).

## Automation and Export/Import

- **Export:** When an app says "back up my data", it typically
  writes everything into a single JSON file — a portable, readable
  backup.
- **Import:** When migrating data from another system (say, a legacy
  app), the source system dumps its data as JSON, and the target
  system reads and imports it into its own database/structure.
- **Automation scripts:** A script might run nightly, pull data from
  an API, and save it to a local JSON file (e.g. archiving daily
  currency exchange rates).

## What Are Its Limits?

- **No comments** — the official JSON standard has no `//` or `/* */`
  comment syntax (this is why extended variants like "JSON5" or
  "JSONC" exist for some tools).
- **Can be inefficient for huge data** — for millions of rows of
  tabular data, CSV or a real database is usually a better fit.
- **No enforced schema** — nothing in the standard guarantees a JSON
  file is "shaped correctly" (extra tools like JSON Schema were built
  to solve this).

---
⬅️ [Back](./README.md) &nbsp;|&nbsp; ➡️ [What Is CSV Data?](./02-What-Is-CSV.md)
