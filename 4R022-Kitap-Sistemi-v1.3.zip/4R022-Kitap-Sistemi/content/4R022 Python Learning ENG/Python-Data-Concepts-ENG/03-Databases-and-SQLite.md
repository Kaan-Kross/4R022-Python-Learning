# 3. What Are Databases and SQLite?

## What Is a Database, and Why Do We Need One?

A database is a system that stores data in an **organized, queryable,
and consistent** way. "Why isn't a JSON/CSV file enough?" — as data
grows (thousands/millions of records), plain files become **slow to
search**, **hard to write to safely from multiple users at once**,
and **can't guarantee consistency rules** (like "this order can't
belong to a customer that doesn't exist"). Databases exist
specifically to solve these problems.

## Relational Database Logic (Briefly)

The most common type is a **relational** database — data is stored
in linked **tables**:

```
students table:              grades table:
+----+-------+              +----+-------------+-------+
| id | name  |              | id | student_id  | grade |
+----+-------+              +----+-------------+-------+
| 1  | Kaan  |              | 1  | 1           | 95    |
| 2  | Ayse  |              | 2  | 2           | 88    |
+----+-------+              +----+-------------+-------+
```

The `student_id` in `grades` **links (foreign key)** to `id` in
`students` — this connection lets you run queries like "get all of
Kaan's grades" quickly and consistently. These queries are written in
**SQL (Structured Query Language)**.

## What Is SQLite, and How Does It Differ From Other Databases?

SQLite is a **server-free**, lightweight relational database engine
where the **entire database lives in a single file**. Unlike
PostgreSQL or MySQL, you don't need to install and run a separate
"database server" — Python's `sqlite3` module connects directly to a
`.db` file.

| Criterion | SQLite | PostgreSQL / MySQL |
|---|---|---|
| Setup | None (file-based) | Requires server setup |
| Concurrent multi-user access | Limited | Strong |
| Typical use | Desktop apps, mobile, prototypes | Websites, large-scale systems |
| Data size | Comfortable up to GBs | Scales to TBs |

## How Do Systems Integrate Databases?

1. **Desktop applications:** In projects like 4R022's Archive and
   Wallet tools, user data (records, transactions) is stored directly
   in a local SQLite file — no internet connection needed.
2. **Web applications:** A website's backend (Flask/Django) usually
   stores user accounts and orders in a server-based database like
   PostgreSQL/MySQL.
3. **ORM (Object-Relational Mapping):** Tools like SQLAlchemy let you
   manage a database with Python objects instead of writing raw
   SQL — a "bridge" between data and code.

## How Is Data Updated, Refreshed, Backed Up?

- **CRUD operations:** Database data changes via `INSERT` (add),
  `SELECT` (read), `UPDATE` (modify), `DELETE` (remove) — these four
  operations underlie almost every application.
- **Schema migration:** When an app updates, its database structure
  might need to change too (e.g. adding a new column); these changes
  are applied in a controlled way via "migration" scripts.
- **Backup:** For SQLite, backup is often as simple as copying the
  `.db` file; server-based databases use dedicated tools like
  `pg_dump` (PostgreSQL).

## Export/Import and Automation

- Exporting a database table to CSV is the most common way to feed
  data into reporting tools.
- Automated backup scripts can be scheduled to back up the database
  nightly and automatically delete old backups (e.g. anything over
  30 days old — see the
  [datetime](../Python-Modules-and-Usage-ENG/05-datetime/README.md)
  module once translated).

## What Are Its Limits?

- SQLite isn't well-suited to large web applications requiring **many
  concurrent write operations** (it allows only one write at a time).
- Relational databases can feel too rigid for flexible/variable data
  shapes (where each record might have different fields) — "NoSQL"
  databases (like MongoDB) are often preferred there.

---
⬅️ [What Is CSV Data?](./02-What-Is-CSV.md) &nbsp;|&nbsp; ⬆️ [Data Concepts Home](./README.md)

🎓 Once you've finished this section, check out
[Modules and Usage](../Python-Modules-and-Usage-ENG/README.md) for
the coding side (`json`, `csv`, `sqlite3`).
