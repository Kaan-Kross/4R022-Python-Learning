# 2. What Is CSV Data?

## Origin and Nature

CSV (Comma-Separated Values) is one of the oldest and simplest
formats for representing tabular data as **plain text**, in use
since the 1970s. It has no strict, enforced standard (RFC 4180 is a
recommendation, not a requirement) — which makes it both the easiest
format to learn and one of the most prone to "small differences"
between implementations.

## What Does Its Structure Look Like?

Each line is a record; the values on each line are columns separated
by a delimiter (usually a comma, sometimes a semicolon or tab):

```csv
name,age,city
Kaan,25,Sakarya
Ayse,22,Istanbul
"Smith, John",30,Ankara
```

Note: the third row's name contains a comma, so it's **quoted** —
this is one of the core rules a CSV parser must understand (which is
why a real CSV library should be used instead of a raw `split(",")`).

## Why Is It Still So Common?

- **The universal exchange format for Excel/Google Sheets** — almost
  every spreadsheet program can import/export CSV.
- **Readable by eye** (for small files) — can even be opened and
  inspected in a plain text editor.
- **The standard export format for databases** — most database
  management tools can export/import tables as CSV.

## How Do Systems Integrate CSV?

1. **Accounting/ERP systems:** A company's accounting software
   exports its monthly sales report as CSV, which then feeds into
   another analysis tool (Excel, a Python script, Power BI).
2. **Data science workflows:** Raw data is often collected as CSV,
   read with `pandas`, cleaned, and analyzed.
3. **Bulk import:** Instead of manually entering hundreds of
   products into a website one by one, a CSV template is filled out
   and imported via a "bulk upload" feature.

## How Is It Refreshed / Automated?

- **Scheduled exports:** Many systems automatically "stamp" current
  data into a CSV file every night/week (e.g. `sales_2026-09-15.csv`).
- **CSV watcher scripts:** An automation script can watch a folder
  and automatically process any new CSV file that appears, importing
  it into a database (a simple example of an ETL — Extract,
  Transform, Load — process).
- **Spreadsheet integrations:** Google Sheets can treat a CSV as a
  "linked sheet" and refresh it periodically.

## Export/Import Practices

- **Export:** Tools like `pandas.DataFrame.to_csv()` can turn a
  table into CSV in a single line of code.
- **Import:** Different systems may use different delimiters/
  encodings (e.g. `windows-1250`-family encodings common in some
  Central/Eastern European CSVs) — accounting for this on import
  prevents garbled-character problems.

## What Are Its Limits?

- **Carries no type information** — everything is text; whether
  `"95"` is a number or a string is not specified by CSV itself, the
  reading program has to guess/interpret it.
- **Can't represent nested data** — unlike JSON, it can't hold an
  object inside another object/list; it's only suited to flat tables.
- **Standard inconsistency** — delimiter choice (comma vs
  semicolon), line-ending characters (Windows `\r\n` vs Unix `\n`),
  and encoding differences are the most common sources of problems
  when transferring CSVs between systems.

---
⬅️ [What Is JSON Data?](./01-What-Is-JSON.md) &nbsp;|&nbsp; ➡️ [What Are Databases and SQLite?](./03-Databases-and-SQLite.md)
