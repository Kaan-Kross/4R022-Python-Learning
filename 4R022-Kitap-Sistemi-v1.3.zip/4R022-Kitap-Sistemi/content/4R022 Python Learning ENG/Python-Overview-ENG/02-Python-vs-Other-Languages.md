# Python vs Other Programming Languages

## Python vs C / C++

C/C++ are **compiled**, **statically typed** languages. They run
very close to the hardware and are fast, but memory management is
usually manual.

```c
// C — types are mandatory
int add(int a, int b) {
    return a + b;
}
```

```python
# ✅ Python — no type declarations needed
def add(a, b):
    return a + b
```

**Difference:** C is chosen for speed and low-level control (OS,
game engines, embedded systems); Python is chosen for development
speed and readability (automation, data science, backend).

## Python vs Java

Java is statically typed and compiles to bytecode; "everything must
live inside a class."

```java
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
```

```python
# ✅ Python — no class required, one line is enough
print("Hello World")
```

**Difference:** Java is strong for large enterprise systems and
Android; Python is stronger for rapid prototyping and scripting.

## Python vs JavaScript

JavaScript is dynamically typed and runs in browsers (and on servers
via Node.js) — closer to Python in feel.

```javascript
function add(a, b) {
    return a + b;
}
```

```python
def add(a, b):
    return a + b
```

**Difference:** JavaScript is the browser's native language (nothing
else runs there); Python has no browser role but is far more
comfortable for backend, automation, data science, and desktop apps.

## Python vs C#

C# is Microsoft's statically typed language for the .NET ecosystem,
very close to Java in style — common for Windows desktop apps (WPF,
WinForms) and Unity game development.

**Difference:** C# integrates deeply with Windows/.NET; Python wins
on cross-platform portability and development speed.

## When to Pick Which Language

| Need | Recommended Language |
|---|---|
| Data analysis, AI, automation | **Python** |
| Browser UI | JavaScript (+ HTML/CSS) |
| High-performance game engine / OS | C / C++ |
| Large enterprise backend / Android | Java |
| Windows desktop / Unity games | C# |
| Fast scripts, prototypes, learning | **Python** |

## Summary

No language is universally "the best" — each exists for a reason.
What sets Python apart isn't raw speed, but **developer productivity
and a low learning curve.** That's exactly why we start here.

---
⬅️ Previous: [What is Python?](./01-What-is-Python.md) &nbsp;|&nbsp; ➡️ Next: [What Can You Build With Python?](./03-What-Can-You-Build.md)
