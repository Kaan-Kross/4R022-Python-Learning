# Python Overview (EN)

Before diving into code, this section answers: what is Python, how
does it compare to other languages, and what can you actually build
with it?

## Contents

1. [What is Python?](./01-What-is-Python.md)
2. [Python vs Other Programming Languages](./02-Python-vs-Other-Languages.md)
3. [What Can You Build With Python?](./03-What-Can-You-Build.md)

Next ➡️ [Python First Education (Basic Level)](../Python-First-Education-ENG/README.md)
