# What Can You Build With Python?

## 1. Web Development (Backend)
**Tools:** Django, Flask, FastAPI

```python
# ✅ This code works (if Flask is installed): a minimal web server
from flask import Flask
app = Flask(__name__)

@app.route("/")
def home():
    return "Welcome to 4R022 Python Learning!"
```

## 2. Data Science & Analysis
**Tools:** pandas, numpy, matplotlib

```python
# ✅ This code works (if pandas is installed)
import pandas as pd
data = {"name": ["Alice", "Bob"], "age": [23, 30]}
df = pd.DataFrame(data)
print(df)
```

## 3. AI and Machine Learning
**Tools:** TensorFlow, PyTorch, scikit-learn

Python is the de-facto standard language of AI — nearly every major
large language model and ML library ships with a Python interface.

## 4. Automation and Scripting
**Tools:** os, shutil, pyautogui, selenium

```python
# ✅ This code works — lists all files in a folder
import os
for file in os.listdir("."):
    print(file)
```

## 5. Desktop Application Development
**Tools:** Tkinter (standard library), PyQt6, Kivy

Many 4R022-branded projects (desktop tools) fall exactly in this
category — professional Windows applications built with Python +
PyQt6/Tkinter.

## 6. Cybersecurity and Networking
**Tools:** socket, scapy, cryptography, requests

Security researchers and sysadmins frequently use Python for network
traffic analysis, encryption, and automated security scans. We cover
the **ethical** side of this in
[Ethics and Security](../Python-Ethics-and-Security-ENG/README.md).

## 7. Game Development (Lightweight)
**Tools:** Pygame

## 8. Glue Language
Python is also widely used to connect different systems together
(C libraries, databases, APIs) — hence the nickname "glue language."

## Summary Table

| Domain | Popular Libraries |
|---|---|
| Web (backend) | Django, Flask, FastAPI |
| Data science | pandas, numpy, matplotlib |
| AI | TensorFlow, PyTorch, scikit-learn |
| Automation | os, selenium, pyautogui |
| Desktop apps | Tkinter, PyQt6, Kivy |
| Networking / security | socket, scapy, cryptography |
| Games | Pygame |

---
⬅️ Previous: [Python vs Other Languages](./02-Python-vs-Other-Languages.md) &nbsp;|&nbsp; ➡️ Next: [Start the Basic Level](../Python-First-Education-ENG/README.md)
