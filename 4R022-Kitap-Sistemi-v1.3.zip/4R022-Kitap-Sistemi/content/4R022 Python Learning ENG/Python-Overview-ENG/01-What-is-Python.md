# What Is Python?

> 🧑‍🏫 **Teacher's note:** think of this as a conversation, not a
> definition to memorize. The goal is to actually understand why
> this language exists and why it's so popular.

## In Short

Python is an **interpreted**, **high-level**, **general-purpose**
programming language created by **Guido van Rossum** in 1991.
"High-level" means it reads close to plain English rather than raw
machine instructions.

Python's philosophy fits in one sentence:

> **"Code readability comes first."**

```python
# ✅ This code works — and reads almost like English
name = "Kaan"
if name == "Kaan":
    print("Hello, 4R022!")
```

## Why "Interpreted"?

Python code isn't compiled straight to machine code; it's run
line-by-line by an **interpreter** (CPython being the most common
one). This makes development faster, at some cost to raw runtime
speed compared to compiled languages like C/C++ — a deliberate
trade-off favoring developer speed and readability.

## Key Characteristics

| Feature | Description |
|---|---|
| Dynamic typing | No need to declare a variable's type up front |
| Readable syntax | Indentation-based blocks |
| Huge standard library | "Batteries included" philosophy |
| Multi-paradigm | Procedural, object-oriented, functional all supported |
| Cross-platform | Same code runs on Windows, Linux, macOS |
| Massive community | 500,000+ packages on PyPI |

```python
# ✅ This code works
x = 5        # x is currently an int
x = "five"   # now the same variable holds a string — no error
print(x)
```

```python
# ❌ This code does NOT work — this is C/Java syntax, not Python.
# Copy-pasting this into a Python file raises a SyntaxError:
int x = 5;
```

## Why Indentation Matters So Much

Python uses **indentation** (not `{}`) to define blocks. It's both
the language's most distinctive trait and its most common early
mistake.

```python
# ✅ This code works — correct indentation
def greet():
    print("Hello")
    print("Welcome to 4R022 Python Learning")

greet()
```

```python
# ❌ This code does NOT work — raises IndentationError
def greet():
print("Hello")   # this line needed to be indented
```

## Summary

- Python is readable, dynamically typed, interpreted, and general-purpose.
- It separates code blocks using indentation — its biggest strength and its most common early pitfall.
- It has a massive standard library and community package ecosystem (PyPI).

### 🎯 Mini Exercise
Find and fix the bug in this code:

```python
def add(a, b):
return a + b

print(add(3, 4))
```

<details>
<summary>Show answer</summary>

`return a + b` isn't indented, so this raises `IndentationError`.
Fixed:

```python
def add(a, b):
    return a + b

print(add(3, 4))
```

</details>

---
⬅️ [Back](./README.md) &nbsp;|&nbsp; ➡️ Next: [Python vs Other Languages](./02-Python-vs-Other-Languages.md)
