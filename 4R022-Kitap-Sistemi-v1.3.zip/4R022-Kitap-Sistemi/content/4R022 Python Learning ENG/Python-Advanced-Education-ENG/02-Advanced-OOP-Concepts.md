# 2. Advanced OOP Concepts

## Writing Your Own Context Manager

The logic behind `with open(...)` can be built into your own classes too:

```python
# ✅ This code works
class DatabaseConnection:
    def __enter__(self):
        print("Connection opened")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        print("Connection closed")
        return False   # don't suppress any exception, let it propagate

with DatabaseConnection() as conn:
    print("Running query...")
# "Connection closed" is printed automatically on exit
```

A shorter alternative with `contextlib`:

```python
# ✅ This code works
from contextlib import contextmanager

@contextmanager
def db_connection():
    print("Connection opened")
    yield "connection_object"
    print("Connection closed")

with db_connection() as c:
    print("Running query...")
```

## Memory Optimization with `__slots__`

```python
# ✅ This code works — objects with __slots__ use less memory
class Point:
    __slots__ = ("x", "y")   # only these two attributes are allowed

    def __init__(self, x, y):
        self.x = x
        self.y = y

p = Point(1, 2)
```

```python
# ❌ This code does NOT work — assigning to an attribute not listed
# in __slots__
p.z = 5
```

This raises `AttributeError: 'Point' object has no attribute 'z'`.
In applications that create thousands of objects (game engines, for
example), `__slots__` gives real memory savings.

## Metaclasses — The Class of a Class

Normally, a class is created from a metaclass called `type`. Writing
your own metaclass lets you customize **how classes themselves get
created** — an advanced concept, mostly useful when building
frameworks/libraries.

```python
# ✅ This code works — logs automatically every time a class is created
class LoggedMeta(type):
    def __new__(mcs, name, bases, namespace):
        print(f"Creating new class: {name}")
        return super().__new__(mcs, name, bases, namespace)

class Example(metaclass=LoggedMeta):
    pass
# output: "Creating new class: Example"
```

> 🧑‍🏫 **Teacher's note:** metaclasses are rarely needed in everyday
> code — they're used heavily inside big frameworks like Django and
> SQLAlchemy. Knowing they exist is enough at this stage.

### 🎯 Mini Exercise
Write your own context manager (using `__enter__`/`__exit__`) that
automates opening and closing a file.

---
⬅️ [Concurrency](./01-Concurrency.md) &nbsp;|&nbsp; ➡️ [Performance and Optimization](./03-Performance-and-Optimization.md)
