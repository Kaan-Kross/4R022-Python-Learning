# 4. Design Patterns

Design patterns are proven solution templates for problems that keep
recurring in software. Here we cover three that are especially
useful in 4R022-style desktop applications.

## 1. Singleton — "One Object Only"

Guarantees that a class only ever produces **one** instance (a single
settings/config object, a single database connection).

```python
# ✅ This code works
class Settings:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.theme = "dark"
        return cls._instance

s1 = Settings()
s2 = Settings()
print(s1 is s2)   # True — both are the SAME object
```

```python
# ❌ This gives the WRONG result — using a plain __init__ instead of
# __new__ creates a NEW object on every call:
class SettingsWrong:
    def __init__(self):
        self.theme = "dark"

s1 = SettingsWrong()
s2 = SettingsWrong()
print(s1 is s2)   # False — these are TWO different objects, not a Singleton!
```

## 2. Factory — "Object Producer"

Centralizes object-creation logic; the exact class to build is
decided at runtime.

```python
# ✅ This code works
class Dog:
    def sound(self):
        return "Woof"

class Cat:
    def sound(self):
        return "Meow"

def make_animal(kind):
    if kind == "dog":
        return Dog()
    elif kind == "cat":
        return Cat()
    raise ValueError(f"Unknown kind: {kind}")

animal = make_animal("cat")
print(animal.sound())   # "Meow"
```

## 3. Observer — "Notify on Change"

Automatically notifies other objects when something changes. PyQt6's
**signal/slot** system is a ready-made implementation of this pattern.

```python
# ✅ This code works — plain Python implementation of Observer
class Publisher:
    def __init__(self):
        self._listeners = []

    def add_listener(self, func):
        self._listeners.append(func)

    def notify(self, data):
        for listener in self._listeners:
            listener(data)

def print_to_screen(data):
    print("New data arrived:", data)

pub = Publisher()
pub.add_listener(print_to_screen)
pub.notify("Hello!")   # "New data arrived: Hello!"
```

PyQt6's equivalent:

```python
# ✅ This code works (if PyQt6 is installed)
from PyQt6.QtCore import QObject, pyqtSignal

class Publisher(QObject):
    data_arrived = pyqtSignal(str)   # signal definition

pub = Publisher()
pub.data_arrived.connect(lambda data: print("New data:", data))
pub.data_arrived.emit("Hello PyQt6!")
```

### 🎯 Mini Exercise
Write a `Logger` Singleton class that writes to the same log file
from anywhere in the app.

---
⬅️ [Performance and Optimization](./03-Performance-and-Optimization.md) &nbsp;|&nbsp; ➡️ [Desktop App Development](./05-Desktop-App-Development.md)
