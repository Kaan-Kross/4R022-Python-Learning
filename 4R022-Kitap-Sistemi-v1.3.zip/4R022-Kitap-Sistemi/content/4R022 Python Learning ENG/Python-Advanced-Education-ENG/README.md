# Python Advanced Education (EN)

This tier is for people who want to build real, performant, professional
software. We're no longer learning the language itself — we're
learning to build **professional software** with it.

## Chapters

1. [Concurrency: Threading, Multiprocessing, Asyncio](./01-Concurrency.md)
2. [Advanced OOP: Context Managers, `__slots__`, Metaclasses](./02-Advanced-OOP-Concepts.md)
3. [Performance and Optimization](./03-Performance-and-Optimization.md)
4. [Design Patterns](./04-Design-Patterns.md)
5. [Professional Desktop App Development (PyQt6)](./05-Desktop-App-Development.md)
6. [GUI, UI/UX, and Cross-Platform Interfaces](./06-GUI-UI-UX-and-Cross-Platform.md)

Next ➡️ [Data Concepts](../Python-Data-Concepts-ENG/README.md)
