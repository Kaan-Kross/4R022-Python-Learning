# 5. Professional Desktop App Development (PyQt6)

## Why PyQt6 Instead of Tkinter?

`tkinter` ships with the standard library and is quick for small
tools. `PyQt6` offers a more modern look, a signal/slot architecture,
and a much sturdier foundation for large applications — which is why
most 4R022 desktop products are built with it.

## A Minimal PyQt6 Application

```python
# ✅ This code works (if PyQt6 is installed: pip install PyQt6)
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4R022 Example App")
        self.resize(400, 200)

        layout = QVBoxLayout()
        label = QLabel("Hello, 4R022 Python Learning!")
        layout.addWidget(label)
        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
```

```python
# ❌ This code does NOT work — showing a window before creating QApplication
window = MainWindow()
window.show()
# RuntimeError: Please create QApplication before QWidget
```

Every PyQt6 app must create `QApplication` **first**, then windows.

## Recommended Architecture: `core/` + `ui/`

```
project/
├── main.py
├── core/              # business logic, data processing (UI-independent)
│   ├── __init__.py
│   └── data_manager.py
└── ui/                # view and user interaction only
    ├── __init__.py
    └── main_window.py
```

The point of this split: keep business logic (`core/`) independent
of the UI (`ui/`), so you can test the logic without ever opening a
window.

## Signal/Slot for Button Clicks

```python
# ✅ This code works
from PyQt6.QtWidgets import QPushButton

button = QPushButton("Click")
button.clicked.connect(lambda: print("Button clicked!"))
```

## Packaging with PyInstaller (Brief Overview)

```bash
# ✅ This command works — turns a .py file into a single .exe
pip install pyinstaller
pyinstaller --onefile --windowed main.py
```

To access bundled resource files (icons, images) inside a
PyInstaller-packaged app, a `resource_path()` helper is standard
practice in 4R022 projects:

```python
# ✅ This code works
import sys, os

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS   # PyInstaller's temp folder
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
```

### 🎯 Mini Exercise
Write a small PyQt6 app with a text box (`QLineEdit`) and a button
(`QPushButton`) that, when clicked, shows the text box's contents in
a `QLabel`.

---
⬅️ [Design Patterns](./04-Design-Patterns.md) &nbsp;|&nbsp; ➡️ [GUI, UI/UX, and Cross-Platform](./06-GUI-UI-UX-and-Cross-Platform.md)
