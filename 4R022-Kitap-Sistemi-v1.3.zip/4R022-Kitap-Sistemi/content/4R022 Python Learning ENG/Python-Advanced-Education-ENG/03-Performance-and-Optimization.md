# 3. Performance and Optimization

## Don't Optimize Without Measuring!

> 🧑‍🏫 **Golden rule:** "Measure first, optimize second." Guessing
> what's "slow" based on intuition is often wrong.

```python
# ✅ This code works — measures how long a function takes
import timeit
duration = timeit.timeit("sum(range(1000))", number=10000)
print(duration)
```

```python
# ✅ This code works — cProfile shows where the whole program spends its time
import cProfile

def slow_function():
    return sum(i * i for i in range(1_000_000))

cProfile.run("slow_function()")
```

## Caching Results with `functools.lru_cache`

```python
# ❌ This WORKS but is VERY SLOW — every call redoes the same work
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(35))   # can take several seconds
```

```python
# ✅ This code works — results are cached, the same input is never
# recomputed, execution drops to well under a second
from functools import lru_cache

@lru_cache(maxsize=None)
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(35))   # instant
```

## List Comprehensions — Faster and More Readable

```python
# ❌ This WORKS but is slower and more verbose
squares = []
for i in range(1000):
    squares.append(i * i)
```

```python
# ✅ This code works — faster (optimized internally) and more readable
squares = [i * i for i in range(1000)]
```

## `join()` for String Concatenation

```python
# ❌ This WORKS but is SLOW in big loops — every '+=' creates a
# brand-new string object (strings are immutable!)
result = ""
for word in ["Python", "is", "fast"]:
    result += word + " "
```

```python
# ✅ This code works — joins in one pass, much better performance
result = " ".join(["Python", "is", "fast"])
```

## When to Reach for C Extensions / Cython?

Even in pure Python, if there's a genuine bottleneck (image
processing, heavy numerical simulation), **NumPy** (written in C,
offers vectorized operations) or **Cython** (a Python-like language
that compiles to C) come into play — covered in more depth in the
Modules and Usage section.

### 🎯 Mini Exercise
Write `fibonacci` both with `@lru_cache` and with a plain (non-
recursive) `for` loop, then compare their speed with `timeit`.

---
⬅️ [Advanced OOP Concepts](./02-Advanced-OOP-Concepts.md) &nbsp;|&nbsp; ➡️ [Design Patterns](./04-Design-Patterns.md)
