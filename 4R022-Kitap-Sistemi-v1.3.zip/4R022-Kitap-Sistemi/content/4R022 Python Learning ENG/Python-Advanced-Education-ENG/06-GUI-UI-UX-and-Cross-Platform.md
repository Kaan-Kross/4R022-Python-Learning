# 6. GUI, UI/UX, and Cross-Platform Interface Knowledge

## What Are UI and UX, and How Do They Differ?

**UI (User Interface)** is everything the user sees and touches:
buttons, colors, fonts, icons. **UX (User Experience)** is how the
user **feels** while using that interface: how easily they understood
it, how many clicks it took to finish their task, how easily they
recovered from a mistake. A good-looking app (good UI) can still be
hard to use (bad UX) — the two concepts are related but distinct.

### Core UX Principles (Briefly)

- **Consistency:** The same action should always be in the same
  place, done the same way (a "Save" button shouldn't move around).
- **Feedback:** When a user clicks something, they should **see**
  that something happened (a loading spinner, a color change, a message).
- **Error tolerance:** Users should be able to undo mistakes;
  destructive actions (like deleting) should ask for confirmation.
- **Simplicity:** A few clear options beat many scattered ones.

## Getting Screen Size and Resolution (Cross-Platform)

A common need when designing a desktop app: centering/sizing a
window based on the user's screen.

```python
# ✅ This code works — WORKS on Windows, Linux, and macOS (platform-independent)
import tkinter as tk
temp = tk.Tk()
width = temp.winfo_screenwidth()
height = temp.winfo_screenheight()
temp.destroy()
print(f"Screen: {width}x{height}")
```

```python
# ✅ This code works — Windows ONLY (platform-specific, via ctypes)
import ctypes
user32 = ctypes.windll.user32
width = user32.GetSystemMetrics(0)
height = user32.GetSystemMetrics(1)
print(f"Screen: {width}x{height}")
```

```python
# ✅ This code works (if PyQt6 is installed) — inside a PyQt6 app
from PyQt6.QtWidgets import QApplication
import sys
app = QApplication(sys.argv)
screen = app.primaryScreen().geometry()
print(f"Screen: {screen.width()}x{screen.height()}")
```

```python
# ❌ This code does NOT work (only works on Windows, crashes on Linux/macOS)
import ctypes
width = ctypes.windll.user32.GetSystemMetrics(0)   # 'windll' is Windows-only!
```

- **Why is this wrong?** `ctypes.windll` only exists on Windows;
  Linux and macOS have no such module/attribute.
- **Where's the error?** Raises `AttributeError: module 'ctypes' has
  no attribute 'windll'` on Linux/macOS.
- **What should you use instead?** For a cross-platform app, prefer
  a platform-independent method like `tkinter.winfo_screenwidth()`;
  reach for `ctypes.windll` only when writing a Windows-only tool.

### DPI Awareness (High-Resolution Screens)

On high-DPI screens (4K, Retina), the OS may auto-scale the
interface — this can make Python's perceived "screen size" differ
from the actual pixel count.

```python
# ✅ This code works (Windows only) — makes the app DPI-aware,
# reducing blurry or wrongly-sized UI issues
import ctypes
ctypes.windll.user32.SetProcessDPIAware()
```

## File Picker Dialogs ("Where You Add a File")

The standard window that lets a user pick a file/photo opens the
OS's **own** file browser — you don't build this from scratch, GUI
libraries provide it ready-made:

```python
# ✅ This code works — Tkinter file picker
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()   # hide the main window, show only the dialog
file_path = filedialog.askopenfilename(
    title="Select an image",
    filetypes=[("Image files", "*.png *.jpg *.jpeg")]
)
print("Selected file:", file_path)
```

```python
# ✅ This code works — PyQt6 file picker
from PyQt6.QtWidgets import QApplication, QFileDialog
import sys

app = QApplication(sys.argv)
file_path, _ = QFileDialog.getOpenFileName(
    None, "Select an image", "", "Image Files (*.png *.jpg *.jpeg)"
)
print("Selected file:", file_path)
```

```python
# ❌ This code does NOT work — calling the file dialog without
# creating/hiding a root Tkinter window first
from tkinter import filedialog
file_path = filedialog.askopenfilename()   # unexpected behavior on some systems
```

- **Why is this wrong?** `filedialog` needs a Tkinter root window
  (`Tk()`) behind the scenes; calling it without one can cause
  unexpected behavior or errors on some platforms.
- **Where's the error?** No `tk.Tk()` instance was ever created.
- **What should you use instead?** Create a hidden `tk.Tk()` window
  first, as in the working example above, then call `filedialog`.

## Displaying (and "Searching for") an Image

To show an image to the user (e.g. a selection preview), you load it
into a widget:

```python
# ✅ This code works (if Pillow is installed: pip install pillow)
import tkinter as tk
from PIL import Image, ImageTk

root = tk.Tk()
image = Image.open("example.png")
tk_image = ImageTk.PhotoImage(image)
label = tk.Label(root, image=tk_image)
label.pack()
root.mainloop()
```

> 🧑‍🏫 **Note:** "Image search" (querying a search engine for visual
> results) is a separate topic — it typically means sending a
> `requests` call to a search API and displaying the results the same
> way as above; technically it uses the same core tools (filesystem +
> GUI widget), just with a network request instead of a local file
> as the data source.

## General Advice for Cross-Platform Development

- If you need platform-specific code (like `ctypes.windll`), always
  guard it with `sys.platform`:
  ```python
  import sys
  if sys.platform.startswith("win"):
      pass   # Windows-specific code
  else:
      pass   # Linux/macOS alternative
  ```
- Prefer the platform-independent APIs of `tkinter`/`PyQt6` whenever
  possible; drop down to `ctypes`/`pywin32` only for things that are
  genuinely platform-specific (like Windows taskbar effects).
- **Actually test** on different operating systems — a feature
  working on Windows doesn't guarantee it works on Linux/macOS.

### 🎯 Mini Exercise
Write a small Tkinter or PyQt6 app that opens centered on the user's
screen (sized relative to screen dimensions), with a "Select File"
button that displays the chosen image.

---
⬅️ [Desktop App Development](./05-Desktop-App-Development.md) &nbsp;|&nbsp; ➡️ [Move on to Data Concepts](../Python-Data-Concepts-ENG/README.md)

🎉 **Congratulations — you've completed the Advanced Level!**
