# 1. Concurrency: Threading, Multiprocessing, Asyncio

## Why It's Needed

Some work involves **waiting** (network requests, file I/O); other
work is **CPU-heavy** (image processing, math). These two situations
call for different tools.

## `threading` — For I/O-Bound Work

```python
# ✅ This code works
import threading, time

def download(file_no):
    print(f"Downloading file {file_no}...")
    time.sleep(2)
    print(f"File {file_no} done.")

threads = [threading.Thread(target=download, args=(i,)) for i in range(3)]
for t in threads: t.start()
for t in threads: t.join()
print("All downloads finished.")
```

## The GIL (Global Interpreter Lock) — An Important Limitation

```python
# ❌ This is SLOWER THAN EXPECTED — because of the GIL in CPython,
# threading provides no real parallelism for CPU-heavy work (only
# one thread runs Python code at a time):
import threading

def heavy_computation():
    total = 0
    for i in range(50_000_000):
        total += i

threads = [threading.Thread(target=heavy_computation) for _ in range(4)]
for t in threads: t.start()
for t in threads: t.join()
# This is barely faster than doing it with a single thread!
```

For CPU-heavy work, `multiprocessing` is the right tool — each
process has its own Python interpreter (and its own GIL).

```python
# ✅ This code works — real parallelism (multiple CPU cores)
import multiprocessing

def compute(limit):
    return sum(range(limit))

if __name__ == "__main__":
    with multiprocessing.Pool(4) as pool:
        results = pool.map(compute, [10_000_000] * 4)
    print(results)
```

## `asyncio` — For Many I/O-Waiting Tasks

```python
# ✅ This code works — handles hundreds of network requests efficiently
import asyncio

async def fetch(id_no):
    print(f"Request {id_no} started")
    await asyncio.sleep(1)   # simulates a real network request
    print(f"Request {id_no} done")
    return id_no

async def main():
    tasks = [fetch(i) for i in range(5)]
    results = await asyncio.gather(*tasks)
    print(results)

asyncio.run(main())
```

```python
# ❌ This code does NOT work — 'await' used outside an async function
def normal_function():
    await asyncio.sleep(1)   # SyntaxError: 'await' outside async function
```

## Which One, When?

| Scenario | Right Tool |
|---|---|
| File download, API request (waiting, few tasks) | `threading` |
| Hundreds of concurrent network requests | `asyncio` |
| Image processing, heavy math (CPU-bound) | `multiprocessing` |

---
⬅️ [Back](./README.md) &nbsp;|&nbsp; ➡️ [Advanced OOP Concepts](./02-Advanced-OOP-Concepts.md)
