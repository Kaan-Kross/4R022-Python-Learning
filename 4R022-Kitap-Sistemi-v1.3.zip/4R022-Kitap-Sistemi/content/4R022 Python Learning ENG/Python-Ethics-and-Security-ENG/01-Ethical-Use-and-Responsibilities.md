# 1. Ethical Use and Responsibilities

## Code Is Neutral, Intent Isn't

Everything you've learned in this resource — file reading/writing,
network programming (`socket`), browser automation (`selenium`),
encryption (`cryptography`) — is **neither good nor bad on its own.**
The exact same `socket` code could be used in a student's homework or
in a malicious tool. What makes the difference is **who is using it,
with whose permission, and for what purpose.**

## Three Simple Questions

Before running a script, ask yourself:

1. **Do I have permission?** Have I gotten explicit permission from
   the owner or an authorized person to test/use this system/data/account?
2. **Does it cause harm?** Could this code damage someone's data,
   privacy, systems, reputation, or finances?
3. **Am I being transparent?** Could I explain exactly what this code
   does, without hiding anything, to the people involved if asked?

If you can't comfortably answer "yes" to all three, you're probably
close to an ethical and/or legal boundary.

## Real-World Legitimate Use Cases

| Technique | Legitimate Use | Where the Line Is Crossed |
|---|---|---|
| Web scraping (`requests`, `BeautifulSoup`) | Collecting your own site's data, scraping public data respecting `robots.txt` | Ignoring a site's Terms of Service to harvest personal data |
| Automation bots | Automating repetitive tasks on your own account | Violating platform rules (spam, manipulation) with fake accounts |
| Network scanning tools | Testing your own network/company's systems with written permission (pentesting) | Scanning someone else's institution/system without permission |
| Password recovery/testing tools | Recovering your own forgotten password, authorized security testing | Trying to access someone else's account without permission |

## Responsibilities

- **Legal responsibility** is yours — "I didn't know" is generally
  not a valid defense; in most countries, unauthorized system access,
  data theft, and denial-of-service offenses carry serious penalties.
- **Ethical responsibility** covers the gray areas the law doesn't
  fully address (e.g. finding a vulnerability and selling it on the
  dark web is clearly illegal; quietly finding one and sitting on it
  without disclosure is a more debatable ethical question).
- **Community responsibility** — when sharing what you learn here
  (blog, GitHub, video), remember others can misuse it; be mindful of
  the line between "how to defend" and "how to attack."

### 🎯 Thought Exercise
If a friend asked you to "just try" cracking their ex's social media
password, you'd apply the three questions above to their request —
what would the answers be?

---
⬅️ [Back](./README.md) &nbsp;|&nbsp; ➡️ [White/Grey/Black Hat Hackers](./02-White-Grey-Black-Hat-Hackers.md)
