# 2. What Are White / Grey / Black Hat Hackers?

> This chapter is purely **descriptive and informational**; it
> teaches no attack techniques. The goal is for you to correctly
> understand terms you often hear in the media and why they exist.

## The Shared Root: What Does "Hacker" Actually Mean?

Though popular culture often equates "hacker" with "computer
criminal," its original meaning is **someone who deeply understands
a system, pushes its boundaries, and builds creative solutions.** In
1960s MIT culture, "hacker" was a positive label for a curious,
skilled programmer. Over time, media coverage tied the word almost
entirely to "cybercriminal." The security community started using
"hat colors" to make the distinction clearer.

## ⚪ White Hat

**Who are they?** People who test systems for security
vulnerabilities **with the owner's written permission**, in order to
find and fix them.

**What do they do?**
- Penetration testing — companies hire them to launch "authorized
  attacks" on their own systems.
- Bug bounty programs (Google, Microsoft, and many others pay
  rewards for reported vulnerabilities).
- Security consulting, penetration test reports, building defense
  systems (firewalls, IDS/IPS).

**Why do they exist?** The person best able to break into a system
is often also the person best able to defend it. Companies would
rather find a flaw internally or via an authorized expert **before** a
malicious actor finds it.

## ⚫ Black Hat

**Who are they?** People who break into systems without permission,
with malicious intent — stealing data, causing damage, or using
access for financial or political gain.

**What do they do?** (described at an informational level, no
technical detail) Distribute ransomware, steal data, run phishing
campaigns, launch DDoS attacks, sell stolen data on the dark web —
all **illegal** activities.

**Why do they exist?** Motivations are usually financial gain,
political activism ("hacktivism"), espionage (state-sponsored
groups), or simply "the challenge." These activities are **crimes**
in nearly every country, carrying severe prison sentences and
financial penalties.

## ⚪⚫ Grey Hat

**Who are they?** People in between white and black — they typically
find a vulnerability **without permission**, but instead of
exploiting it maliciously, they usually report it to the owner
(sometimes publicly too).

**What do they do?** For example, finding a security flaw in a
company's website without authorization, then emailing the company
"you have a vulnerability, please fix it" — sometimes receiving
thanks/a reward, sometimes facing "unauthorized access" charges
(because they never got permission).

**Why do they stay in this zone?** Their intent usually isn't
malicious (they want to help secure the system), but the **method**
(unauthorized access) is still illegal in most countries. Hence
"grey" — good intent, questionable/illegal method.

## Comparison Table

| | White Hat | Grey Hat | Black Hat |
|---|---|---|---|
| Permission | Yes (written agreement) | No | No |
| Intent | Good (defense) | Usually good | Bad (gain/harm) |
| Legality | Legal | Ambiguous / usually illegal | Illegal |
| Example activity | Bug bounty, pentesting | Finding & reporting flaws without permission | Ransomware, data theft |
| Outcome | Reward, career, reputation | Thanks or a lawsuit, varies | Prison sentence, fines |

## Other Colors (Briefly)

- **Red Hat:** Takes an **aggressive** counter-attack approach
  against black hat attackers (targeting their systems too) — a
  controversial approach.
- **Blue Team:** Works on the **defense** side of an organization,
  doing continuous monitoring and response (close to white hat, but
  more focused on day-to-day operations).
- **Script Kiddie:** A (somewhat dismissive) term for inexperienced
  people who use ready-made tools found online to attempt attacks
  without understanding how they work — respected neither
  ethically nor technically.

## Why Does This Distinction Matter?

The tools you've learned about in Python — `socket`, `requests`,
`selenium`, `cryptography` — can technically be used by white hats
and black hats alike. Rather than steer you away from these tools,
we want you to understand that **which side you're on is determined
entirely by permission and intent** — the code is the same, the
decision is what differs.

---
⬅️ [Ethical Use and Responsibilities](./01-Ethical-Use-and-Responsibilities.md) &nbsp;|&nbsp; ➡️ [Legal Boundaries and Disclaimer](./03-Legal-Boundaries-and-Disclaimer.md)
