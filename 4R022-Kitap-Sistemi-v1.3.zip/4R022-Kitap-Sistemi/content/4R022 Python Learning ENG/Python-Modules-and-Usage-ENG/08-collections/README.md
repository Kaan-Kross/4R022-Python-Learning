# The `collections` Module

## What Is It and How Does It Work?

`collections` provides **specialized, faster, or more readable**
versions of the basic `list`/`dict` structures. `Counter`, for
example, is a `dict` subclass optimized for counting elements;
`deque` is a list variant that can efficiently add/remove from both
ends.

## When / Where Is It Used?

- Counting word frequency in text (`Counter`)
- Building a queue or a "last N items" pattern (`deque`)
- Auto-assigning a default value when a dict key doesn't exist yet
  (`defaultdict`)
- Creating simple, lightweight records with named fields (`namedtuple`)

## ✅ Working Examples

```python
# Example 1: counting elements with Counter
from collections import Counter
words = "apple pear apple banana apple pear".split()
counts = Counter(words)
print(counts)                # Counter({'apple': 3, 'pear': 2, 'banana': 1})
print(counts.most_common(1))  # [('apple', 3)]
```

```python
# Example 2: grouping without KeyError, using defaultdict
from collections import defaultdict
groups = defaultdict(list)
groups["fruit"].append("apple")   # no KeyError even though key didn't exist
groups["fruit"].append("pear")
print(groups)
```

```python
# Example 3: deque for a fast "last N records" pattern
from collections import deque
recent_actions = deque(maxlen=3)   # holds at most 3 elements
for action in ["login", "save", "logout", "login again"]:
    recent_actions.append(action)
print(recent_actions)   # ['logout', 'login again', ...] — oldest dropped
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Appending to a Missing Key in a Plain `dict`

```python
groups = {}
groups["fruit"].append("apple")
```

- **Why is this wrong?** In a normal `dict`, if `"fruit"` doesn't
  exist yet, you can't call `.append()` on it.
- **Where's the error?** Raises `KeyError: 'fruit'` because the key
  was never created.
- **What should you use instead?** `from collections import
  defaultdict` and use `groups = defaultdict(list)` — it
  automatically starts with an empty list for missing keys.

### Wrong Example 2 — Trying to Modify a `namedtuple`'s Fields

```python
from collections import namedtuple
Point = namedtuple("Point", ["x", "y"])
p = Point(1, 2)
p.x = 5
```

- **Why is this wrong?** Like a regular `tuple`, `namedtuple` is
  **immutable** — once created, its fields can't be changed.
- **Where's the error?** The `p.x = 5` assignment raises
  `AttributeError: can't set attribute`.
- **What should you use instead?** If you need a mutable record, use
  a regular `class` or a `dataclass`; if you need to change a
  `namedtuple`, use `p._replace(x=5)` to get a **new** object (the
  original stays unchanged).

### Wrong Example 3 — Assuming `Counter` Is Sorted by Frequency

```python
from collections import Counter
counts = Counter(["b", "a", "c", "a"])
first_key = list(counts.keys())[0]
print("Is this the most frequent key?", first_key)
```

- **Why is this wrong?** `Counter`'s key order reflects **insertion
  order**, not "most frequent first." This runs but produces a
  logically wrong result.
- **Where's the error?** The assumption "first key = most frequent"
  is false.
- **What should you use instead?** Use `counts.most_common(1)`,
  which is specifically designed to find the most frequent item(s).

## 🔗 Related Modules
[itertools and functools](../09-itertools-and-functools/README.md)

---
⬅️ [Modules Home](../README.md)
