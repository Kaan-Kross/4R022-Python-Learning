# The `argparse` Module

## What Is It and How Does It Work?

`argparse` gives command-line scripts a **professional argument
interface.** Instead of manually parsing `sys.argv` (see
[sys](../02-sys/README.md)), `argparse` automatically generates a
`--help` message, handles type conversion, distinguishes required vs
optional arguments, and produces clear error messages.

## When / Where Is It Used?

- Writing command-line tools that take multiple options/parameters
- Supporting "headless" (no-GUI) command-line modes in apps like 4R022's tools

## ✅ Working Examples

```python
# Example 1: basic argument parsing
import argparse

parser = argparse.ArgumentParser(description="4R022 example tool")
parser.add_argument("file", help="Path to the file to process")
parser.add_argument("--verbose", action="store_true", help="Print detailed output")

args = parser.parse_args()
print("File:", args.file)
if args.verbose:
    print("Verbose mode is on")
```

```bash
python tool.py notes.txt --verbose
```

```python
# Example 2: type conversion and default values
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--repeat", type=int, default=1, help="How many times to run")
args = parser.parse_args()
print(args.repeat)   # automatically converted to int
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Running the Script Without a Required Argument

```bash
python tool.py
```
```python
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("file")   # positional, required argument
args = parser.parse_args()
```

- **Why is this wrong?** `file` is defined as a positional argument,
  so it's **required**; if it's not provided, `argparse` produces its
  own error.
- **Where's the error?** The terminal shows `error: the following
  arguments are required: file` and the program exits (this is
  `argparse`'s **expected, helpful** behavior, not a bug).
- **What should you use instead?** Provide the argument: `python
  tool.py notes.txt`; if you genuinely want it optional, add
  `nargs="?"` or a `default=...`.

### Wrong Example 2 — Trying to Give a Value to a `store_true` Flag

```bash
python tool.py --verbose yes
```
```python
parser.add_argument("--verbose", action="store_true")
```

- **Why is this wrong?** An argument defined with
  `action="store_true"` **takes no value** — it only carries a
  True/False (present/absent) meaning; `"yes"` gets treated as a
  separate, unrecognized argument.
- **Where's the error?** Raises `error: unrecognized arguments: yes`.
- **What should you use instead?** Use flag arguments without a
  value: `python tool.py --verbose`; if you want it to take a value,
  define a normal argument instead (`parser.add_argument
  ("--level")`) rather than `action="store_true"`.

## 🔗 Related Modules
[sys](../02-sys/README.md)

---
⬅️ [Modules Home](../README.md)
