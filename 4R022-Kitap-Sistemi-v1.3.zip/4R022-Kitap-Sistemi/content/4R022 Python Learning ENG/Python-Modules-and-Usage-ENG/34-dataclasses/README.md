# The `dataclasses` Module

## What Is It and How Does It Work?

`dataclasses` automatically generates the boilerplate code
(`__init__`, `__repr__`, `__eq__`, etc.) that's repetitive in classes
whose main job is to **hold data.** Adding `@dataclass` to a class
means you don't write these methods by hand — Python generates them
based on the fields defined in the class.

## When / Where Is It Used?

- Writing simple, mostly-data-carrying classes (a coordinate, a user
  record, a settings block)
- Similar to `namedtuple`, but when you need a **mutable** structure

## ✅ Working Examples

```python
# Example 1: a dataclass instead of a classic class
from dataclasses import dataclass

@dataclass
class Point:
    x: int
    y: int

p1 = Point(1, 2)
print(p1)           # Point(x=1, y=2) — automatic __repr__!
p2 = Point(1, 2)
print(p1 == p2)      # True — automatic __eq__!
```

```python
# Example 2: default values and type hints
from dataclasses import dataclass, field

@dataclass
class Student:
    name: str
    grades: list = field(default_factory=list)   # mutable default, done safely

student = Student("Kaan")
student.grades.append(95)
print(student)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Giving a Mutable Default Value Directly

```python
from dataclasses import dataclass

@dataclass
class Student:
    name: str
    grades: list = []   # a bare empty list as the default!
```

- **Why is this wrong?** Python (just like in regular functions)
  doesn't let you give a mutable default value (`list`, `dict`)
  directly — a classic trap where every instance could end up
  sharing the **same** list.
- **Where's the error?** Raises `ValueError: mutable default
  <class 'list'> for field grades is not allowed` — `dataclasses`
  deliberately blocks this.
- **What should you use instead?** Use `field(default_factory=list)`
  — this creates a **fresh** list for every new instance.

### Wrong Example 2 — Assuming Type Hints Are Enforced

```python
from dataclasses import dataclass

@dataclass
class Point:
    x: int
    y: int

p = Point("one", "two")   # given str, not int!
print(p)
```

- **Why is this wrong?** Type hints in `dataclasses` (like `x: int`)
  are **not enforced at runtime** — they're documentation/IDE
  assistance only. Python allows assigning a string like `"one"` to
  `x` without complaint.
- **Where's the error?** There isn't actually an "error" here — the
  mistake is **assuming** that a type hint provides automatic
  validation.
- **What should you use instead?** For real type validation, use a
  library like `pydantic` (see the Pydantic example in
  [Flask and FastAPI](../17-flask-and-fastapi/README.md)) — it
  genuinely validates types at runtime.

## 🔗 Related Modules
[typing](../35-typing/README.md), [collections](../08-collections/README.md) (namedtuple)

---
⬅️ [Modules Home](../README.md)
