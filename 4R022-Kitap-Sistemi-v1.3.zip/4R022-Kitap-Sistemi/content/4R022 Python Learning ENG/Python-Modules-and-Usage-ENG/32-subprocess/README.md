# The `subprocess` Module

## What Is It and How Does It Work?

`subprocess` lets a Python program run **another program/command**
(a terminal command, another script, an external tool). It launches a
new OS process, and you can capture its output and wait for it to finish.

## When / Where Is It Used?

- Triggering external command-line tools like `ffmpeg`, `git` from Python
- Feeding the output of one script into another Python program
- Chaining multiple steps together in build/automation scripts

## ✅ Working Examples

```python
# Example 1: running a simple command and getting output
import subprocess
result = subprocess.run(["python", "--version"], capture_output=True, text=True)
print(result.stdout)
```

```python
# Example 2: running with error checking
import subprocess
try:
    subprocess.run(["git", "status"], check=True)
except subprocess.CalledProcessError as e:
    print("Command failed:", e)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Running User Input Directly With `shell=True`

```python
import subprocess
filename = input("File to delete: ")
subprocess.run(f"del {filename}", shell=True)
```

- **Why is this wrong?** The code runs but this is a **serious
  security vulnerability** — if the user enters something like
  `"temp.txt & format C:"` as `filename`, `shell=True` might
  interpret it as **a separate command too** (command injection).
- **Where's the error?** User input is inserted directly,
  uncontrolled, into a shell command.
- **What should you use instead?** Avoid `shell=True`; give the
  command and its arguments as a separate list:
  `subprocess.run(["del", filename])` — this treats the argument as a
  plain filename, not shell syntax.

### Wrong Example 2 — Using `capture_output` Without Considering Huge Output

```python
import subprocess
result = subprocess.run(["find", "/", "-name", "*.log"], capture_output=True, text=True)
```

- **Why is this wrong?** If the command produces a **massive** amount
  of output (e.g. scanning an entire disk), it all gets loaded into
  memory at once — potentially causing high memory use and slowdowns.
- **Where's the error?** `capture_output=True` was used without
  considering the output size.
- **What should you use instead?** For very large outputs, use
  `subprocess.Popen` and read the output **line by line, as a
  stream**, instead of waiting for it all to load into memory.

## 🔗 Related Modules
[os](../01-os/README.md), [threading](../12-threading/README.md)

---
⬅️ [Modules Home](../README.md)
