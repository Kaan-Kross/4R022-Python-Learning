# The `enum` Module

## What Is It and How Does It Work?

`enum` lets you define a fixed set of values (like "Monday, Tuesday,
Wednesday...") as **readable, error-resistant** named constants
instead of raw strings or numbers. Internally, each member is a
unique name-value pair, and comparisons are identity-based, fast,
and safe.

## When / Where Is It Used?

- Defining a fixed set of states (e.g. `Status.PENDING`,
  `Status.COMPLETE`, `Status.CANCELLED`)
- Avoiding "magic strings" — a typo in an enum name fails loudly,
  unlike a typo'd raw string
- Managing an app's language (`Language.EN`, `Language.TR`) or theme

## ✅ Working Examples

```python
# Example 1: a basic enum definition
from enum import Enum

class Status(Enum):
    PENDING = 1
    PROCESSING = 2
    COMPLETE = 3

order_status = Status.PENDING
print(order_status)          # Status.PENDING
print(order_status.name)     # 'PENDING'
print(order_status.value)    # 1
```

```python
# Example 2: comparing with an enum
from enum import Enum

class Status(Enum):
    PENDING = 1
    COMPLETE = 2

def process(status):
    if status == Status.COMPLETE:
        print("Already completed.")
    else:
        print("Processing...")

process(Status.PENDING)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Comparing an Enum Member to a Plain Number

```python
from enum import Enum

class Status(Enum):
    PENDING = 1
    COMPLETE = 2

if Status.PENDING == 1:
    print("Pending")
```

- **Why is this wrong?** An `Enum` member is **not equal** to a
  plain number (`1`), even if its `.value` matches — `Enum` compares
  by its own type.
- **Where's the error?** `Status.PENDING == 1` evaluates to `False`
  — no error is raised, but the logic silently produces the wrong result.
- **What should you use instead?** Compare `Status.PENDING ==
  Status.PENDING`, or explicitly compare the value:
  `Status.PENDING.value == 1`.

### Wrong Example 2 — Defining Two Members With the Same Value, Expecting Them to Differ

```python
from enum import Enum

class Color(Enum):
    RED = 1
    CRIMSON = 1   # same value!

print(Color.RED is Color.CRIMSON)
```

- **Why is this wrong?** Defining two members with the same value
  makes `enum` treat one as an **alias** — `CRIMSON` is actually
  just another name for `RED`, not a separate member.
- **Where's the error?** `Color.RED is Color.CRIMSON` unexpectedly
  returns `True` (a distinct member was expected).
- **What should you use instead?** Give truly distinct members
  different values (`RED = 1`, `CRIMSON = 2`); if you want to
  prevent accidental aliasing, use the `@enum.unique` decorator —
  it raises an error if a value repeats.

## 🔗 Related Modules
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Modules Home](../README.md)
