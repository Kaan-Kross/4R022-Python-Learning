# The `qrcode` Module

## What Is It and How Does It Work?

`qrcode` converts a given piece of text (URL, credential, payment
link) into a **QR code image** (`pip install qrcode[pil]`). Under the
hood, it encodes the text using the QR standard's error-correction
algorithms (Reed-Solomon) and renders it as a black-and-white pixel
grid (an image).

## When / Where Is It Used?

- Sharing a Wi-Fi password or link easily
- Sharing links/data on event tickets, menus
- Two-factor authentication (2FA) setup screens

## ✅ Working Examples

```python
# Example 1: generating a simple QR code
import qrcode
img = qrcode.make("https://github.com/4R022")
img.save("qr.png")
```

```python
# Example 2: a customized QR code (color, size)
import qrcode
qr = qrcode.QRCode(box_size=10, border=4)
qr.add_data("4R022 Python Learning")
qr.make(fit=True)
img = qr.make_image(fill_color="black", back_color="white")
img.save("custom_qr.png")
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Installing `qrcode` Without the `[pil]` Extra

```bash
pip install qrcode
```
```python
import qrcode
img = qrcode.make("test")
img.save("qr.png")
```

- **Why is this wrong?** Image generation depends on Pillow (PIL);
  without the `[pil]` extra, image creation can fail.
- **Where's the error?** Raises an `ImportError` or similar,
  indicating the Pillow dependency is missing.
- **What should you use instead?** Install with `pip install
  "qrcode[pil]"` to bring in Pillow too.

### Wrong Example 2 — Trying to Fit Overly Long Text Into a Small QR Code

```python
import qrcode
very_long_text = "A" * 5000
img = qrcode.make(very_long_text)   # with default version/size
```

- **Why is this wrong?** The QR standard has a **capacity limit**;
  even though the error-correction version auto-grows, extremely
  long data can exceed what fits.
- **Where's the error?** Can raise
  `qrcode.exceptions.DataOverflowError`.
- **What should you use instead?** For long data, manually increase
  the `version` parameter (`qrcode.QRCode(version=None)` lets it
  auto-select the best size), or shorten the data to just share a URL.

## 🔗 Related Modules
[hashlib](../30-hashlib/README.md)

---
⬅️ [Modules Home](../README.md)
