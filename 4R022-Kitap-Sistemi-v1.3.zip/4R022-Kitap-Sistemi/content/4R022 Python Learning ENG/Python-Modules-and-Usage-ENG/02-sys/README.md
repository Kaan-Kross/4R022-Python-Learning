# The `sys` Module

## What Is It and How Does It Work?

The `sys` module lets you interact directly with the **Python
interpreter itself**: command-line arguments, interpreter version,
the program's exit code, module search paths. Where `os` deals with
the operating system, `sys` deals with **Python's own runtime
environment** — that's the key difference.

## When / Where Is It Used?

- Passing parameters to scripts run from the command line
- Ending a program with a specific exit code (`sys.exit()`)
- Finding the resource path in PyInstaller-packaged apps
  (`sys._MEIPASS`) — a standard technique in 4R022 projects
- Checking the Python version

## ✅ Working Examples

```python
# Example 1: reading command-line arguments
import sys
print(sys.argv)   # e.g. ['script.py', 'arg1', 'arg2']
if len(sys.argv) > 1:
    print("First argument:", sys.argv[1])
```

```python
# Example 2: exiting with a specific error code
import sys
def process_file(path):
    if not path:
        print("Error: empty file path!", file=sys.stderr)
        sys.exit(1)   # non-zero codes mean "ended with an error"
    print("Processing:", path)
```

```python
# Example 3: PyInstaller-compatible resource path (4R022 standard)
import sys, os
def resource_path(relative_path):
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, relative_path)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Mistaking `sys.argv[0]` for the First User Argument

```python
import sys
username = sys.argv[0]
print("Hello", username)
```

- **Why is this wrong?** `sys.argv[0]` is always the **script's own
  filename**, not the first argument the user provided.
- **Where's the error?** Index `0` should have been `1`.
- **What should you use instead?** `sys.argv[1]` — and always add a
  length check: `if len(sys.argv) > 1: username = sys.argv[1]`

### Wrong Example 2 — Accidentally Catching `sys.exit()` With `try/except`

```python
import sys
try:
    sys.exit(1)
except Exception:
    print("Caught an error, continuing anyway")
```

- **Why is this wrong?** `sys.exit()` actually raises a special
  exception called `SystemExit`; a broad `except Exception` block can
  catch it too and **prevent the program from actually closing** —
  the opposite of what was intended.
- **Where's the error?** The `except Exception` clause is too broad.
- **What should you use instead?** If you're not deliberately
  handling `SystemExit`, catch more specific exception types (e.g.
  `except ValueError`) so `sys.exit()` still terminates the program
  as expected.

### Wrong Example 3 — Blindly Overwriting `sys.path`

```python
import sys
sys.path = ["/wrong/folder"]
import json
```

- **Why is this wrong?** `sys.path` tells Python **where to look**
  for modules; replacing the whole list can make even the standard
  library unfindable.
- **Where's the error?** `sys.path =` overwrites the **entire list**.
- **What should you use instead?** Append instead: `sys.path.append
  ("/extra/folder")`

## 🔗 Related Modules
[os](../01-os/README.md), [logging](../11-logging/README.md)

---
⬅️ [Modules Home](../README.md)
