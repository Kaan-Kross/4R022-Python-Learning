# The `asyncio` Module

## What Is It and How Does It Work?

`asyncio` lets you efficiently manage many waiting-heavy tasks
(network requests, file I/O) **within a single thread**. The logic:
when a task hits `await` and starts "waiting," `asyncio` suspends
that task and runs another one on the **same thread** — achieving
concurrency without spawning threads or processes.

## When / Where Is It Used?

- Tools making hundreds/thousands of concurrent network requests
  (web scrapers, API clients)
- Behind the scenes of modern web servers (FastAPI, aiohttp)
- Apps like Discord bots that constantly wait on many events at once

## ✅ Working Examples

```python
# Example 1: a basic async function
import asyncio

async def greet(name):
    await asyncio.sleep(1)
    print(f"Hello, {name}!")

asyncio.run(greet("Kaan"))
```

```python
# Example 2: running multiple tasks concurrently
import asyncio

async def download(file_no):
    print(f"Downloading {file_no}...")
    await asyncio.sleep(2)
    return f"{file_no} done"

async def main():
    results = await asyncio.gather(download(1), download(2), download(3))
    print(results)   # all finish in ~2 seconds, not 6!

asyncio.run(main())
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Calling an Async Function Without `await`

```python
import asyncio

async def greet():
    print("Hello!")

greet()   # no 'await' or asyncio.run()
```

- **Why is this wrong?** Calling an `async def` function directly
  does **not run** it — it just creates a "coroutine object."
- **Where's the error?** Python doesn't error out loudly, but gives
  `RuntimeWarning: coroutine 'greet' was never awaited` — and the
  code inside the function **never runs.**
- **What should you use instead?** Either run it with
  `asyncio.run(greet())`, or, if inside another async function, use
  `await greet()`.

### Wrong Example 2 — Using Blocking (Synchronous) Code Inside an Async Function

```python
import asyncio, time

async def slow_task():
    time.sleep(3)   # this FREEZES the entire event loop!
    print("Done")

async def main():
    await asyncio.gather(slow_task(), slow_task())

asyncio.run(main())
```

- **Why is this wrong?** `time.sleep()` is synchronous (blocking) —
  it stops the event loop **itself**, not just that one task. This
  defeats the entire purpose of `asyncio` (concurrent waiting).
- **Where's the error?** `time.sleep(3)` was used instead of `await
  asyncio.sleep(3)`.
- **What should you use instead?** Always use async-compatible
  functions in async code: `await asyncio.sleep(3)`. For real I/O
  operations (file, network), prefer async-compatible libraries like
  `aiofiles`, `aiohttp`.

### Wrong Example 3 — Calling `asyncio.run()` From Inside a Running Event Loop

```python
import asyncio

async def main_task():
    await asyncio.sleep(1)

async def other_task():
    asyncio.run(main_task())   # already inside an event loop!

asyncio.run(other_task())
```

- **Why is this wrong?** `asyncio.run()` is designed to start a
  **new** event loop; it can't be called again from inside one
  that's already running.
- **Where's the error?** Raises `RuntimeError: asyncio.run() cannot
  be called from a running event loop`.
- **What should you use instead?** If you're already inside an
  async function, call another async function with `await
  main_task()`, not `asyncio.run()`.

## 🔗 Related Modules
[threading](../12-threading/README.md), [requests](../16-requests/README.md) (synchronous alternative)

---
⬅️ [Modules Home](../README.md)
