# Python Modules and Usage (EN)

A reference library answering "which module do I use for this
task?" — with **one folder per module.** Each module folder covers:

- 📖 What the module is and its **working principle**
- 🎯 What it's for, when and where it's used
- ✅ Multiple working code examples
- ❌ Multiple **broken/incorrect** examples — each with: **"why is
  this wrong? where's the error? what should you use instead?"**
- 🔗 Links to related/complementary modules

## 🟢 Standard Library (No Installation Needed)

| Module | What It's For |
|---|---|
| [os](./01-os/README.md) | OS interaction, file/folder operations |
| [sys](./02-sys/README.md) | Interpreter interaction, command-line arguments |
| [json](./03-json/README.md) | Reading/writing JSON data |
| [csv](./04-csv/README.md) | Reading/writing CSV (tabular) data |
| [datetime](./05-datetime/README.md) | Date and time handling |
| [math and random](./06-math-and-random/README.md) | Math operations, random number generation |
| [re (Regular Expressions)](./07-re-regular-expressions/README.md) | Pattern search/replace in text |
| [collections](./08-collections/README.md) | Advanced data structures (Counter, defaultdict, deque) |
| [itertools and functools](./09-itertools-and-functools/README.md) | Loop and function utilities |
| [pathlib](./10-pathlib/README.md) | Modern, object-based file path handling |
| [logging](./11-logging/README.md) | Professional logging |
| [threading](./12-threading/README.md) | Multithreading (I/O-bound work) |
| [multiprocessing](./13-multiprocessing/README.md) | Multiprocessing (CPU-bound work) |
| [asyncio](./14-asyncio/README.md) | Asynchronous programming |
| [sqlite3](./15-sqlite3/README.md) | Built-in lightweight database |
| [queue](./27-queue/README.md) | Thread-safe data queue |
| [tempfile](./28-tempfile/README.md) | Temporary file/folder management |
| [hashlib](./30-hashlib/README.md) | Hash functions |
| [shutil](./31-shutil/README.md) | High-level file/folder operations, archiving |
| [subprocess](./32-subprocess/README.md) | Running external commands/programs |
| [enum](./33-enum/README.md) | Readable named constants (enumeration) |
| [dataclasses](./34-dataclasses/README.md) | Writing data classes with less code |
| [typing](./35-typing/README.md) | Type hints |
| [argparse](./36-argparse/README.md) | Professional command-line interfaces |
| [unittest and pytest](./26-unittest-and-pytest/README.md) | Automated testing |

## 🔵 Popular Third-Party Libraries (`pip install` required)

| Module | What It's For |
|---|---|
| [requests](./16-requests/README.md) | HTTP requests, talking to external APIs |
| [Flask and FastAPI](./17-flask-and-fastapi/README.md) | Web server / API development |
| [numpy](./18-numpy/README.md) | Fast numerical array operations |
| [pandas](./19-pandas/README.md) | Tabular data analysis |
| [matplotlib](./20-matplotlib/README.md) | Charts and data visualization |
| [tkinter](./21-tkinter/README.md) | Standard desktop GUI library |
| [PyQt6](./22-PyQt6/README.md) | Professional desktop GUI library |
| [selenium](./23-selenium/README.md) | Browser automation |
| [socket](./24-socket/README.md) | Low-level network programming |
| [cryptography](./25-cryptography/README.md) | Encryption and data security |
| [qrcode](./29-qrcode/README.md) | QR code generation |

> 🧑‍🏫 **Why list both popular and lesser-known modules?** Our goal
> isn't just to cover "trendy" ones, but everything a real developer
> should have in their toolbox. Some modules (like `pathlib`,
> `dataclasses`) aren't known to beginners but save real time in
> everyday code.

Don't forget [Ethics and Security](../Python-Ethics-and-Security-ENG/README.md) for the legal and ethical boundaries.

⬅️ [Data Concepts](../Python-Data-Concepts-ENG/README.md) &nbsp;|&nbsp; ➡️ [Ethics and Security](../Python-Ethics-and-Security-ENG/README.md)
