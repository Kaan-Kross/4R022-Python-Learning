# The `numpy` Module

## What Is It and How Does It Work?

`numpy` (Numerical Python) is a library, written in C, for very fast
work with numeric arrays (`pip install numpy`). Unlike plain Python
lists, a numpy array is stored **contiguously, with a fixed type** in
memory — so math operations run as **vectorized** C-level operations
across the whole array at once, instead of one-by-one in a Python
loop. This makes it tens to hundreds of times faster than plain
Python for numeric work.

## When / Where Is It Used?

- Mathematical operations on large datasets
- Image processing (an image is, fundamentally, a numeric array)
- The foundation of scientific computing and ML (pandas, scikit-
  learn, TensorFlow are all built on top of numpy)

## ✅ Working Examples

```python
# Example 1: array creation and vectorized operations
import numpy as np
arr = np.array([1, 2, 3, 4, 5])
print(arr * 2)        # [2 4 6 8 10] — applied to every element
print(arr.mean())     # 3.0
```

```python
# Example 2: multi-dimensional array (matrix) operations
import numpy as np
matrix = np.array([[1, 2], [3, 4]])
print(matrix.T)             # transpose
print(matrix @ matrix)      # matrix multiplication
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Expecting a Plain Python List to Behave "Like numpy"

```python
lst = [1, 2, 3, 4, 5]
print(lst * 2)
```

- **Why is this wrong?** The code runs but doesn't give the expected
  result — `*` on a plain Python list doesn't multiply elements, it
  **repeats the list**: `[1,2,3,4,5,1,2,3,4,5]`.
- **Where's the error?** A numpy array was confused with a plain
  Python list; they behave differently under `*`.
- **What should you use instead?** For element-wise multiplication,
  use `np.array(lst) * 2`.

### Wrong Example 2 — Trying to Combine Arrays of Mismatched Shapes

```python
import numpy as np
a = np.array([1, 2, 3])
b = np.array([1, 2])
print(a + b)
```

- **Why is this wrong?** `numpy` adds elements position by position;
  a 3-element array and a 2-element array can't be matched up this
  way (broadcasting rules don't permit it here).
- **Where's the error?** Raises `ValueError: operands could not be
  broadcast together with shapes (3,) (2,)`.
- **What should you use instead?** Make sure array shapes are
  compatible (equal, or compatible under broadcasting rules); pad `b`
  to length 3 or otherwise fix the shape mismatch.

### Wrong Example 3 — Choosing an Insufficient Data Type for Large Values

```python
import numpy as np
arr = np.array([200, 100, 50], dtype=np.int8)
print(arr + 100)   # possible overflow!
```

- **Why is this wrong?** `int8` only holds values from -128 to 127;
  `200 + 100 = 300` overflows this range and **silently wraps around
  to a wrong value** (no error!) — one of the most dangerous kinds of
  bugs.
- **Where's the error?** The `dtype` chosen doesn't fit the actual
  value range.
- **What should you use instead?** Choose a type that fits the range
  (`dtype=np.int32` or `np.int64`), especially if additions/
  multiplications could produce large values.

## 🔗 Related Modules
[pandas](../19-pandas/README.md), [matplotlib](../20-matplotlib/README.md)

---
⬅️ [Modules Home](../README.md)
