# The `queue` Module

## What Is It and How Does It Work?

`queue` provides a FIFO (First In, First Out) structure designed for
**safely passing data between threads.** Using a plain `list` to
share data between threads is prone to race conditions;
`queue.Queue` handles internal locking automatically to make this safe.

## When / Where Is It Used?

- Building a "producer-consumer" pattern (one thread produces data,
  another processes it)
- Safely passing a background task's result back to the main (e.g.
  GUI) thread

## ✅ Working Examples

```python
# Example 1: basic queue usage
import queue
q = queue.Queue()
q.put("task-1")
q.put("task-2")
print(q.get())   # "task-1" (first in, first out)
print(q.get())   # "task-2"
```

```python
# Example 2: safe data transfer between threads
import threading, queue

def produce(q):
    q.put("Result ready!")

q = queue.Queue()
t = threading.Thread(target=produce, args=(q,))
t.start()
t.join()
print(q.get())
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Getting From an Empty Queue Without Waiting

```python
import queue
q = queue.Queue()
result = q.get_nowait()
```

- **Why is this wrong?** When the queue is empty, `get_nowait()`
  raises immediately instead of waiting.
- **Where's the error?** Raises `queue.Empty` because there's
  nothing in the queue.
- **What should you use instead?** If waiting is fine, use `q.get()`
  (it waits until an item arrives); if you don't want to wait, catch
  it with `try/except queue.Empty`.

### Wrong Example 2 — Using a Plain `list` as an Inter-Thread Queue

```python
import threading
data = []

def produce():
    data.append("data")

def consume():
    if data:
        print(data.pop(0))

threading.Thread(target=produce).start()
threading.Thread(target=consume).start()
```

- **Why is this wrong?** `list.append()`/`list.pop()` aren't atomic;
  two threads accessing the list at the same time risk data
  loss/crashes (see [threading](../12-threading/README.md)).
- **Where's the error?** A non-thread-safe `list` was chosen as
  shared data.
- **What should you use instead?** Use `queue.Queue()` — it's
  guaranteed thread-safe.

## 🔗 Related Modules
[threading](../12-threading/README.md)

---
⬅️ [Modules Home](../README.md)
