# `unittest` and `pytest`

## What Are They and How Do They Work?

`unittest` is Python's built-in testing framework; you write test
functions inside `TestCase` classes using assertion methods like
`self.assertEqual(...)`. `pytest` is a third-party alternative
(`pip install pytest`), far more popular, requiring much less
boilerplate and letting you use plain Python `assert` statements.

## When / Where Are They Used?

- Automatically verifying a function/class behaves as expected
- Quickly checking "did I break anything?" after a code change
  (regression testing)
- Running automated tests in CI/CD pipelines (like GitHub Actions)

## ✅ Working Examples

```python
# Example 1: testing with unittest
import unittest

def add(a, b):
    return a + b

class TestAdd(unittest.TestCase):
    def test_positive_numbers(self):
        self.assertEqual(add(2, 3), 5)

if __name__ == "__main__":
    unittest.main()
```

```python
# Example 2: testing with pytest (less code)
def multiply(a, b):
    return a * b

def test_multiply():
    assert multiply(3, 4) == 12
# Run with: pytest test_file.py -v
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Wrong File/Function Naming (pytest)

```python
# file: checks.py (missing pytest's required "test_" prefix!)
def check_multiplication():   # function name also doesn't start with "test_"
    assert 2 * 2 == 4
```

- **Why is this wrong?** `pytest` **auto-discovers** tests based on
  filenames starting with `test_` (or ending in `_test`) and
  functions starting with `test_`.
- **Where's the error?** Neither the filename nor the function name
  follows this rule; `pytest` scans this file and silently reports
  "0 tests collected" — not an error message, but an unexpected result.
- **What should you use instead?** Rename the file to
  `test_checks.py` and the function to `test_multiplication()`.

### Wrong Example 2 — A Wrong `assert` Comparison (Failing Test)

```python
def square(n):
    return n * n

def test_square():
    assert square(4) == 15   # 4*4 = 16, not 15!
```

- **Why is this wrong?** `4 * 4` is mathematically `16`, not `15` —
  this isn't a code bug, it's a **wrong expectation in the test itself.**
- **Where's the error?** The expected value in the `assert` statement
  is wrong; the test is reported as "failed" (`AssertionError`).
- **What should you use instead?** Fix the expected value: `assert
  square(4) == 16`. (This example also illustrates: a failing test
  doesn't always mean the code is wrong — sometimes the test itself
  is written incorrectly!)

### Wrong Example 3 — Not Resetting Shared State Between Tests

```python
cart = []

def add_to_cart(item):
    cart.append(item)

def test_add_one_item():
    add_to_cart("apple")
    assert len(cart) == 1   # correct on its own

def test_add_another_item():
    add_to_cart("pear")
    assert len(cart) == 1   # WRONG! the cart now has 2 items
```

- **Why is this wrong?** The `cart` list is **shared global state**
  between tests; the first test changes it, and the second doesn't
  account for that. Tests should be **independent** of each other.
- **Where's the error?** In the second test, `len(cart)` is actually
  `2` because "apple" from the first test is still there.
- **What should you use instead?** Use a "fixture" that resets state
  before every test (`@pytest.fixture` in pytest), or create a fresh
  `cart = []` in every test.

## 🔗 Related Modules
[logging](../11-logging/README.md)

---
⬅️ [Modules Home](../README.md)
