# The `PyQt6` Module

## What Is It and How Does It Work?

`PyQt6` is the Python binding for **Qt6**, a powerful, professional
C++ GUI library (`pip install PyQt6`). Like tkinter, it's built on an
event loop (`app.exec()`), but its defining feature is the
**signal/slot** architecture: when something happens on a widget (a
signal), a connected function (a slot) is triggered automatically.

## When / Where Is It Used?

- Professional-looking, scalable desktop applications (most 4R022
  desktop products are written in PyQt6)
- Complex interfaces (multiple windows, custom widgets, theming)
- Large projects using the `core/` + `ui/` architecture

## ✅ Working Examples

```python
# Example 1: a minimal window
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("4R022 Example")
label = QLabel("Hello!", window)
window.show()
sys.exit(app.exec())
```

```python
# Example 2: connecting a button with signal/slot
from PyQt6.QtWidgets import QPushButton
button = QPushButton("Click")
button.clicked.connect(lambda: print("Clicked!"))
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Creating a Widget Before `QApplication`

```python
from PyQt6.QtWidgets import QWidget, QApplication
import sys

window = QWidget()   # QApplication doesn't exist yet!
app = QApplication(sys.argv)
window.show()
```

- **Why is this wrong?** Every PyQt6 app must create `QApplication`
  **first**; widgets rely on the app's core infrastructure.
- **Where's the error?** `QWidget()` was called **before**
  `QApplication(sys.argv)`.
- **What should you use instead?** Fix the order: create `app =
  QApplication(sys.argv)` first, then create widgets.

### Wrong Example 2 — Trying to Connect a Signal With Parentheses

```python
from PyQt6.QtWidgets import QPushButton
def on_click():
    print("Clicked")

button = QPushButton("Click")
button.clicked.connect(on_click())   # has parentheses!
```

- **Why is this wrong?** `on_click()` calls the function
  **immediately** and passes its return value (`None`) to
  `.connect()` — no function actually gets bound to the click event.
- **Where's the error?** May raise a `TypeError` (or similar) because
  `None` isn't a valid callable for `.connect()`.
- **What should you use instead?** `button.clicked.connect(on_click)`
  — no parentheses, pass the function reference.

### Wrong Example 3 — Updating a Widget From a Non-Main Thread

```python
import threading
def background_work():
    label.setText("Done!")   # updating a widget from another thread

threading.Thread(target=background_work).start()
```

- **Why is this wrong?** Just like tkinter, Qt widgets can only be
  safely updated from the **main (GUI) thread.**
- **Where's the error?** `label.setText(...)` is called from a
  background thread — can cause crashes or undefined behavior.
- **What should you use instead?** Use PyQt6's own `QThread` class
  and its **signal** mechanism: emit a signal when the background
  work finishes, and let a slot on the main thread update the UI.

## 🔗 Related Modules
[tkinter](../21-tkinter/README.md), [threading](../12-threading/README.md)

---
⬅️ [Modules Home](../README.md)
