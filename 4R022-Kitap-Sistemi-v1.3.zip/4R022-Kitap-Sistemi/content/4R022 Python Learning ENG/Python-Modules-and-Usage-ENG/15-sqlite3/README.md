# The `sqlite3` Module

## What Is It and How Does It Work?

`sqlite3` is a lightweight relational database engine that ships
with Python and runs entirely from **a single file** — no server
needed. The whole database is one `.db` file, and you interact with
it using SQL (Structured Query Language) commands to add, query, and
update data.

## When / Where Is It Used?

- Local data storage in desktop applications (exactly what powers
  SQLite usage in 4R022's Archive and Wallet projects)
- Single-user applications that don't need a large-scale server
  database (PostgreSQL, MySQL)
- Prototyping and learning database concepts

## ✅ Working Examples

```python
# Example 1: creating a database and opening a table
import sqlite3

conn = sqlite3.connect("app.db")
cursor = conn.cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        grade INTEGER
    )
""")
conn.commit()
```

```python
# Example 2: inserting data (parameterized — the safe way)
cursor.execute("INSERT INTO students (name, grade) VALUES (?, ?)", ("Kaan", 95))
conn.commit()
```

```python
# Example 3: querying data
cursor.execute("SELECT name, grade FROM students WHERE grade > ?", (80,))
for row in cursor.fetchall():
    print(row)
conn.close()
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — SQL Injection via String Concatenation

```python
name = "Kaan"
cursor.execute(f"SELECT * FROM students WHERE name = '{name}'")
```

- **Why is this wrong?** The code runs but is a **serious security
  vulnerability** — if `name` comes from user input, someone could
  enter something like `"x'; DROP TABLE students; --"` and delete the
  entire table (a SQL Injection attack).
- **Where's the error?** The SQL query is built by **directly
  concatenating** user input into the string.
- **What should you use instead?** Always use parameterized queries:
  `cursor.execute("SELECT * FROM students WHERE name = ?", (name,))`
  — `sqlite3` handles this value safely.

### Wrong Example 2 — Forgetting to Call `commit()`

```python
cursor.execute("INSERT INTO students (name, grade) VALUES (?, ?)", ("Ayse", 88))
conn.close()   # commit() was forgotten!
```

- **Why is this wrong?** SQLite keeps changes inside a **transaction**
  by default; if the connection is closed without `commit()`, the
  change is **never permanently saved to disk.**
- **Where's the error?** The `conn.commit()` line was never called.
- **What should you use instead?** Call `conn.commit()` after every
  write operation (`INSERT`, `UPDATE`, `DELETE`), or use a `with
  conn:` block for automatic commit/rollback.

### Wrong Example 3 — Using the Same Connection Across Threads Unsafely

```python
import sqlite3, threading

conn = sqlite3.connect("app.db")

def add_data(name):
    conn.execute("INSERT INTO students (name) VALUES (?)", (name,))
    conn.commit()

threading.Thread(target=add_data, args=("Mehmet",)).start()
```

- **Why is this wrong?** By default, a `sqlite3` connection can only
  be safely used **from the thread that created it.**
- **Where's the error?** May raise `ProgrammingError: SQLite objects
  created in a thread can only be used in that same thread`.
- **What should you use instead?** Either open a separate connection
  per thread, or use `sqlite3.connect("app.db",
  check_same_thread=False)` and synchronize access yourself with a
  `threading.Lock`.

## 🔗 Related Modules
[threading](../12-threading/README.md)

---
⬅️ [Modules Home](../README.md)
