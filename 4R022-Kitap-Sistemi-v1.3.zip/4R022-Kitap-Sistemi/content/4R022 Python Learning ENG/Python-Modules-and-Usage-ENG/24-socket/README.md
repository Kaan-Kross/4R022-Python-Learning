# The `socket` Module

> ⚠️ This is the foundation of network programming; see
> [Ethics and Security](../../Python-Ethics-and-Security-ENG/README.md)
> for the line between legitimate use (your own server, learning on
> your local network) and unauthorized use.

## What Is It and How Does It Work?

`socket` gives direct access to the operating system's networking
layer — the lowest-level networking module in the standard library.
Libraries like `requests` actually use `socket` under the hood;
with this module, you drop **below** a ready-made protocol like HTTP
and work with raw TCP/UDP connections directly.

## When / Where Is It Used?

- Writing your own simple client-server application
- Learning the fundamentals of network programming (understanding
  what happens beneath protocols like HTTP, FTP)
- Direct data exchange between two programs on a local network (LAN)

## ✅ Working Examples

```python
# Example 1: a simple TCP server (localhost)
import socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("localhost", 5000))
server.listen(1)
conn, addr = server.accept()
conn.send(b"Hello, client!")
conn.close()
```

```python
# Example 2: a simple TCP client
import socket
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("localhost", 5000))
message = client.recv(1024)
print(message.decode())
client.close()
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Using a Low Port That Needs Admin Privileges

```python
import socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("localhost", 80))
```

- **Why is this wrong?** Ports below 1024 (like 80, 443) require
  **administrator/root privileges** on most operating systems.
- **Where's the error?** Can raise `PermissionError: [Errno 13]
  Permission denied` (especially on Linux/macOS with a normal user).
- **What should you use instead?** Use a port above 1024 for
  development/testing (e.g. `8080`, `5000`).

### Wrong Example 2 — Mixing Up Bytes and Strings

```python
import socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
conn, addr = server.accept()
conn.send("Hello")   # str, not bytes!
```

- **Why is this wrong?** `socket.send()` only accepts **bytes**;
  trying to send a plain `str` fails.
- **Where's the error?** Raises `TypeError: a bytes-like object is
  required, not 'str'`.
- **What should you use instead?** Encode the string to bytes first:
  `conn.send("Hello".encode())` or use `b"Hello"` directly.

### Wrong Example 3 — Trying to Restart a Server Without Closing the Port

```python
import socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("localhost", 5000))
# ... program crashes somehow, socket never gets closed ...
# script is run again:
server2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server2.bind(("localhost", 5000))   # same port is still busy!
```

- **Why is this wrong?** A socket left over from a previous run is
  kept in a "TIME_WAIT" state by the OS for a while; reusing that
  same port immediately can conflict.
- **Where's the error?** Raises `OSError: [Errno 98] Address already
  in use`.
- **What should you use instead?** Add `server.setsockopt
  (socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)` so the port can be
  reused immediately; also always call `server.close()` in a
  `finally` block.

## 🔗 Related Modules
[threading](../12-threading/README.md), [cryptography](../25-cryptography/README.md)

---
⬅️ [Modules Home](../README.md)
