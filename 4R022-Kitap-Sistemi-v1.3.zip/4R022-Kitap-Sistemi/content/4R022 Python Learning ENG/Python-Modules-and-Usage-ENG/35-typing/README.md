# The `typing` Module

## What Is It and How Does It Work?

`typing` lets you add **type hints** to Python — specifying what
type a variable/parameter/return value is **expected** to be. An
important caveat: Python doesn't enforce these hints at runtime
(it stays a dynamically typed language) — they mainly serve as a
"contract" for editors (like VS Code) and static analysis tools
(`mypy`).

## When / Where Is It Used?

- Improving code readability in large, multi-developer projects
- Getting better autocomplete and error detection in your editor
- Enabling automatic data validation in frameworks like FastAPI (see
  [Flask and FastAPI](../17-flask-and-fastapi/README.md))

## ✅ Working Examples

```python
# Example 1: basic type hints
def greet(name: str) -> str:
    return f"Hello, {name}!"

age: int = 25
```

```python
# Example 2: more complex types
from typing import List, Dict, Optional

def student_summary(names: List[str]) -> Dict[str, int]:
    return {name: len(name) for name in names}

def find_user(id_no: int) -> Optional[str]:
    database = {1: "Kaan"}
    return database.get(id_no)   # can return None, hence Optional
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Assuming a Type Hint Is Checked at Runtime

```python
def add(a: int, b: int) -> int:
    return a + b

result = add("5", "3")   # strings passed, error expected but...
print(result)
```

- **Why is this wrong?** The code **runs** — `"5" + "3"` is valid
  string concatenation in Python (giving `"53"`); the `int` type hint
  does **not prevent** this.
- **Where's the error?** There's no actual error; the mistake is
  believing type hints provide automatic validation. The result is
  `"53"`, not `8` — a silent logic bug.
- **What should you use instead?** For real runtime validation, add
  a static analysis tool like `mypy` to your CI/CD pipeline, or
  manually check with `isinstance()` inside the function.

### Wrong Example 2 — Using New Generic Syntax on Older Python Versions

```python
def first_item(items: list[int]) -> int:   # does NOT work before Python 3.9
    return items[0]
```

- **Why is this wrong?** The "built-in generics" syntax like
  `list[int]` was added in Python 3.9; older versions don't support it.
- **Where's the error?** On Python 3.8 and earlier, raises
  `TypeError: 'type' object is not subscriptable`.
- **What should you use instead?** On older versions, use `from
  typing import List` and write `List[int]`; if you're targeting
  3.9+, `list[int]` directly is fine.

## 🔗 Related Modules
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Modules Home](../README.md)
