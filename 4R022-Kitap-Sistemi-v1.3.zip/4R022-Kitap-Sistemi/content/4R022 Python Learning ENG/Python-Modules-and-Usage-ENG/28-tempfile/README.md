# The `tempfile` Module

## What Is It and How Does It Work?

`tempfile` automatically creates **uniquely named temporary
files/folders** in the OS's temp directory (`%TEMP%` on Windows,
`/tmp` on Linux), and generally cleans them up automatically once
the program is done.

## When / Where Is It Used?

- Keeping a temporary copy of a file during intermediate processing steps
- Creating temporary test data without touching the real filesystem
- Temporarily writing large downloads to disk before processing and
  deleting them

## ✅ Working Examples

```python
# Example 1: creating a temporary file (auto-deleted)
import tempfile
with tempfile.NamedTemporaryFile(mode="w", delete=True, suffix=".txt") as f:
    f.write("temporary data")
    print(f.name)   # the temp file's path
# the file is automatically deleted once the 'with' block ends
```

```python
# Example 2: creating a temporary folder
import tempfile, os
with tempfile.TemporaryDirectory() as tmp_dir:
    path = os.path.join(tmp_dir, "data.txt")
    with open(path, "w") as f:
        f.write("test")
# the entire folder is deleted once the block ends
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Trying to Reopen a `delete=True` File After Closing It

```python
import tempfile
f = tempfile.NamedTemporaryFile(mode="w", delete=True)
f.write("data")
f.close()
with open(f.name) as again:   # the file may already be deleted!
    print(again.read())
```

- **Why is this wrong?** `delete=True` (the default) deletes the
  file **as soon as it's closed**; trying to access that path
  afterward fails.
- **Where's the error?** Raises `FileNotFoundError` because the file
  was deleted the moment `close()` ran.
- **What should you use instead?** If you need the file after
  closing it, use `delete=False` and manually `os.remove(f.name)`
  when you're truly done.

### Wrong Example 2 — Trying to Open the Same File From Another Process While Open (Windows)

```python
import tempfile
f = tempfile.NamedTemporaryFile(mode="w")
with open(f.name, "r") as another_process:   # can fail on Windows
    print(another_process.read())
```

- **Why is this wrong?** On Windows, a file already open in one
  process (especially with `NamedTemporaryFile`'s default mode) can
  block being opened simultaneously by another process.
- **Where's the error?** Can raise `PermissionError` (this is
  platform-specific — usually fine on Linux).
- **What should you use instead?** If you need cross-access on
  Windows, use `NamedTemporaryFile(delete=False)` and manage the
  file's lifecycle manually.

## 🔗 Related Modules
[os](../01-os/README.md), [pathlib](../10-pathlib/README.md)

---
⬅️ [Modules Home](../README.md)
