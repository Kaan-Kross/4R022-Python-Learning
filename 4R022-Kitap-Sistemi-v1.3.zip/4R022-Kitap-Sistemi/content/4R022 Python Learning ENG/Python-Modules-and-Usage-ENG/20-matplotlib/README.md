# The `matplotlib` Module

## What Is It and How Does It Work?

`matplotlib` is Python's foundational library for charts and data
visualization (`pip install matplotlib`). Its most widely used
submodule, `pyplot`, offers a step-by-step, MATLAB-like drawing
interface: you plot data first, then add details like axes/titles,
then show or save the result.

## When / Where Is It Used?

- Visualizing trends in data analysis
- Producing charts for reports
- Giving a visual summary to the user in tools like 4R022 Steam
  Analiz

## ✅ Working Examples

```python
# Example 1: a simple line chart
import matplotlib.pyplot as plt
x = [1, 2, 3, 4]
y = [10, 20, 25, 30]
plt.plot(x, y, marker="o")
plt.title("Example Chart")
plt.savefig("chart.png")
```

```python
# Example 2: multiple data series and a legend
import matplotlib.pyplot as plt
plt.plot([1,2,3], [1,4,9], label="squares")
plt.plot([1,2,3], [1,8,27], label="cubes")
plt.legend()
plt.savefig("comparison.png")
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Using `plt.show()` in a Headless/Server Environment

```python
import matplotlib.pyplot as plt
plt.plot([1, 2, 3])
plt.show()
```

- **Why is this wrong?** On a server or CI/CD environment with no
  display (GUI), `plt.show()` tries to open a window — this usually
  errors out or silently hangs.
- **Where's the error?** `plt.show()` assumes a display environment exists.
- **What should you use instead?** In server environments, use
  `plt.savefig("chart.png")` — it writes to a file and needs no display.

### Wrong Example 2 — Continuing to Draw on Top of the Previous Figure

```python
import matplotlib.pyplot as plt
plt.plot([1, 2, 3], [1, 4, 9])
plt.savefig("chart1.png")

plt.plot([1, 2, 3], [3, 2, 1])   # gets added to the SAME figure!
plt.savefig("chart2.png")        # chart2.png ends up with BOTH lines
```

- **Why is this wrong?** Unless explicitly cleared, `matplotlib`
  keeps drawing on the **same figure**; the assumption that
  "chart2.png" would only have the second line is wrong — it has both.
- **Where's the error?** No `plt.clf()` (clear figure) or
  `plt.figure()` (new figure) call between the two plots.
- **What should you use instead?** Call `plt.figure()` before each
  new chart, or `plt.clf()` to clear the current one.

### Wrong Example 3 — Giving Mismatched-Length X/Y Data

```python
import matplotlib.pyplot as plt
x = [1, 2, 3, 4, 5]
y = [10, 20, 30]   # 2 elements shorter than x!
plt.plot(x, y)
```

- **Why is this wrong?** `plt.plot()` expects `x` and `y` to be the
  **same length** — every x point needs a matching y value.
- **Where's the error?** Raises `ValueError: x and y must have same
  first dimension`.
- **What should you use instead?** Make sure both lists are the same
  length, or when building data in a loop, append to both `x` and `y`
  on every iteration.

## 🔗 Related Modules
[numpy](../18-numpy/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Modules Home](../README.md)
