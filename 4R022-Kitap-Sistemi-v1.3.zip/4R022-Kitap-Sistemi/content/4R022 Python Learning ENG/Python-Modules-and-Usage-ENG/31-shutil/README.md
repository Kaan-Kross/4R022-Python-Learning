# The `shutil` Module

## What Is It and How Does It Work?

`shutil` (shell utilities) adds **high-level** file/folder operations
on top of `os`'s single-file operations (creating, deleting):
copying, moving, deleting an entire folder, and creating archives
(zip/tar). Where `os` gives you "bricks," `shutil` gives you
ready-made "walls" built from them.

## When / Where Is It Used?

- Copying a folder along with all its subfolders/files
- Deleting a non-empty folder entirely (`os.rmdir()` can't do this)
- Packaging application output as a `.zip`

## ✅ Working Examples

```python
# Example 1: copying a file
import shutil
shutil.copy("source.txt", "destination.txt")
```

```python
# Example 2: deleting a non-empty folder entirely
import shutil
shutil.rmtree("full_folder")   # does what os.rmdir() can't
```

```python
# Example 3: packaging a folder into a zip
import shutil
shutil.make_archive("output", "zip", "output_folder")
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Trying to Copy a Folder With `shutil.copy()`

```python
import shutil
shutil.copy("source_folder", "destination_folder")
```

- **Why is this wrong?** `shutil.copy()` is only for **files**, not folders.
- **Where's the error?** Raises `IsADirectoryError`.
- **What should you use instead?** To copy an entire folder
  (including subfolders), use `shutil.copytree("source_folder",
  "destination_folder")`.

### Wrong Example 2 — Assuming `shutil.rmtree()` Is Reversible

```python
import shutil
shutil.rmtree("important_data")   # thinking "I can undo this"
```

- **Why is this wrong?** `shutil.rmtree()` deletes a folder and
  **everything inside it permanently, with no undo** — it doesn't
  move things to a recycle bin.
- **Where's the error?** This isn't a code bug — it's a **caution/
  safety** mistake — there's no built-in undo mechanism.
- **What should you use instead?** Always back up before deleting,
  or use a third-party library like `send2trash` for "move to
  recycle bin" behavior instead.

## 🔗 Related Modules
[os](../01-os/README.md), [tempfile](../28-tempfile/README.md)

---
⬅️ [Modules Home](../README.md)
