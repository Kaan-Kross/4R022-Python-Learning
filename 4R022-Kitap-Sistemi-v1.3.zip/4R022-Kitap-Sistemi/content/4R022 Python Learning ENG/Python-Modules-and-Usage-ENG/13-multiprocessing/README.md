# The `multiprocessing` Module

## What Is It and How Does It Work?

`multiprocessing` launches multiple **fully independent Python
processes** — each with its own memory and its own GIL. Unlike
`threading`, this gives you **real parallelism** for CPU-bound work
(it genuinely uses multiple CPU cores at once).

## When / Where Is It Used?

- Image/video processing, heavy mathematical computation
- Analyzing multiple files in parallel
- Data-processing scripts that want to use all of a CPU's cores

## ✅ Working Examples

```python
# Example 1: parallel computation with Pool
import multiprocessing

def square(n):
    return n * n

if __name__ == "__main__":
    with multiprocessing.Pool(4) as pool:
        results = pool.map(square, [1, 2, 3, 4, 5])
    print(results)   # [1, 4, 9, 16, 25]
```

```python
# Example 2: Process and shared data (via Queue)
import multiprocessing

def produce(q):
    q.put("Result from the process")

if __name__ == "__main__":
    q = multiprocessing.Queue()
    p = multiprocessing.Process(target=produce, args=(q,))
    p.start()
    p.join()
    print(q.get())
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Forgetting the `if __name__ == "__main__":` Guard (Windows)

```python
import multiprocessing

def process(n):
    return n * 2

pool = multiprocessing.Pool(4)
print(pool.map(process, [1, 2, 3]))
```

- **Why is this wrong?** On Windows (and in some macOS scenarios),
  every new process **re-imports** the main script; without this
  guard, each child process tries to spawn its own `Pool` again,
  leading to an endless process loop/crash.
- **Where's the error?** The code isn't wrapped inside `if __name__
  == "__main__":`.
- **What should you use instead?**
  ```python
  if __name__ == "__main__":
      pool = multiprocessing.Pool(4)
      print(pool.map(process, [1, 2, 3]))
  ```

### Wrong Example 2 — Trying to Share a Normal Variable Between Processes

```python
import multiprocessing

counter = 0

def increment():
    global counter
    counter += 1

if __name__ == "__main__":
    p = multiprocessing.Process(target=increment)
    p.start()
    p.join()
    print(counter)   # still 0! (unlike threading)
```

- **Why is this wrong?** Each process has **its own separate
  memory**; changing `counter` inside a process does NOT affect the
  main program's memory. This is the biggest difference from
  `threading` and a very common point of confusion.
- **Where's the error?** `global counter` only affects that
  process's own copy, not a shared one.
- **What should you use instead?** For sharing data between
  processes, use `multiprocessing.Queue`, `multiprocessing.Value`,
  or `multiprocessing.Manager()`.

### Wrong Example 3 — Spinning Up Processes for Tiny Tasks (Overkill)

```python
import multiprocessing

def add(a, b):
    return a + b

if __name__ == "__main__":
    with multiprocessing.Pool(4) as pool:
        print(pool.map(lambda x: add(x, 1), range(10)))
```

- **Why is this wrong?** Starting a process has real overhead (new
  memory space, OS resource allocation); for such a tiny task, this
  can be **slower** than just computing directly. (Also, `lambda`
  usually can't be pickled by `multiprocessing`, causing an error too.)
- **Where's the error?** The task size doesn't justify process
  overhead; also, `lambda` may raise `PicklingError`.
- **What should you use instead?** For small/simple work, a plain
  `for` loop or list comprehension is enough; reserve
  `multiprocessing` for genuinely heavy computation, and use a named
  function instead of `lambda`.

## 🔗 Related Modules
[threading](../12-threading/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modules Home](../README.md)
