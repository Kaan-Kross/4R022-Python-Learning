# The `requests` Module

## What Is It and How Does It Work?

`requests` lets you send HTTP requests to web servers/APIs — a
third-party library (`pip install requests`) much more readable than
the standard library's lower-level `urllib`. Under the hood, it
opens a TCP connection, builds HTTP headers, and parses the server's
response for you.

## When / Where Is It Used?

- Fetching data from a web API (weather, exchange rates, news)
- Writing a client that talks to your own backend (Flask/FastAPI)
- Collecting data from websites (scraping — within legitimate,
  authorized limits; see
  [Ethics and Security](../../Python-Ethics-and-Security-ENG/README.md))

## ✅ Working Examples

```python
# Example 1: a simple GET request
import requests
r = requests.get("https://api.github.com", timeout=5)
print(r.status_code)   # 200
print(r.json())
```

```python
# Example 2: a POST request with data
import requests
data = {"user": "Kaan", "message": "Hello"}
r = requests.post("https://httpbin.org/post", json=data, timeout=5)
print(r.json())
```

```python
# Example 3: a safe request with error handling
import requests
try:
    r = requests.get("https://api.github.com", timeout=5)
    r.raise_for_status()
    print("Success:", r.status_code)
except requests.RequestException as e:
    print("Request failed:", e)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Not Specifying a `timeout`

```python
import requests
r = requests.get("https://a-very-slow-server.com")
```

- **Why is this wrong?** Without `timeout`, if the server never
  responds, the program **waits forever** — in an app with a GUI,
  this looks exactly like a frozen crash.
- **Where's the error?** `timeout` is missing from `requests.get()`.
- **What should you use instead?** Always set `timeout=5` (or an
  appropriate duration): `requests.get(url, timeout=5)`

### Wrong Example 2 — Reading JSON Without Checking the Status Code

```python
import requests
r = requests.get("https://api.example.com/nonexistent-endpoint")
data = r.json()   # the server may have returned a 404!
```

- **Why is this wrong?** Even if the server returns an error like
  404/500, `requests` doesn't automatically turn that into a Python
  exception; `.json()` can crash or silently return wrong data if the
  response isn't actually JSON (like an HTML error page).
- **Where's the error?** `r.raise_for_status()` or a status-code
  check was never done.
- **What should you use instead?**
  ```python
  r.raise_for_status()   # raises on 4xx/5xx
  data = r.json()
  ```

### Wrong Example 3 — Hardcoding an API Key Directly in the Code

```python
import requests
API_KEY = "sk-real-key-12345"   # hardcoded in source!
r = requests.get(f"https://api.example.com/data?key={API_KEY}")
```

- **Why is this wrong?** The code runs but this is a **serious
  security mistake** — pushing this to GitHub (especially a public
  repo) exposes your API key to anyone, ready to be abused.
- **Where's the error?** A secret/sensitive key is written directly
  into the source code.
- **What should you use instead?** Store keys in environment
  variables (`os.getenv("API_KEY")`) or `.env` files, and add those
  files to `.gitignore` so they never reach GitHub.

## 🔗 Related Modules
[Flask and FastAPI](../17-flask-and-fastapi/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modules Home](../README.md)
