# The `pathlib` Module

## What Is It and How Does It Work?

`pathlib` handles file paths as **objects rather than strings**
(Python 3.4+). Instead of gluing strings together with
`os.path.join()`, you build paths using the `/` operator on `Path`
objects — more readable and less error-prone.

## When / Where Is It Used?

- In new code, as the modern replacement for `os.path`
- Checking whether something exists, and whether it's a file or folder
- Finding files with a specific extension in a folder (`.glob()`)

## ✅ Working Examples

```python
# Example 1: building a path — instead of os.path.join
from pathlib import Path
path = Path("project") / "data" / "settings.json"
print(path)   # project/data/settings.json (with the right OS separator)
```

```python
# Example 2: checking and reading a file
from pathlib import Path
file = Path("notes.txt")
if file.exists():
    content = file.read_text(encoding="utf-8")
    print(content)
```

```python
# Example 3: finding files with a given extension
from pathlib import Path
for py_file in Path(".").glob("*.py"):
    print(py_file.name)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Confusing `Path` Methods With `str` Methods

```python
from pathlib import Path
path = Path("file.txt")
print(path.replace(".txt", ".csv"))
```

- **Why is this wrong?** `str.replace()` means something completely
  different on `Path` objects — `Path.replace()` actually **moves/
  renames** the file, it doesn't do text replacement.
- **Where's the error?** `.replace(".txt", ".csv")` tries to move the
  path to a location literally named "file.csv" and can raise
  `FileNotFoundError`.
- **What should you use instead?** Use the dedicated method for
  changing the extension: `path.with_suffix(".csv")` — this returns
  a new `Path` object without touching the file.

### Wrong Example 2 — Mixing `Path` and `os.path` Functions Directly

```python
import os
from pathlib import Path
path = Path("data") / "file.txt"
print(os.path.join(path, "extra"))
```

- **Why is this wrong?** This often "works" (Path converts to a
  string implicitly) but produces an inconsistent code style, and
  some older `os.path` functions may not handle `Path` objects as
  expected.
- **Where's the error?** Two different APIs (`os.path` and `pathlib`)
  are mixed without a clear reason.
- **What should you use instead?** Pick **one** per project — in
  new code, use `pathlib` throughout: `path / "extra"` is enough,
  `os.path.join()` isn't needed.

### Wrong Example 3 — Trying to Write a File Into a Nonexistent Folder

```python
from pathlib import Path
file = Path("missing_folder/notes.txt")
file.write_text("hello")
```

- **Why is this wrong?** If `missing_folder` doesn't exist yet, a
  file can't be written inside it — the parent folder must exist first.
- **Where's the error?** Raises `FileNotFoundError: [Errno 2] No such
  file or directory` because the parent folder was never created.
- **What should you use instead?**
  ```python
  file.parent.mkdir(parents=True, exist_ok=True)
  file.write_text("hello", encoding="utf-8")
  ```

## 🔗 Related Modules
[os](../01-os/README.md)

---
⬅️ [Modules Home](../README.md)
