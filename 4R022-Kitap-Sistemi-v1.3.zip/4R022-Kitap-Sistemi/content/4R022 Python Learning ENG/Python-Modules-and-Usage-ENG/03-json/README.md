# The `json` Module

## What Is It and How Does It Work?

The `json` module converts Python objects (`dict`, `list`, `str`,
`int`...) into **JSON text** (serialization) and back into Python
objects (deserialization). JSON is a universal "common language" for
web APIs and configuration files — nearly every programming language
can read and write it.

## When / Where Is It Used?

- Storing app settings (theme, language, window size) in a file
- Processing data coming from/going to a web API
- **Atomic JSON writes** (with a `.bak` backup) in 4R022 archive/
  settings systems — to prevent data loss

## ✅ Working Examples

```python
# Example 1: dict -> JSON file
import json
settings = {"theme": "dark", "lang": "en"}
with open("settings.json", "w", encoding="utf-8") as f:
    json.dump(settings, f, indent=4)
```

```python
# Example 2: JSON file -> dict
import json
with open("settings.json", "r", encoding="utf-8") as f:
    settings = json.load(f)
print(settings["theme"])
```

```python
# Example 3: atomic write pattern (4R022 standard — prevents data loss)
import json, os
def safe_save(data, filename):
    tmp = filename + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
    if os.path.exists(filename):
        os.replace(filename, filename + ".bak")
    os.replace(tmp, filename)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Parsing a Single-Quoted "JSON" String

```python
import json
data = json.loads("{'theme': 'dark'}")
```

- **Why is this wrong?** The JSON standard requires **double
  quotes**; single quotes are Python dict syntax, not JSON.
- **Where's the error?** The string passed to `json.loads()` uses `'`.
- **What should you use instead?** `json.loads('{"theme": "dark"}')`
  — with double quotes.

### Wrong Example 2 — Special Characters Getting Garbled

```python
import json
data = {"city": "Zürich"}
with open("data.json", "w") as f:   # no encoding specified!
    json.dump(data, f)
```

- **Why is this wrong?** Without `encoding="utf-8"`, some systems'
  default encoding can garble non-ASCII characters (accents, umlauts,
  etc.).
- **Where's the error?** `encoding="utf-8"` is missing from `open()`.
- **What should you use instead?** `open("data.json", "w",
  encoding="utf-8")` and, if readability of non-ASCII characters
  matters, `json.dump(data, f, ensure_ascii=False)`.

### Wrong Example 3 — Reading a Corrupt/Missing JSON File Without a Safety Net

```python
import json
with open("broken.json", "r") as f:
    data = json.load(f)   # crashes if the file is empty or malformed
```

- **Why is this wrong?** If the file is empty, corrupt, or missing,
  the program crashes; in real applications files can get corrupted
  (interrupted writes, disk errors, etc.).
- **Where's the error?** There's no error handling (`try/except`) at all.
- **What should you use instead?**
  ```python
  try:
      with open("broken.json", "r", encoding="utf-8") as f:
          data = json.load(f)
  except (json.JSONDecodeError, FileNotFoundError):
      data = {}   # fall back to a sensible default
  ```

## 🔗 Related Modules
[csv](../04-csv/README.md), [os](../01-os/README.md)

---
⬅️ [Modules Home](../README.md)
