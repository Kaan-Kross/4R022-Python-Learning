# The `itertools` and `functools` Modules

## What Are They and How Do They Work?

`itertools` provides **memory-efficient, fast** tools for loops —
instead of putting results into one big list immediately, it
produces them one at a time via generator logic (see the
Intermediate level). `functools` provides tools for treating
functions "as functions" — caching, partial application, reduction.

## When / Where Are They Used?

- Generating combinations/permutations over large datasets (`itertools`)
- Handling infinite or very large loops in a memory-friendly way
- Caching function results (`functools.lru_cache`)
- Reducing a list to a single value (`functools.reduce`)

## ✅ Working Examples

```python
# Example 1: itertools.permutations — all orderings
from itertools import permutations
for p in permutations(["A", "B", "C"]):
    print(p)
```

```python
# Example 2: itertools.chain — chaining multiple lists together
from itertools import chain
list1 = [1, 2, 3]
list2 = [4, 5, 6]
for item in chain(list1, list2):
    print(item)   # 1,2,3,4,5,6 — without building a combined list
```

```python
# Example 3: functools.reduce — reducing a list to one value
from functools import reduce
numbers = [1, 2, 3, 4]
product = reduce(lambda a, b: a * b, numbers)
print(product)   # 24 (1*2*3*4)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Using a Normal `for` Loop on Infinite `itertools.count()`

```python
from itertools import count
for i in count(1):
    print(i)   # never stops!
```

- **Why is this wrong?** `count()` is, as the name says, **infinite**;
  without `break` it never stops.
- **Where's the error?** There's no exit condition (`break`) in the loop.
- **What should you use instead?**
  ```python
  from itertools import count
  for i in count(1):
      if i > 10:
          break
      print(i)
  ```

### Wrong Example 2 — Using `lru_cache` With a Mutable Argument

```python
from functools import lru_cache

@lru_cache(maxsize=None)
def sum_list(items):
    return sum(items)

sum_list([1, 2, 3])
```

- **Why is this wrong?** `lru_cache` requires arguments to be
  hashable to key the cache; mutable types like `list` aren't hashable.
- **Where's the error?** Raises `TypeError: unhashable type: 'list'`
  because a `list` was passed as a parameter.
- **What should you use instead?** Call it with a tuple instead:
  `sum_list((1, 2, 3))` — `tuple` is hashable.

### Wrong Example 3 — Using `itertools.permutations` on Overly Large Input

```python
from itertools import permutations
big_list = list(range(15))
all_perms = list(permutations(big_list))
```

- **Why is this wrong?** 15 elements have `15! ≈ 1.3 trillion`
  permutations — this exhausts memory and can freeze/crash the
  program. This is a capacity/algorithm mistake, not a syntax error.
- **Where's the error?** The result is being forced **entirely and
  immediately** into memory with `list()`.
- **What should you use instead?** Iterate the generator directly
  with a `for` loop instead of wrapping it in `list()`; or realistically
  bound the input size (e.g. 8-10 elements).

## 🔗 Related Modules
[collections](../08-collections/README.md)

---
⬅️ [Modules Home](../README.md)
