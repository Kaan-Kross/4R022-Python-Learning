# The `pandas` Module

## What Is It and How Does It Work?

`pandas` is built for working with tabular (row-column) data (`pip
install pandas`), using `numpy` arrays under the hood. Its main data
structure is the **DataFrame** — very much like an Excel sheet:
rows, named columns, and an index.

## When / Where Is It Used?

- Reading and analyzing CSV/Excel files
- Data cleaning (filling missing values, filtering)
- Grouping, summarizing, building pivot tables
- The data-preparation stage of data science and ML projects

## ✅ Working Examples

```python
# Example 1: reading CSV and basic analysis
import pandas as pd
df = pd.read_csv("grades.csv")
print(df.head())          # first 5 rows
print(df["grade"].mean())  # column average
```

```python
# Example 2: filtering and grouping
import pandas as pd
df = pd.DataFrame({"branch": ["A", "B", "A", "B"], "sales": [100, 200, 150, 250]})
print(df[df["sales"] > 120])              # filtering
print(df.groupby("branch")["sales"].sum()) # sum by branch
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Accessing a Column That Doesn't Exist

```python
import pandas as pd
df = pd.DataFrame({"name": ["Kaan"], "grade": [95]})
print(df["grades"])
```

- **Why is this wrong?** The actual column is named `"grade"`, not
  `"grades"` — spelling and case must match exactly.
- **Where's the error?** Raises `KeyError: 'grades'`.
- **What should you use instead?** Check the real column names first
  with `print(df.columns)`, then use the correct one: `df["grade"]`

### Wrong Example 2 — Chained Assignment Warning

```python
import pandas as pd
df = pd.DataFrame({"grade": [50, 90, 70]})
df[df["grade"] < 60]["grade"] = 60   # trying to bump failing grades to 60
```

- **Why is this wrong?** This is a "chained assignment" pattern where
  pandas can't guarantee whether it's operating on a copy — often
  the **original `df` doesn't change**, and a silent
  `SettingWithCopyWarning` is raised.
- **Where's the error?** Two separate bracket accesses are chained
  together (`df[...][...] =`).
- **What should you use instead?** Use `.loc` for a single, explicit
  update: `df.loc[df["grade"] < 60, "grade"] = 60`

### Wrong Example 3 — Leaving Missing (NaN) Values Unhandled

```python
import pandas as pd
df = pd.read_csv("incomplete_data.csv")
average = df["grade"].sum() / len(df)
```

- **Why is this wrong?** Missing cells in a CSV are read as `NaN`;
  `len(df)` counts **all rows** (including ones with missing grades),
  which skews the average. No error occurs, but the result is
  **silently wrong.**
- **Where's the error?** `NaN` values were included in the
  calculation without being filtered or filled.
- **What should you use instead?** Use `df["grade"].mean()` (pandas'
  `.mean()` automatically ignores `NaN`), or first drop incomplete
  rows with `df = df.dropna(subset=["grade"])`.

## 🔗 Related Modules
[numpy](../18-numpy/README.md), [matplotlib](../20-matplotlib/README.md), [csv](../04-csv/README.md)

---
⬅️ [Modules Home](../README.md)
