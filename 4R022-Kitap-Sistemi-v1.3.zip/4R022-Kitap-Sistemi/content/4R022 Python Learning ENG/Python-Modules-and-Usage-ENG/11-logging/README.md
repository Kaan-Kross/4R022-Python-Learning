# The `logging` Module

## What Is It and How Does It Work?

`logging` is the professional replacement for `print()`-based
debugging. The difference: it categorizes messages into **levels**
(DEBUG, INFO, WARNING, ERROR, CRITICAL), can write to the screen and
a file at the same time, and automatically timestamps every message —
answering "what happened, and when" in large applications like
4R022's desktop tools.

## When / Where Is It Used?

- Tracking errors/events in production applications
- Recording detailed information a developer needs but a user
  shouldn't see
- The "grown-up" version of debugging with `print()` that sticks around

## ✅ Working Examples

```python
# Example 1: basic usage
import logging
logging.basicConfig(level=logging.INFO)
logging.info("Application started")
logging.warning("Settings file not found, using defaults")
```

```python
# Example 2: logging to both a file and the screen
import logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("app.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logging.debug("This is a detailed debug message")
```

```python
# Example 3: logging an exception inside try/except
import logging
try:
    1 / 0
except ZeroDivisionError:
    logging.exception("A division error occurred")   # also logs the traceback
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Calling `basicConfig()` More Than Once

```python
import logging
logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.ERROR)   # this call is IGNORED!
logging.debug("This message might not appear")
```

- **Why is this wrong?** By default, `logging.basicConfig()` is only
  effective on its **first** call; later calls are silently ignored —
  no error is raised, which makes this hard to notice.
- **Where's the error?** The second `basicConfig()` call was assumed
  to take effect.
- **What should you use instead?** Configure it correctly once; if
  you need to change it later, use the more detailed API like
  `logging.getLogger().setLevel(...)`.

### Wrong Example 2 — DEBUG-Level Messages Not Appearing

```python
import logging
logging.basicConfig(level=logging.WARNING)
logging.debug("This will never show up")
```

- **Why is this wrong?** No error occurs, but the expected message is
  **never printed** — a configuration/logic issue.
- **Where's the error?** The level is set to `WARNING`; `DEBUG` is
  considered **less severe** than `WARNING` and is filtered out.
- **What should you use instead?** Set `level=logging.DEBUG` if you
  want `DEBUG` messages to show — levels are filtered by severity:
  DEBUG < INFO < WARNING < ERROR < CRITICAL.

### Wrong Example 3 — Logging Sensitive Data

```python
import logging
logging.info(f"User login: password={user_password}")
```

- **Why is this wrong?** The code technically works, but it's a
  **serious security mistake** — log files are often stored with
  weaker protection, and passwords should never end up there.
- **Where's the error?** The password is written directly into the
  log message.
- **What should you use instead?** Never log sensitive data; if
  needed, mask it: `logging.info(f"User login: {username}")` (no
  password).

## 🔗 Related Modules
[datetime](../05-datetime/README.md)

---
⬅️ [Modules Home](../README.md)
