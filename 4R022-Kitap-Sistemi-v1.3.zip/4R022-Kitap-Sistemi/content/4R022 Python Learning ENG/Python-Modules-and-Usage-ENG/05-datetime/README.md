# The `datetime` Module

## What Is It and How Does It Work?

The `datetime` module lets you represent, compare, and format dates
and times **correctly**. Storing dates as plain strings like
"2026-09-15" instead of `datetime` objects makes calculating
day/month differences, sorting, and time zone handling unsafe.

## When / Where Is It Used?

- Adding timestamps to log entries
- Calculating times in reminder/alarm apps ("remind me in 2 hours") —
  the core logic behind the 4R022 SAAT project
- Age, duration, and countdown calculations

## ✅ Working Examples

```python
# Example 1: current date/time and formatting
from datetime import datetime
now = datetime.now()
print(now.strftime("%m/%d/%Y %H:%M"))
```

```python
# Example 2: calculating a date difference
from datetime import datetime
birthday = datetime(2000, 5, 20)
diff = datetime.now() - birthday
print(diff.days, "days lived")
```

```python
# Example 3: calculating a future time (reminder logic)
from datetime import datetime, timedelta
reminder = datetime.now() + timedelta(hours=2, minutes=30)
print("Reminder time:", reminder.strftime("%H:%M"))
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Format String Doesn't Match the Actual Data

```python
from datetime import datetime
date = datetime.strptime("2026-09-15", "%m/%d/%Y")
```

- **Why is this wrong?** The format given to `strptime` (`%m/%d/%Y`,
  month/day/year with `/`) doesn't **exactly match** the string's
  actual shape (year-month-day with `-`).
- **Where's the error?** Wrong separator (`/` instead of `-`) and
  wrong field order.
- **What should you use instead?** `datetime.strptime("2026-09-15",
  "%Y-%m-%d")`

### Wrong Example 2 — Comparing Two Different Types

```python
from datetime import datetime
date1 = datetime.now()
date2 = "2026-09-15"
print(date1 > date2)
```

- **Why is this wrong?** A `datetime` object and a plain `str` can't
  be compared directly — they're different types.
- **Where's the error?** `date2` was left as a string, never
  converted to `datetime`.
- **What should you use instead?** Convert first: `date2 =
  datetime.strptime("2026-09-15", "%Y-%m-%d")`, then compare.

### Wrong Example 3 — Ignoring Time Zones

```python
from datetime import datetime
meeting_time = datetime(2026, 9, 15, 14, 0)   # which time zone?
```

- **Why is this wrong?** The code runs but creates a **"naive"
  (timezone-unaware)** `datetime`; comparing it across users in
  different time zones gives wrong results.
- **Where's the error?** No time zone information was ever specified.
- **What should you use instead?** For multi-user/global apps, use
  `zoneinfo` (standard library, Python 3.9+) to specify a time zone:
  `datetime(2026, 9, 15, 14, 0, tzinfo=ZoneInfo("America/New_York"))`

## 🔗 Related Modules
[os](../01-os/README.md) (for file modification times), [logging](../11-logging/README.md)

---
⬅️ [Modules Home](../README.md)
