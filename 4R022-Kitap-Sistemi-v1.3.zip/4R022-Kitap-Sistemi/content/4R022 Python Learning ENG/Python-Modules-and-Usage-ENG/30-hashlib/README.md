# The `hashlib` Module

## What Is It and How Does It Work?

`hashlib` provides algorithms (MD5, SHA-256, SHA-512, etc.) that
transform data into a **fixed-length, one-way digest (hash)**.
"One-way" means going from the hash back to the original data is
(theoretically) impossible — even a tiny change in input produces a
completely different hash.

## When / Where Is It Used?

- Verifying a downloaded file hasn't been corrupted (does its hash
  match the official site's?)
- Storing **not the password itself, but its hash** (in real
  production systems, purpose-built password hashing algorithms like
  `bcrypt`/`argon2` are preferred over plain `hashlib`)
- Quickly comparing large files' contents (are they identical?)

## ✅ Working Examples

```python
# Example 1: getting a string's SHA-256 hash
import hashlib
text = "4R022 Python Learning"
digest = hashlib.sha256(text.encode()).hexdigest()
print(digest)
```

```python
# Example 2: hashing a file (chunk by chunk for large files)
import hashlib
def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Storing User Passwords With Plain `hashlib.md5()`

```python
import hashlib
password_hash = hashlib.md5("123456".encode()).hexdigest()
# storing this hash as the user's "password" in a database
```

- **Why is this wrong?** The code runs but this is a **serious
  security mistake** — MD5 is both cryptographically broken and
  **fast**, which is bad for password storage (an attacker can try
  millions of possible passwords per second, "brute-forcing" it).
- **Where's the error?** The wrong tool was chosen for password storage.
- **What should you use instead?** Use algorithms specifically
  designed to be slow and salted for password storage: `bcrypt`,
  `argon2`, or `hashlib.pbkdf2_hmac()`.

### Wrong Example 2 — Trying to Hash a `str` Directly

```python
import hashlib
digest = hashlib.sha256("hello")
```

- **Why is this wrong?** `hashlib` functions only accept **bytes**,
  not a plain `str`.
- **Where's the error?** Raises `TypeError: Unicode-objects must be
  encoded before hashing`.
- **What should you use instead?** Encode to bytes first:
  `hashlib.sha256("hello".encode())`

## 🔗 Related Modules
[cryptography](../25-cryptography/README.md)

---
⬅️ [Modules Home](../README.md)
