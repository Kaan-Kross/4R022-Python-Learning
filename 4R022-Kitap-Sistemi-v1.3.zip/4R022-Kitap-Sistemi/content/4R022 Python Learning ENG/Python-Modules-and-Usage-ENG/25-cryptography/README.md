# The `cryptography` Module

## What Is It and How Does It Work?

`cryptography` is an industry-standard third-party library for
secure encryption in Python (`pip install cryptography`). Writing
your own encryption algorithm is extremely risky (a tiny mistake can
break the whole security model); this library provides expert-
reviewed, proven algorithms (like AES, Fernet) ready to use.

## When / Where Is It Used?

- Securely storing user data/passwords inside an application
- Encrypting/decrypting files (e.g. encrypted login systems in
  projects like 4R022 Arşiv)
- Secure data transmission between two systems

## ✅ Working Examples

```python
# Example 1: simple symmetric encryption with Fernet
from cryptography.fernet import Fernet
key = Fernet.generate_key()
f = Fernet(key)

encrypted = f.encrypt(b"Secret message")
decrypted = f.decrypt(encrypted)
print(decrypted.decode())   # "Secret message"
```

```python
# Example 2: safely storing/loading the key
from cryptography.fernet import Fernet

# Generate once and save to a file:
key = Fernet.generate_key()
with open("secret.key", "wb") as f:
    f.write(key)

# Load the SAME key on subsequent runs:
with open("secret.key", "rb") as f:
    loaded_key = f.read()
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Generating a New Key Every Time It Runs

```python
from cryptography.fernet import Fernet
f = Fernet(Fernet.generate_key())
encrypted = f.encrypt(b"Secret data")
# ... program closes ...
# next run:
f2 = Fernet(Fernet.generate_key())   # a DIFFERENT, new key!
decrypted = f2.decrypt(encrypted)
```

- **Why is this wrong?** Every call to `generate_key()` produces a
  **completely different** key; the key used to encrypt and the one
  used to decrypt **must be identical.**
- **Where's the error?** Raises `cryptography.fernet.InvalidToken`
  because `f2`'s key doesn't match the key `f` used to encrypt.
- **What should you use instead?** Generate the key **once**, store
  it somewhere safe (a file, an environment variable), and load the
  **same** key every time.

### Wrong Example 2 — Hardcoding the Encryption Key in Source Code

```python
from cryptography.fernet import Fernet
KEY = b"gAAAAABhZ...(real-key-here)..."   # hardcoded in source!
f = Fernet(KEY)
```

- **Why is this wrong?** The code runs but this is a **serious
  security hole** — pushing this to GitHub (especially a public
  repo) makes your encryption key public; the encrypted data now has
  no real protection.
- **Where's the error?** The key is embedded directly in the source code.
- **What should you use instead?** Store the key in an environment
  variable or a separate file added to `.gitignore`; **never** put a
  real key/password directly in the source.

### Wrong Example 3 — Trying to Encrypt a `str` Instead of `bytes`

```python
from cryptography.fernet import Fernet
f = Fernet(Fernet.generate_key())
encrypted = f.encrypt("Secret message")   # str, not bytes!
```

- **Why is this wrong?** `Fernet.encrypt()` only accepts **bytes**
  data; a plain `str` isn't accepted.
- **Where's the error?** Raises a `TypeError` because the function
  expects `bytes`, not `str`.
- **What should you use instead?** Encode the string to bytes:
  `f.encrypt("Secret message".encode())` — decode back with
  `.decode()` when decrypting.

## 🔗 Related Modules
[hashlib (planned)](../README.md), [socket](../24-socket/README.md)

---
⬅️ [Modules Home](../README.md)
