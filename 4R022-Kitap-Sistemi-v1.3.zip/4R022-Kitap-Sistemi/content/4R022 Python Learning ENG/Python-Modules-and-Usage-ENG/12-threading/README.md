# The `threading` Module

## What Is It and How Does It Work?

`threading` lets a program run multiple "threads" of execution at
once. In CPython, the **GIL (Global Interpreter Lock)** prevents
threads from running Python bytecode truly simultaneously, but while
one thread is **waiting** (for file I/O, a network response, etc.)
another can run — so threading genuinely helps with "I/O-bound" work.
See the [Concurrency](../../Python-Advanced-Education-ENG/01-Concurrency.md)
chapter for a deeper comparison.

## When / Where Is It Used?

- Downloading multiple files/URLs at once
- Running a long task in the background without freezing the GUI
  (`QThread` is PyQt6's equivalent of this idea)

## ✅ Working Examples

```python
# Example 1: creating a simple thread
import threading, time

def wait_and_print(name):
    time.sleep(1)
    print(f"{name} finished")

t = threading.Thread(target=wait_and_print, args=("Task-1",))
t.start()
t.join()   # main program waits here until the thread finishes
```

```python
# Example 2: safely modifying shared data with a Lock
import threading

counter = 0
lock = threading.Lock()

def increment():
    global counter
    with lock:      # only one thread can be in this block at a time
        counter += 1

threads = [threading.Thread(target=increment) for _ in range(100)]
for t in threads: t.start()
for t in threads: t.join()
print(counter)   # always 100 — not guaranteed without the Lock
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Forgetting to Call `join()`

```python
import threading, time

def long_task():
    time.sleep(2)
    print("Task finished")

t = threading.Thread(target=long_task)
t.start()
print("Program finished")   # this may print BEFORE "Task finished"
```

- **Why is this wrong?** `t.start()` launches the thread but doesn't
  **wait** for it; the main program continues immediately. No error
  is raised, but the expected order is broken.
- **Where's the error?** The `t.join()` call is missing.
- **What should you use instead?** If you need to wait for the
  thread, add `t.join()` after `t.start()`.

### Wrong Example 2 — Modifying Shared Data Without a Lock

```python
import threading

counter = 0

def increment():
    global counter
    counter += 1   # this operation is NOT atomic!

threads = [threading.Thread(target=increment) for _ in range(100000)]
for t in threads: t.start()
for t in threads: t.join()
print(counter)   # 100000 is EXPECTED, but often a SMALLER number results!
```

- **Why is this wrong?** `counter += 1` is actually three steps
  (read, increment, write); if two threads interleave those steps, an
  increment can be "lost" — this is called a **race condition**.
- **Where's the error?** The shared `counter` variable isn't
  protected by a `Lock`.
- **What should you use instead?** Use `threading.Lock()` to protect
  the critical section, as in Working Example 2 above.

### Wrong Example 3 — Using Threading for CPU-Bound Work

```python
import threading

def heavy_computation():
    total = sum(i * i for i in range(50_000_000))

threads = [threading.Thread(target=heavy_computation) for _ in range(4)]
for t in threads: t.start()
for t in threads: t.join()
```

- **Why is this wrong?** This "runs" but doesn't give the expected
  speedup — the GIL prevents real parallelism for CPU-heavy work.
- **Where's the error?** The wrong tool was chosen; this is
  computation-bound work, not I/O-bound.
- **What should you use instead?** Use `multiprocessing` for
  CPU-bound work (see [multiprocessing](../13-multiprocessing/README.md)).

## 🔗 Related Modules
[multiprocessing](../13-multiprocessing/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modules Home](../README.md)
