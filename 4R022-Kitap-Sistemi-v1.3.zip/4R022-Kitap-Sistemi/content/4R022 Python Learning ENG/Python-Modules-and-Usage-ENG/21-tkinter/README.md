# The `tkinter` Module

## What Is It and How Does It Work?

`tkinter` is the desktop GUI library that ships with Python's
standard library — a thin Python wrapper around the older but solid
Tcl/Tk GUI toolkit. It runs on an **event loop**: once `mainloop()`
is called, the program waits and reacts to events until the user
clicks/types something.

## When / Where Is It Used?

- Quick, small desktop tools that need no extra installation
- Prototyping — quickly testing an idea
- School/learning projects (not needing an install is a big plus)

## ✅ Working Examples

```python
# Example 1: a minimal window
import tkinter as tk
root = tk.Tk()
root.title("4R022 Example")
tk.Label(root, text="Hello!").pack()
root.mainloop()
```

```python
# Example 2: interacting with a button
import tkinter as tk
def on_click():
    label.config(text="Clicked!")

root = tk.Tk()
label = tk.Label(root, text="Waiting...")
label.pack()
tk.Button(root, text="Click", command=on_click).pack()
root.mainloop()
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Forgetting to Call `mainloop()`

```python
import tkinter as tk
root = tk.Tk()
tk.Label(root, text="This won't show").pack()
```

- **Why is this wrong?** Without `mainloop()`, the event loop never
  starts; the program ends immediately, and the window either never
  appears or closes instantly.
- **Where's the error?** The `root.mainloop()` line is simply missing.
- **What should you use instead?** Every tkinter program's **last
  line** should be `root.mainloop()`.

### Wrong Example 2 — Calling the Function With Parentheses in `command=`

```python
import tkinter as tk
def on_click():
    print("Clicked")

root = tk.Tk()
tk.Button(root, text="Click", command=on_click()).pack()  # has parentheses!
root.mainloop()
```

- **Why is this wrong?** Writing `command=on_click()` calls the
  function **immediately, while the window is being built**, and
  binds the button to its **return value** (`None`) — so it never
  actually responds to real clicks.
- **Where's the error?** An extra pair of parentheses was added;
  `on_click` (no parentheses, the function itself) should have been
  passed.
- **What should you use instead?** `command=on_click` — no
  parentheses, pass the function reference; tkinter calls it itself
  when clicked.

### Wrong Example 3 — Updating the UI From a Non-Main Thread

```python
import tkinter as tk
import threading, time

def long_task():
    time.sleep(3)
    label.config(text="Done!")   # updating the UI from another thread!

root = tk.Tk()
label = tk.Label(root, text="Waiting...")
label.pack()
threading.Thread(target=long_task).start()
root.mainloop()
```

- **Why is this wrong?** Tkinter (like most GUI libraries) is **not
  thread-safe** — UI elements should only be updated from the main
  thread; updating from another thread can crash the app or cause
  odd behavior.
- **Where's the error?** `label.config(...)` is called from a
  background thread, not the main thread.
- **What should you use instead?** Use `root.after(...)` to send a
  "message" back to the main thread, or use a `queue.Queue` to pass
  the result and process/update the UI from the main loop.

## 🔗 Related Modules
[PyQt6](../22-PyQt6/README.md), [threading](../12-threading/README.md)

---
⬅️ [Modules Home](../README.md)
