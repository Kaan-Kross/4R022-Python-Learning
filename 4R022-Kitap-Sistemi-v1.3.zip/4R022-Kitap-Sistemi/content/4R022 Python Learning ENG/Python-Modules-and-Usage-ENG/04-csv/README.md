# The `csv` Module

## What Is It and How Does It Work?

The `csv` (Comma-Separated Values) module reads and writes tabular
data made of rows and columns — a simple, plain-text table format
you can open in Excel. The `csv` module correctly handles separators,
quoted text, and line endings for you — trying to do this by hand
(with `.split(",")` alone) is error-prone.

## When / Where Is It Used?

- Exchanging data with Excel/Google Sheets
- Storing tabular data like student grades, inventory lists, logs
- Lightweight tabular data handling without installing `pandas`

## ✅ Working Examples

```python
# Example 1: writing to CSV
import csv
with open("grades.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "grade"])
    writer.writerow(["Kaan", 95])
```

```python
# Example 2: reading CSV (as lists)
import csv
with open("grades.csv", "r", encoding="utf-8") as f:
    for row in csv.reader(f):
        print(row)
```

```python
# Example 3: DictReader/DictWriter for named-column access
import csv
with open("grades.csv", "r", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        print(row["name"], "->", row["grade"])
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Forgetting `newline=""` (Windows)

```python
import csv
with open("grades.csv", "w", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "grade"])
```

- **Why is this wrong?** The code runs without error — but on
  Windows it produces **extra blank rows** between lines in the CSV.
  This is the sneakiest CSV bug because nothing crashes.
- **Where's the error?** `newline=""` is missing from `open()`.
- **What should you use instead?** `open("grades.csv", "w",
  newline="", encoding="utf-8")`

### Wrong Example 2 — Manually `split(",")`-ing Data That Contains Commas

```python
line = 'Kaan,"Sakarya, Turkey",95'
parts = line.split(",")
print(parts)   # ['Kaan', '"Sakarya', ' Turkey"', '95'] — WRONG!
```

- **Why is this wrong?** The comma inside the address is also
  treated as a separator by `split(",")`; the data splits into 4
  parts when it should be 3 columns.
- **Where's the error?** There's no logic to ignore commas inside
  quotes; plain `split` doesn't know about that.
- **What should you use instead?** `csv.reader()` — it correctly
  treats a quoted comma as part of one field:
  ```python
  import csv, io
  print(next(csv.reader(io.StringIO(line))))
  # ['Kaan', 'Sakarya, Turkey', '95']  — CORRECT
  ```

### Wrong Example 3 — Writing Rows With an Inconsistent Number of Columns

```python
import csv
with open("grades.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "grade", "class"])
    writer.writerow(["Kaan", 95])   # 'class' is missing!
```

- **Why is this wrong?** The code runs (CSV doesn't enforce a fixed
  column count) but reading it back with `DictReader` later leaves
  the missing column as `None` — a data-consistency bug, not a
  syntax error.
- **Where's the error?** The second `writerow` call doesn't match
  the header row's column count.
- **What should you use instead?** Check column counts before
  writing, or use `DictWriter` so missing fields are handled
  explicitly with a default value.

## 🔗 Related Modules
[json](../03-json/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Modules Home](../README.md)
