# The `selenium` Module

> ⚠️ This module is powerful and can be misused. Before using it,
> please read
> [Ethics and Security](../../Python-Ethics-and-Security-ENG/README.md).
> The examples below are strictly for testing/automating **your own**
> site/app.

## What Is It and How Does It Work?

`selenium` lets you control a real web browser (Chrome, Firefox)
**programmatically** (`pip install selenium`). Under the hood, it
talks to the browser via the "WebDriver Protocol" — clicking,
typing, scrolling just like a human would, but automated in code.

## When / Where Is It Used?

- Writing automated tests for your own website (instead of manually
  clicking through it on every release)
- Automating repetitive form-filling on your own account/authorized
  environment
- Extracting content from pages rendered dynamically with JavaScript,
  which `requests` alone can't fetch

## ✅ Working Examples

```python
# Example 1: opening a page and reading the title
from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://example.com")
print(driver.title)
driver.quit()
```

```python
# Example 2: finding an element and reading its text
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://example.com")
heading = driver.find_element(By.TAG_NAME, "h1")
print(heading.text)
driver.quit()
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Accessing an Element Before the Page Fully Loads

```python
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://a-slow-example-site.com")
element = driver.find_element(By.ID, "results")   # page might not have loaded yet
```

- **Why is this wrong?** Modern websites often load content
  **afterward** via JavaScript; `get()` doesn't guarantee the page is
  **fully** loaded with JS content.
- **Where's the error?** Can raise `NoSuchElementException` because
  the `"results"` element doesn't exist in the DOM yet.
- **What should you use instead?** Use `WebDriverWait` to wait for
  the element to appear:
  ```python
  from selenium.webdriver.support.ui import WebDriverWait
  from selenium.webdriver.support import expected_conditions as EC
  element = WebDriverWait(driver, 10).until(
      EC.presence_of_element_located((By.ID, "results"))
  )
  ```

### Wrong Example 2 — Forgetting to Call `driver.quit()`

```python
from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://example.com")
print(driver.title)
# driver.quit() was never called
```

- **Why is this wrong?** The code "works" but the browser process
  **stays open** — running the script repeatedly leaves dozens of
  Chrome windows/processes running in the background, slowing the
  computer down.
- **Where's the error?** Resource cleanup (`driver.quit()`) is missing.
- **What should you use instead?** Guarantee cleanup with
  `try/finally`:
  ```python
  driver = webdriver.Chrome()
  try:
      driver.get("https://example.com")
  finally:
      driver.quit()
  ```

### Wrong Example 3 — Ignoring a Site's Terms of Service to Build an Automation

```python
# Building a bot that sends thousands of requests per hour despite
# a site's ToS explicitly forbidding automated access
```

- **Why is this wrong?** It might technically "work," but it's a
  **terms-of-service violation and potential legal issue**; it can
  also overload the target server, effectively causing a
  denial-of-service.
- **Where's the error?** Not a code error — it's a **permission/
  ethics** issue (see
  [Ethics and Security](../../Python-Ethics-and-Security-ENG/README.md)).
- **What should you use instead?** Respect a site's `robots.txt` and
  terms of service; if you need substantial data, use the site's
  official API or ask for permission.

## 🔗 Related Modules
[requests](../16-requests/README.md)

---
⬅️ [Modules Home](../README.md)
