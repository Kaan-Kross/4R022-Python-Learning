# The `math` and `random` Modules

## What Are They and How Do They Work?

`math` provides advanced mathematical functions (square root,
trigonometry, logarithms, constants) that basic operators (`+ - * /`)
don't cover — a thin Python wrapper around C's math library.
`random` generates **pseudo-random** numbers: actually produced by a
deterministic formula, but unpredictable enough for practical
purposes.

## When / Where Are They Used?

- Geometry, physics simulations, game mechanics (`math`)
- Dice rolls, shuffling cards, generating sample data, draft
  password/code generation (`random`) — **not for security!**

## ✅ Working Examples

```python
# Example 1: basic math functions
import math
print(math.sqrt(16))     # 4.0
print(math.pi)            # 3.14159...
print(math.ceil(4.1))     # 5
print(math.floor(4.9))    # 4
```

```python
# Example 2: random number and choice
import random
print(random.randint(1, 6))          # a die: 1-6, both inclusive
print(random.choice(["rock", "paper", "scissors"]))
```

```python
# Example 3: shuffling a list
import random
deck = list(range(1, 53))
random.shuffle(deck)   # shuffles in place
print(deck[:5])
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Taking the Square Root of a Negative Number

```python
import math
print(math.sqrt(-16))
```

- **Why is this wrong?** The square root of a negative number is
  undefined over real numbers; `math` only works with real numbers.
- **Where's the error?** A negative value was given to `math.sqrt()`
  — raises `ValueError: math domain error`.
- **What should you use instead?** For complex-number support, use
  `cmath.sqrt(-16)` (result: `4j`).

### Wrong Example 2 — Misunderstanding `random.randint()`'s Bounds

```python
import random
roll = random.randint(1, 6)
# writing logic assuming "6 won't come up if I try 5 times"
```

- **Why is this wrong?** `random.randint(a, b)` includes **both `a`
  and `b`** — unlike `randrange(a, b)`, the upper bound is inclusive.
  Not knowing this leads to probability logic mistakes.
- **Where's the error?** A wrong assumption about the function's
  boundary behavior.
- **What should you use instead?** If you want the upper bound
  **excluded**, use `random.randrange(1, 6)` instead (returns 1-5,
  excluding 6).

### Wrong Example 3 — Using `random` for Security/Cryptographic Purposes

```python
import random
password = "".join(random.choice("abcdefg12345") for _ in range(8))
# generating this as a real user account password
```

- **Why is this wrong?** The `random` module is **not
  cryptographically secure** — its underlying algorithm (Mersenne
  Twister) is predictable, so it should never be used where real
  security matters.
- **Where's the error?** The wrong module was chosen for a
  security-sensitive context — this is a **security flaw**, not a
  runtime error.
- **What should you use instead?** Use the `secrets` module for
  passwords/tokens/keys: `secrets.token_urlsafe(16)` or
  `secrets.choice(...)`.

## 🔗 Related Modules
[secrets (planned)](../README.md), [cryptography](../25-cryptography/README.md)

---
⬅️ [Modules Home](../README.md)
