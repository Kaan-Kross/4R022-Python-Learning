# The `re` Module (Regular Expressions)

## What Is It and How Does It Work?

The `re` module lets you search text for **patterns**. Regular
expressions (regex) form a small special-purpose language that
describes a pattern (like "a digit, then an @ sign, then letters").
Python compiles this pattern into a **state machine** and scans the
text character by character with it.

## When / Where Is It Used?

- Validating formats like emails, phone numbers, URLs
- Extracting specific info (error codes, IP addresses) from log files
- Pattern-based find-and-replace in text (where plain `str.replace()`
  isn't enough)

## ✅ Working Examples

```python
# Example 1: simple pattern search
import re
text = "Contact: kaan@4r022.com"
match = re.search(r"[\w.]+@[\w.]+", text)
print(match.group())   # kaan@4r022.com
```

```python
# Example 2: finding all matches
import re
text = "Phone: 555-111-2233, Backup: 532-999-8877"
numbers = re.findall(r"\d{3}-\d{3}-\d{4}", text)
print(numbers)
```

```python
# Example 3: find-and-replace
import re
date = "2026-09-15"
result = re.sub(r"-", "/", date)
print(result)   # 2026/09/15
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Not Using a Raw String for Backslashes

```python
import re
pattern = re.compile("\d+")   # no 'r' prefix!
```

- **Why is this wrong?** This usually "works," but in more complex
  patterns, Python's own escape sequences (`\n`, `\t`) can **clash**
  with regex escape sequences, leading to subtle bugs.
- **Where's the error?** The string is missing the `r` (raw string) prefix.
- **What should you use instead?** Always use a **raw string** for
  regex patterns: `r"\d+"` — this disables Python's own escape-sequence
  interpretation.

### Wrong Example 2 — Confusing `match()` with `search()`

```python
import re
text = "Hello, my number is 12345"
result = re.match(r"\d+", text)
print(result.group())
```

- **Why is this wrong?** `re.match()` only looks for a match **at
  the very start** of the string; here the string starts with
  "Hello", not a digit.
- **Where's the error?** `result` is `None`, so `.group()` raises
  `AttributeError: 'NoneType' object has no attribute 'group'`.
- **What should you use instead?** Use `re.search(r"\d+", text)` to
  search **anywhere** in the string.

### Wrong Example 3 — Writing an Overly Complex, Unreadable One-Line Regex

```python
import re
# Trying to write one "does everything" regex to validate all emails
pattern = r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
```

- **Why is this wrong?** It might technically work but is **nearly
  impossible to maintain or debug** — a code smell, not a syntax error.
- **Where's the error?** Trying to cram every real-world email rule
  into a single regex.
- **What should you use instead?** For a simple check, `"@" in text
  and "." in text` may be enough; for real validation, use a
  well-tested library like `email-validator`.

## 🔗 Related Modules
[collections](../08-collections/README.md)

---
⬅️ [Modules Home](../README.md)
