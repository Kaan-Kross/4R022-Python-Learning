# The `os` Module

## What Is It and How Does It Work?

The `os` module lets your Python program talk to the **operating
system** (Windows, Linux, macOS). Under the hood, it wraps the OS's
system calls in Python functions — so calling `os.listdir(".")` asks
the OS "list the files in this folder" on your behalf and returns
the result as a Python list. It's part of the standard library — **no
installation needed.**

## When / Where Is It Used?

- Creating, deleting, renaming files and folders
- Listing files in a folder
- Accessing environment variables
- Building cross-platform (Windows/Linux) compatible file paths
- Finding a user's data folder (`%APPDATA%`, `~/.config`) per-platform in 4R022 desktop apps

## ✅ Working Examples

```python
# Example 1: current working directory and its contents
import os
print(os.getcwd())
print(os.listdir("."))
```

```python
# Example 2: creating a folder (without erroring if it exists)
import os
os.makedirs("output/daily", exist_ok=True)
```

```python
# Example 3: building a platform-appropriate file path
import os
path = os.path.join("project", "data", "settings.json")
print(path)   # On Windows: project\data\settings.json
              # On Linux/macOS: project/data/settings.json
```

```python
# Example 4: accessing an environment variable (user data folder)
import os
appdata = os.getenv("APPDATA", os.path.expanduser("~"))
print(appdata)
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Trying to Remove a Folder That Doesn't Exist

```python
import os
os.rmdir("nonexistent_folder")
```

- **Why is this wrong?** If `nonexistent_folder` genuinely doesn't
  exist on disk, the OS tells Python "no such directory."
- **Where's the error?** In the `os.rmdir()` call — this function
  removes an existing, **empty** folder; it fails for a folder that
  isn't there.
- **What should you use instead?** Check first:
  ```python
  if os.path.isdir("nonexistent_folder"):
      os.rmdir("nonexistent_folder")
  else:
      print("Folder doesn't exist already.")
  ```

### Wrong Example 2 — Trying to `rmdir()` a Non-Empty Folder

```python
import os
os.rmdir("full_folder")   # contains files
```

- **Why is this wrong?** `os.rmdir()` **only** removes empty
  folders; it refuses on purpose if the folder has contents.
- **Where's the error?** `full_folder` has at least one file/subfolder,
  so this raises `OSError: [Errno 39] Directory not empty`.
- **What should you use instead?** To delete a folder with everything
  inside it, use `shutil.rmtree("full_folder")` instead of `os`.

### Wrong Example 3 — Manually Joining Paths (Platform Dependence)

```python
import os
path = "data" + "/" + "settings.json"
f = open(path)
```

- **Why is this wrong?** The code "works" but isn't **portable** —
  this isn't a runtime crash, it's a hidden platform-dependence bug.
- **Where's the error?** The `/` character is hardcoded; on Windows
  this can cause issues with some older APIs or mixed-path scenarios.
- **What should you use instead?** `os.path.join("data",
  "settings.json")` — this automatically detects the OS and uses the
  correct separator (`/` or `\`).

## 🔗 Related Modules
[pathlib](../10-pathlib/README.md) (a more modern alternative), [sys](../02-sys/README.md)

---
⬅️ [Modules Home](../README.md)
