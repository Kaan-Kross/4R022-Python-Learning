# Flask and FastAPI

## What Are They and How Do They Work?

Both let you write a **web server / API** in Python (`pip install
flask` / `pip install fastapi uvicorn`). Flask is a minimal
"micro-framework" that maps incoming HTTP requests to URLs (routes).
FastAPI extends that same idea by generating automatic data
validation and API documentation (Swagger UI) from Python type
hints, and runs on `asyncio` under the hood.

## When / Where Are They Used?

- Building a backend that serves your desktop/mobile app
- A simple website or internal dashboard tool (Flask)
- A high-performance, type-safe API with automatic docs (FastAPI)

## ✅ Working Examples

```python
# Example 1: minimal Flask API
from flask import Flask, jsonify
app = Flask(__name__)

@app.route("/students")
def students():
    return jsonify([{"name": "Kaan", "grade": 95}])

if __name__ == "__main__":
    app.run(debug=True)
```

```python
# Example 2: a type-safe FastAPI endpoint
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Student(BaseModel):
    name: str
    grade: int

@app.post("/add-student")
def add_student(student: Student):
    return {"message": f"{student.name} added"}
# Run with: uvicorn filename:app --reload
```

## ❌ Broken / Incorrect Examples

### Wrong Example 1 — Deploying With `debug=True` in Production

```python
app.run(debug=True, host="0.0.0.0")
```

- **Why is this wrong?** `debug=True` opens an **interactive Python
  console** (the Werkzeug debugger) in the browser when an error
  occurs — on a server exposed to real users, this can let an
  attacker **execute arbitrary code.** A serious security hole.
- **Where's the error?** A development-only setting was carried into
  production.
- **What should you use instead?** Use `debug=False` in production
  and run Flask behind a real WSGI server like `gunicorn`, not
  directly.

### Wrong Example 2 — Calling a Route With the Wrong HTTP Method

```python
# Flask side:
@app.route("/data", methods=["GET"])
def get_data():
    return jsonify({"status": "ok"})

# Client side:
import requests
requests.post("http://localhost:5000/data")
```

- **Why is this wrong?** The route is defined to accept only `GET`;
  a `POST` request doesn't match it.
- **Where's the error?** The server returns `405 Method Not
  Allowed` because `"POST"` isn't in the `methods` list.
- **What should you use instead?** Either send the request as
  `requests.get(...)`, or expand the route to
  `methods=["GET", "POST"]`.

### Wrong Example 3 — Sending Data That Doesn't Match the Pydantic Model (FastAPI)

```python
import requests
requests.post("http://localhost:8000/add-student",
              json={"name": "Kaan", "grade": "ninety-five"})   # str, not int!
```

- **Why is this wrong?** The `Student` model expects `grade: int`;
  `"ninety-five"` can't be converted to an integer.
- **Where's the error?** FastAPI automatically rejects the request
  with `422 Unprocessable Entity` (this is actually FastAPI's
  **advantage**: bad data is caught before it reaches your code).
- **What should you use instead?** Send correctly typed data from
  the client: `{"name": "Kaan", "grade": 95}`

## 🔗 Related Modules
[requests](../16-requests/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Modules Home](../README.md)
