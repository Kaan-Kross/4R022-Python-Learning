# 3. Operators

## Arithmetic Operators

```python
# ✅ This code works
print(5 + 3)   # 8   addition
print(5 - 3)   # 2   subtraction
print(5 * 3)   # 15  multiplication
print(5 / 3)   # 1.666... division (always returns a float)
print(5 // 3)  # 1   floor division
print(5 % 3)   # 2   modulo (remainder)
print(5 ** 3)  # 125 exponent
```

```python
# ❌ This code does NOT work — division by zero is undefined
print(5 / 0)
```

This raises `ZeroDivisionError: division by zero`. Python doesn't
guess; it stops the program — we'll cover catching this in the Error
Handling chapter.

## Comparison Operators

```python
# ✅ This code works — all return True/False
print(5 == 5)   # True  equal?
print(5 != 3)   # True  not equal?
print(5 > 3)    # True
print(5 < 3)    # False
print(5 >= 5)   # True
print(5 <= 4)   # False
```

```python
# ❌ This code does NOT work — assignment (=) confused with comparison (==)
if x = 5:
    print("five")
```

This raises a `SyntaxError`. Single `=` **assigns**, double `==`
**compares** — a classic beginner mistake.

## Logical Operators

```python
# ✅ This code works
age = 20
is_student = True

print(age >= 18 and is_student)   # True — both must be true
print(age >= 18 or is_student)    # True — one being true is enough
print(not is_student)             # False — flips the value
```

## Compound Assignment Operators

```python
# ✅ This code works
counter = 0
counter += 1   # counter = counter + 1 -> 1
counter -= 1   # -> 0
counter *= 5   # -> 0
counter += 10  # -> 10
print(counter)
```

### 🎯 Mini Exercise
Write an expression using `%` and `and` that checks whether a number
is divisible by both 2 and 3.

---
⬅️ [Variables and Data Types](./02-Variables-and-Data-Types.md) &nbsp;|&nbsp; ➡️ [Conditionals](./04-Conditionals.md)
