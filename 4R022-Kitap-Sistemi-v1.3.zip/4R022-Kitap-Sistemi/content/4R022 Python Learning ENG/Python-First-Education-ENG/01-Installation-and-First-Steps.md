# 1. Installation and First Steps

## Installing Python

1. Download from [python.org/downloads](https://python.org/downloads)
   for your OS (on Windows, make sure to check **"Add Python to
   PATH"**).
2. Verify the install in a terminal:

```bash
python --version
```

3. Install a code editor: **VS Code** (recommended), PyCharm, or the
   built-in IDLE.

## Your First Program

```python
# ✅ This code works — save as "hello.py" and run it
print("Hello, 4R022 Python Learning!")
```

```bash
python hello.py
```

```python
# ❌ This code does NOT work — "print" is misspelled
prnt("Hello")
```

This raises `NameError: name 'prnt' is not defined`. Python reports
any name it doesn't recognize this way — reading error messages is
far more useful than fearing them.

## The Interactive Shell

Typing just `python` in a terminal opens an interactive shell (you'll
see a `>>>` prompt) where you can run code line by line — great for
quick experiments.

```python
>>> 2 + 2
4
>>> print("test")
test
```

## Comments

```python
# This is a single-line comment, Python ignores it
print("This line runs")  # comments can also follow code

"""
This is a multi-line comment
(also used as a docstring).
"""
```

### 🎯 Mini Exercise
Write a two-line program that prints your name, then prints "I'm
learning Python!" on the next line.

---
⬅️ [Back](./README.md) &nbsp;|&nbsp; ➡️ [Variables and Data Types](./02-Variables-and-Data-Types.md)
