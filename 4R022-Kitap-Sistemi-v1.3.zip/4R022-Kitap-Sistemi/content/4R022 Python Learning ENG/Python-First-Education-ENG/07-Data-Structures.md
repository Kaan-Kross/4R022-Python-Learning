# 7. Data Structures: List, Tuple, Dict, Set

## List — Ordered, Mutable

```python
# ✅ This code works
fruits = ["apple", "pear", "banana"]
fruits.append("strawberry")     # adds to the end
fruits[0] = "apricot"           # changes the first element
print(fruits)                   # ['apricot', 'pear', 'banana', 'strawberry']
print(fruits[1])                # 'pear'
print(fruits[-1])               # last element: 'strawberry'
print(fruits[0:2])              # slicing: first two elements
```

```python
# ❌ This code does NOT work — accessing beyond the list's bounds
fruits = ["apple", "pear"]
print(fruits[5])
```

This raises `IndexError: list index out of range`. A 2-item list only
has valid indexes `0` and `1`.

## Tuple — Ordered, IMMUTABLE

```python
# ✅ This code works
coordinate = (10, 20)
print(coordinate[0])   # 10
```

```python
# ❌ This code does NOT work — tuples can't be changed after creation
coordinate = (10, 20)
coordinate[0] = 99
```

This raises `TypeError: 'tuple' object does not support item
assignment`. Tuples are ideal when you want a "this shouldn't change"
guarantee (e.g. a fixed coordinate or RGB color value).

## Dict — Key-Value Pairs

```python
# ✅ This code works
student = {"name": "Kaan", "age": 25, "major": "CS"}
print(student["name"])       # 'Kaan'
student["age"] = 26          # update a value
student["city"] = "Sakarya"  # add a new key

for key, value in student.items():
    print(key, "->", value)
```

```python
# ❌ This code does NOT work — accessing a key that doesn't exist
student = {"name": "Kaan"}
print(student["lastname"])
```

This raises `KeyError: 'lastname'`. Safe access uses `.get()`:

```python
# ✅ This code works — no error if the key is missing, returns None
print(student.get("lastname"))          # None
print(student.get("lastname", "N/A"))   # "N/A" (default value)
```

## Set — Unordered, No Duplicates

```python
# ✅ This code works — sets automatically drop duplicates
numbers = {1, 2, 2, 3, 3, 3}
print(numbers)   # {1, 2, 3}

a = {1, 2, 3}
b = {2, 3, 4}
print(a & b)   # intersection: {2, 3}
print(a | b)   # union: {1, 2, 3, 4}
print(a - b)   # difference: {1}
```

## Comparison Table

| Structure | Ordered? | Mutable? | Duplicates? | Syntax |
|---|---|---|---|---|
| `list` | ✅ | ✅ | ✅ | `[1, 2, 3]` |
| `tuple` | ✅ | ❌ | ✅ | `(1, 2, 3)` |
| `dict` | ✅ (3.7+) | ✅ | keys unique | `{"a": 1}` |
| `set` | ❌ | ✅ | ❌ | `{1, 2, 3}` |

### 🎯 Mini Exercise
Build a `list` of student names, then a `dict` mapping each name to a
grade (`{"name": grade}`), and compute the average.

---
⬅️ [Functions](./06-Functions.md) &nbsp;|&nbsp; ➡️ [File and Error Handling](./08-File-and-Error-Handling.md)
