# 6. Functions

## Why Functions?

Instead of repeating the same code, wrap it under a name you can call
whenever you need it — the foundation of the "DRY" (Don't Repeat
Yourself) principle.

```python
# ✅ This code works
def greet(name):
    print(f"Hello, {name}!")

greet("Kaan")
greet("4R022")
```

```python
# ❌ This code does NOT work — function called before it's defined
greet("Kaan")

def greet(name):
    print(f"Hello, {name}!")
```

This raises `NameError: name 'greet' is not defined`. Python runs
top to bottom; you must define a function before calling it.

## Returning Values with `return`

```python
# ✅ This code works
def square(n):
    return n ** 2

result = square(5)
print(result)   # 25
```

> ⚠️ `print()` displays to screen but does not **return** a value;
> `return` sends a value back out of the function so it can be stored.

## Default Parameters

```python
# ✅ This code works
def greet(name, message="Welcome"):
    print(f"{message}, {name}!")

greet("Kaan")               # "Welcome, Kaan!"
greet("Kaan", "Hi")         # "Hi, Kaan!"
```

## `*args` and `**kwargs`

```python
# ✅ This code works — accepts any number of arguments
def add(*numbers):
    return sum(numbers)

print(add(1, 2, 3, 4))   # 10
```

```python
# ✅ This code works — accepts any number of named arguments
def print_info(**info):
    for key, value in info.items():
        print(f"{key}: {value}")

print_info(name="Kaan", job="Developer")
```

## Variable Scope

```python
# ❌ This behaves unexpectedly — the 'x' inside the function does not
# touch the outer 'x':
x = 10

def change():
    x = 20   # this creates a NEW local x, scoped to the function

change()
print(x)   # still 10, not 20
```

```python
# ✅ This code works — 'global' modifies the outer x
x = 10

def change():
    global x
    x = 20

change()
print(x)   # 20
```

### 🎯 Mini Exercise
Write a function `largest(numbers)` that finds the largest number in
a list without using the built-in `max()` — use a `for` loop instead.

---
⬅️ [Loops](./05-Loops.md) &nbsp;|&nbsp; ➡️ [Data Structures](./07-Data-Structures.md)
