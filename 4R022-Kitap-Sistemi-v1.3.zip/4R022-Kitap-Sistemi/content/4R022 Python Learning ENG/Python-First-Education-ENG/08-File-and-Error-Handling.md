# 8. File Handling and Error Handling

## Reading / Writing Files

```python
# ✅ This code works — writes to a file (creates it if missing)
with open("notes.txt", "w", encoding="utf-8") as f:
    f.write("Hello 4R022!\n")
    f.write("I'm learning Python.\n")

# ✅ This code works — reads the file
with open("notes.txt", "r", encoding="utf-8") as f:
    content = f.read()
    print(content)
```

Using `with` means the file is **automatically closed** when the
block ends — no risk of forgetting `f.close()`.

```python
# ❌ This code does NOT work — trying to read a file that doesn't exist
with open("nonexistent_file.txt", "r") as f:
    print(f.read())
```

This raises `FileNotFoundError: [Errno 2] No such file or directory`.

## Error Handling: `try / except`

Errors like the one above crash the program. We "catch" them instead:

```python
# ✅ This code works — catches the error, program keeps running
try:
    with open("nonexistent_file.txt", "r") as f:
        print(f.read())
except FileNotFoundError:
    print("File not found, creating a new one...")
```

```python
# ✅ This code works — multiple error types can be caught
try:
    number = int(input("Enter a number: "))
    print(10 / number)
except ValueError:
    print("That wasn't a valid number.")
except ZeroDivisionError:
    print("You can't divide by zero.")
```

```python
# ❌ This has a LOGIC bug — the except block catches the WRONG type,
# so the error still crashes the program:
try:
    number = int("abc")
except ZeroDivisionError:   # wrong error type caught here
    print("error caught")
# The actual error is ValueError, NOT ZeroDivisionError, so Python
# doesn't catch it and the program crashes.
```

## `finally` and `else`

```python
# ✅ This code works — 'finally' always runs, error or not
try:
    x = 10 / 2
except ZeroDivisionError:
    print("An error occurred")
else:
    print("No error, result:", x)
finally:
    print("Done.")
```

## Raising Your Own Errors: `raise`

```python
# ✅ This code works
def check_age(age):
    if age < 0:
        raise ValueError("Age can't be negative!")
    return age

try:
    check_age(-5)
except ValueError as e:
    print("Caught an error:", e)
```

### 🎯 Mini Exercise
Ask the user for a filename and some text to write; handle the
possible errors (including `PermissionError`) with `try/except`.

---
⬅️ [Data Structures](./07-Data-Structures.md) &nbsp;|&nbsp; ➡️ [Introduction to OOP](./09-OOP-Introduction.md)
