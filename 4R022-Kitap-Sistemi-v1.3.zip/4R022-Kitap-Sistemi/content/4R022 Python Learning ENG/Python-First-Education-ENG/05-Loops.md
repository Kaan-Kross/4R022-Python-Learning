# 5. Loops (for / while)

## `for` Loop

```python
# ✅ This code works — counts 0 through 4 (5 is excluded)
for i in range(5):
    print(i)
```

```python
# ✅ This code works — iterates over a list
fruits = ["apple", "pear", "banana"]
for fruit in fruits:
    print(fruit)
```

```python
# ❌ This code doesn't do what you might expect — range() EXCLUDES
# the final number, a common conceptual mistake (runs fine, just
# produces different output than assumed):
for i in range(1, 5):
    print(i)   # prints 1,2,3,4 — 5 is NOT included
```

## `while` Loop

```python
# ✅ This code works
counter = 0
while counter < 5:
    print(counter)
    counter += 1
```

```python
# ❌ This code does NOT work (infinite loop!)
counter = 0
while counter < 5:
    print(counter)
    # counter += 1 was forgotten, so the condition stays True forever
```

> ⚠️ If you hit an infinite loop, stop it in the terminal with **Ctrl + C**.

## `break` and `continue`

```python
# ✅ This code works — stops the loop entirely at 3
for i in range(10):
    if i == 3:
        break
    print(i)   # prints 0, 1, 2
```

```python
# ✅ This code works — skips only 3, loop continues
for i in range(5):
    if i == 3:
        continue
    print(i)   # prints 0, 1, 2, 4 (3 is skipped)
```

## Nested Loops

```python
# ✅ This code works — a 3x3 multiplication-style grid
for i in range(1, 4):
    for j in range(1, 4):
        print(i * j, end=" ")
    print()  # new line after each outer iteration
```

### 🎯 Mini Exercise
Sum all numbers between 1 and 100 that are divisible by 3 or 5, using
a `for` loop.

---
⬅️ [Conditionals](./04-Conditionals.md) &nbsp;|&nbsp; ➡️ [Functions](./06-Functions.md)
