# 9. Introduction to Object-Oriented Programming (OOP)

## Class and Object

A **class** is a blueprint/template. An **object (instance)** is a
real, concrete thing built from that blueprint.

```python
# ✅ This code works
class Student:
    def __init__(self, name, age):
        self.name = name   # attribute
        self.age = age

    def introduce(self):   # method
        print(f"I'm {self.name}, {self.age} years old.")

student1 = Student("Kaan", 25)
student2 = Student("Ayse", 22)

student1.introduce()   # "I'm Kaan, 25 years old."
student2.introduce()   # "I'm Ayse, 22 years old."
```

`__init__` is a special method that runs **automatically** whenever
an object is created (the constructor). `self` refers to the current
object itself.

```python
# ❌ This code does NOT work — the 'self' parameter is missing
class Student:
    def __init__(name, age):     # 'self' is missing!
        name = name
        age = age

student1 = Student("Kaan", 25)
```

This raises `TypeError: __init__() takes 2 positional arguments but
3 were given`. Python automatically passes the object itself
(`self`) as the first argument to every method; forgetting it is the
classic first OOP mistake.

## Inheritance

```python
# ✅ This code works
class Animal:
    def __init__(self, name):
        self.name = name

    def make_sound(self):
        print(f"{self.name} makes a sound.")

class Dog(Animal):                # inherits from Animal
    def make_sound(self):         # overrides the method
        print(f"{self.name}: Woof!")

animal = Animal("Unknown")
dog = Dog("Rex")

animal.make_sound()   # "Unknown makes a sound."
dog.make_sound()      # "Rex: Woof!"
```

## Encapsulation — A Simple Introduction

```python
# ✅ This code works — a leading underscore marks an attribute as
# "private" by convention (Python has no real access restriction here)
class BankAccount:
    def __init__(self, balance):
        self._balance = balance

    def deposit(self, amount):
        if amount > 0:
            self._balance += amount

    def get_balance(self):
        return self._balance

account = BankAccount(100)
account.deposit(50)
print(account.get_balance())   # 150
```

## Why OOP?

As a program grows, keeping related data (attributes) and the
behavior that acts on it (methods) together keeps code readable and
maintainable. The `core/` + `ui/` split used in 4R022's PyQt6
projects is this same idea, scaled up.

### 🎯 Mini Exercise
Write a `Vehicle` class (with `brand` and `speed` attributes), then a
`SportsCar` subclass that inherits from it and overrides a
`accelerate()` method to behave differently.

---
⬅️ [File and Error Handling](./08-File-and-Error-Handling.md) &nbsp;|&nbsp; ➡️ [Move on to Intermediate Level](../Python-Intermediate-Education-ENG/README.md)

🎉 **Congratulations — you've completed the Basic Level!**
