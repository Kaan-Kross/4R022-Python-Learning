# 2. Variables and Data Types

## What Is a Variable?

A variable stores a value in memory under a name you can reuse.

```python
# ✅ This code works
age = 25
name = "Kaan"
height = 1.80
is_student = True

print(name, age, height, is_student)
```

```python
# ❌ This code does NOT work — variable names can't start with a digit
1age = 25
```

This raises `SyntaxError: invalid decimal literal`. Names must start
with a letter or underscore (`_`), never a digit.

## Core Data Types

| Type | Example | Meaning |
|---|---|---|
| `int` | `5`, `-12` | Integer |
| `float` | `3.14`, `-0.5` | Decimal number |
| `str` | `"hello"` | Text (string) |
| `bool` | `True`, `False` | Boolean |
| `NoneType` | `None` | "No value" |

```python
# ✅ This code works
print(type(5))        # <class 'int'>
print(type(5.0))      # <class 'float'>
print(type("5"))      # <class 'str'>
print(type(True))     # <class 'bool'>
```

## Type Conversion (Casting)

```python
# ✅ This code works
text_number = "42"
real_number = int(text_number)     # str -> int
print(real_number + 8)             # 50
```

```python
# ❌ This code does NOT work — "forty two" can't become a number
number = int("forty two")
```

This raises `ValueError: invalid literal for int()`. `int()` can only
convert strings made purely of digits.

## Getting Input: `input()`

```python
# ✅ This code works
name = input("What's your name? ")
print("Hello " + name + "!")
```

> ⚠️ **Note:** `input()` always returns a **string**. For numeric
> operations you must convert it with `int()` or `float()`:

```python
# ✅ This code works
age = int(input("How old are you? "))
print("In 5 years you'll be", age + 5)
```

### 🎯 Mini Exercise
Ask the user for two numbers with `input()`, convert them with
`int()`, add them, and print the result.

---
⬅️ [Installation](./01-Installation-and-First-Steps.md) &nbsp;|&nbsp; ➡️ [Operators](./03-Operators.md)
