# 4. Conditionals (if / elif / else)

## Basic Structure

```python
# ✅ This code works
age = 20

if age >= 18:
    print("You're an adult.")
else:
    print("You're a minor.")
```

## Multiple Conditions: `elif`

```python
# ✅ This code works
grade = 75

if grade >= 85:
    print("A")
elif grade >= 70:
    print("B")
elif grade >= 50:
    print("C")
else:
    print("F")
```

```python
# ❌ This code does NOT work — "else if" instead of "elif"
# (that's C/Java/JavaScript syntax, invalid in Python)
if grade >= 85:
    print("A")
else if grade >= 70:
    print("B")
```

Python has no `else if` keyword; the correct single word is `elif`.

## Nested Conditionals

```python
# ✅ This code works
age = 20
has_license = True

if age >= 18:
    if has_license:
        print("You can drive.")
    else:
        print("You need a license.")
else:
    print("You can't drive yet.")
```

## Ternary (One-Line) Conditional

```python
# ✅ This code works
age = 16
status = "adult" if age >= 18 else "minor"
print(status)
```

## Truthy / Falsy Values

Python treats many values as automatically "true" or "false" in a
condition, not just `True`/`False`:

```python
# ✅ This code works
if "":        # empty string -> Falsy
    print("won't print")
if "hello":   # non-empty string -> Truthy
    print("this prints")
if 0:         # zero -> Falsy
    print("won't print")
if []:        # empty list -> Falsy
    print("won't print")
```

### 🎯 Mini Exercise
Ask the user for a grade (0-100); print "A" for 85+, "B" for 70-84,
"C" for 50-69, and "F" below that.

---
⬅️ [Operators](./03-Operators.md) &nbsp;|&nbsp; ➡️ [Loops](./05-Loops.md)
