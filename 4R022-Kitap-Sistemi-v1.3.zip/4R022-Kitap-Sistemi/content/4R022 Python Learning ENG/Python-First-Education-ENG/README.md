# Python First Education (EN) — Basic Level

This tier takes someone who has never programmed and gets them
writing small, real Python programs.

## Chapters (follow in order)

1. [Installation and First Steps](./01-Installation-and-First-Steps.md)
2. [Variables and Data Types](./02-Variables-and-Data-Types.md)
3. [Operators](./03-Operators.md)
4. [Conditionals (if / elif / else)](./04-Conditionals.md)
5. [Loops (for / while)](./05-Loops.md)
6. [Functions](./06-Functions.md)
7. [Data Structures: List, Tuple, Dict, Set](./07-Data-Structures.md)
8. [File Handling and Error Handling](./08-File-and-Error-Handling.md)
9. [Introduction to OOP](./09-OOP-Introduction.md)

Every chapter has ✅ working and ❌ broken code examples, explanations,
and a mini exercise at the end.

Next ➡️ [Intermediate Level](../Python-Intermediate-Education-ENG/README.md)
