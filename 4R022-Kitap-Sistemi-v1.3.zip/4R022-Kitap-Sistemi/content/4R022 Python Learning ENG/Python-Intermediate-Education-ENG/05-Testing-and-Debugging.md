# 5. Testing and Debugging

## Why Write Tests?

As code grows, manually checking that a change hasn't broken
something else becomes impossible. Tests automate that check.

## `unittest` (Standard Library)

```python
# ✅ This code works — calculator.py
def add(a, b):
    return a + b

def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

```python
# ✅ This code works — test_calculator.py
import unittest
from calculator import add, divide

class TestCalculator(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(2, 3), 5)

    def test_divide_by_zero(self):
        with self.assertRaises(ValueError):
            divide(10, 0)

if __name__ == "__main__":
    unittest.main()
```

```bash
python -m unittest test_calculator.py
```

```python
# ❌ This test FAILS (a wrong expectation, not a crash) — 2 + 3 is
# actually 5, not 6:
self.assertEqual(add(2, 3), 6)   # AssertionError: 5 != 6
```

## `pytest` (Popular Third-Party Library)

```bash
pip install pytest
```

```python
# ✅ This code works — pytest doesn't even require unittest.TestCase
# test_calc.py
from calculator import add

def test_add():
    assert add(2, 3) == 5

def test_add_negative():
    assert add(-1, -1) == -2
```

```bash
pytest test_calc.py -v
```

## Debugging Tips

```python
# ✅ This code works — using print() to trace "what's where"
def compute(data):
    print("DEBUG: incoming data ->", data)   # temporary debug line
    return sum(data) / len(data)
```

```python
# ✅ This code works — Python's built-in debugger
def compute(data):
    breakpoint()   # execution pauses here so you can inspect variables
    return sum(data) / len(data)
```

> 🧑‍🏫 **Teacher's note:** debugging with `print()` isn't "amateur" —
> real developers use it constantly for quick checks. But in larger
> projects, the `logging` module and a real debugger (like the one
> built into VS Code) are far more powerful.

### 🎯 Mini Exercise
Add a `subtract(a, b)` function to `calculator.py`, then write tests
for it with both `unittest` and `pytest`.

---
⬅️ [Modules, Packages, Virtual Environments](./04-Modules-Packages-Virtual-Environments.md) &nbsp;|&nbsp; ➡️ [Move on to Advanced Level](../Python-Advanced-Education-ENG/README.md)

🎉 **Congratulations — you've completed the Intermediate Level!**
