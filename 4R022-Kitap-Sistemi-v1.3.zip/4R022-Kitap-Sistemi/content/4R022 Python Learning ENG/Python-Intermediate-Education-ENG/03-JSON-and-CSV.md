# 3. Data Formats: JSON and CSV

## JSON — Structured Data Exchange

JSON (JavaScript Object Notation) is the most common data format for
web APIs and configuration files; it maps closely onto Python's `dict`.

```python
# ✅ This code works — writes a Python dict to a JSON file
import json

settings = {"theme": "dark", "lang": "en", "version": 2}

with open("settings.json", "w", encoding="utf-8") as f:
    json.dump(settings, f, indent=4)

# ✅ This code works — reads the JSON file back into a dict
with open("settings.json", "r", encoding="utf-8") as f:
    loaded = json.load(f)
    print(loaded["theme"])   # "dark"
```

```python
# ❌ This code does NOT work — parsing a broken (invalid) JSON string
# (single quotes are not valid in JSON!)
import json
data = json.loads("{'theme': 'dark'}")   # single quotes are invalid!
```

This raises `json.decoder.JSONDecodeError`. The JSON standard
requires **double quotes** — don't confuse it with Python dict syntax.

This pattern underlies the **atomic JSON write** (with a `.bak`
backup) technique used in 4R022's archive and settings systems.

## CSV — Tabular Data

```python
# ✅ This code works — writing to CSV
import csv
with open("grades.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "grade"])
    writer.writerow(["Kaan", 95])
    writer.writerow(["Ayse", 88])
```

```python
# ✅ This code works — reading CSV
import csv
with open("grades.csv", "r", encoding="utf-8") as f:
    for row in csv.reader(f):
        print(row)
```

```python
# ❌ This does NOT work (on Windows) — forgetting 'newline=""' leads
# to extra blank rows appearing between lines in the CSV file
# (this is a sneaky formatting bug, not a runtime crash):
with open("grades.csv", "w", encoding="utf-8") as f:   # newline="" is missing!
    writer = csv.writer(f)
    writer.writerows([["name", "grade"], ["Kaan", 95]])
```

### 🎯 Mini Exercise
Write a program that saves a list of students (`name`, `grade`) as
both JSON and CSV, then reads them back and computes the average.

---
⬅️ [Decorators and Generators](./02-Decorators-and-Generators.md) &nbsp;|&nbsp; ➡️ [Modules, Packages, Virtual Environments](./04-Modules-Packages-Virtual-Environments.md)
