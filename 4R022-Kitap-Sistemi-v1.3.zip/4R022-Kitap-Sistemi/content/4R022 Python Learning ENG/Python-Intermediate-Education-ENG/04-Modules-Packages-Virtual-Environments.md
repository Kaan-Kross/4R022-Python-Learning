# 4. Modules, Packages, and Virtual Environments

## What Is a Module?

Any `.py` file is a **module**. Splitting code into files keeps a
project organized and reusable.

```python
# ✅ This code works — file: math_utils.py
def add(a, b):
    return a + b

def multiply(a, b):
    return a * b
```

```python
# ✅ This code works — importing it in main.py
import math_utils
print(math_utils.add(3, 4))   # 7

from math_utils import add
print(add(1, 2))               # 3
```

```python
# ❌ This code does NOT work — the filename has a typo
import mathutilss
```

This raises `ModuleNotFoundError: No module named 'mathutilss'`.

## What Is a Package?

A **package** is a folder containing an `__init__.py` file, grouping
multiple modules together.

```
project/
├── main.py
└── helpers/
    ├── __init__.py
    ├── math_utils.py
    └── text_utils.py
```

```python
# ✅ This code works
from helpers import math_utils
from helpers.text_utils import to_uppercase
```

This layout underlies the `core/` + `ui/` modular architecture used
in 4R022's PyQt6 projects.

## Managing Packages with pip

```bash
# ✅ These commands work
pip install requests
pip freeze > requirements.txt
pip install -r requirements.txt
```

## Why Virtual Environments?

A virtual environment gives each project its own isolated set of
installed packages — so `flask==2.0` in one project doesn't clash
with `flask==3.0` in another.

```bash
# ✅ These commands work (in the project folder)
python -m venv venv

# Activate on Windows:
venv\Scripts\activate

# Activate on macOS / Linux:
source venv/bin/activate

pip install requests   # only affects this environment now
```

```bash
# ❌ This does NOT work — using the wrong activation command for
# the OS (a very common mistake):
source venv/bin/activate    # this is a Linux/macOS command, not recognized in Windows cmd
```

On Windows `cmd`, the correct command is `venv\Scripts\activate` (or
`venv\Scripts\Activate.ps1` in PowerShell).

### 🎯 Mini Exercise
Create a `shapes.py` module with functions to compute a circle's and
a square's area, then import and use it from `main.py`. Then set up
a virtual environment and install `requests` into it.

---
⬅️ [JSON and CSV](./03-JSON-and-CSV.md) &nbsp;|&nbsp; ➡️ [Testing and Debugging](./05-Testing-and-Debugging.md)
