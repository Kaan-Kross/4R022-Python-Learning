# 2. Decorators and Generators

## What Is a Decorator?

A decorator is a function that "wraps" another function, extending
or modifying its behavior.

```python
# ✅ This code works
import time

def time_it(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end - start:.4f} seconds")
        return result
    return wrapper

@time_it
def slow_task():
    time.sleep(1)
    return "done"

slow_task()
```

`@time_it` is shorthand for `slow_task = time_it(slow_task)`.

```python
# ❌ This code does NOT work — the inner function doesn't return a
# value, so the decorated function's actual result is lost:
def logger(func):
    def wrapper(*args, **kwargs):
        func(*args, **kwargs)   # 'return' was forgotten!
    return wrapper

@logger
def multiply(a, b):
    return a * b

result = multiply(3, 4)
print(result)   # prints None, NOT 12
```

## What Is a Generator (`yield`)?

A normal function ends with `return` and puts its entire result in
memory at once. A **generator** produces values **one at a time**,
on demand, using `yield` — saving memory on large data sets.

```python
# ✅ This code works
def generate_squares(n):
    for i in range(n):
        yield i * i

for square in generate_squares(5):
    print(square)   # 0, 1, 4, 9, 16 — produced one at a time
```

```python
# ✅ This code works — generator expression, parentheses instead of brackets
squares = (x * x for x in range(1_000_000))
print(next(squares))   # 0 — only the requested value is computed
print(next(squares))   # 1
```

```python
# ❌ This code loads millions of elements into memory IMMEDIATELY —
# far more memory-hungry than the generator above:
squares_list = [x * x for x in range(10_000_000)]  # the whole list is in memory!
```

The code above "works" but can cause serious memory problems with
large or unbounded data — that's why generators are preferred there.

### 🎯 Mini Exercise
Write a `fibonacci(n)` generator function that `yield`s the first
`n` Fibonacci numbers one at a time.

---
⬅️ [Advanced OOP](./01-Advanced-OOP.md) &nbsp;|&nbsp; ➡️ [JSON and CSV](./03-JSON-and-CSV.md)
