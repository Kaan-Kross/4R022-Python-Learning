# Python Intermediate Education (EN)

Once you've finished the Basic level, this tier moves closer to real
projects: advanced OOP, decorators/generators, data formats, package
management, and testing.

## Chapters

1. [Advanced Object-Oriented Programming](./01-Advanced-OOP.md)
2. [Decorators and Generators](./02-Decorators-and-Generators.md)
3. [Data Formats: JSON and CSV](./03-JSON-and-CSV.md)
4. [Modules, Packages, and Virtual Environments](./04-Modules-Packages-Virtual-Environments.md)
5. [Testing and Debugging](./05-Testing-and-Debugging.md)

Next ➡️ [Advanced Level](../Python-Advanced-Education-ENG/README.md)
