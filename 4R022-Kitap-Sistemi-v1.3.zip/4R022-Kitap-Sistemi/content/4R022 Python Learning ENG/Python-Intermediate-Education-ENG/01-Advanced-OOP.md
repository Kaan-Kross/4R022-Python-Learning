# 1. Advanced Object-Oriented Programming

## `@property` for Controlled Access

```python
# ✅ This code works
class Rectangle:
    def __init__(self, width, height):
        self._width = width
        self._height = height

    @property
    def area(self):
        return self._width * self._height

r = Rectangle(4, 5)
print(r.area)   # 20 — defined like a method, accessed like an attribute (no parentheses!)
```

```python
# ❌ This code does NOT work — a property can't be called with parentheses
print(r.area())
```

This raises `TypeError: 'int' object is not callable` because
`r.area` is already a computed value, not a function.

## Special (Dunder) Methods

```python
# ✅ This code works — __str__ and __eq__ customize object behavior
class Point:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __str__(self):
        return f"Point({self.x}, {self.y})"

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

p1 = Point(1, 2)
p2 = Point(1, 2)
print(p1)          # Point(1, 2) — thanks to __str__
print(p1 == p2)    # True — thanks to __eq__
```

```python
# ❌ This behaves differently — without __eq__, Python defaults to
# checking "is this the same object in memory?", so this returns
# False (a logic surprise, not a syntax error):
class PlainPoint:
    def __init__(self, x, y):
        self.x, self.y = x, y

a = PlainPoint(1, 2)
b = PlainPoint(1, 2)
print(a == b)   # False! (no __eq__ defined)
```

## Multiple Inheritance and `super()`

```python
# ✅ This code works
class Employee:
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary

class Developer(Employee):
    def __init__(self, name, salary, language):
        super().__init__(name, salary)   # calls the parent's __init__
        self.language = language

d = Developer("Kaan", 50000, "Python")
print(d.name, d.salary, d.language)
```

## Abstract Base Classes

```python
# ✅ This code works
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

class Square(Shape):
    def __init__(self, side):
        self.side = side

    def area(self):
        return self.side ** 2

print(Square(4).area())   # 16
```

```python
# ❌ This code does NOT work — an abstract class can't be instantiated directly
shape = Shape()
```

This raises `TypeError: Can't instantiate abstract class Shape with
abstract method area`. That's exactly the point of `ABC`: it forces
subclasses to implement specific methods.

---
⬅️ [Back](./README.md) &nbsp;|&nbsp; ➡️ [Decorators and Generators](./02-Decorators-and-Generators.md)
