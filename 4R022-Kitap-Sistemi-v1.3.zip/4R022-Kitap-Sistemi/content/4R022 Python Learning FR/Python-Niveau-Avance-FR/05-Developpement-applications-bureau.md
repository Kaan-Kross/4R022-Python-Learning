# 5. Développement professionnel d'applications de bureau (PyQt6)

## Pourquoi PyQt6 plutôt que Tkinter ?

`tkinter` est inclus dans la bibliothèque standard, rapide pour de
petits outils. `PyQt6` offre une apparence plus moderne, une
architecture signal/slot et une base plus solide pour les grandes
applications — c'est pourquoi la plupart des produits de bureau
4R022 sont écrits avec.

## Une application PyQt6 minimale

```python
# ✅ Ce code fonctionne (si PyQt6 est installé : pip install PyQt6)
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout

class FenetrePrincipale(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Exemple 4R022")
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Bonjour, 4R022 Python Learning !"))
        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    fenetre = FenetrePrincipale()
    fenetre.show()
    sys.exit(app.exec())
```

```python
# ❌ Ce code NE FONCTIONNE PAS — afficher une fenêtre avant QApplication
fenetre = FenetrePrincipale()
fenetre.show()
# RuntimeError: Please create QApplication before QWidget
```

## Architecture recommandée : `core/` + `ui/`

```
projet/
├── main.py
├── core/     # logique métier, indépendante de l'interface
└── ui/       # affichage et interaction uniquement
```

## Empaquetage avec PyInstaller

```bash
pip install pyinstaller
pyinstaller --onefile --windowed main.py
```

### 🎯 Mini-exercice
Écris une petite application PyQt6 avec un champ de texte
(`QLineEdit`) et un bouton qui affiche le texte saisi dans un `QLabel`.

---
⬅️ [Patrons de conception](./04-Patrons-de-conception.md) &nbsp;|&nbsp; ➡️ [GUI, UI/UX et multiplateforme](./06-GUI-UI-UX-et-multiplateforme.md)
