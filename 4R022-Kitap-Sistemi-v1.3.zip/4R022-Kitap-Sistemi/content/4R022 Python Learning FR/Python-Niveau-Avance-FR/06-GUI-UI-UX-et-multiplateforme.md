# 6. GUI, UI/UX et interfaces multiplateformes

## UI et UX : quelle différence ?

**UI (interface utilisateur)** : ce que l'utilisateur voit et
touche. **UX (expérience utilisateur)** : ce que l'utilisateur
**ressent** en l'utilisant. Une appli qui a l'air jolie (bon UI)
peut quand même être difficile à utiliser (mauvais UX).

## Obtenir la taille de l'écran (multiplateforme)

```python
# ✅ Ce code fonctionne — sur Windows, Linux ET macOS
import tkinter as tk
temp = tk.Tk()
largeur = temp.winfo_screenwidth()
hauteur = temp.winfo_screenheight()
temp.destroy()
print(f"Écran : {largeur}x{hauteur}")
```

```python
# ✅ Ce code fonctionne — UNIQUEMENT sur Windows (via ctypes)
import ctypes
user32 = ctypes.windll.user32
largeur = user32.GetSystemMetrics(0)
hauteur = user32.GetSystemMetrics(1)
```

```python
# ❌ Ce code NE FONCTIONNE PAS (uniquement sur Windows, plante sur Linux/macOS)
import ctypes
largeur = ctypes.windll.user32.GetSystemMetrics(0)   # 'windll' est spécifique à Windows !
```

- **Pourquoi est-ce faux ?** `ctypes.windll` n'existe que sur Windows.
- **Où est l'erreur ?** `AttributeError: module 'ctypes' has no
  attribute 'windll'` sur Linux/macOS.
- **Que faire à la place ?** Préférer une méthode indépendante de la
  plateforme comme `tkinter.winfo_screenwidth()`.

## Fenêtre de sélection de fichier

```python
# ✅ Ce code fonctionne — Tkinter
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()
chemin = filedialog.askopenfilename(
    title="Choisir une image",
    filetypes=[("Fichiers image", "*.png *.jpg *.jpeg")]
)
```

```python
# ✅ Ce code fonctionne — PyQt6
from PyQt6.QtWidgets import QApplication, QFileDialog
import sys

app = QApplication(sys.argv)
chemin, _ = QFileDialog.getOpenFileName(None, "Choisir une image", "", "Images (*.png *.jpg)")
```

## Conseils généraux pour le développement multiplateforme

- Utilise `sys.platform` pour protéger le code spécifique à une plateforme.
- Préfère les API multiplateformes de `tkinter`/`PyQt6` autant que possible.
- **Teste réellement** sur plusieurs OS.

### 🎯 Mini-exercice
Écris une petite application (Tkinter ou PyQt6) qui s'ouvre centrée
sur l'écran, avec un bouton « Choisir un fichier » qui affiche
l'image sélectionnée.

---
⬅️ [Développement d'applications de bureau](./05-Developpement-applications-bureau.md) &nbsp;|&nbsp; ➡️ [Passer aux concepts de données](../Python-Concepts-de-Donnees-FR/README.md)

🎉 **Félicitations — tu as terminé le niveau avancé !**
