# 2. Concepts de POO avancés

## Écrire son propre gestionnaire de contexte

```python
# ✅ Ce code fonctionne
class ConnexionBD:
    def __enter__(self):
        print("Connexion ouverte")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        print("Connexion fermée")
        return False

with ConnexionBD() as conn:
    print("Exécution de la requête...")
```

Version plus courte avec `contextlib` :

```python
# ✅ Ce code fonctionne
from contextlib import contextmanager

@contextmanager
def connexion_bd():
    print("Connexion ouverte")
    yield "objet_connexion"
    print("Connexion fermée")

with connexion_bd() as c:
    print("Exécution de la requête...")
```

## Optimisation mémoire avec `__slots__`

```python
# ✅ Ce code fonctionne
class Point:
    __slots__ = ("x", "y")

    def __init__(self, x, y):
        self.x = x
        self.y = y

p = Point(1, 2)
```

```python
# ❌ Ce code NE FONCTIONNE PAS — affectation à un attribut non listé
p.z = 5
```

Cela lève `AttributeError: 'Point' object has no attribute 'z'`.

## Métaclasses — la classe d'une classe

```python
# ✅ Ce code fonctionne
class MetaLog(type):
    def __new__(mcs, nom, bases, namespace):
        print(f"Création de la classe : {nom}")
        return super().__new__(mcs, nom, bases, namespace)

class Exemple(metaclass=MetaLog):
    pass
```

> 🧑‍🏫 **Note du professeur :** les métaclasses sont rarement
> nécessaires au quotidien — surtout utilisées dans les grands
> frameworks comme Django et SQLAlchemy.

### 🎯 Mini-exercice
Écris ton propre gestionnaire de contexte pour automatiser
l'ouverture et la fermeture d'un fichier.

---
⬅️ [Concurrence](./01-Concurrence.md) &nbsp;|&nbsp; ➡️ [Performance et optimisation](./03-Performance-et-optimisation.md)
