# 3. Performance et optimisation

## Ne pas optimiser sans mesurer !

> 🧑‍🏫 **Règle d'or :** « Mesure d'abord, optimise ensuite. »

```python
import timeit
duree = timeit.timeit("sum(range(1000))", number=10000)
print(duree)
```

## Mise en cache avec `functools.lru_cache`

```python
# ❌ Ce code FONCTIONNE mais est TRÈS LENT
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
```

```python
# ✅ Ce code fonctionne — mise en cache des résultats
from functools import lru_cache

@lru_cache(maxsize=None)
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(35))   # instantané
```

## `join()` pour concaténer des chaînes

```python
# ❌ Ce code FONCTIONNE mais est LENT dans les grandes boucles
resultat = ""
for mot in ["Python", "est", "rapide"]:
    resultat += mot + " "
```

```python
# ✅ Ce code fonctionne — bien plus performant
resultat = " ".join(["Python", "est", "rapide"])
```

### 🎯 Mini-exercice
Écris `fibonacci` avec `@lru_cache` et avec une boucle `for`
classique, compare leur vitesse avec `timeit`.

---
⬅️ [Concepts POO avancés](./02-Concepts-POO-avances.md) &nbsp;|&nbsp; ➡️ [Patrons de conception](./04-Patrons-de-conception.md)
