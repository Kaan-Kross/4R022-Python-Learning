# 4. Patrons de conception

## 1. Singleton — « un seul objet »

```python
# ✅ Ce code fonctionne
class Parametres:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.theme = "sombre"
        return cls._instance

p1 = Parametres()
p2 = Parametres()
print(p1 is p2)   # True — le MÊME objet
```

## 2. Factory — « producteur d'objets »

```python
# ✅ Ce code fonctionne
class Chien:
    def son(self):
        return "Ouaf"

class Chat:
    def son(self):
        return "Miaou"

def creer_animal(type_):
    if type_ == "chien":
        return Chien()
    elif type_ == "chat":
        return Chat()
    raise ValueError(f"Type inconnu : {type_}")
```

## 3. Observer — « observateur »

```python
# ✅ Ce code fonctionne
class Editeur:
    def __init__(self):
        self._abonnes = []

    def ajouter_abonne(self, fonction):
        self._abonnes.append(fonction)

    def notifier(self, donnees):
        for abonne in self._abonnes:
            abonne(donnees)

def afficher(donnees):
    print("Nouvelles données :", donnees)

editeur = Editeur()
editeur.ajouter_abonne(afficher)
editeur.notifier("Bonjour !")
```

Le système signal/slot de PyQt6 en est une implémentation prête à l'emploi.

### 🎯 Mini-exercice
Écris une classe Singleton `Journal` qui écrit dans le même fichier
de log depuis n'importe où dans l'application.

---
⬅️ [Performance et optimisation](./03-Performance-et-optimisation.md) &nbsp;|&nbsp; ➡️ [Développement d'applications de bureau](./05-Developpement-applications-bureau.md)
