# Python Niveau Avancé (FR)

Ce niveau s'adresse à ceux qui veulent créer des logiciels réels,
performants et professionnels. On n'apprend plus le langage
lui-même — on apprend à construire du **logiciel professionnel** avec.

## Chapitres

1. [Concurrence : Threading, Multiprocessing, Asyncio](./01-Concurrence.md)
2. [POO avancée : gestionnaires de contexte, `__slots__`, métaclasses](./02-Concepts-POO-avances.md)
3. [Performance et optimisation](./03-Performance-et-optimisation.md)
4. [Patrons de conception](./04-Patrons-de-conception.md)
5. [Développement professionnel d'applications de bureau (PyQt6)](./05-Developpement-applications-bureau.md)
6. [GUI, UI/UX et interfaces multiplateformes](./06-GUI-UI-UX-et-multiplateforme.md)

Suite ➡️ [Concepts de données](../Python-Concepts-de-Donnees-FR/README.md)
