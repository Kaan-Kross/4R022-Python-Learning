# 1. Concurrence : Threading, Multiprocessing, Asyncio

## Pourquoi est-ce nécessaire ?

Certaines tâches impliquent **d'attendre** (requêtes réseau, E/S
fichier) ; d'autres sont **gourmandes en calcul** (traitement
d'image, maths). Ces deux situations demandent des outils différents.

## `threading` — pour les tâches liées aux E/S

```python
# ✅ Ce code fonctionne
import threading, time

def telecharger(numero):
    print(f"Téléchargement du fichier {numero}...")
    time.sleep(2)
    print(f"Fichier {numero} terminé.")

threads = [threading.Thread(target=telecharger, args=(i,)) for i in range(3)]
for t in threads: t.start()
for t in threads: t.join()
print("Tous les téléchargements sont terminés.")
```

## Le GIL (Global Interpreter Lock) — une limitation importante

```python
# ❌ Ceci est PLUS LENT QUE PRÉVU — à cause du GIL dans CPython,
# threading n'offre aucun vrai parallélisme pour un travail gourmand
# en CPU (un seul thread exécute du code Python à la fois) :
import threading

def calcul_lourd():
    total = 0
    for i in range(50_000_000):
        total += i

threads = [threading.Thread(target=calcul_lourd) for _ in range(4)]
for t in threads: t.start()
for t in threads: t.join()
# À peine plus rapide qu'avec un seul thread !
```

Pour un travail gourmand en CPU, le bon outil est `multiprocessing` —
chaque processus a son propre interpréteur Python (et son propre GIL).

```python
# ✅ Ce code fonctionne — vrai parallélisme (plusieurs cœurs CPU)
import multiprocessing

def calculer(limite):
    return sum(range(limite))

if __name__ == "__main__":
    with multiprocessing.Pool(4) as pool:
        resultats = pool.map(calculer, [10_000_000] * 4)
    print(resultats)
```

## `asyncio` — pour de nombreuses tâches d'attente

```python
# ✅ Ce code fonctionne — gère efficacement des centaines de requêtes réseau
import asyncio

async def recuperer(id_no):
    print(f"Requête {id_no} démarrée")
    await asyncio.sleep(1)
    print(f"Requête {id_no} terminée")
    return id_no

async def main():
    taches = [recuperer(i) for i in range(5)]
    resultats = await asyncio.gather(*taches)
    print(resultats)

asyncio.run(main())
```

```python
# ❌ Ce code NE FONCTIONNE PAS — 'await' utilisé hors d'une fonction async
def fonction_normale():
    await asyncio.sleep(1)   # SyntaxError: 'await' outside async function
```

## Quel outil, quand ?

| Scénario | Bon outil |
|---|---|
| Téléchargement de fichier, requête API (attente, peu de tâches) | `threading` |
| Centaines de requêtes réseau simultanées | `asyncio` |
| Traitement d'image, maths lourdes (lié au CPU) | `multiprocessing` |

---
⬅️ [Retour](./README.md) &nbsp;|&nbsp; ➡️ [Concepts POO avancés](./02-Concepts-POO-avances.md)
