# Module `csv`

## Qu'est-ce que c'est et comment ça marche ?

Lit et écrit des données tabulaires en gérant correctement
séparateurs, guillemets et fins de ligne.

## ✅ Exemples fonctionnels

```python
import csv
with open("notes.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["nom", "note"])
    writer.writerow(["Kaan", 95])
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `newline=""` oublié (Windows)

```python
with open("notes.csv", "w", encoding="utf-8") as f:
    writer = csv.writer(f)
```
- **Pourquoi est-ce faux ?** Lignes vides supplémentaires sur Windows.
- **Où est l'erreur ?** `newline=""` manque dans `open()`.
- **Que faire à la place ?** `open("notes.csv", "w", newline="", encoding="utf-8")`

### Exemple incorrect 2 — `split(",")` manuel avec virgules internes

```python
ligne = 'Kaan,"Paris, France",95'
parties = ligne.split(",")   # découpe en 4 au lieu de 3 !
```
- **Pourquoi est-ce faux ?** La virgule entre guillemets est aussi
  traitée comme séparateur.
- **Où est l'erreur ?** Pas de gestion des guillemets.
- **Que faire à la place ?** Utiliser `csv.reader()`.

## 🔗 Modules associés
[json](../03-json/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Accueil des modules](../README.md)
