# Module `socket`

> ⚠️ Base de la programmation réseau — usage légal uniquement.

## Qu'est-ce que c'est et comment ça marche ?

Accès direct à la couche réseau de l'OS — connexions TCP/UDP brutes.

## ✅ Exemples fonctionnels

```python
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("localhost", 5000))
s.listen(1)
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — port nécessitant des droits admin

```python
s.bind(("localhost", 80))
```
- **Pourquoi est-ce faux ?** Les ports < 1024 nécessitent des privilèges.
- **Où est l'erreur ?** `PermissionError`
- **Que faire à la place ?** Utiliser un port > 1024 (ex. 8080).

### Exemple incorrect 2 — confusion str/bytes

```python
conn.send("Bonjour")   # str, pas bytes !
```
- **Pourquoi est-ce faux ?** `send()` n'accepte que des bytes.
- **Où est l'erreur ?** `TypeError`
- **Que faire à la place ?** `conn.send("Bonjour".encode())`

## 🔗 Modules associés
[threading](../12-threading/README.md)

---
⬅️ [Accueil des modules](../README.md)
