# Module `collections`

## Qu'est-ce que c'est et comment ça marche ?

Versions spécialisées de `list`/`dict` : `Counter`, `deque`,
`defaultdict`, `namedtuple`.

## ✅ Exemples fonctionnels

```python
from collections import Counter, defaultdict
c = Counter("pomme poire pomme".split())
print(c.most_common(1))
g = defaultdict(list)
g["fruits"].append("pomme")
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — ajout à une clé absente dans un dict normal

```python
g = {}
g["fruits"].append("pomme")
```
- **Pourquoi est-ce faux ?** La clé n'existe pas encore.
- **Où est l'erreur ?** `KeyError: 'fruits'`
- **Que faire à la place ?** Utiliser `defaultdict(list)`.

### Exemple incorrect 2 — modifier un `namedtuple`

```python
from collections import namedtuple
Point = namedtuple("Point", ["x", "y"])
p = Point(1, 2)
p.x = 5
```
- **Pourquoi est-ce faux ?** Les namedtuples sont immuables.
- **Où est l'erreur ?** `AttributeError: can't set attribute`
- **Que faire à la place ?** `p._replace(x=5)` crée un nouvel objet.

## 🔗 Modules associés
[itertools et functools](../09-itertools-et-functools/README.md)

---
⬅️ [Accueil des modules](../README.md)
