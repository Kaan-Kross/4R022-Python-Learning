# Module `PyQt6`

## Qu'est-ce que c'est et comment ça marche ?

Interface Python pour Qt6, avec une architecture signal/slot :
un événement (signal) déclenche automatiquement une fonction connectée (slot).

## ✅ Exemples fonctionnels

```python
import sys
from PyQt6.QtWidgets import QApplication, QWidget
app = QApplication(sys.argv)
window = QWidget()
window.show()
sys.exit(app.exec())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — widget avant QApplication

```python
window = QWidget()   # QApplication pas encore créé !
app = QApplication(sys.argv)
```
- **Pourquoi est-ce faux ?** QApplication doit être créé en premier.
- **Où est l'erreur ?** Mauvais ordre des appels.
- **Que faire à la place ?** Créer `app` d'abord.

### Exemple incorrect 2 — signal avec parenthèses

```python
button.clicked.connect(clic())   # parenthèses !
```
- **Pourquoi est-ce faux ?** La fonction s'exécute immédiatement.
- **Où est l'erreur ?** `None` est passé au lieu de la fonction.
- **Que faire à la place ?** `button.clicked.connect(clic)`

## 🔗 Modules associés
[tkinter](../21-tkinter/README.md)

---
⬅️ [Accueil des modules](../README.md)
