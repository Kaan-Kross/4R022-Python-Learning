# Python : Modules et utilisations (FR)

Une bibliothèque de référence répondant à « quel module utiliser
pour cette tâche ? » — **un dossier par module.** Chaque dossier couvre :

- 📖 Ce qu'est le module et son **principe de fonctionnement**
- 🎯 Pourquoi, quand et où il est utilisé
- ✅ Plusieurs exemples de code fonctionnels
- ❌ Plusieurs exemples **incorrects/défectueux** — chacun avec :
  **« pourquoi est-ce faux ? où est l'erreur ? que faire à la place ? »**
- 🔗 Liens vers les modules associés

## 🟢 Bibliothèque standard (aucune installation nécessaire)

| Module | Utilité |
|---|---|
| [os](./01-os/README.md) | Interaction avec l'OS, fichiers/dossiers |
| [sys](./02-sys/README.md) | Interaction avec l'interpréteur, arguments de ligne de commande |
| [json](./03-json/README.md) | Lecture/écriture de données JSON |
| [csv](./04-csv/README.md) | Lecture/écriture de données CSV |
| [datetime](./05-datetime/README.md) | Gestion des dates et heures |
| [math et random](./06-math-et-random/README.md) | Opérations mathématiques, nombres aléatoires |
| [re (expressions régulières)](./07-re-expressions-regulieres/README.md) | Recherche/remplacement par motif |
| [collections](./08-collections/README.md) | Structures de données avancées |
| [itertools et functools](./09-itertools-et-functools/README.md) | Outils pour boucles et fonctions |
| [pathlib](./10-pathlib/README.md) | Gestion moderne des chemins de fichiers |
| [logging](./11-logging/README.md) | Journalisation professionnelle |
| [threading](./12-threading/README.md) | Multithreading (tâches liées aux E/S) |
| [multiprocessing](./13-multiprocessing/README.md) | Multiprocessing (tâches liées au CPU) |
| [asyncio](./14-asyncio/README.md) | Programmation asynchrone |
| [sqlite3](./15-sqlite3/README.md) | Base de données légère intégrée |
| [queue](./27-queue/README.md) | File d'attente thread-safe |
| [tempfile](./28-tempfile/README.md) | Gestion de fichiers/dossiers temporaires |
| [hashlib](./30-hashlib/README.md) | Fonctions de hachage |
| [shutil](./31-shutil/README.md) | Opérations fichiers/dossiers de haut niveau |
| [subprocess](./32-subprocess/README.md) | Exécution de commandes/programmes externes |
| [enum](./33-enum/README.md) | Constantes nommées lisibles |
| [dataclasses](./34-dataclasses/README.md) | Classes de données avec moins de code |
| [typing](./35-typing/README.md) | Annotations de type |
| [argparse](./36-argparse/README.md) | Interfaces de ligne de commande professionnelles |
| [unittest et pytest](./26-unittest-et-pytest/README.md) | Tests automatisés |

## 🔵 Bibliothèques tierces populaires (`pip install` requis)

| Module | Utilité |
|---|---|
| [requests](./16-requests/README.md) | Requêtes HTTP, API externes |
| [Flask et FastAPI](./17-flask-et-fastapi/README.md) | Serveur web / API |
| [numpy](./18-numpy/README.md) | Opérations rapides sur tableaux numériques |
| [pandas](./19-pandas/README.md) | Analyse de données tabulaires |
| [matplotlib](./20-matplotlib/README.md) | Graphiques et visualisation |
| [tkinter](./21-tkinter/README.md) | Bibliothèque GUI standard |
| [PyQt6](./22-PyQt6/README.md) | Bibliothèque GUI professionnelle |
| [selenium](./23-selenium/README.md) | Automatisation de navigateur |
| [socket](./24-socket/README.md) | Programmation réseau bas niveau |
| [cryptography](./25-cryptography/README.md) | Chiffrement et sécurité des données |
| [qrcode](./29-qrcode/README.md) | Génération de QR codes |

N'oublie pas [Éthique et Sécurité](../Python-Ethique-et-Securite-FR/README.md) pour les limites légales et éthiques.

⬅️ [Concepts de données](../Python-Concepts-de-Donnees-FR/README.md) &nbsp;|&nbsp; ➡️ [Éthique et Sécurité](../Python-Ethique-et-Securite-FR/README.md)
