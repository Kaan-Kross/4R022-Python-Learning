# Module `cryptography`

## Qu'est-ce que c'est et comment ça marche ?

Bibliothèque de chiffrement fiable utilisant des algorithmes
éprouvés (AES, Fernet) plutôt qu'une implémentation maison.

## ✅ Exemples fonctionnels

```python
from cryptography.fernet import Fernet
cle = Fernet.generate_key()
f = Fernet(cle)
chiffre = f.encrypt(b"secret")
print(f.decrypt(chiffre).decode())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — nouvelle clé à chaque exécution

```python
f2 = Fernet(Fernet.generate_key())   # clé différente !
f2.decrypt(chiffre)
```
- **Pourquoi est-ce faux ?** Les clés de chiffrement et déchiffrement doivent être identiques.
- **Où est l'erreur ?** `InvalidToken`
- **Que faire à la place ?** Sauvegarder et réutiliser la même clé.

### Exemple incorrect 2 — clé codée en dur dans le code

```python
CLE = b"gAAAAA...(vraie clé)..."
```
- **Pourquoi est-ce faux ?** Fuite si publié sur GitHub.
- **Où est l'erreur ?** Clé intégrée au code source.
- **Que faire à la place ?** Stocker dans une variable d'environnement.

## 🔗 Modules associés
[hashlib](../30-hashlib/README.md)

---
⬅️ [Accueil des modules](../README.md)
