# Module `shutil`

## Qu'est-ce que c'est et comment ça marche ?

Opérations fichiers/dossiers de haut niveau : copie, déplacement,
suppression complète, archivage.

## ✅ Exemples fonctionnels

```python
import shutil
shutil.copy("a.txt", "b.txt")
shutil.rmtree("dossier_plein")
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — copier un dossier avec `copy()`

```python
shutil.copy("dossier1", "dossier2")
```
- **Pourquoi est-ce faux ?** `copy()` est seulement pour les fichiers.
- **Où est l'erreur ?** `IsADirectoryError`
- **Que faire à la place ?** `shutil.copytree()`

### Exemple incorrect 2 — croire `rmtree()` réversible

```python
shutil.rmtree("donnees_importantes")
```
- **Pourquoi est-ce faux ?** Suppression permanente, sans corbeille.
- **Où est l'erreur ?** Aucun mécanisme d'annulation.
- **Que faire à la place ?** Sauvegarder avant de supprimer.

## 🔗 Modules associés
[os](../01-os/README.md)

---
⬅️ [Accueil des modules](../README.md)
