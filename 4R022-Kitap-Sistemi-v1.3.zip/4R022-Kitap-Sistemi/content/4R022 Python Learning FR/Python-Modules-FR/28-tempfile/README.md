# Module `tempfile`

## Qu'est-ce que c'est et comment ça marche ?

Crée automatiquement des fichiers/dossiers temporaires uniques,
généralement supprimés à la fin du programme.

## ✅ Exemples fonctionnels

```python
import tempfile
with tempfile.NamedTemporaryFile(mode="w") as f:
    f.write("donnees")
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — accès après fermeture (delete=True)

```python
f = tempfile.NamedTemporaryFile(mode="w", delete=True)
f.close()
open(f.name)   # déjà supprimé !
```
- **Pourquoi est-ce faux ?** Le fichier est supprimé dès sa fermeture.
- **Où est l'erreur ?** `FileNotFoundError`
- **Que faire à la place ?** Utiliser `delete=False`.

### Exemple incorrect 2 — accès depuis un autre processus (Windows)

```python
f = tempfile.NamedTemporaryFile(mode="w")
open(f.name, "r")   # peut échouer sur Windows
```
- **Pourquoi est-ce faux ?** Windows bloque l'accès simultané.
- **Où est l'erreur ?** `PermissionError`
- **Que faire à la place ?** Utiliser `delete=False` pour un accès croisé.

## 🔗 Modules associés
[os](../01-os/README.md)

---
⬅️ [Accueil des modules](../README.md)
