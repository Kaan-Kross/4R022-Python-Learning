# Module `hashlib`

## Qu'est-ce que c'est et comment ça marche ?

Transforme des données en une empreinte (hash) à sens unique de
longueur fixe (MD5, SHA-256, etc.).

## ✅ Exemples fonctionnels

```python
import hashlib
print(hashlib.sha256("texte".encode()).hexdigest())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — stocker des mots de passe avec MD5

```python
h = hashlib.md5("123456".encode()).hexdigest()
```
- **Pourquoi est-ce faux ?** MD5 est rapide et cassé — mauvais pour les mots de passe.
- **Où est l'erreur ?** Mauvais outil pour un contexte de sécurité.
- **Que faire à la place ?** Utiliser `bcrypt`/`argon2`.

### Exemple incorrect 2 — hacher une chaîne directement

```python
hashlib.sha256("bonjour")
```
- **Pourquoi est-ce faux ?** Les fonctions n'acceptent que des bytes.
- **Où est l'erreur ?** `TypeError`
- **Que faire à la place ?** `.encode()` avant le hachage.

## 🔗 Modules associés
[cryptography](../25-cryptography/README.md)

---
⬅️ [Accueil des modules](../README.md)
