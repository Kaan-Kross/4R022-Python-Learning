# Module `multiprocessing`

## Qu'est-ce que c'est et comment ça marche ?

Lance des processus indépendants avec leur propre mémoire et GIL —
vrai parallélisme pour le CPU.

## ✅ Exemples fonctionnels

```python
import multiprocessing
def carre(n): return n*n
if __name__ == "__main__":
    with multiprocessing.Pool(4) as p:
        print(p.map(carre, [1,2,3,4]))
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `if __name__ == "__main__":` oublié (Windows)

```python
pool = multiprocessing.Pool(4)
print(pool.map(carre, [1,2,3]))
```
- **Pourquoi est-ce faux ?** Sur Windows, chaque processus réimporte le script.
- **Où est l'erreur ?** Pas de protection `__main__`.
- **Que faire à la place ?** Encapsuler dans `if __name__ == "__main__":`

### Exemple incorrect 2 — partager une variable normale entre processus

```python
compteur = 0
def incrementer():
    global compteur
    compteur += 1
if __name__ == "__main__":
    p = multiprocessing.Process(target=incrementer)
    p.start(); p.join()
    print(compteur)   # toujours 0 !
```
- **Pourquoi est-ce faux ?** Chaque processus a sa propre mémoire.
- **Où est l'erreur ?** `global` n'affecte que la copie du processus.
- **Que faire à la place ?** Utiliser `multiprocessing.Queue` ou `Manager()`.

## 🔗 Modules associés
[threading](../12-threading/README.md)

---
⬅️ [Accueil des modules](../README.md)
