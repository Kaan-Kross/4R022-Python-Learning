# Module `enum`

## Qu'est-ce que c'est et comment ça marche ?

Définit un ensemble fixe de constantes nommées, plus lisible et
plus sûr que des chaînes/nombres bruts.

## ✅ Exemples fonctionnels

```python
from enum import Enum
class Statut(Enum):
    ATTENTE = 1
    TERMINE = 2
print(Statut.ATTENTE.name)
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — comparaison avec un nombre brut

```python
if Statut.ATTENTE == 1:
    print("en attente")
```
- **Pourquoi est-ce faux ?** Un membre Enum n'est pas égal à un nombre brut.
- **Où est l'erreur ?** Renvoie `False`, sans erreur visible.
- **Que faire à la place ?** `Statut.ATTENTE == Statut.ATTENTE`

### Exemple incorrect 2 — deux membres avec la même valeur

```python
class Couleur(Enum):
    ROUGE = 1
    ECARLATE = 1   # même valeur !
print(Couleur.ROUGE is Couleur.ECARLATE)   # True, inattendu
```
- **Pourquoi est-ce faux ?** Les valeurs identiques créent un alias, pas un nouveau membre.
- **Où est l'erreur ?** `ECARLATE` est juste un autre nom pour `ROUGE`.
- **Que faire à la place ?** Donner des valeurs différentes, ou utiliser `@enum.unique`.

## 🔗 Modules associés
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Accueil des modules](../README.md)
