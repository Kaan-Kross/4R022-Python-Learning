# Module `datetime`

## Qu'est-ce que c'est et comment ça marche ?

Représente, compare et formate dates et heures correctement — base
des rappels/alarmes (projet 4R022 SAAT).

## ✅ Exemples fonctionnels

```python
from datetime import datetime, timedelta
maintenant = datetime.now()
print(maintenant.strftime("%d/%m/%Y %H:%M"))
rappel = maintenant + timedelta(hours=2)
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — format incompatible

```python
date = datetime.strptime("2026-09-15", "%d/%m/%Y")
```
- **Pourquoi est-ce faux ?** Le format ne correspond pas à la chaîne réelle.
- **Où est l'erreur ?** Mauvais séparateur/ordre.
- **Que faire à la place ?** `datetime.strptime("2026-09-15", "%Y-%m-%d")`

### Exemple incorrect 2 — comparaison datetime/string

```python
d1 = datetime.now()
d2 = "2026-09-15"
print(d1 > d2)
```
- **Pourquoi est-ce faux ?** Types incompatibles.
- **Où est l'erreur ?** `d2` n'est pas converti.
- **Que faire à la place ?** Convertir `d2` d'abord avec `strptime`.

## 🔗 Modules associés
[os](../01-os/README.md), [logging](../11-logging/README.md)

---
⬅️ [Accueil des modules](../README.md)
