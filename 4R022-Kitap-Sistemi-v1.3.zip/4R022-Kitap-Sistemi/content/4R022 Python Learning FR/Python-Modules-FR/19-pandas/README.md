# Module `pandas`

## Qu'est-ce que c'est et comment ça marche ?

Travaille avec des données tabulaires via l'objet **DataFrame**,
comme une feuille Excel.

## ✅ Exemples fonctionnels

```python
import pandas as pd
df = pd.read_csv("notes.csv")
print(df["note"].mean())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — colonne inexistante

```python
df = pd.DataFrame({"nom": ["Kaan"], "note": [95]})
print(df["notes"])
```
- **Pourquoi est-ce faux ?** La colonne s'appelle `"note"`.
- **Où est l'erreur ?** `KeyError: 'notes'`
- **Que faire à la place ?** Vérifier `df.columns` d'abord.

### Exemple incorrect 2 — valeurs manquantes (NaN) non gérées

```python
df = pd.read_csv("donnees_incompletes.csv")
moyenne = df["note"].sum() / len(df)
```
- **Pourquoi est-ce faux ?** `len(df)` compte aussi les lignes avec NaN.
- **Où est l'erreur ?** Calcul faussé silencieusement.
- **Que faire à la place ?** `df["note"].mean()` ignore les NaN automatiquement.

## 🔗 Modules associés
[numpy](../18-numpy/README.md), [csv](../04-csv/README.md)

---
⬅️ [Accueil des modules](../README.md)
