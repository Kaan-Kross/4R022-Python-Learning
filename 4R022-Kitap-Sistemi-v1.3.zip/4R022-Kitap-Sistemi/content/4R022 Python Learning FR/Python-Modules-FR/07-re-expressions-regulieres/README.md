# Module `re` (expressions régulières)

## Qu'est-ce que c'est et comment ça marche ?

Recherche des motifs dans du texte via un mini-langage compilé en
automate d'états.

## ✅ Exemples fonctionnels

```python
import re
m = re.search(r"[\w.]+@[\w.]+", "Contact: kaan@4r022.com")
print(m.group())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — sans chaîne brute (raw string)

```python
pattern = re.compile("\d+")   # sans 'r' !
```
- **Pourquoi est-ce faux ?** Conflit possible entre échappements Python et regex.
- **Où est l'erreur ?** Préfixe `r` manquant.
- **Que faire à la place ?** `r"\d+"`

### Exemple incorrect 2 — confusion `match()`/`search()`

```python
m = re.match(r"\d+", "Bonjour, numéro 12345")
print(m.group())
```
- **Pourquoi est-ce faux ?** `match()` ne cherche qu'au début.
- **Où est l'erreur ?** `m` vaut `None`, `AttributeError`.
- **Que faire à la place ?** `re.search(r"\d+", texte)`

## 🔗 Modules associés
[collections](../08-collections/README.md)

---
⬅️ [Accueil des modules](../README.md)
