# Module `sys`

## Qu'est-ce que c'est et comment ça marche ?

`sys` permet d'interagir directement avec **l'interpréteur Python
lui-même** : arguments de ligne de commande, version, code de sortie.

## ✅ Exemples fonctionnels

```python
import sys
print(sys.argv)
if len(sys.argv) > 1:
    print("Premier argument :", sys.argv[1])
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — confondre `sys.argv[0]` avec le premier argument

```python
nom = sys.argv[0]
```
- **Pourquoi est-ce faux ?** `sys.argv[0]` est le nom du script lui-même.
- **Où est l'erreur ?** Il fallait utiliser l'indice `1`.
- **Que faire à la place ?** `sys.argv[1]` avec vérification de longueur.

### Exemple incorrect 2 — capturer `sys.exit()` par erreur

```python
try:
    sys.exit(1)
except Exception:
    print("continuons quand même")
```
- **Pourquoi est-ce faux ?** `sys.exit()` lève `SystemExit`, capturé
  par un `except Exception` trop large.
- **Où est l'erreur ?** Le bloc except est trop englobant.
- **Que faire à la place ?** Utiliser des types d'exception plus précis.

## 🔗 Modules associés
[os](../01-os/README.md)

---
⬅️ [Accueil des modules](../README.md)
