# Module `sqlite3`

## Qu'est-ce que c'est et comment ça marche ?

Base de données relationnelle légère, tout dans un seul fichier,
aucun serveur requis.

## ✅ Exemples fonctionnels

```python
import sqlite3
conn = sqlite3.connect("app.db")
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS e (id INTEGER PRIMARY KEY, nom TEXT)")
c.execute("INSERT INTO e (nom) VALUES (?)", ("Kaan",))
conn.commit()
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — injection SQL par concaténation

```python
nom = "Kaan"
c.execute(f"SELECT * FROM e WHERE nom = '{nom}'")
```
- **Pourquoi est-ce faux ?** Vulnérabilité d'injection SQL.
- **Où est l'erreur ?** Entrée utilisateur insérée directement.
- **Que faire à la place ?** `c.execute("SELECT * FROM e WHERE nom = ?", (nom,))`

### Exemple incorrect 2 — `commit()` oublié

```python
c.execute("INSERT INTO e (nom) VALUES (?)", ("Ayse",))
conn.close()   # commit() oublié !
```
- **Pourquoi est-ce faux ?** Les changements ne sont pas sauvegardés.
- **Où est l'erreur ?** `conn.commit()` jamais appelé.
- **Que faire à la place ?** Toujours appeler `conn.commit()` après une écriture.

## 🔗 Modules associés
[threading](../12-threading/README.md)

---
⬅️ [Accueil des modules](../README.md)
