# Modules `itertools` et `functools`

## Qu'est-ce que c'est et comment ça marche ?

`itertools` fournit des outils économes en mémoire pour les boucles ;
`functools` des outils pour manipuler les fonctions (cache, réduction).

## ✅ Exemples fonctionnels

```python
from itertools import chain
from functools import reduce
for x in chain([1,2],[3,4]): print(x)
print(reduce(lambda a,b: a*b, [1,2,3,4]))
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `count()` infini sans arrêt

```python
from itertools import count
for i in count(1):
    print(i)   # ne s'arrête jamais !
```
- **Pourquoi est-ce faux ?** `count()` est infini.
- **Où est l'erreur ?** Pas de condition de sortie.
- **Que faire à la place ?** Ajouter `if i > 10: break`.

### Exemple incorrect 2 — `lru_cache` avec argument mutable

```python
from functools import lru_cache
@lru_cache(maxsize=None)
def somme(liste): return sum(liste)
somme([1,2,3])
```
- **Pourquoi est-ce faux ?** `list` n'est pas hachable.
- **Où est l'erreur ?** `TypeError: unhashable type: 'list'`
- **Que faire à la place ?** Passer un `tuple` : `somme((1,2,3))`

## 🔗 Modules associés
[collections](../08-collections/README.md)

---
⬅️ [Accueil des modules](../README.md)
