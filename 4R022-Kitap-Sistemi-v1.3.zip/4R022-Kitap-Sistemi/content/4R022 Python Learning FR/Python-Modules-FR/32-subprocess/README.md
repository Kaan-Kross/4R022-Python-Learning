# Module `subprocess`

## Qu'est-ce que c'est et comment ça marche ?

Exécute des programmes/commandes externes depuis Python.

## ✅ Exemples fonctionnels

```python
import subprocess
r = subprocess.run(["python", "--version"], capture_output=True, text=True)
print(r.stdout)
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `shell=True` avec entrée utilisateur

```python
nom_fichier = input("Fichier : ")
subprocess.run(f"del {nom_fichier}", shell=True)
```
- **Pourquoi est-ce faux ?** Injection de commande — faille grave.
- **Où est l'erreur ?** Entrée utilisateur directement dans une commande shell.
- **Que faire à la place ?** `subprocess.run(["del", nom_fichier])` sans shell=True.

### Exemple incorrect 2 — sortie énorme en mémoire

```python
subprocess.run(["find", "/", "-name", "*.log"], capture_output=True)
```
- **Pourquoi est-ce faux ?** Toute la sortie est chargée en mémoire.
- **Où est l'erreur ?** Risque de saturation mémoire.
- **Que faire à la place ?** Utiliser `Popen` pour lire ligne par ligne.

## 🔗 Modules associés
[os](../01-os/README.md)

---
⬅️ [Accueil des modules](../README.md)
