# Module `pathlib`

## Qu'est-ce que c'est et comment ça marche ?

Représente les chemins comme des **objets** plutôt que des chaînes,
via l'opérateur `/`.

## ✅ Exemples fonctionnels

```python
from pathlib import Path
p = Path("projet") / "donnees" / "config.json"
f = Path("notes.txt")
if f.exists():
    print(f.read_text(encoding="utf-8"))
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — confusion `Path.replace()`/remplacement de texte

```python
p = Path("fichier.txt")
print(p.replace(".txt", ".csv"))
```
- **Pourquoi est-ce faux ?** `Path.replace()` déplace/renomme le fichier.
- **Où est l'erreur ?** Peut lever `FileNotFoundError`.
- **Que faire à la place ?** `p.with_suffix(".csv")`

### Exemple incorrect 2 — écrire dans un dossier inexistant

```python
f = Path("dossier_absent/notes.txt")
f.write_text("bonjour")
```
- **Pourquoi est-ce faux ?** Le dossier parent doit exister.
- **Où est l'erreur ?** `FileNotFoundError`
- **Que faire à la place ?** `f.parent.mkdir(parents=True, exist_ok=True)`

## 🔗 Modules associés
[os](../01-os/README.md)

---
⬅️ [Accueil des modules](../README.md)
