# Module `dataclasses`

## Qu'est-ce que c'est et comment ça marche ?

Génère automatiquement `__init__`, `__repr__`, `__eq__` pour les
classes servant principalement à stocker des données.

## ✅ Exemples fonctionnels

```python
from dataclasses import dataclass
@dataclass
class Point:
    x: int
    y: int
p = Point(1, 2)
print(p)   # Point(x=1, y=2)
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — valeur par défaut mutable directe

```python
@dataclass
class Etudiant:
    notes: list = []   # liste vide directement !
```
- **Pourquoi est-ce faux ?** Les valeurs par défaut mutables sont interdites.
- **Où est l'erreur ?** `ValueError: mutable default ... is not allowed`
- **Que faire à la place ?** `field(default_factory=list)`

### Exemple incorrect 2 — croire les annotations de type vérifiées

```python
@dataclass
class Point:
    x: int
p = Point("un")   # chaîne au lieu d'int, aucune erreur !
```
- **Pourquoi est-ce faux ?** Les annotations ne sont pas vérifiées à l'exécution.
- **Où est l'erreur ?** Fausse hypothèse de validation automatique.
- **Que faire à la place ?** Utiliser `pydantic` pour une vraie validation.

## 🔗 Modules associés
[typing](../35-typing/README.md)

---
⬅️ [Accueil des modules](../README.md)
