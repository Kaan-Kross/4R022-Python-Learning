# Module `requests`

## Qu'est-ce que c'est et comment ça marche ?

Envoie des requêtes HTTP vers des serveurs/API — plus lisible que `urllib`.

## ✅ Exemples fonctionnels

```python
import requests
r = requests.get("https://api.github.com", timeout=5)
print(r.status_code, r.json())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — sans `timeout`

```python
r = requests.get("https://serveur-tres-lent.com")
```
- **Pourquoi est-ce faux ?** Le programme peut attendre indéfiniment.
- **Où est l'erreur ?** `timeout` manquant.
- **Que faire à la place ?** `requests.get(url, timeout=5)`

### Exemple incorrect 2 — clé API dans le code source

```python
CLE_API = "sk-vraie-cle"
r = requests.get(f"https://api.example.com/data?key={CLE_API}")
```
- **Pourquoi est-ce faux ?** Fuite de clé si publié sur GitHub.
- **Où est l'erreur ?** Clé codée en dur.
- **Que faire à la place ?** Utiliser des variables d'environnement.

## 🔗 Modules associés
[Flask et FastAPI](../17-flask-et-fastapi/README.md)

---
⬅️ [Accueil des modules](../README.md)
