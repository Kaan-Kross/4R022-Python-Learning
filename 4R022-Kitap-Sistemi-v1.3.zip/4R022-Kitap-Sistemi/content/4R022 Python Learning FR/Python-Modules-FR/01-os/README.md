# Module `os`

## Qu'est-ce que c'est et comment ça marche ?

Le module `os` permet à ton programme Python de dialoguer avec le
**système d'exploitation** (Windows, Linux, macOS). En interne, il
enveloppe les appels système de l'OS dans des fonctions Python.
Fait partie de la bibliothèque standard — **aucune installation requise.**

## Quand / où est-il utilisé ?

Créer/supprimer/renommer fichiers et dossiers, lister le contenu
d'un dossier, accéder aux variables d'environnement, construire des
chemins multiplateformes.

## ✅ Exemples fonctionnels

```python
import os
print(os.getcwd())
print(os.listdir("."))
os.makedirs("sortie/quotidien", exist_ok=True)
chemin = os.path.join("projet", "donnees", "config.json")
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — supprimer un dossier inexistant

```python
import os
os.rmdir("dossier_inexistant")
```
- **Pourquoi est-ce faux ?** Le dossier n'existe pas sur le disque.
- **Où est l'erreur ?** `os.rmdir()` échoue sur un dossier absent.
- **Que faire à la place ?** Vérifier avec `os.path.isdir()` d'abord.

### Exemple incorrect 2 — `rmdir()` sur un dossier non vide

```python
import os
os.rmdir("dossier_plein")
```
- **Pourquoi est-ce faux ?** `rmdir()` ne supprime que les dossiers vides.
- **Où est l'erreur ?** `OSError: [Errno 39] Directory not empty`
- **Que faire à la place ?** Utiliser `shutil.rmtree()`.

## 🔗 Modules associés
[pathlib](../10-pathlib/README.md), [sys](../02-sys/README.md)

---
⬅️ [Accueil des modules](../README.md)
