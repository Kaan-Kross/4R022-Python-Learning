# Flask et FastAPI

## Qu'est-ce que c'est et comment ça marche ?

Deux façons d'écrire un serveur web/API en Python. Flask est
minimaliste ; FastAPI ajoute validation automatique et documentation
via les annotations de type.

## ✅ Exemples fonctionnels

```python
from flask import Flask, jsonify
app = Flask(__name__)
@app.route("/etudiants")
def etudiants():
    return jsonify([{"nom": "Kaan", "note": 95}])
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `debug=True` en production

```python
app.run(debug=True, host="0.0.0.0")
```
- **Pourquoi est-ce faux ?** Ouvre une console interactive exploitable.
- **Où est l'erreur ?** Réglage de développement en prod.
- **Que faire à la place ?** `debug=False`, utiliser `gunicorn`.

### Exemple incorrect 2 — donnée non conforme au modèle Pydantic

```python
requests.post(url, json={"nom": "Kaan", "note": "quatre-vingt-quinze"})
```
- **Pourquoi est-ce faux ?** `note` attend un `int`.
- **Où est l'erreur ?** FastAPI renvoie `422 Unprocessable Entity`.
- **Que faire à la place ?** Envoyer `{"nom": "Kaan", "note": 95}`.

## 🔗 Modules associés
[requests](../16-requests/README.md)

---
⬅️ [Accueil des modules](../README.md)
