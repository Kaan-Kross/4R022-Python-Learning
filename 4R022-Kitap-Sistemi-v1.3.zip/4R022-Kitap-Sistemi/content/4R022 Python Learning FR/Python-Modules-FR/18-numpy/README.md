# Module `numpy`

## Qu'est-ce que c'est et comment ça marche ?

Bibliothèque écrite en C pour des opérations rapides sur tableaux
numériques via la vectorisation.

## ✅ Exemples fonctionnels

```python
import numpy as np
arr = np.array([1,2,3,4,5])
print(arr * 2)
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — attendre le même comportement d'une liste

```python
lst = [1,2,3]
print(lst * 2)   # [1,2,3,1,2,3] — pas une multiplication !
```
- **Pourquoi est-ce faux ?** `*` répète la liste, ne multiplie pas les éléments.
- **Où est l'erreur ?** Confusion entre liste Python et tableau numpy.
- **Que faire à la place ?** `np.array(lst) * 2`

### Exemple incorrect 2 — type de données insuffisant

```python
arr = np.array([200, 100], dtype=np.int8)
print(arr + 100)   # dépassement silencieux !
```
- **Pourquoi est-ce faux ?** `int8` va de -128 à 127.
- **Où est l'erreur ?** Type inadapté à la plage de valeurs.
- **Que faire à la place ?** Utiliser `dtype=np.int32`.

## 🔗 Modules associés
[pandas](../19-pandas/README.md)

---
⬅️ [Accueil des modules](../README.md)
