# Module `typing`

## Qu'est-ce que c'est et comment ça marche ?

Ajoute des annotations de type ; NON vérifiées à l'exécution — sert
surtout pour les éditeurs et `mypy`.

## ✅ Exemples fonctionnels

```python
def saluer(nom: str) -> str:
    return f"Bonjour, {nom} !"
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — croire à une vérification de type

```python
def additionner(a: int, b: int) -> int:
    return a + b
print(additionner("5", "3"))   # fonctionne, mais donne "53", pas 8 !
```
- **Pourquoi est-ce faux ?** Les annotations ne garantissent aucune validation.
- **Où est l'erreur ?** Fausse hypothèse de validation automatique.
- **Que faire à la place ?** Utiliser `mypy` ou `isinstance()`.

### Exemple incorrect 2 — nouvelle syntaxe sur une ancienne version de Python

```python
def f(x: list[int]) -> int:   # ne fonctionne pas avant Python 3.9 !
    return x[0]
```
- **Pourquoi est-ce faux ?** `list[int]` a été introduit en 3.9.
- **Où est l'erreur ?** `TypeError` sur les anciennes versions.
- **Que faire à la place ?** `from typing import List` -> `List[int]`

## 🔗 Modules associés
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Accueil des modules](../README.md)
