# `unittest` et `pytest`

## Qu'est-ce que c'est et comment ça marche ?

`unittest` est le framework de test intégré ; `pytest` est une
alternative tierce plus populaire avec un `assert` simple.

## ✅ Exemples fonctionnels

```python
def addition(a, b): return a + b
def test_addition():
    assert addition(2, 3) == 5
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — mauvais nom de fichier/fonction pour pytest

```python
# fichier : verifications.py (sans préfixe test_ !)
def verifier_multiplication():
    assert 2*2 == 4
```
- **Pourquoi est-ce faux ?** pytest cherche les fichiers/fonctions préfixés `test_`.
- **Où est l'erreur ?** Ni le fichier ni la fonction ne respectent la règle.
- **Que faire à la place ?** Renommer en `test_verifications.py` / `test_multiplication()`.

### Exemple incorrect 2 — état partagé entre tests

```python
panier = []
def test_un():
    panier.append("a")
    assert len(panier) == 1
def test_deux():
    panier.append("b")
    assert len(panier) == 1   # FAUX ! il y a maintenant 2 éléments
```
- **Pourquoi est-ce faux ?** Les tests doivent être indépendants.
- **Où est l'erreur ?** La liste `panier` est partagée entre les tests.
- **Que faire à la place ?** Réinitialiser l'état à chaque test.

## 🔗 Modules associés
[logging](../11-logging/README.md)

---
⬅️ [Accueil des modules](../README.md)
