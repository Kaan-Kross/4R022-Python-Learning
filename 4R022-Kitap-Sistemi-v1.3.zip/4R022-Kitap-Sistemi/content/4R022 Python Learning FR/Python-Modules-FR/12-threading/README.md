# Module `threading`

## Qu'est-ce que c'est et comment ça marche ?

Exécute plusieurs threads. À cause du GIL, pas de vrai parallélisme
CPU, mais efficace pour les tâches d'attente (I/O).

## ✅ Exemples fonctionnels

```python
import threading, time
def tache():
    time.sleep(1)
t = threading.Thread(target=tache)
t.start(); t.join()
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `join()` oublié

```python
t = threading.Thread(target=tache)
t.start()
print("fin")   # peut s'afficher avant la fin de la tâche !
```
- **Pourquoi est-ce faux ?** `start()` n'attend pas la fin du thread.
- **Où est l'erreur ?** `t.join()` manque.
- **Que faire à la place ?** Ajouter `t.join()`.

### Exemple incorrect 2 — donnée partagée sans Lock

```python
compteur = 0
def incrementer():
    global compteur
    compteur += 1   # pas atomique !
```
- **Pourquoi est-ce faux ?** Condition de course (race condition).
- **Où est l'erreur ?** Pas de `threading.Lock()`.
- **Que faire à la place ?** Protéger avec `with lock:`.

## 🔗 Modules associés
[multiprocessing](../13-multiprocessing/README.md)

---
⬅️ [Accueil des modules](../README.md)
