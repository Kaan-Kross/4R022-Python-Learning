# Modules `math` et `random`

## Qu'est-ce que c'est et comment ça marche ?

`math` fournit des fonctions mathématiques avancées ; `random`
génère des nombres pseudo-aléatoires (non sécurisés).

## ✅ Exemples fonctionnels

```python
import math, random
print(math.sqrt(16))
print(random.randint(1, 6))
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — racine d'un nombre négatif

```python
math.sqrt(-16)
```
- **Pourquoi est-ce faux ?** Non défini pour les réels.
- **Où est l'erreur ?** `ValueError: math domain error`
- **Que faire à la place ?** Utiliser `cmath.sqrt(-16)`.

### Exemple incorrect 2 — `random` pour un mot de passe

```python
mdp = "".join(random.choice("abc123") for _ in range(8))
```
- **Pourquoi est-ce faux ?** `random` n'est pas sécurisé cryptographiquement.
- **Où est l'erreur ?** Mauvais module pour un contexte de sécurité.
- **Que faire à la place ?** Utiliser `secrets.token_urlsafe(16)`.

## 🔗 Modules associés
[cryptography](../25-cryptography/README.md)

---
⬅️ [Accueil des modules](../README.md)
