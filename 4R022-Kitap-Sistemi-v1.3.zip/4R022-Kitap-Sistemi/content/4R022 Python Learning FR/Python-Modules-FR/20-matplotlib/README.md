# Module `matplotlib`

## Qu'est-ce que c'est et comment ça marche ?

Bibliothèque de référence pour les graphiques et la visualisation
de données.

## ✅ Exemples fonctionnels

```python
import matplotlib.pyplot as plt
plt.plot([1,2,3], [10,20,30])
plt.savefig("graphique.png")
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `plt.show()` sans écran (serveur)

```python
plt.plot([1,2,3])
plt.show()
```
- **Pourquoi est-ce faux ?** Erreur/blocage sans environnement graphique.
- **Où est l'erreur ?** `plt.show()` suppose un écran.
- **Que faire à la place ?** `plt.savefig("graphique.png")`

### Exemple incorrect 2 — dessiner sur la même figure

```python
plt.plot([1,2,3], [1,4,9])
plt.savefig("g1.png")
plt.plot([1,2,3], [3,2,1])   # ajouté à la MÊME figure !
plt.savefig("g2.png")         # g2.png contient les DEUX courbes
```
- **Pourquoi est-ce faux ?** matplotlib continue à dessiner sur la même figure.
- **Où est l'erreur ?** Pas de `plt.figure()`/`plt.clf()` entre les deux.
- **Que faire à la place ?** Appeler `plt.figure()` avant chaque nouveau graphique.

## 🔗 Modules associés
[numpy](../18-numpy/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Accueil des modules](../README.md)
