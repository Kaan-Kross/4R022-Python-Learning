# Module `argparse`

## Qu'est-ce que c'est et comment ça marche ?

Donne aux scripts une interface de ligne de commande professionnelle :
`--help`, conversion de type, arguments obligatoires/optionnels.

## ✅ Exemples fonctionnels

```python
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("fichier")
parser.add_argument("--verbose", action="store_true")
args = parser.parse_args()
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — exécution sans argument obligatoire

```bash
python outil.py
```
- **Pourquoi est-ce faux ?** `fichier` est un argument positionnel obligatoire.
- **Où est l'erreur ?** `error: the following arguments are required: fichier`
- **Que faire à la place ?** `python outil.py notes.txt`

### Exemple incorrect 2 — valeur donnée à un flag `store_true`

```bash
python outil.py --verbose oui
```
- **Pourquoi est-ce faux ?** `store_true` ne prend aucune valeur.
- **Où est l'erreur ?** `error: unrecognized arguments: oui`
- **Que faire à la place ?** `python outil.py --verbose` sans valeur.

## 🔗 Modules associés
[sys](../02-sys/README.md)

---
⬅️ [Accueil des modules](../README.md)
