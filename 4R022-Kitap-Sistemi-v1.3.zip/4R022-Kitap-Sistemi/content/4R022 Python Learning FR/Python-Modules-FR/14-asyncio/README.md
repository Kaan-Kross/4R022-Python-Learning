# Module `asyncio`

## Qu'est-ce que c'est et comment ça marche ?

Gère de nombreuses tâches d'attente dans un seul thread — à
`await`, la tâche se suspend, une autre s'exécute.

## ✅ Exemples fonctionnels

```python
import asyncio
async def bonjour():
    await asyncio.sleep(1)
    print("Bonjour !")
asyncio.run(bonjour())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — appel sans `await`

```python
async def bonjour(): print("Bonjour !")
bonjour()   # ne s'exécute pas réellement !
```
- **Pourquoi est-ce faux ?** Crée un objet coroutine sans l'exécuter.
- **Où est l'erreur ?** `RuntimeWarning: coroutine was never awaited`
- **Que faire à la place ?** `asyncio.run(bonjour())`

### Exemple incorrect 2 — code bloquant dans une fonction async

```python
import time
async def tache():
    time.sleep(3)   # bloque TOUT l'event loop !
```
- **Pourquoi est-ce faux ?** `time.sleep()` est synchrone.
- **Où est l'erreur ?** Il fallait `await asyncio.sleep(3)`.
- **Que faire à la place ?** Toujours utiliser des fonctions compatibles async.

## 🔗 Modules associés
[threading](../12-threading/README.md)

---
⬅️ [Accueil des modules](../README.md)
