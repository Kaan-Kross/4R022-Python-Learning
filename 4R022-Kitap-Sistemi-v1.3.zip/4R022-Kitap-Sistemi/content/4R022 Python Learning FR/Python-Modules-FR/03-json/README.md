# Module `json`

## Qu'est-ce que c'est et comment ça marche ?

Convertit les objets Python en texte JSON et inversement — le
langage commun des API web et fichiers de configuration.

## ✅ Exemples fonctionnels

```python
import json
config = {"theme": "sombre", "langue": "fr"}
with open("config.json", "w", encoding="utf-8") as f:
    json.dump(config, f, ensure_ascii=False, indent=4)
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — guillemets simples

```python
data = json.loads("{'theme': 'sombre'}")
```
- **Pourquoi est-ce faux ?** JSON exige des guillemets doubles.
- **Où est l'erreur ?** `json.decoder.JSONDecodeError`
- **Que faire à la place ?** `json.loads('{"theme": "sombre"}')`

### Exemple incorrect 2 — lecture sans protection

```python
with open("casse.json", "r") as f:
    data = json.load(f)   # plante si le fichier est vide/corrompu
```
- **Pourquoi est-ce faux ?** Aucune gestion d'erreur.
- **Où est l'erreur ?** Pas de `try/except`.
- **Que faire à la place ?** Entourer de `try/except (json.JSONDecodeError, FileNotFoundError)`.

## 🔗 Modules associés
[csv](../04-csv/README.md)

---
⬅️ [Accueil des modules](../README.md)
