# Module `tkinter`

## Qu'est-ce que c'est et comment ça marche ?

Bibliothèque GUI standard de Python, basée sur une boucle
d'événements déclenchée par `mainloop()`.

## ✅ Exemples fonctionnels

```python
import tkinter as tk
root = tk.Tk()
tk.Label(root, text="Bonjour !").pack()
root.mainloop()
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `mainloop()` oublié

```python
root = tk.Tk()
tk.Label(root, text="N'apparaîtra pas").pack()
```
- **Pourquoi est-ce faux ?** Sans `mainloop()`, la boucle d'événements ne démarre pas.
- **Où est l'erreur ?** `root.mainloop()` manquant.
- **Que faire à la place ?** Toujours l'ajouter en dernière ligne.

### Exemple incorrect 2 — fonction appelée avec parenthèses dans `command=`

```python
def clic(): print("clic")
tk.Button(root, text="Bouton", command=clic()).pack()   # parenthèses !
```
- **Pourquoi est-ce faux ?** La fonction s'exécute immédiatement à la création.
- **Où est l'erreur ?** Parenthèses en trop après `clic`.
- **Que faire à la place ?** `command=clic` sans parenthèses.

## 🔗 Modules associés
[PyQt6](../22-PyQt6/README.md)

---
⬅️ [Accueil des modules](../README.md)
