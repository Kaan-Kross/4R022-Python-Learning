# Module `queue`

## Qu'est-ce que c'est et comment ça marche ?

File FIFO thread-safe pour transmettre des données en sécurité entre threads.

## ✅ Exemples fonctionnels

```python
import queue
q = queue.Queue()
q.put("tache-1")
print(q.get())
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — `get_nowait()` sur file vide

```python
q.get_nowait()
```
- **Pourquoi est-ce faux ?** Aucune attente, erreur immédiate.
- **Où est l'erreur ?** `queue.Empty`
- **Que faire à la place ?** Utiliser `q.get()` ou gérer `queue.Empty`.

### Exemple incorrect 2 — liste normale entre threads

```python
data = []
threading.Thread(target=lambda: data.append(1)).start()
```
- **Pourquoi est-ce faux ?** `list.append()` n'est pas atomique.
- **Où est l'erreur ?** Risque de corruption de données.
- **Que faire à la place ?** Utiliser `queue.Queue()`.

## 🔗 Modules associés
[threading](../12-threading/README.md)

---
⬅️ [Accueil des modules](../README.md)
