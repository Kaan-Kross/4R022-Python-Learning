# Module `qrcode`

## Qu'est-ce que c'est et comment ça marche ?

Transforme un texte en image de QR code via des algorithmes de
correction d'erreur.

## ✅ Exemples fonctionnels

```python
import qrcode
img = qrcode.make("https://github.com/4R022")
img.save("qr.png")
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — installation sans `[pil]`

```bash
pip install qrcode
```
- **Pourquoi est-ce faux ?** La génération d'image dépend de Pillow.
- **Où est l'erreur ?** `ImportError`
- **Que faire à la place ?** `pip install "qrcode[pil]"`

### Exemple incorrect 2 — texte trop long

```python
img = qrcode.make("A" * 5000)
```
- **Pourquoi est-ce faux ?** Dépasse la capacité du standard QR.
- **Où est l'erreur ?** `DataOverflowError`
- **Que faire à la place ?** Utiliser `version=None` pour un ajustement automatique.

## 🔗 Modules associés
[hashlib](../30-hashlib/README.md)

---
⬅️ [Accueil des modules](../README.md)
