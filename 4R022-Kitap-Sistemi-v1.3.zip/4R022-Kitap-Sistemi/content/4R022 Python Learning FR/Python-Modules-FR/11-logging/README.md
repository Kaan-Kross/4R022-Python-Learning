# Module `logging`

## Qu'est-ce que c'est et comment ça marche ?

Remplacement professionnel de `print()` : niveaux de gravité,
écriture simultanée fichier + écran, horodatage automatique.

## ✅ Exemples fonctionnels

```python
import logging
logging.basicConfig(level=logging.INFO)
logging.info("Application démarrée")
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — appeler `basicConfig()` plusieurs fois

```python
logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.ERROR)   # ignoré !
```
- **Pourquoi est-ce faux ?** Seul le premier appel est pris en compte.
- **Où est l'erreur ?** Le second appel n'a aucun effet.
- **Que faire à la place ?** Configurer correctement une seule fois.

### Exemple incorrect 2 — logger un mot de passe

```python
logging.info(f"Connexion : password={mdp}")
```
- **Pourquoi est-ce faux ?** Faille de sécurité grave.
- **Où est l'erreur ?** Mot de passe écrit dans le log.
- **Que faire à la place ?** Ne jamais logger de données sensibles.

## 🔗 Modules associés
[datetime](../05-datetime/README.md)

---
⬅️ [Accueil des modules](../README.md)
