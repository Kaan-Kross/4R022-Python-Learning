# Module `selenium`

> ⚠️ Voir [Éthique et Sécurité](../../Python-Ethique-et-Securite-FR/README.md) — usage légal uniquement.

## Qu'est-ce que c'est et comment ça marche ?

Contrôle un vrai navigateur par programme via le WebDriver Protocol.

## ✅ Exemples fonctionnels

```python
from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://example.com")
print(driver.title)
driver.quit()
```

## ❌ Exemples incorrects

### Exemple incorrect 1 — accès à un élément avant chargement complet

```python
driver.get("https://site-lent.com")
el = driver.find_element(By.ID, "resultats")
```
- **Pourquoi est-ce faux ?** Le contenu JS peut se charger plus tard.
- **Où est l'erreur ?** `NoSuchElementException`
- **Que faire à la place ?** Utiliser `WebDriverWait`.

### Exemple incorrect 2 — `driver.quit()` oublié

```python
driver = webdriver.Chrome()
driver.get("https://example.com")
# driver.quit() jamais appelé
```
- **Pourquoi est-ce faux ?** Le processus navigateur reste ouvert.
- **Où est l'erreur ?** Pas de nettoyage des ressources.
- **Que faire à la place ?** Utiliser `try/finally` avec `driver.quit()`.

## 🔗 Modules associés
[requests](../16-requests/README.md)

---
⬅️ [Accueil des modules](../README.md)
