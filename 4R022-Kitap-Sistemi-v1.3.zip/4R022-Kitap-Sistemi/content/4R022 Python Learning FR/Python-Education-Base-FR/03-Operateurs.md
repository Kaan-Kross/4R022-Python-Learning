# 3. Opérateurs

## Opérateurs arithmétiques

```python
# ✅ Ce code fonctionne
print(5 + 3)   # 8   addition
print(5 - 3)   # 2   soustraction
print(5 * 3)   # 15  multiplication
print(5 / 3)   # 1.666... division (renvoie toujours un float)
print(5 // 3)  # 1   division entière
print(5 % 3)   # 2   modulo (reste)
print(5 ** 3)  # 125 puissance
```

```python
# ❌ Ce code NE FONCTIONNE PAS — la division par zéro n'est pas définie
print(5 / 0)
```

Cela lève `ZeroDivisionError: division by zero`. Python ne devine
pas, il arrête le programme — on verra comment gérer ça dans le
chapitre sur la gestion des erreurs.

## Opérateurs de comparaison

```python
# ✅ Ce code fonctionne — tous renvoient True/False
print(5 == 5)   # True
print(5 != 3)   # True
print(5 > 3)    # True
print(5 < 3)    # False
print(5 >= 5)   # True
print(5 <= 4)   # False
```

```python
# ❌ Ce code NE FONCTIONNE PAS — assignation (=) confondue avec comparaison (==)
if x = 5:
    print("cinq")
```

Cela lève une `SyntaxError`. Un seul `=` **assigne**, deux `==`
**comparent** — une erreur classique de débutant.

## Opérateurs logiques

```python
# ✅ Ce code fonctionne
age = 20
est_etudiant = True

print(age >= 18 and est_etudiant)   # True — les deux doivent être vrais
print(age >= 18 or est_etudiant)    # True — un seul suffit
print(not est_etudiant)             # False — inverse la valeur
```

## Opérateurs d'affectation composée

```python
# ✅ Ce code fonctionne
compteur = 0
compteur += 1   # compteur = compteur + 1 -> 1
compteur -= 1   # -> 0
compteur *= 5   # -> 0
compteur += 10  # -> 10
print(compteur)
```

### 🎯 Mini-exercice
Écris une expression avec `%` et `and` qui vérifie si un nombre est
divisible à la fois par 2 et par 3.

---
⬅️ [Variables et types de données](./02-Variables-et-types-de-donnees.md) &nbsp;|&nbsp; ➡️ [Structures conditionnelles](./04-Structures-conditionnelles.md)
