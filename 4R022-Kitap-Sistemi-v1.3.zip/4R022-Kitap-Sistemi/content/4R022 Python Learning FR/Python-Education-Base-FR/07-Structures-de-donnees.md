# 7. Structures de données : liste, tuple, dictionnaire, ensemble

## Liste (`list`) — ordonnée, modifiable

```python
# ✅ Ce code fonctionne
fruits = ["pomme", "poire", "banane"]
fruits.append("fraise")       # ajoute à la fin
fruits[0] = "abricot"         # modifie le premier élément
print(fruits)                 # ['abricot', 'poire', 'banane', 'fraise']
print(fruits[1])              # 'poire'
print(fruits[-1])             # dernier élément : 'fraise'
print(fruits[0:2])            # tranche : les deux premiers éléments
```

```python
# ❌ Ce code NE FONCTIONNE PAS — accès hors des limites de la liste
fruits = ["pomme", "poire"]
print(fruits[5])
```

Cela lève `IndexError: list index out of range`. Une liste de 2
éléments n'a que les indices valides `0` et `1`.

## Tuple (`tuple`) — ordonné, IMMUABLE

```python
# ✅ Ce code fonctionne
coordonnee = (10, 20)
print(coordonnee[0])   # 10
```

```python
# ❌ Ce code NE FONCTIONNE PAS — les tuples ne peuvent pas être modifiés
coordonnee = (10, 20)
coordonnee[0] = 99
```

Cela lève `TypeError: 'tuple' object does not support item
assignment`. Le tuple est idéal quand on veut garantir « ceci ne
changera pas » (une coordonnée fixe, une couleur RVB).

## Dictionnaire (`dict`) — paires clé-valeur

```python
# ✅ Ce code fonctionne
etudiant = {"nom": "Kaan", "age": 25, "filiere": "Informatique"}
print(etudiant["nom"])       # 'Kaan'
etudiant["age"] = 26          # mise à jour
etudiant["ville"] = "Sakarya" # nouvelle clé

for cle, valeur in etudiant.items():
    print(cle, "->", valeur)
```

```python
# ❌ Ce code NE FONCTIONNE PAS — accès à une clé inexistante
etudiant = {"nom": "Kaan"}
print(etudiant["nom_famille"])
```

Cela lève `KeyError: 'nom_famille'`. L'accès sûr se fait via `.get()` :

```python
# ✅ Ce code fonctionne — pas d'erreur si la clé manque, renvoie None
print(etudiant.get("nom_famille"))          # None
print(etudiant.get("nom_famille", "N/A"))   # "N/A" (valeur par défaut)
```

## Ensemble (`set`) — non ordonné, sans doublons

```python
# ✅ Ce code fonctionne — les ensembles suppriment les doublons automatiquement
nombres = {1, 2, 2, 3, 3, 3}
print(nombres)   # {1, 2, 3}

a = {1, 2, 3}
b = {2, 3, 4}
print(a & b)   # intersection : {2, 3}
print(a | b)   # union : {1, 2, 3, 4}
print(a - b)   # différence : {1}
```

## Tableau comparatif

| Structure | Ordonnée ? | Modifiable ? | Doublons ? | Syntaxe |
|---|---|---|---|---|
| `list` | ✅ | ✅ | ✅ | `[1, 2, 3]` |
| `tuple` | ✅ | ❌ | ✅ | `(1, 2, 3)` |
| `dict` | ✅ (3.7+) | ✅ | clés uniques | `{"a": 1}` |
| `set` | ❌ | ✅ | ❌ | `{1, 2, 3}` |

### 🎯 Mini-exercice
Crée une `list` de noms d'étudiants, puis un `dict` associant chaque
nom à une note (`{"nom": note}`), et calcule la moyenne.

---
⬅️ [Fonctions](./06-Fonctions.md) &nbsp;|&nbsp; ➡️ [Gestion des fichiers et des erreurs](./08-Gestion-fichiers-et-erreurs.md)
