# 5. Boucles (for / while)

## Boucle `for`

```python
# ✅ Ce code fonctionne — compte de 0 à 4 (5 exclu)
for i in range(5):
    print(i)
```

```python
# ✅ Ce code fonctionne — parcourt une liste
fruits = ["pomme", "poire", "banane"]
for fruit in fruits:
    print(fruit)
```

```python
# ❌ Ce code ne fait pas ce qu'on pourrait attendre — range() EXCLUT
# le dernier nombre, une erreur de conception fréquente (le code
# tourne, mais produit un résultat différent de ce qui était supposé) :
for i in range(1, 5):
    print(i)   # affiche 1,2,3,4 — 5 n'est PAS inclus
```

## Boucle `while`

```python
# ✅ Ce code fonctionne
compteur = 0
while compteur < 5:
    print(compteur)
    compteur += 1
```

```python
# ❌ Ce code NE FONCTIONNE PAS (boucle infinie !)
compteur = 0
while compteur < 5:
    print(compteur)
    # compteur += 1 a été oublié, la condition reste True pour toujours
```

> ⚠️ Si tu tombes dans une boucle infinie, arrête-la dans le terminal
> avec **Ctrl + C**.

## `break` et `continue`

```python
# ✅ Ce code fonctionne — arrête complètement la boucle à 3
for i in range(10):
    if i == 3:
        break
    print(i)   # affiche 0, 1, 2
```

```python
# ✅ Ce code fonctionne — saute seulement 3, la boucle continue
for i in range(5):
    if i == 3:
        continue
    print(i)   # affiche 0, 1, 2, 4 (3 est sauté)
```

## Boucles imbriquées

```python
# ✅ Ce code fonctionne — une grille 3x3 façon table de multiplication
for i in range(1, 4):
    for j in range(1, 4):
        print(i * j, end=" ")
    print()  # nouvelle ligne après chaque itération externe
```

### 🎯 Mini-exercice
Additionne tous les nombres entre 1 et 100 divisibles par 3 ou par 5,
avec une boucle `for`.

---
⬅️ [Structures conditionnelles](./04-Structures-conditionnelles.md) &nbsp;|&nbsp; ➡️ [Fonctions](./06-Fonctions.md)
