# 1. Installation et premiers pas

## Installer Python

1. Télécharge la version adaptée à ton OS sur
   [python.org/downloads](https://python.org/downloads) (sur
   Windows, coche bien **« Add Python to PATH »**).
2. Vérifie l'installation dans un terminal :

```bash
python --version
```

3. Installe un éditeur de code : **VS Code** (recommandé), PyCharm
   ou l'IDLE intégré.

## Ton premier programme

```python
# ✅ Ce code fonctionne — enregistre sous "bonjour.py" et exécute-le
print("Bonjour, 4R022 Python Learning !")
```

```bash
python bonjour.py
```

```python
# ❌ Ce code NE FONCTIONNE PAS — "print" est mal orthographié
prnt("Bonjour")
```

Cela lève `NameError: name 'prnt' is not defined`. Python signale
ainsi tout nom qu'il ne reconnaît pas — lire les messages d'erreur
est bien plus utile que de les craindre.

## Le shell interactif

Taper simplement `python` dans un terminal ouvre un shell interactif
(tu verras une invite `>>>`) où tu peux exécuter du code ligne par
ligne — idéal pour des tests rapides.

```python
>>> 2 + 2
4
>>> print("test")
test
```

## Commentaires

```python
# Ceci est un commentaire sur une ligne, Python l'ignore
print("Cette ligne s'exécute")  # un commentaire peut aussi suivre du code

"""
Ceci est un commentaire multi-lignes
(aussi utilisé comme docstring).
"""
```

### 🎯 Mini-exercice
Écris un programme de deux lignes qui affiche ton prénom, puis
affiche « J'apprends Python ! » à la ligne suivante.

---
⬅️ [Retour](./README.md) &nbsp;|&nbsp; ➡️ [Variables et types de données](./02-Variables-et-types-de-donnees.md)
