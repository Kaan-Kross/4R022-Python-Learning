# 9. Introduction à la programmation orientée objet (POO)

## Classe et objet

Une **classe** est un « plan ». Un **objet (instance)** est une
chose réelle et concrète construite à partir de ce plan.

```python
# ✅ Ce code fonctionne
class Etudiant:
    def __init__(self, nom, age):
        self.nom = nom       # attribut
        self.age = age

    def se_presenter(self):  # méthode
        print(f"Je suis {self.nom}, j'ai {self.age} ans.")

etudiant1 = Etudiant("Kaan", 25)
etudiant2 = Etudiant("Ayse", 22)

etudiant1.se_presenter()   # "Je suis Kaan, j'ai 25 ans."
etudiant2.se_presenter()   # "Je suis Ayse, j'ai 22 ans."
```

`__init__` est une méthode spéciale exécutée **automatiquement**
lors de la création d'un objet (le constructeur). `self` représente
l'objet lui-même.

```python
# ❌ Ce code NE FONCTIONNE PAS — le paramètre 'self' est oublié
class Etudiant:
    def __init__(nom, age):     # 'self' manque !
        nom = nom
        age = age

etudiant1 = Etudiant("Kaan", 25)
```

Cela lève `TypeError: __init__() takes 2 positional arguments but 3
were given`. Python transmet automatiquement l'objet lui-même
(`self`) comme premier argument de chaque méthode ; l'oublier est
l'erreur classique en POO.

## Héritage

```python
# ✅ Ce code fonctionne
class Animal:
    def __init__(self, nom):
        self.nom = nom

    def faire_un_son(self):
        print(f"{self.nom} fait un son.")

class Chien(Animal):              # hérite de Animal
    def faire_un_son(self):       # redéfinit la méthode
        print(f"{self.nom} : Ouaf !")

animal = Animal("Inconnu")
chien = Chien("Rex")

animal.faire_un_son()   # "Inconnu fait un son."
chien.faire_un_son()    # "Rex : Ouaf !"
```

## Encapsulation — introduction simple

```python
# ✅ Ce code fonctionne — les attributs commençant par _ sont
# considérés « privés » par convention (Python n'impose pas de
# véritable restriction d'accès ici)
class CompteBancaire:
    def __init__(self, solde):
        self._solde = solde

    def deposer(self, montant):
        if montant > 0:
            self._solde += montant

    def afficher_solde(self):
        return self._solde

compte = CompteBancaire(100)
compte.deposer(50)
print(compte.afficher_solde())   # 150
```

## Pourquoi la POO ?

Quand un programme grandit, regrouper les données liées (attributs)
et le comportement qui agit dessus (méthodes) rend le code lisible
et maintenable. La séparation `core/` + `ui/` des projets PyQt6 de
4R022 est cette même idée, à plus grande échelle.

### 🎯 Mini-exercice
Écris une classe `Vehicule` (avec les attributs `marque`, `vitesse`),
puis une sous-classe `VoitureSport` qui en hérite et redéfinit une
méthode `accelerer()`.

---
⬅️ [Gestion des fichiers et des erreurs](./08-Gestion-fichiers-et-erreurs.md) &nbsp;|&nbsp; ➡️ [Passer au niveau intermédiaire](../Python-Niveau-Intermediaire-FR/README.md)

🎉 **Félicitations — tu as terminé le niveau débutant !**
