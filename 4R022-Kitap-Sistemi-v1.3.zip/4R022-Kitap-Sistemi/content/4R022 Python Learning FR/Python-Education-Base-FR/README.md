# Python Éducation de Base (FR) — Niveau Débutant

Ce niveau permet à quelqu'un qui n'a jamais programmé d'écrire de
petits programmes Python réels.

## Chapitres (à suivre dans l'ordre)

1. [Installation et premiers pas](./01-Installation-et-premiers-pas.md)
2. [Variables et types de données](./02-Variables-et-types-de-donnees.md)
3. [Opérateurs](./03-Operateurs.md)
4. [Structures conditionnelles (if / elif / else)](./04-Structures-conditionnelles.md)
5. [Boucles (for / while)](./05-Boucles.md)
6. [Fonctions](./06-Fonctions.md)
7. [Structures de données : liste, tuple, dictionnaire, ensemble](./07-Structures-de-donnees.md)
8. [Gestion des fichiers et des erreurs](./08-Gestion-fichiers-et-erreurs.md)
9. [Introduction à la POO](./09-Introduction-a-la-POO.md)

Suite ➡️ [Niveau Intermédiaire](../Python-Niveau-Intermediaire-FR/README.md)
