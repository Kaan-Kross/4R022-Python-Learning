# 8. Gestion des fichiers et des erreurs

## Lire / écrire des fichiers

```python
# ✅ Ce code fonctionne — écrit dans un fichier (le crée s'il n'existe pas)
with open("notes.txt", "w", encoding="utf-8") as f:
    f.write("Bonjour 4R022 !\n")
    f.write("J'apprends Python.\n")

# ✅ Ce code fonctionne — lit le fichier
with open("notes.txt", "r", encoding="utf-8") as f:
    contenu = f.read()
    print(contenu)
```

Utiliser `with` garantit que le fichier est **fermé automatiquement**
à la fin du bloc — pas de risque d'oublier `f.close()`.

```python
# ❌ Ce code NE FONCTIONNE PAS — tenter de lire un fichier inexistant
with open("fichier_inexistant.txt", "r") as f:
    print(f.read())
```

Cela lève `FileNotFoundError: [Errno 2] No such file or directory`.

## Gestion des erreurs : `try / except`

Ce genre d'erreur fait planter le programme. On les « attrape » :

```python
# ✅ Ce code fonctionne — l'erreur est attrapée, le programme continue
try:
    with open("fichier_inexistant.txt", "r") as f:
        print(f.read())
except FileNotFoundError:
    print("Fichier introuvable, création d'un nouveau...")
```

```python
# ✅ Ce code fonctionne — plusieurs types d'erreurs peuvent être attrapés
try:
    nombre = int(input("Entrez un nombre : "))
    print(10 / nombre)
except ValueError:
    print("Ce n'était pas un nombre valide.")
except ZeroDivisionError:
    print("Impossible de diviser par zéro.")
```

```python
# ❌ Ce code contient une erreur LOGIQUE — le bloc 'except' attrape
# le MAUVAIS type, donc l'erreur fait quand même planter le programme :
try:
    nombre = int("abc")
except ZeroDivisionError:   # mauvais type d'erreur attrapé
    print("erreur attrapée")
# L'erreur réelle est ValueError, PAS ZeroDivisionError, donc Python
# ne l'attrape pas et le programme plante.
```

## `finally` et `else`

```python
# ✅ Ce code fonctionne — 'finally' s'exécute toujours (erreur ou pas)
try:
    x = 10 / 2
except ZeroDivisionError:
    print("Une erreur est survenue")
else:
    print("Pas d'erreur, résultat :", x)
finally:
    print("Terminé.")
```

## Lever sa propre erreur : `raise`

```python
# ✅ Ce code fonctionne
def verifier_age(age):
    if age < 0:
        raise ValueError("L'âge ne peut pas être négatif !")
    return age

try:
    verifier_age(-5)
except ValueError as e:
    print("Erreur attrapée :", e)
```

### 🎯 Mini-exercice
Demande un nom de fichier et un texte à écrire à l'utilisateur ;
gère les erreurs possibles (dont `PermissionError`) avec `try/except`.

---
⬅️ [Structures de données](./07-Structures-de-donnees.md) &nbsp;|&nbsp; ➡️ [Introduction à la POO](./09-Introduction-a-la-POO.md)
