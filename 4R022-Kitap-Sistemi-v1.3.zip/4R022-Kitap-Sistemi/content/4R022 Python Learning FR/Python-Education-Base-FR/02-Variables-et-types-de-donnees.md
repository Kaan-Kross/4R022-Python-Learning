# 2. Variables et types de données

## Qu'est-ce qu'une variable ?

Une variable stocke une valeur en mémoire sous un nom réutilisable.

```python
# ✅ Ce code fonctionne
age = 25
nom = "Kaan"
taille = 1.80
est_etudiant = True

print(nom, age, taille, est_etudiant)
```

```python
# ❌ Ce code NE FONCTIONNE PAS — un nom de variable ne peut pas
# commencer par un chiffre
1age = 25
```

Cela lève `SyntaxError: invalid decimal literal`. Les noms doivent
commencer par une lettre ou un underscore (`_`), jamais un chiffre.

## Types de données de base

| Type | Exemple | Signification |
|---|---|---|
| `int` | `5`, `-12` | Nombre entier |
| `float` | `3.14`, `-0.5` | Nombre décimal |
| `str` | `"bonjour"` | Texte (chaîne) |
| `bool` | `True`, `False` | Booléen |
| `NoneType` | `None` | « Aucune valeur » |

```python
# ✅ Ce code fonctionne
print(type(5))        # <class 'int'>
print(type(5.0))      # <class 'float'>
print(type("5"))      # <class 'str'>
print(type(True))     # <class 'bool'>
```

## Conversion de types

```python
# ✅ Ce code fonctionne
texte_nombre = "42"
vrai_nombre = int(texte_nombre)     # str -> int
print(vrai_nombre + 8)              # 50
```

```python
# ❌ Ce code NE FONCTIONNE PAS — "quarante-deux" ne peut pas devenir un nombre
nombre = int("quarante-deux")
```

Cela lève `ValueError: invalid literal for int()`. `int()` ne peut
convertir que des chaînes composées uniquement de chiffres.

## Récupérer une saisie : `input()`

```python
# ✅ Ce code fonctionne
nom = input("Quel est ton prénom ? ")
print("Bonjour " + nom + " !")
```

> ⚠️ **Attention :** `input()` renvoie toujours une **chaîne**. Pour
> des opérations numériques, convertis-la avec `int()` ou `float()` :

```python
# ✅ Ce code fonctionne
age = int(input("Quel âge as-tu ? "))
print("Dans 5 ans tu auras", age + 5, "ans")
```

### 🎯 Mini-exercice
Demande deux nombres à l'utilisateur avec `input()`, convertis-les
avec `int()`, additionne-les et affiche le résultat.

---
⬅️ [Installation](./01-Installation-et-premiers-pas.md) &nbsp;|&nbsp; ➡️ [Opérateurs](./03-Operateurs.md)
