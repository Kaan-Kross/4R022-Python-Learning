# 4. Structures conditionnelles (if / elif / else)

## Structure de base

```python
# ✅ Ce code fonctionne
age = 20

if age >= 18:
    print("Tu es majeur.")
else:
    print("Tu es mineur.")
```

## Plusieurs conditions : `elif`

```python
# ✅ Ce code fonctionne
note = 75

if note >= 85:
    print("Très bien")
elif note >= 70:
    print("Bien")
elif note >= 50:
    print("Passable")
else:
    print("Insuffisant")
```

```python
# ❌ Ce code NE FONCTIONNE PAS — "else if" au lieu de "elif"
# (c'est la syntaxe de C/Java/JavaScript, invalide en Python)
if note >= 85:
    print("Très bien")
else if note >= 70:
    print("Bien")
```

Python n'a pas de mot-clé `else if` ; le bon mot unique est `elif`.

## Conditions imbriquées

```python
# ✅ Ce code fonctionne
age = 20
a_permis = True

if age >= 18:
    if a_permis:
        print("Tu peux conduire.")
    else:
        print("Il te faut un permis.")
else:
    print("Tu ne peux pas encore conduire.")
```

## Expression ternaire (en une ligne)

```python
# ✅ Ce code fonctionne
age = 16
statut = "majeur" if age >= 18 else "mineur"
print(statut)
```

## Valeurs Truthy / Falsy

Python considère automatiquement beaucoup de valeurs comme « vraies »
ou « fausses » dans une condition, pas seulement `True`/`False` :

```python
# ✅ Ce code fonctionne
if "":        # chaîne vide -> Falsy
    print("ne s'affiche pas")
if "bonjour": # chaîne non vide -> Truthy
    print("s'affiche")
if 0:         # zéro -> Falsy
    print("ne s'affiche pas")
if []:        # liste vide -> Falsy
    print("ne s'affiche pas")
```

### 🎯 Mini-exercice
Demande une note (0-100) à l'utilisateur ; affiche « Très bien » pour
85+, « Bien » pour 70-84, « Passable » pour 50-69, sinon « Insuffisant ».

---
⬅️ [Opérateurs](./03-Operateurs.md) &nbsp;|&nbsp; ➡️ [Boucles](./05-Boucles.md)
