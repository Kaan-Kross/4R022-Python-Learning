# 6. Fonctions

## Pourquoi des fonctions ?

Plutôt que de répéter le même code, on l'enferme sous un nom qu'on
peut appeler à volonté — la base du principe DRY (Don't Repeat Yourself).

```python
# ✅ Ce code fonctionne
def saluer(nom):
    print(f"Bonjour, {nom} !")

saluer("Kaan")
saluer("4R022")
```

```python
# ❌ Ce code NE FONCTIONNE PAS — fonction appelée avant d'être définie
saluer("Kaan")

def saluer(nom):
    print(f"Bonjour, {nom} !")
```

Cela lève `NameError: name 'saluer' is not defined`. Python exécute
le code de haut en bas ; il faut définir une fonction avant de
l'appeler.

## Renvoyer une valeur avec `return`

```python
# ✅ Ce code fonctionne
def carre(n):
    return n ** 2

resultat = carre(5)
print(resultat)   # 25
```

> ⚠️ `print()` affiche à l'écran mais ne **renvoie** pas de valeur ;
> `return` fait sortir une valeur de la fonction pour la stocker.

## Paramètres par défaut

```python
# ✅ Ce code fonctionne
def saluer(nom, message="Bienvenue"):
    print(f"{message}, {nom} !")

saluer("Kaan")               # "Bienvenue, Kaan !"
saluer("Kaan", "Salut")      # "Salut, Kaan !"
```

## `*args` et `**kwargs`

```python
# ✅ Ce code fonctionne — accepte n'importe quel nombre d'arguments
def additionner(*nombres):
    return sum(nombres)

print(additionner(1, 2, 3, 4))   # 10
```

```python
# ✅ Ce code fonctionne — accepte n'importe quel nombre d'arguments nommés
def afficher_infos(**infos):
    for cle, valeur in infos.items():
        print(f"{cle}: {valeur}")

afficher_infos(nom="Kaan", metier="Développeur")
```

## Portée des variables

```python
# ❌ Ce code se comporte de façon INATTENDUE — le 'x' à l'intérieur
# de la fonction n'affecte pas le 'x' extérieur :
x = 10

def modifier():
    x = 20   # ceci crée un NOUVEAU x local, propre à la fonction

modifier()
print(x)   # toujours 10, pas 20
```

```python
# ✅ Ce code fonctionne — 'global' modifie le x extérieur
x = 10

def modifier():
    global x
    x = 20

modifier()
print(x)   # 20
```

### 🎯 Mini-exercice
Écris une fonction `plus_grand(liste)` qui trouve le plus grand
nombre d'une liste sans utiliser `max()`, avec une boucle `for`.

---
⬅️ [Boucles](./05-Boucles.md) &nbsp;|&nbsp; ➡️ [Structures de données](./07-Structures-de-donnees.md)
