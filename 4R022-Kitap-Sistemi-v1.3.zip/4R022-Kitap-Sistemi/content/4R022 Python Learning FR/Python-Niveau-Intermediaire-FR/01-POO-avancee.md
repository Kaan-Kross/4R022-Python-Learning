# 1. Programmation orientée objet avancée

## `@property` pour un accès contrôlé

```python
# ✅ Ce code fonctionne
class Rectangle:
    def __init__(self, largeur, hauteur):
        self._largeur = largeur
        self._hauteur = hauteur

    @property
    def aire(self):
        return self._largeur * self._hauteur

r = Rectangle(4, 5)
print(r.aire)   # 20 — défini comme une méthode, appelé comme un attribut (sans parenthèses !)
```

```python
# ❌ Ce code NE FONCTIONNE PAS — une property ne s'appelle pas avec des parenthèses
print(r.aire())
```

Cela lève `TypeError: 'int' object is not callable` car `r.aire` est
déjà une valeur calculée, pas une fonction.

## Méthodes spéciales (dunder)

```python
# ✅ Ce code fonctionne — __str__ et __eq__ personnalisent le comportement
class Point:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __str__(self):
        return f"Point({self.x}, {self.y})"

    def __eq__(self, autre):
        return self.x == autre.x and self.y == autre.y

p1 = Point(1, 2)
p2 = Point(1, 2)
print(p1)          # Point(1, 2) — grâce à __str__
print(p1 == p2)    # True — grâce à __eq__
```

```python
# ❌ Ce code se comporte différemment — sans __eq__, Python compare
# par défaut "est-ce le même objet en mémoire ?", donc ceci renvoie
# False (surprise logique, pas une erreur de syntaxe) :
class PointSimple:
    def __init__(self, x, y):
        self.x, self.y = x, y

a = PointSimple(1, 2)
b = PointSimple(1, 2)
print(a == b)   # False ! (__eq__ non défini)
```

## Héritage multiple et `super()`

```python
# ✅ Ce code fonctionne
class Employe:
    def __init__(self, nom, salaire):
        self.nom = nom
        self.salaire = salaire

class Developpeur(Employe):
    def __init__(self, nom, salaire, langage):
        super().__init__(nom, salaire)
        self.langage = langage

d = Developpeur("Kaan", 50000, "Python")
print(d.nom, d.salaire, d.langage)
```

## Classes abstraites

```python
# ✅ Ce code fonctionne
from abc import ABC, abstractmethod

class Forme(ABC):
    @abstractmethod
    def aire(self):
        pass

class Carre(Forme):
    def __init__(self, cote):
        self.cote = cote

    def aire(self):
        return self.cote ** 2

print(Carre(4).aire())   # 16
```

```python
# ❌ Ce code NE FONCTIONNE PAS — une classe abstraite ne peut pas être instanciée
forme = Forme()
```

Cela lève `TypeError: Can't instantiate abstract class Forme with
abstract method aire`. C'est exactement le rôle d'`ABC` : forcer les
sous-classes à implémenter certaines méthodes.

---
⬅️ [Retour](./README.md) &nbsp;|&nbsp; ➡️ [Décorateurs et générateurs](./02-Decorateurs-et-generateurs.md)
