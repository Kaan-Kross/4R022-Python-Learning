# 4. Modules, paquets et environnements virtuels

## Qu'est-ce qu'un module ?

Tout fichier `.py` est un **module**. Répartir le code dans
plusieurs fichiers garde un projet organisé et réutilisable.

```python
# ✅ Ce code fonctionne — fichier maths.py
def additionner(a, b):
    return a + b
```

```python
# ✅ Ce code fonctionne — import dans main.py
import maths
print(maths.additionner(3, 4))     # 7

from maths import additionner
print(additionner(1, 2))            # 3
```

```python
# ❌ Ce code NE FONCTIONNE PAS — faute de frappe dans le nom du fichier
import mathss
```

Cela lève `ModuleNotFoundError: No module named 'mathss'`.

## Qu'est-ce qu'un paquet ?

Un **paquet** est un dossier contenant un fichier `__init__.py`,
regroupant plusieurs modules.

```
projet/
├── main.py
└── aides/
    ├── __init__.py
    ├── maths.py
    └── texte.py
```

```python
# ✅ Ce code fonctionne
from aides import maths
from aides.texte import mettre_en_majuscule
```

Cette structure sous-tend l'architecture modulaire `core/` + `ui/`
utilisée dans les projets PyQt6 de 4R022.

## Gérer les paquets avec pip

```bash
# ✅ Ces commandes fonctionnent
pip install requests
pip freeze > requirements.txt
pip install -r requirements.txt
```

## Pourquoi des environnements virtuels ?

Un environnement virtuel donne à chaque projet son propre ensemble
isolé de paquets installés — pour que `flask==2.0` dans un projet
n'entre pas en conflit avec `flask==3.0` dans un autre.

```bash
# ✅ Ces commandes fonctionnent (dans le dossier du projet)
python -m venv venv

# Activation sur Windows :
venv\Scripts\activate

# Activation sur macOS / Linux :
source venv/bin/activate

pip install requests   # n'affecte que cet environnement
```

```bash
# ❌ Ceci NE FONCTIONNE PAS — mauvaise commande d'activation pour l'OS
source venv/bin/activate    # commande Linux/macOS, non reconnue dans Windows cmd
```

Sur Windows `cmd`, la bonne commande est `venv\Scripts\activate` (ou
`venv\Scripts\Activate.ps1` dans PowerShell).

### 🎯 Mini-exercice
Crée un module `formes.py` (avec des fonctions calculant l'aire d'un
cercle et d'un carré), puis importe-le et utilise-le depuis
`main.py`. Ensuite, crée un environnement virtuel et installe-y `requests`.

---
⬅️ [JSON et CSV](./03-JSON-et-CSV.md) &nbsp;|&nbsp; ➡️ [Tests et débogage](./05-Tests-et-debogage.md)
