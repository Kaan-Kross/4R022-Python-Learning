# 5. Tests et débogage

## Pourquoi écrire des tests ?

À mesure que le code grandit, vérifier manuellement qu'une
modification n'a rien cassé devient impossible. Les tests
automatisent cette vérification.

## `unittest` (bibliothèque standard)

```python
# ✅ Ce code fonctionne — calculatrice.py
def additionner(a, b):
    return a + b

def diviser(a, b):
    if b == 0:
        raise ValueError("Impossible de diviser par zéro")
    return a / b
```

```python
# ✅ Ce code fonctionne — test_calculatrice.py
import unittest
from calculatrice import additionner, diviser

class TestCalculatrice(unittest.TestCase):
    def test_additionner(self):
        self.assertEqual(additionner(2, 3), 5)

    def test_diviser_par_zero(self):
        with self.assertRaises(ValueError):
            diviser(10, 0)

if __name__ == "__main__":
    unittest.main()
```

```bash
python -m unittest test_calculatrice.py
```

## `pytest` (bibliothèque tierce populaire)

```bash
pip install pytest
```

```python
# ✅ Ce code fonctionne — pytest ne nécessite même pas unittest.TestCase
# test_calc.py
from calculatrice import additionner

def test_additionner():
    assert additionner(2, 3) == 5
```

```bash
pytest test_calc.py -v
```

## Astuces de débogage

```python
# ✅ Ce code fonctionne — utiliser print() pour tracer "quoi où"
def calculer(donnees):
    print("DEBUG : données entrantes ->", donnees)
    return sum(donnees) / len(donnees)
```

```python
# ✅ Ce code fonctionne — le débogueur intégré de Python
def calculer(donnees):
    breakpoint()   # l'exécution s'arrête ici pour inspecter les variables
    return sum(donnees) / len(donnees)
```

> 🧑‍🏫 **Note du professeur :** déboguer avec `print()` n'a rien
> d'« amateur » — les vrais développeurs l'utilisent souvent pour des
> vérifications rapides. Mais dans les gros projets, le module
> `logging` et un vrai débogueur (comme celui intégré à VS Code) sont
> bien plus puissants.

### 🎯 Mini-exercice
Ajoute une fonction `soustraire(a, b)` à `calculatrice.py`, puis
écris des tests pour elle avec `unittest` et avec `pytest`.

---
⬅️ [Modules, paquets, environnements virtuels](./04-Modules-paquets-environnements-virtuels.md) &nbsp;|&nbsp; ➡️ [Passer au niveau avancé](../Python-Niveau-Avance-FR/README.md)

🎉 **Félicitations — tu as terminé le niveau intermédiaire !**
