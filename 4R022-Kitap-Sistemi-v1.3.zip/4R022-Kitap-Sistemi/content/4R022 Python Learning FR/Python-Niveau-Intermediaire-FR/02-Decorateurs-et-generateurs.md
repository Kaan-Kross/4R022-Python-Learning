# 2. Décorateurs et générateurs

## Qu'est-ce qu'un décorateur ?

Un décorateur est une fonction qui « enveloppe » une autre fonction,
en étendant ou modifiant son comportement.

```python
# ✅ Ce code fonctionne
import time

def chronometrer(func):
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = func(*args, **kwargs)
        fin = time.time()
        print(f"{func.__name__} a pris {fin - debut:.4f} secondes")
        return resultat
    return wrapper

@chronometrer
def tache_longue():
    time.sleep(1)
    return "terminé"

tache_longue()
```

```python
# ❌ Ce code NE FONCTIONNE PAS — la fonction interne ne renvoie pas
# de valeur, donc le résultat réel de la fonction décorée est perdu :
def logger(func):
    def wrapper(*args, **kwargs):
        func(*args, **kwargs)   # 'return' a été oublié !
    return wrapper

@logger
def multiplier(a, b):
    return a * b

resultat = multiplier(3, 4)
print(resultat)   # affiche None, PAS 12
```

## Qu'est-ce qu'un générateur (`yield`) ?

Une fonction normale se termine par `return` et met tout son
résultat en mémoire d'un coup. Un **générateur** produit des valeurs
**une par une**, à la demande, via `yield` — économisant la mémoire
sur les gros volumes de données.

```python
# ✅ Ce code fonctionne
def generer_carres(n):
    for i in range(n):
        yield i * i

for carre in generer_carres(5):
    print(carre)   # 0, 1, 4, 9, 16 — produits un par un
```

```python
# ✅ Ce code fonctionne — expression génératrice, parenthèses au lieu de crochets
carres = (x * x for x in range(1_000_000))
print(next(carres))   # 0 — seule la valeur demandée est calculée
print(next(carres))   # 1
```

```python
# ❌ Ce code charge IMMÉDIATEMENT des millions d'éléments en mémoire —
# bien plus gourmand que le générateur ci-dessus :
carres_liste = [x * x for x in range(10_000_000)]  # toute la liste en mémoire !
```

Ce code « fonctionne » mais peut causer de sérieux problèmes de
mémoire sur de gros volumes de données — d'où la préférence pour les
générateurs.

### 🎯 Mini-exercice
Écris une fonction génératrice `fibonacci(n)` qui produit les `n`
premiers nombres de Fibonacci un par un via `yield`.

---
⬅️ [POO avancée](./01-POO-avancee.md) &nbsp;|&nbsp; ➡️ [JSON et CSV](./03-JSON-et-CSV.md)
