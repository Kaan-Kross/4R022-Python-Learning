# Python Niveau Intermédiaire (FR)

Une fois le niveau débutant terminé, on se rapproche de projets
réels : POO avancée, décorateurs/générateurs, formats de données,
gestion de paquets et tests.

## Chapitres

1. [POO avancée](./01-POO-avancee.md)
2. [Décorateurs et générateurs](./02-Decorateurs-et-generateurs.md)
3. [Formats de données : JSON et CSV](./03-JSON-et-CSV.md)
4. [Modules, paquets et environnements virtuels](./04-Modules-paquets-environnements-virtuels.md)
5. [Tests et débogage](./05-Tests-et-debogage.md)

Suite ➡️ [Niveau Avancé](../Python-Niveau-Avance-FR/README.md)
