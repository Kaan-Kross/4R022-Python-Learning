# 3. Formats de données : JSON et CSV

## JSON — échange de données structurées

JSON (JavaScript Object Notation) est le format le plus courant pour
les API web et les fichiers de configuration ; il correspond de
près à un `dict` Python.

```python
# ✅ Ce code fonctionne — écrit un dict Python dans un fichier JSON
import json

parametres = {"theme": "sombre", "langue": "fr", "version": 2}

with open("parametres.json", "w", encoding="utf-8") as f:
    json.dump(parametres, f, ensure_ascii=False, indent=4)

# ✅ Ce code fonctionne — relit le fichier JSON dans un dict
with open("parametres.json", "r", encoding="utf-8") as f:
    charges = json.load(f)
    print(charges["theme"])
```

```python
# ❌ Ce code NE FONCTIONNE PAS — analyse d'une chaîne "JSON" invalide
# (les guillemets simples ne sont pas valides en JSON !)
import json
donnees = json.loads("{'theme': 'sombre'}")
```

Cela lève `json.decoder.JSONDecodeError`. Le standard JSON exige des
**guillemets doubles** — à ne pas confondre avec la syntaxe des
dictionnaires Python.

## CSV — données tabulaires

```python
# ✅ Ce code fonctionne — écriture en CSV
import csv
with open("notes.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["nom", "note"])
    writer.writerow(["Kaan", 95])
```

```python
# ✅ Ce code fonctionne — lecture CSV
import csv
with open("notes.csv", "r", encoding="utf-8") as f:
    for ligne in csv.reader(f):
        print(ligne)
```

```python
# ❌ Ce code NE FONCTIONNE PAS (sur Windows) — oublier 'newline=""'
# provoque des lignes vides supplémentaires dans le fichier CSV
# (un bug de format sournois, pas un plantage) :
with open("notes.csv", "w", encoding="utf-8") as f:   # newline="" manque !
    writer = csv.writer(f)
    writer.writerows([["nom", "note"], ["Kaan", 95]])
```

### 🎯 Mini-exercice
Écris un programme qui sauvegarde une liste d'étudiants (`nom`,
`note`) à la fois en JSON et en CSV, puis les relit et calcule la
moyenne.

---
⬅️ [Décorateurs et générateurs](./02-Decorateurs-et-generateurs.md) &nbsp;|&nbsp; ➡️ [Modules, paquets, environnements virtuels](./04-Modules-paquets-environnements-virtuels.md)
