# Python : Concepts de données (FR)

Cette section est volontairement séparée des
[Modules](../Python-Modules-FR/README.md). Là où cette dernière
répond à « comment utiliser ce module en Python ? », celle-ci répond
à une question plus fondamentale : **« qu'est-ce que ce format/
système de données au juste, comment fonctionne-t-il, et comment
est-il intégré, automatisé, exporté et importé dans de vrais
systèmes ? »**

## Chapitres

1. [Que sont les données JSON ?](./01-Quest-ce-que-JSON.md)
2. [Que sont les données CSV ?](./02-Quest-ce-que-CSV.md)
3. [Que sont les bases de données et SQLite ?](./03-Bases-de-donnees-et-SQLite.md)

⬅️ [Niveau Avancé](../Python-Niveau-Avance-FR/README.md) &nbsp;|&nbsp; ➡️ [Modules](../Python-Modules-FR/README.md)
