# 3. Que sont les bases de données et SQLite ?

## Qu'est-ce qu'une base de données, et pourquoi en a-t-on besoin ?

Une base de données stocke les informations de manière
**organisée, interrogeable et cohérente.** Pourquoi un fichier JSON/
CSV ne suffit-il pas ? À mesure que les données grandissent
(milliers/millions d'enregistrements), les fichiers plats deviennent
**lents à chercher**, **difficiles à écrire en sécurité depuis
plusieurs utilisateurs à la fois**, et **incapables de garantir des
règles de cohérence.**

## Logique des bases de données relationnelles (brièvement)

Le type le plus courant est la base **relationnelle** — les données
sont stockées dans des **tables** liées entre elles par des clés
étrangères, interrogées en **SQL (Structured Query Language)**.

## Qu'est-ce que SQLite, et en quoi diffère-t-il des autres BDD ?

SQLite est un moteur de base de données relationnelle **sans
serveur**, où **toute la base tient dans un seul fichier.**
Contrairement à PostgreSQL ou MySQL, aucun serveur séparé n'est
nécessaire — le module `sqlite3` de Python se connecte directement à
un fichier `.db`.

| Critère | SQLite | PostgreSQL / MySQL |
|---|---|---|
| Installation | Aucune (basé fichier) | Serveur requis |
| Accès multi-utilisateur simultané | Limité | Robuste |
| Usage typique | Apps de bureau, mobile, prototypes | Sites web, systèmes à grande échelle |

## Comment les systèmes intègrent-ils les bases de données ?

1. **Applications de bureau :** les données utilisateur d'outils
   comme 4R022 Arşiv sont stockées directement dans un fichier
   SQLite local — pas besoin d'internet.
2. **Applications web :** le backend d'un site stocke souvent les
   comptes utilisateurs dans une BDD serveur.
3. **ORM :** des outils comme SQLAlchemy permettent de gérer une BDD
   avec des objets Python plutôt que du SQL brut.

## Comment les données sont-elles mises à jour, sauvegardées ?

- **Opérations CRUD :** `INSERT`, `SELECT`, `UPDATE`, `DELETE`.
- **Migration de schéma :** appliquée via des scripts contrôlés.
- **Sauvegarde :** pour SQLite, copier le fichier `.db` suffit
  souvent ; les BDD serveur utilisent des outils dédiés.

## Export/import et automatisation

- Exporter une table en CSV est le moyen le plus courant d'alimenter
  des outils de reporting.
- Des scripts automatisés peuvent sauvegarder la BDD chaque nuit et
  supprimer les anciennes sauvegardes.

## Quelles sont ses limites ?

- SQLite ne convient pas aux grandes applications web nécessitant
  **beaucoup d'écritures simultanées.**
- Les BDD relationnelles peuvent être trop rigides pour des
  structures de données flexibles — d'où les bases « NoSQL »
  (MongoDB).

---
⬅️ [Que sont les données CSV ?](./02-Quest-ce-que-CSV.md) &nbsp;|&nbsp; ⬆️ [Accueil de la section](./README.md)

🎓 Ensuite, consulte [Modules](../Python-Modules-FR/README.md) pour
le côté code (`json`, `csv`, `sqlite3`).
