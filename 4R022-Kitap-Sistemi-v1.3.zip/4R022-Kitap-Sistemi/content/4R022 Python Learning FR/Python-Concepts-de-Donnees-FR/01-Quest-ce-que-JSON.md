# 1. Que sont les données JSON ?

## Origine et nature de JSON

JSON (JavaScript Object Notation) est né de la syntaxe des objets
JavaScript, mais est devenu un **format d'échange de données
universel, indépendant du langage.** Popularisé vers 2001 par
Douglas Crockford, il est aujourd'hui défini par le standard RFC 8259.

## À quoi ressemble sa structure ?

JSON repose sur seulement **6 briques de base** : objet, tableau,
chaîne, nombre, booléen, valeur nulle. Elles s'imbriquent pour
représenter des données de complexité arbitraire.

```json
{
  "utilisateur": "Kaan",
  "actif": true,
  "age": 25,
  "roles": ["developpeur", "etudiant"],
  "adresse": {"ville": "Sakarya", "pays": "Turquie"},
  "telephone_secondaire": null
}
```

## Pourquoi est-il si répandu ?

- **La langue commune des API web** — mobile, site web et serveur
  peuvent être écrits dans des langages totalement différents et
  échanger des données sans problème via JSON.
- **Lisible par l'humain** — un développeur peut ouvrir un fichier
  JSON brut et le comprendre presque sans documentation.
- **Léger** — moins de « bruit » que le XML.

## Comment les systèmes intègrent-ils JSON ?

1. **Communication via API :** une appli mobile envoie une requête
   au serveur → le serveur renvoie les infos utilisateur en JSON →
   l'appli les analyse et affiche le nom d'utilisateur.
2. **Fichiers de configuration :** de nombreuses applications (VS
   Code, projets npm) stockent leurs réglages dans des fichiers `.json`.
3. **Logs/systèmes de données :** les journaux serveur utilisent
   souvent le format « JSON Lines » (chaque ligne est un objet JSON).

## Comment est-il actualisé ?

- **Sondage (polling) :** le client interroge périodiquement le serveur.
- **Push (webhook/websocket) :** le serveur envoie lui-même le
  nouveau JSON dès qu'une donnée change.
- **Basé sur fichier :** une application locale réécrit son fichier
  de paramètres JSON à chaque modification (avec écriture atomique
  pour éviter la perte de données).

## Automatisation et export/import

- **Export :** une sauvegarde complète est souvent écrite dans un
  unique fichier JSON.
- **Import :** un système source exporte ses données en JSON, le
  système cible les lit et les importe dans sa propre structure.

## Quelles sont ses limites ?

- **Pas de commentaires** dans le standard officiel.
- **Peut être inefficace pour de très gros volumes** — CSV ou une
  vraie base de données conviennent mieux à des millions de lignes.
- **Aucun schéma imposé** — rien ne garantit qu'un fichier JSON est
  « bien structuré » (d'où des outils comme JSON Schema).

---
⬅️ [Retour](./README.md) &nbsp;|&nbsp; ➡️ [Que sont les données CSV ?](./02-Quest-ce-que-CSV.md)
