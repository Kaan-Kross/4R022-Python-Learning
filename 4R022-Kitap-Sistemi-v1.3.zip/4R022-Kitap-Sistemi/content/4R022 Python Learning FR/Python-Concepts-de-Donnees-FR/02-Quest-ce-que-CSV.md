# 2. Que sont les données CSV ?

## Origine et nature

CSV (Comma-Separated Values) est l'un des plus anciens et plus
simples formats de données tabulaires en **texte brut**, utilisé
depuis les années 1970. Il n'a pas de standard strict imposé (RFC
4180 est une recommandation).

## À quoi ressemble sa structure ?

```csv
nom,age,ville
Kaan,25,Sakarya
Ayse,22,Istanbul
"Dupont, Jean",30,Paris
```

Le nom de la troisième ligne contient une virgule, il est donc mis
**entre guillemets** — une règle de base qu'un vrai parseur CSV doit
comprendre (d'où l'usage d'une vraie bibliothèque CSV plutôt qu'un
`split(",")` brut).

## Pourquoi est-il encore si utilisé ?

- **Format d'échange universel pour Excel/Google Sheets.**
- **Lisible à l'œil** pour les petits fichiers.
- **Format d'export standard des bases de données.**

## Comment les systèmes intègrent-ils CSV ?

1. **Systèmes comptables/ERP :** export d'un rapport de ventes
   mensuel en CSV, réutilisé dans un autre outil.
2. **Data science :** les données brutes sont souvent collectées en
   CSV, lues avec `pandas`, nettoyées et analysées.
3. **Import en masse :** remplir un modèle CSV plutôt que saisir des
   centaines de produits un par un.

## Comment est-il actualisé / automatisé ?

- **Exports programmés :** de nombreux systèmes horodatent
  automatiquement un fichier CSV chaque nuit/semaine.
- **Scripts de surveillance :** un script d'automatisation peut
  surveiller un dossier et importer tout nouveau CSV apparu.

## Pratiques d'export/import

- **Export :** `pandas.DataFrame.to_csv()` transforme un tableau en
  CSV en une ligne.
- **Import :** attention aux différences de séparateur/encodage
  entre systèmes.

## Quelles sont ses limites ?

- **Ne transporte aucune information de type** — tout est du texte.
- **Ne peut pas représenter de données imbriquées** — contrairement
  à JSON.
- **Incohérence du standard** — séparateur, fin de ligne, encodage
  varient d'un système à l'autre.

---
⬅️ [Que sont les données JSON ?](./01-Quest-ce-que-JSON.md) &nbsp;|&nbsp; ➡️ [Bases de données et SQLite](./03-Bases-de-donnees-et-SQLite.md)
