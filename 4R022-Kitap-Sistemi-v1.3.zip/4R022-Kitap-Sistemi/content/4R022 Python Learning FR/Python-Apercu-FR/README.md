# Python : Aperçu (FR)

Avant de plonger dans le code, cette section répond à : qu'est-ce
que Python, comment se compare-t-il aux autres langages, et que
peut-on réellement construire avec ?

## Sommaire

1. [Qu'est-ce que Python ?](./01-Quest-ce-que-Python.md)
2. [Python face aux autres langages de programmation](./02-Python-face-aux-autres-langages.md)
3. [Que peut-on construire avec Python ?](./03-Que-peut-on-construire.md)

Suite ➡️ [Python Éducation de Base](../Python-Education-Base-FR/README.md)
