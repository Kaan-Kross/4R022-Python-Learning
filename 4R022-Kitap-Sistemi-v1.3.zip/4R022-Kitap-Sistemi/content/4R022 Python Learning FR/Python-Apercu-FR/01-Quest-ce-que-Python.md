# Qu'est-ce que Python ?

> 🧑‍🏫 **Note du professeur :** considère cette section comme une
> conversation, pas une définition à mémoriser. Le but est de
> vraiment comprendre pourquoi ce langage existe et pourquoi il est
> si populaire.

## En bref

Python est un langage de programmation **interprété**, **de haut
niveau**, à **usage général**, créé par **Guido van Rossum** en
1991. « Haut niveau » signifie qu'il se lit presque comme de
l'anglais courant plutôt que comme des instructions machine brutes.

La philosophie de Python tient en une phrase :

> **« La lisibilité du code passe avant tout. »**

```python
# ✅ Ce code fonctionne — et se lit presque comme une phrase normale
nom = "Kaan"
if nom == "Kaan":
    print("Bonjour, 4R022 !")
```

## Pourquoi « interprété » ?

Le code Python n'est pas compilé directement en code machine ; il
est exécuté ligne par ligne par un **interpréteur** (CPython étant
le plus courant). Cela accélère le développement, au prix d'une
vitesse d'exécution un peu plus faible que les langages compilés
comme C/C++ — un compromis délibéré en faveur de la rapidité de
développement et de la lisibilité.

## Caractéristiques principales

| Caractéristique | Description |
|---|---|
| Typage dynamique | Pas besoin de déclarer le type d'une variable à l'avance |
| Syntaxe lisible | Blocs de code basés sur l'indentation |
| Bibliothèque standard immense | Philosophie « piles incluses » |
| Multi-paradigme | Procédural, orienté objet et fonctionnel tous pris en charge |
| Multiplateforme | Le même code fonctionne sur Windows, Linux, macOS |
| Communauté massive | Plus de 500 000 paquets sur PyPI |

```python
# ✅ Ce code fonctionne
x = 5        # x est actuellement un entier
x = "cinq"   # maintenant la même variable contient une chaîne — pas d'erreur
print(x)
```

```python
# ❌ Ce code NE FONCTIONNE PAS — c'est la syntaxe de C/Java, pas de Python.
# Coller ceci dans un fichier Python lève une SyntaxError :
int x = 5;
```

## Pourquoi l'indentation compte-t-elle autant ?

Python utilise **l'indentation** (pas des `{}`) pour définir les
blocs. C'est à la fois le trait le plus distinctif du langage et
l'erreur la plus fréquente chez les débutants.

```python
# ✅ Ce code fonctionne — indentation correcte
def saluer():
    print("Bonjour")
    print("Bienvenue dans 4R022 Python Learning")

saluer()
```

```python
# ❌ Ce code NE FONCTIONNE PAS — lève une IndentationError
def saluer():
print("Bonjour")   # cette ligne devait être indentée
```

## Résumé

- Python est lisible, à typage dynamique, interprété et polyvalent.
- Il sépare les blocs de code par l'indentation — sa plus grande
  force et son piège le plus fréquent au début.
- Il possède une bibliothèque standard immense et un écosystème de
  paquets communautaires (PyPI).

### 🎯 Mini-exercice
Trouve et corrige le bug dans ce code :

```python
def additionner(a, b):
return a + b

print(additionner(3, 4))
```

<details>
<summary>Voir la réponse</summary>

`return a + b` n'est pas indenté, ce qui lève une `IndentationError`.
Version corrigée :

```python
def additionner(a, b):
    return a + b

print(additionner(3, 4))
```

</details>

---
⬅️ [Retour](./README.md) &nbsp;|&nbsp; ➡️ Suite : [Python face aux autres langages](./02-Python-face-aux-autres-langages.md)
