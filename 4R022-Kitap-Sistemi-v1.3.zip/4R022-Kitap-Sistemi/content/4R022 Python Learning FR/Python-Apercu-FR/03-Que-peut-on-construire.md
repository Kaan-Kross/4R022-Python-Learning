# Que peut-on construire avec Python ?

## 1. Développement web (backend)
**Outils :** Django, Flask, FastAPI

```python
# ✅ Ce code fonctionne (si Flask est installé) : un serveur web minimal
from flask import Flask
app = Flask(__name__)

@app.route("/")
def accueil():
    return "Bienvenue dans 4R022 Python Learning !"
```

## 2. Science des données et analyse
**Outils :** pandas, numpy, matplotlib

```python
# ✅ Ce code fonctionne (si pandas est installé)
import pandas as pd
donnees = {"nom": ["Alice", "Bob"], "age": [23, 30]}
df = pd.DataFrame(donnees)
print(df)
```

## 3. Intelligence artificielle et apprentissage automatique
**Outils :** TensorFlow, PyTorch, scikit-learn

Python est le langage de facto de l'IA — presque tous les grands
modèles de langage et bibliothèques de ML proposent une interface Python.

## 4. Automatisation et scripts
**Outils :** os, shutil, pyautogui, selenium

```python
# ✅ Ce code fonctionne — liste tous les fichiers d'un dossier
import os
for fichier in os.listdir("."):
    print(fichier)
```

## 5. Développement d'applications de bureau
**Outils :** Tkinter (bibliothèque standard), PyQt6, Kivy

De nombreux projets de la marque 4R022 (outils de bureau) entrent
exactement dans cette catégorie — des applications Windows
professionnelles construites avec Python + PyQt6/Tkinter.

## 6. Cybersécurité et programmation réseau
**Outils :** socket, scapy, cryptography, requests

Les chercheurs en sécurité utilisent souvent Python pour l'analyse
du trafic réseau, le chiffrement et les scans de sécurité
automatisés. Nous couvrons le côté **éthique** de ce sujet dans
[Éthique et Sécurité](../Python-Ethique-et-Securite-FR/README.md).

## 7. Développement de jeux (léger)
**Outils :** Pygame

## 8. Langage de « colle »
Python est aussi largement utilisé pour connecter différents systèmes
entre eux (bibliothèques C, bases de données, API) — d'où son
surnom de « langage de colle ».

## Tableau récapitulatif

| Domaine | Bibliothèques populaires |
|---|---|
| Web (backend) | Django, Flask, FastAPI |
| Science des données | pandas, numpy, matplotlib |
| IA | TensorFlow, PyTorch, scikit-learn |
| Automatisation | os, selenium, pyautogui |
| Applications de bureau | Tkinter, PyQt6, Kivy |
| Réseau / sécurité | socket, scapy, cryptography |
| Jeux | Pygame |

---
⬅️ Précédent : [Python face aux autres langages](./02-Python-face-aux-autres-langages.md) &nbsp;|&nbsp; ➡️ Suite : [Commencer le niveau débutant](../Python-Education-Base-FR/README.md)
