# Python face aux autres langages de programmation

## Python vs C / C++

C et C++ sont des langages **compilés** et à **typage statique**.
Ils s'exécutent très près du matériel et sont donc rapides, mais la
gestion de la mémoire est généralement manuelle.

```c
// C — les types sont obligatoires
int addition(int a, int b) {
    return a + b;
}
```

```python
# ✅ Python — pas besoin de déclarer les types
def addition(a, b):
    return a + b
```

**Différence :** C est choisi pour la vitesse et le contrôle
bas niveau (OS, moteurs de jeu, systèmes embarqués) ; Python pour la
rapidité de développement et la lisibilité (automatisation, science
des données, backend).

## Python vs Java

Java est aussi à typage statique et compile vers du bytecode ;
« tout doit vivre dans une classe » est une règle obligatoire.

```java
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
```

```python
# ✅ Python — pas besoin de classe, une seule ligne suffit
print("Hello World")
```

**Différence :** Java est puissant pour les grands systèmes
d'entreprise et Android ; Python est plus adapté au prototypage
rapide et aux scripts.

## Python vs JavaScript

JavaScript est à typage dynamique et s'exécute dans le navigateur
(et sur serveur via Node.js) — proche de Python dans l'esprit.

```javascript
function addition(a, b) {
    return a + b;
}
```

```python
def addition(a, b):
    return a + b
```

**Différence :** JavaScript est le langage natif du navigateur (rien
d'autre n'y fonctionne) ; Python n'a aucun rôle dans le navigateur
mais est bien plus à l'aise pour le backend, l'automatisation, la
science des données et les applications de bureau.

## Python vs C#

C# est le langage à typage statique de Microsoft pour l'écosystème
.NET, très proche de Java dans le style — courant pour les
applications de bureau Windows (WPF, WinForms) et le développement
de jeux (Unity).

**Différence :** C# s'intègre profondément à Windows/.NET ; Python
l'emporte sur la portabilité multiplateforme et la rapidité de
développement.

## Quel langage choisir ?

| Besoin | Langage recommandé |
|---|---|
| Analyse de données, IA, automatisation | **Python** |
| Interface de navigateur | JavaScript (+ HTML/CSS) |
| Moteur de jeu haute performance / OS | C / C++ |
| Backend d'entreprise / Android | Java |
| Bureau Windows / jeux Unity | C# |
| Scripts rapides, prototypes, apprentissage | **Python** |

## Résumé

Aucun langage n'est universellement « le meilleur » — chacun existe
pour une raison. Ce qui distingue Python, ce n'est pas la vitesse
brute, mais **la productivité du développeur et une courbe
d'apprentissage faible.** C'est exactement pour cela que nous
commençons ici.

---
⬅️ Précédent : [Qu'est-ce que Python ?](./01-Quest-ce-que-Python.md) &nbsp;|&nbsp; ➡️ Suite : [Que peut-on construire avec Python ?](./03-Que-peut-on-construire.md)
