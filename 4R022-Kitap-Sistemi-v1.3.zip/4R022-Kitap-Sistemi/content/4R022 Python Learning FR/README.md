<img src="./assets/4r022-logo.png" alt="4R022 Python Learning Logo" width="220"/>

# 4R022 Python Learning (FR)

Marque : **4R022** | Auteur : **Kaan Kross**

Ceci est le paquet français du projet **4R022 Python Learning** — un
cursus Python complet, structuré et original.

## 📌 Statut du projet

| Section | Statut |
|---|---|
| Aperçu | ✅ Terminé |
| Niveau Débutant | ✅ Terminé |
| Niveau Intermédiaire | ✅ Terminé |
| Niveau Avancé (+ GUI/UX) | ✅ Terminé |
| Concepts de données | ✅ Terminé |
| Modules (36 modules) | ✅ Terminé |
| Éthique et Sécurité | ✅ Terminé |

L'édition française est désormais entièrement complète — même
ampleur et profondeur que les éditions turque et anglaise.

## Contenu du paquet
- `Python-Apercu-FR/`
- `Python-Education-Base-FR/`
- `Python-Niveau-Intermediaire-FR/`
- `Python-Niveau-Avance-FR/`
- `Python-Concepts-de-Donnees-FR/`
- `Python-Modules-FR/`
- `Python-Ethique-et-Securite-FR/`

## Licence
Voir [`LICENSE.txt`](./LICENSE.txt) — usage éducatif libre ; revente
commerciale sans mention de la marque "4R022" interdite.
