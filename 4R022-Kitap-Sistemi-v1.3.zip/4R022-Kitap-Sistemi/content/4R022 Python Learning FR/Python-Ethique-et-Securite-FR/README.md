# Python Éthique et Sécurité (FR)

Cette section n'est pas un chapitre technique — c'est un chapitre de
**prise de conscience.** Avec un langage aussi capable que Python,
on peut presque tout automatiser, parler aux réseaux, toucher aux
systèmes de fichiers — et ce pouvoir vient avec une responsabilité.

En tant que 4R022 Python Learning, nous ne prenons **aucun parti**
ici : nous ne disons pas « apprends à pirater, tout est permis », ni
ne suggérons d'éviter ce domaine par peur. Notre but est de présenter
ces notions **avec précision et neutralité**, et de te laisser la
décision et la responsabilité.

## Chapitres

1. [Usage éthique et responsabilités](./01-Usage-ethique-et-responsabilites.md)
2. [Qui sont les hackers White / Grey / Black Hat ?](./02-Hackers-White-Grey-Black-Hat.md)
3. [Limites légales et avertissement](./03-Limites-legales-et-avertissement.md)

Terminer cette section complète tout le programme actuellement disponible. 🎓
