# 2. Qui sont les hackers White / Grey / Black Hat ?

> Ce chapitre est purement **descriptif et informatif** ; il
> n'enseigne aucune technique d'attaque.

## La racine commune : que signifie vraiment « hacker » ?

Bien que la culture populaire assimile souvent « hacker » à
« criminel informatique », son sens original est **une personne qui
comprend profondément un système, repousse ses limites et crée des
solutions créatives.** Dans la culture du MIT des années 1960,
« hacker » était un qualificatif positif. Avec le temps, les médias
ont presque entièrement lié ce mot à « cybercriminel » — d'où
l'usage de « couleurs de chapeau » pour distinguer.

## ⚪ White Hat

**Qui sont-ils ?** Des personnes qui testent des systèmes pour y
trouver des vulnérabilités **avec l'autorisation écrite du
propriétaire**, afin de les corriger.

**Que font-ils ?** Tests d'intrusion (pentest), programmes bug
bounty, conseil en sécurité, construction de systèmes de défense.

**Pourquoi existent-ils ?** La personne la mieux placée pour casser
un système est souvent la mieux placée pour le défendre.

## ⚫ Black Hat

**Qui sont-ils ?** Des personnes qui s'introduisent dans des
systèmes sans permission, avec une intention malveillante — vol de
données, dommages, gain financier ou politique.

**Que font-ils ?** (décrit à un niveau informatif, sans détail
technique) Distribution de rançongiciels, vol de données, phishing,
attaques DDoS, vente de données volées — toutes des activités
**illégales.**

**Pourquoi existent-ils ?** Gain financier, activisme politique
(« hacktivisme »), espionnage, ou simplement « le défi ». Ces
activités sont des **crimes** dans presque tous les pays.

## ⚪⚫ Grey Hat

**Qui sont-ils ?** Entre les deux — trouvent généralement une
vulnérabilité **sans permission**, mais au lieu de l'exploiter,
préviennent souvent le propriétaire.

**Pourquoi restent-ils dans cette zone ?** Leur intention n'est
généralement pas malveillante, mais la **méthode** (accès non
autorisé) reste illégale dans la plupart des pays.

## Tableau comparatif

| | White Hat | Grey Hat | Black Hat |
|---|---|---|---|
| Permission | Oui | Non | Non |
| Intention | Bonne | Généralement bonne | Mauvaise |
| Légalité | Légal | Ambigu | Illégal |
| Résultat | Récompense, carrière | Remerciement ou procès | Prison, amendes |

## Autres couleurs (brièvement)

- **Red Hat :** contre-attaque agressive contre les black hats.
- **Blue Team :** défense continue au sein d'une organisation.
- **Script Kiddie :** terme (péjoratif) pour des personnes
  inexpérimentées utilisant des outils tout faits sans comprendre
  leur fonctionnement.

## Pourquoi cette distinction compte-t-elle ?

Les outils appris ici — `socket`, `requests`, `selenium`,
`cryptography` — peuvent techniquement servir aux deux camps. Ce qui
détermine ton camp, c'est **uniquement la permission et
l'intention** — le code est le même, la décision fait la différence.

---
⬅️ [Usage éthique et responsabilités](./01-Usage-ethique-et-responsabilites.md) &nbsp;|&nbsp; ➡️ [Limites légales et avertissement](./03-Limites-legales-et-avertissement.md)
