# 1. Usage éthique et responsabilités

## Le code est neutre, l'intention ne l'est pas

Tout ce que tu as appris ici — lecture/écriture de fichiers,
programmation réseau (`socket`), automatisation de navigateur
(`selenium`), chiffrement (`cryptography`) — **n'est en soi ni bon
ni mauvais.** Le même code `socket` peut servir dans un devoir
d'étudiant ou dans un outil malveillant. Ce qui fait la différence,
c'est **qui l'utilise, avec quelle permission, et dans quel but.**

## Trois questions simples

Avant d'exécuter un script, demande-toi :

1. **Ai-je la permission ?** Ai-je obtenu l'accord explicite du
   propriétaire pour tester/utiliser ce système/ces données/ce compte ?
2. **Cela cause-t-il un préjudice ?** Ce code peut-il nuire aux
   données, à la vie privée, aux systèmes, à la réputation ou aux
   finances de quelqu'un ?
3. **Suis-je transparent ?** Pourrais-je expliquer sans rien cacher
   ce que fait exactement ce code aux personnes concernées ?

Si tu ne peux pas répondre « oui » sans hésiter aux trois, tu es
probablement proche d'une limite éthique et/ou légale.

## Exemples réels d'usage légitime

| Technique | Usage légitime | Où la limite est franchie |
|---|---|---|
| Web scraping | Collecter les données de son propre site, dans le respect de `robots.txt` | Collecter des données personnelles en violant les CGU d'un site |
| Bots d'automatisation | Automatiser des tâches répétitives sur son propre compte | Violer les règles d'une plateforme avec de faux comptes |
| Outils de scan réseau | Tester son propre réseau avec autorisation écrite (pentest) | Scanner le système d'un tiers sans autorisation |
| Outils de récupération de mot de passe | Récupérer son propre mot de passe oublié | Tenter d'accéder au compte de quelqu'un d'autre |

## Responsabilités

- **Responsabilité légale :** elle t'incombe — « je ne savais pas »
  ne fonctionne généralement pas comme défense.
- **Responsabilité éthique :** couvre aussi les zones grises que la
  loi ne règle pas entièrement.
- **Responsabilité envers la communauté :** en partageant ce que tu
  apprends ici, garde à l'esprit que d'autres peuvent en abuser.

### 🎯 Exercice de réflexion
Si un ami te demandait de « juste essayer » de craquer le mot de
passe des réseaux sociaux de son ex, quelles seraient les réponses
aux trois questions ci-dessus ?

---
⬅️ [Retour](./README.md) &nbsp;|&nbsp; ➡️ [Hackers White/Grey/Black Hat](./02-Hackers-White-Grey-Black-Hat.md)
