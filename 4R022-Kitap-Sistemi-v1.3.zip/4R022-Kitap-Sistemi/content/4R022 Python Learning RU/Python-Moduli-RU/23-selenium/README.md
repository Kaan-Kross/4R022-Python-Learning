# Модуль `selenium`

> ⚠️ Смотри [Этика и безопасность](../../Python-Etika-i-Bezopasnost-RU/README.md) — только для легального использования на собственных сайтах.

## Что это и как работает?

Управляет настоящим браузером программно через WebDriver Protocol.

## ✅ Рабочие примеры

```python
from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://example.com")
print(driver.title)
driver.quit()
```

## ❌ Неправильные примеры

### Неправильный пример 1 — обращение к элементу до загрузки страницы

```python
driver.get("https://medlenniy-sayt.com")
el = driver.find_element(By.ID, "rezultaty")
```
- **Почему неправильно?** Контент может подгружаться JS позже.
- **Где ошибка?** `NoSuchElementException`.
- **Что вместо?** Используй `WebDriverWait`.

### Неправильный пример 2 — забыт `driver.quit()`

```python
driver = webdriver.Chrome()
driver.get("https://example.com")
# driver.quit() не вызван
```
- **Почему неправильно?** Процесс браузера остаётся открытым.
- **Где ошибка?** Отсутствует очистка ресурсов.
- **Что вместо?** Используй `try/finally` с `driver.quit()`.

## 🔗 Связанные модули
[requests](../16-requests/README.md)

---
⬅️ [Главная страница модулей](../README.md)
