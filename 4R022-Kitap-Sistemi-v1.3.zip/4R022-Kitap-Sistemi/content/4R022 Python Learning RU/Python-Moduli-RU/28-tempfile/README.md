# Модуль `tempfile`

## Что это и как работает?

Автоматически создаёт уникальные временные файлы/папки, обычно
удаляемые по завершении программы.

## ✅ Рабочие примеры

```python
import tempfile
with tempfile.NamedTemporaryFile(mode="w") as f:
    f.write("dannye")
```

## ❌ Неправильные примеры

### Неправильный пример 1 — доступ к файлу после закрытия (delete=True)

```python
f = tempfile.NamedTemporaryFile(mode="w", delete=True)
f.close()
open(f.name)   # файл уже удалён!
```
- **Почему неправильно?** Файл удаляется сразу при закрытии.
- **Где ошибка?** `FileNotFoundError`
- **Что вместо?** Используй `delete=False`, удаляй вручную позже.

### Неправильный пример 2 — доступ из другого процесса на Windows

```python
f = tempfile.NamedTemporaryFile(mode="w")
open(f.name, "r")   # может не сработать на Windows
```
- **Почему неправильно?** Windows блокирует одновременный доступ.
- **Где ошибка?** `PermissionError`
- **Что вместо?** Используй `delete=False` для кроссдоступа.

## 🔗 Связанные модули
[os](../01-os/README.md)

---
⬅️ [Главная страница модулей](../README.md)
