# Модуль `sqlite3`

## Что это и как работает?

Лёгкая реляционная СУБД, вся база данных — один файл, сервер не
нужен.

## ✅ Рабочие примеры

```python
import sqlite3
conn = sqlite3.connect("app.db")
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS s (id INTEGER PRIMARY KEY, imya TEXT)")
c.execute("INSERT INTO s (imya) VALUES (?)", ("Каан",))
conn.commit()
```

## ❌ Неправильные примеры

### Неправильный пример 1 — SQL-инъекция через конкатенацию строк

```python
imya = "Каан"
c.execute(f"SELECT * FROM s WHERE imya = '{imya}'")
```
- **Почему неправильно?** Уязвимость SQL-инъекции.
- **Где ошибка?** Пользовательский ввод вставлен напрямую в запрос.
- **Что вместо?** `c.execute("SELECT * FROM s WHERE imya = ?", (imya,))`

### Неправильный пример 2 — забыт `commit()`

```python
c.execute("INSERT INTO s (imya) VALUES (?)", ("Айше",))
conn.close()   # commit() забыт!
```
- **Почему неправильно?** Изменения не сохраняются на диск.
- **Где ошибка?** `conn.commit()` не вызван.
- **Что вместо?** Всегда вызывай `conn.commit()` после записи.

## 🔗 Связанные модули
[threading](../12-threading/README.md)

---
⬅️ [Главная страница модулей](../README.md)
