# Модуль `asyncio`

## Что это и как работает?

Управляет множеством задач ожидания в одном потоке — при `await`
задача приостанавливается, выполняется другая.

## ✅ Рабочие примеры

```python
import asyncio
async def privet():
    await asyncio.sleep(1)
    print("Привет!")
asyncio.run(privet())
```

```python
import asyncio
async def main():
    await asyncio.gather(privet(), privet())
```

## ❌ Неправильные примеры

### Неправильный пример 1 — вызов async-функции без await

```python
import asyncio
async def privet():
    print("Привет!")
privet()   # ничего не выполнится!
```
- **Почему неправильно?** Создаётся объект-корутина, но не выполняется.
- **Где ошибка?** `RuntimeWarning: coroutine was never awaited`
- **Что вместо?** `asyncio.run(privet())`

### Неправильный пример 2 — блокирующий код внутри async

```python
import asyncio, time
async def zadacha():
    time.sleep(3)   # блокирует ВЕСЬ event loop!
```
- **Почему неправильно?** `time.sleep()` синхронен, замораживает всё.
- **Где ошибка?** Использован `time.sleep`, а не `await asyncio.sleep`.
- **Что вместо?** `await asyncio.sleep(3)`

## 🔗 Связанные модули
[threading](../12-threading/README.md)

---
⬅️ [Главная страница модулей](../README.md)
