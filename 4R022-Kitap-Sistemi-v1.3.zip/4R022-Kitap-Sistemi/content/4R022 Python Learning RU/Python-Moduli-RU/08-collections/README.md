# Модуль `collections`

## Что это и как работает?

`collections` предоставляет специализированные версии `list`/`dict`:
`Counter` для подсчёта, `deque` для быстрых операций с обоих концов,
`defaultdict` для автоматических значений по умолчанию.

## Когда используется?
Подсчёт частоты слов, очереди, группировка без KeyError.

## ✅ Рабочие примеры

```python
from collections import Counter
c = Counter("apple pear apple".split())
print(c.most_common(1))
```

```python
from collections import defaultdict
g = defaultdict(list)
g["frukty"].append("yabloko")
```

## ❌ Неправильные примеры

### Неправильный пример 1 — добавление в отсутствующий ключ обычного dict

```python
g = {}
g["frukty"].append("yabloko")
```
- **Почему неправильно?** Ключа `"frukty"` ещё нет.
- **Где ошибка?** `KeyError: 'frukty'`
- **Что вместо?** `defaultdict(list)`

### Неправильный пример 2 — изменение `namedtuple`

```python
from collections import namedtuple
Tochka = namedtuple("Tochka", ["x", "y"])
t = Tochka(1, 2)
t.x = 5
```
- **Почему неправильно?** `namedtuple` неизменяем.
- **Где ошибка?** `AttributeError: can't set attribute`
- **Что вместо?** `t._replace(x=5)` — создаёт новый объект.

## 🔗 Связанные модули
[itertools и functools](../09-itertools-i-functools/README.md)

---
⬅️ [Главная страница модулей](../README.md)
