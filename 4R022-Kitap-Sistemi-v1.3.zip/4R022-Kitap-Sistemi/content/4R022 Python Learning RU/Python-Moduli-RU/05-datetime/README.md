# Модуль `datetime`

## Что это и как работает?

Модуль `datetime` позволяет корректно представлять, сравнивать и
форматировать даты и время — вместо хранения дат как обычных строк.

## Когда используется?
Временные метки в логах, расчёты в напоминаниях/будильниках (основа
проекта 4R022 SAAT), вычисление возраста и продолжительности.

## ✅ Рабочие примеры

```python
from datetime import datetime
seychas = datetime.now()
print(seychas.strftime("%d.%m.%Y %H:%M"))
```

```python
from datetime import datetime, timedelta
napominanie = datetime.now() + timedelta(hours=2)
print(napominanie.strftime("%H:%M"))
```

## ❌ Неправильные примеры

### Неправильный пример 1 — несовпадающий формат

```python
from datetime import datetime
data = datetime.strptime("2026-09-15", "%d/%m/%Y")
```
- **Почему неправильно?** Формат не совпадает со строкой.
- **Где ошибка?** `-` вместо `/`, неверный порядок.
- **Что вместо?** `datetime.strptime("2026-09-15", "%Y-%m-%d")`

### Неправильный пример 2 — сравнение datetime со строкой

```python
from datetime import datetime
d1 = datetime.now()
d2 = "2026-09-15"
print(d1 > d2)
```
- **Почему неправильно?** Нельзя сравнивать `datetime` и `str`.
- **Где ошибка?** `d2` не преобразована в datetime.
- **Что вместо?** Сначала `d2 = datetime.strptime(...)`.

## 🔗 Связанные модули
[os](../01-os/README.md), [logging](../11-logging/README.md)

---
⬅️ [Главная страница модулей](../README.md)
