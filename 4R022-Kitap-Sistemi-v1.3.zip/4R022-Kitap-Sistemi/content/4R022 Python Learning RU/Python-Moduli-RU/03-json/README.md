# Модуль `json`

## Что это и как работает?

Модуль `json` превращает объекты Python (`dict`, `list`, `str`,
`int`...) в **текст JSON** (сериализация) и обратно (десериализация).
JSON — универсальный «общий язык» для веб-API и файлов конфигурации.

## Когда и где используется?

- Хранение настроек приложения в файле
- Обработка данных, приходящих от веб-API или отправляемых в него
- Атомарная запись JSON (с резервной копией `.bak`) в системах
  архивации/настроек 4R022

## ✅ Рабочие примеры

```python
# Пример 1: dict -> файл JSON
import json
nastroyki = {"tema": "tyomnaya", "yazyk": "ru"}
with open("nastroyki.json", "w", encoding="utf-8") as f:
    json.dump(nastroyki, f, ensure_ascii=False, indent=4)
```

```python
# Пример 2: файл JSON -> dict
import json
with open("nastroyki.json", "r", encoding="utf-8") as f:
    nastroyki = json.load(f)
print(nastroyki["tema"])
```

## ❌ Нерабочие/неправильные примеры

### Неправильный пример 1 — разбор строки с одинарными кавычками

```python
import json
data = json.loads("{'tema': 'tyomnaya'}")
```

- **Почему неправильно?** Стандарт JSON требует **двойных кавычек**;
  одинарные — это синтаксис словаря Python, а не JSON.
- **Где ошибка?** Возникает `json.decoder.JSONDecodeError`.
- **Что использовать вместо?** `json.loads('{"tema": "tyomnaya"}')`

### Неправильный пример 2 — чтение битого файла без защиты

```python
import json
with open("bitiy.json", "r") as f:
    data = json.load(f)   # падает, если файл пуст или повреждён
```

- **Почему неправильно?** Если файл пуст, повреждён или отсутствует,
  программа падает.
- **Где ошибка?** Обработка ошибок (`try/except`) отсутствует.
- **Что использовать вместо?**
  ```python
  try:
      with open("bitiy.json", "r", encoding="utf-8") as f:
          data = json.load(f)
  except (json.JSONDecodeError, FileNotFoundError):
      data = {}
  ```

## 🔗 Связанные модули
[csv](../04-csv/README.md), [os](../01-os/README.md)

---
⬅️ [Главная страница модулей](../README.md)
