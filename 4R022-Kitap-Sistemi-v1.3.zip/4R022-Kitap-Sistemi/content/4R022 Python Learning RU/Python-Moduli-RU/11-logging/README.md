# Модуль `logging`

## Что это и как работает?

`logging` — профессиональная замена `print()` для отладки: уровни
важности (DEBUG, INFO, WARNING, ERROR, CRITICAL), запись в файл и на
экран одновременно, автоматические временные метки.

## ✅ Рабочие примеры

```python
import logging
logging.basicConfig(level=logging.INFO)
logging.info("Приложение запущено")
```

```python
import logging
try:
    1/0
except ZeroDivisionError:
    logging.exception("Ошибка деления")
```

## ❌ Неправильные примеры

### Неправильный пример 1 — повторный вызов `basicConfig()`

```python
import logging
logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.ERROR)   # игнорируется!
```
- **Почему неправильно?** `basicConfig()` эффективен только при
  первом вызове.
- **Где ошибка?** Второй вызов ничего не меняет, без предупреждения.
- **Что вместо?** Настрой один раз правильно, или используй
  `logging.getLogger().setLevel(...)`.

### Неправильный пример 2 — логирование пароля

```python
import logging
logging.info(f"Вход: password={parol}")
```
- **Почему неправильно?** Серьёзная угроза безопасности.
- **Где ошибка?** Пароль напрямую записан в лог.
- **Что вместо?** Никогда не логируй чувствительные данные.

## 🔗 Связанные модули
[datetime](../05-datetime/README.md)

---
⬅️ [Главная страница модулей](../README.md)
