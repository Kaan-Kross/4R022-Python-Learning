# Flask и FastAPI

## Что это и как работает?

Обе библиотеки позволяют писать веб-сервер/API на Python. Flask —
минималистичный микрофреймворк; FastAPI генерирует автоматическую
валидацию данных и документацию из аннотаций типов.

## ✅ Рабочие примеры

```python
from flask import Flask, jsonify
app = Flask(__name__)
@app.route("/studenty")
def studenty():
    return jsonify([{"imya": "Каан", "otsenka": 95}])
```

```python
from fastapi import FastAPI
from pydantic import BaseModel
app = FastAPI()
class Student(BaseModel):
    imya: str
    otsenka: int
```

## ❌ Неправильные примеры

### Неправильный пример 1 — `debug=True` в продакшене

```python
app.run(debug=True, host="0.0.0.0")
```
- **Почему неправильно?** Открывает интерактивную консоль для
  выполнения кода — серьёзная уязвимость.
- **Где ошибка?** Настройка для разработки перенесена в прод.
- **Что вместо?** `debug=False`, использовать `gunicorn`.

### Неправильный пример 2 — данные не соответствуют модели Pydantic

```python
import requests
requests.post(url, json={"imya": "Каан", "otsenka": "девяносто пять"})
```
- **Почему неправильно?** `otsenka` ожидает `int`, а не строку.
- **Где ошибка?** FastAPI вернёт `422 Unprocessable Entity`.
- **Что вместо?** Отправляй `{"imya": "Каан", "otsenka": 95}`.

## 🔗 Связанные модули
[requests](../16-requests/README.md)

---
⬅️ [Главная страница модулей](../README.md)
