# Модуль `PyQt6`

## Что это и как работает?

Python-обёртка над мощной C++ библиотекой Qt6, с архитектурой
сигнал/слот — при событии сигнал автоматически вызывает связанный слот.

## ✅ Рабочие примеры

```python
import sys
from PyQt6.QtWidgets import QApplication, QWidget
app = QApplication(sys.argv)
window = QWidget()
window.show()
sys.exit(app.exec())
```

## ❌ Неправильные примеры

### Неправильный пример 1 — виджет до QApplication

```python
window = QWidget()   # QApplication ещё не создан!
app = QApplication(sys.argv)
```
- **Почему неправильно?** QApplication должен создаваться первым.
- **Где ошибка?** Неверный порядок вызовов.
- **Что вместо?** Сначала `app = QApplication(sys.argv)`.

### Неправильный пример 2 — сигнал со скобками

```python
button.clicked.connect(klik())   # скобки!
```
- **Почему неправильно?** Функция вызывается немедленно.
- **Где ошибка?** Передаётся результат `None`, а не функция.
- **Что вместо?** `button.clicked.connect(klik)`

## 🔗 Связанные модули
[tkinter](../21-tkinter/README.md)

---
⬅️ [Главная страница модулей](../README.md)
