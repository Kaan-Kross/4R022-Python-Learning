# Модуль `pathlib`

## Что это и как работает?

`pathlib` представляет пути к файлам как **объекты**, а не строки —
через оператор `/` вместо `os.path.join()`.

## ✅ Рабочие примеры

```python
from pathlib import Path
put = Path("proekt") / "dannye" / "nastroyki.json"
print(put)
```

```python
from pathlib import Path
f = Path("zametki.txt")
if f.exists():
    print(f.read_text(encoding="utf-8"))
```

## ❌ Неправильные примеры

### Неправильный пример 1 — путаница `Path.replace()` со строковым replace

```python
from pathlib import Path
p = Path("file.txt")
print(p.replace(".txt", ".csv"))
```
- **Почему неправильно?** `Path.replace()` перемещает/переименовывает
  файл, а не заменяет текст.
- **Где ошибка?** Может вызвать `FileNotFoundError`.
- **Что вместо?** `p.with_suffix(".csv")`

### Неправильный пример 2 — запись в несуществующую папку

```python
from pathlib import Path
f = Path("net_papki/zametki.txt")
f.write_text("privet")
```
- **Почему неправильно?** Родительская папка должна существовать.
- **Где ошибка?** `FileNotFoundError`
- **Что вместо?** `f.parent.mkdir(parents=True, exist_ok=True)`

## 🔗 Связанные модули
[os](../01-os/README.md)

---
⬅️ [Главная страница модулей](../README.md)
