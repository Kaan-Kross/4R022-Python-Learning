# Модуль `requests`

## Что это и как работает?

Отправляет HTTP-запросы к веб-серверам/API — гораздо удобнее
стандартного `urllib`.

## ✅ Рабочие примеры

```python
import requests
r = requests.get("https://api.github.com", timeout=5)
print(r.status_code, r.json())
```

## ❌ Неправильные примеры

### Неправильный пример 1 — без `timeout`

```python
import requests
r = requests.get("https://ochen-medlenniy-server.com")
```
- **Почему неправильно?** Программа может ждать вечно.
- **Где ошибка?** Параметр `timeout` отсутствует.
- **Что вместо?** `requests.get(url, timeout=5)`

### Неправильный пример 2 — API-ключ в коде

```python
API_KLYUCH = "sk-realniy-klyuch"
r = requests.get(f"https://api.example.com/data?key={API_KLYUCH}")
```
- **Почему неправильно?** Серьёзная угроза безопасности при
  публикации на GitHub.
- **Где ошибка?** Ключ вшит в исходный код.
- **Что вместо?** Храни в переменных окружения / `.env`.

## 🔗 Связанные модули
[Flask и FastAPI](../17-flask-i-fastapi/README.md)

---
⬅️ [Главная страница модулей](../README.md)
