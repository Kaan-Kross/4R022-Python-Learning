# Модуль `queue`

## Что это и как работает?

Потокобезопасная очередь FIFO для безопасной передачи данных между потоками.

## ✅ Рабочие примеры

```python
import queue
q = queue.Queue()
q.put("zadacha-1")
print(q.get())
```

## ❌ Неправильные примеры

### Неправильный пример 1 — `get_nowait()` на пустой очереди

```python
q = queue.Queue()
q.get_nowait()
```
- **Почему неправильно?** Нет ожидания — сразу ошибка.
- **Где ошибка?** `queue.Empty`
- **Что вместо?** Используй `q.get()` или `try/except queue.Empty`.

### Неправильный пример 2 — обычный list между потоками

```python
data = []
threading.Thread(target=lambda: data.append(1)).start()
```
- **Почему неправильно?** `list.append()` не атомарен.
- **Где ошибка?** Риск гонки данных.
- **Что вместо?** `queue.Queue()`

## 🔗 Связанные модули
[threading](../12-threading/README.md)

---
⬅️ [Главная страница модулей](../README.md)
