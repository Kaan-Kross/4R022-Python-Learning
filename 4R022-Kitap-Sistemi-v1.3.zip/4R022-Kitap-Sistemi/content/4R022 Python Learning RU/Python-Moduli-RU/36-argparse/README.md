# Модуль `argparse`

## Что это и как работает?

Даёт скриптам профессиональный интерфейс командной строки: `--help`,
преобразование типов, обязательные/опциональные аргументы.

## ✅ Рабочие примеры

```python
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("fayl")
parser.add_argument("--podrobno", action="store_true")
args = parser.parse_args()
```

## ❌ Неправильные примеры

### Неправильный пример 1 — запуск без обязательного аргумента

```bash
python tool.py
```
- **Почему неправильно?** `fayl` — обязательный позиционный аргумент.
- **Где ошибка?** `error: the following arguments are required: fayl`
- **Что вместо?** `python tool.py notes.txt`

### Неправильный пример 2 — значение для флага `store_true`

```bash
python tool.py --podrobno da
```
- **Почему неправильно?** `store_true` не принимает значение.
- **Где ошибка?** `error: unrecognized arguments: da`
- **Что вместо?** `python tool.py --podrobno` без значения.

## 🔗 Связанные модули
[sys](../02-sys/README.md)

---
⬅️ [Главная страница модулей](../README.md)
