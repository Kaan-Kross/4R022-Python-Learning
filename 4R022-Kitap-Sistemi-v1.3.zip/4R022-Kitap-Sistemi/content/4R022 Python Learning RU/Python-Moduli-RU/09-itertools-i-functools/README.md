# Модули `itertools` и `functools`

## Что это и как работает?

`itertools` — быстрые, экономные по памяти инструменты для циклов
(генераторная логика). `functools` — инструменты для работы с
функциями: кэширование, сведение списка к одному значению.

## ✅ Рабочие примеры

```python
from itertools import chain
for x in chain([1,2], [3,4]):
    print(x)
```

```python
from functools import reduce
print(reduce(lambda a,b: a*b, [1,2,3,4]))   # 24
```

## ❌ Неправильные примеры

### Неправильный пример 1 — бесконечный `count()` без break

```python
from itertools import count
for i in count(1):
    print(i)   # никогда не остановится!
```
- **Почему неправильно?** `count()` бесконечен.
- **Где ошибка?** Нет условия выхода.
- **Что вместо?** Добавь `if i > 10: break`.

### Неправильный пример 2 — `lru_cache` с изменяемым аргументом

```python
from functools import lru_cache
@lru_cache(maxsize=None)
def summa(spisok):
    return sum(spisok)
summa([1,2,3])
```
- **Почему неправильно?** `list` не хешируем.
- **Где ошибка?** `TypeError: unhashable type: 'list'`
- **Что вместо?** Передай `tuple`: `summa((1,2,3))`

## 🔗 Связанные модули
[collections](../08-collections/README.md)

---
⬅️ [Главная страница модулей](../README.md)
