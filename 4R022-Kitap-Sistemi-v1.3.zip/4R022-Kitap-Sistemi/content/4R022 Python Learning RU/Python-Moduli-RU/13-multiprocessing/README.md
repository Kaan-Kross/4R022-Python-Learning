# Модуль `multiprocessing`

## Что это и как работает?

Запускает независимые процессы с собственной памятью и GIL — даёт
реальный параллелизм для CPU-задач.

## ✅ Рабочие примеры

```python
import multiprocessing
def kvadrat(n):
    return n*n
if __name__ == "__main__":
    with multiprocessing.Pool(4) as p:
        print(p.map(kvadrat, [1,2,3,4]))
```

## ❌ Неправильные примеры

### Неправильный пример 1 — забыт `if __name__ == "__main__":` (Windows)

```python
import multiprocessing
def f(n): return n*2
pool = multiprocessing.Pool(4)
print(pool.map(f, [1,2,3]))
```
- **Почему неправильно?** На Windows каждый процесс переимпортирует
  скрипт заново без этой защиты.
- **Где ошибка?** Код не обёрнут в `if __name__ == "__main__":`
- **Что вместо?** Оберни весь код запуска в этот блок.

### Неправильный пример 2 — попытка разделить обычную переменную

```python
import multiprocessing
schetchik = 0
def uvelichit():
    global schetchik
    schetchik += 1
if __name__ == "__main__":
    p = multiprocessing.Process(target=uvelichit)
    p.start(); p.join()
    print(schetchik)   # всё ещё 0!
```
- **Почему неправильно?** У каждого процесса своя память.
- **Где ошибка?** `global` влияет только на копию процесса.
- **Что вместо?** `multiprocessing.Queue` или `Manager()`.

## 🔗 Связанные модули
[threading](../12-threading/README.md)

---
⬅️ [Главная страница модулей](../README.md)
