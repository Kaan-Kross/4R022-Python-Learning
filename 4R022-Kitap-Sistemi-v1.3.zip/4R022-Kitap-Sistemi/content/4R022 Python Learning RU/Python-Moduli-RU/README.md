# Python: Модули и их использование (RU)

Библиотека-справочник, отвечающая на вопрос «какой модуль
использовать для этой задачи?» — **по одной папке на модуль.**
Каждая папка модуля содержит:

- 📖 Что это за модуль и его **принцип работы**
- 🎯 Для чего, когда и где он используется
- ✅ Несколько рабочих примеров кода
- ❌ Несколько **нерабочих/неправильных** примеров — каждый с
  разбором: **«почему неправильно? где ошибка? что использовать вместо?»**
- 🔗 Ссылки на связанные/дополняющие модули

## 🟢 Стандартная библиотека (установка не требуется)

| Модуль | Для чего нужен |
|---|---|
| [os](./01-os/README.md) | Взаимодействие с ОС, операции с файлами/папками |
| [sys](./02-sys/README.md) | Взаимодействие с интерпретатором, аргументы командной строки |
| [json](./03-json/README.md) | Чтение/запись данных JSON |
| [csv](./04-csv/README.md) | Чтение/запись табличных данных CSV |
| [datetime](./05-datetime/README.md) | Работа с датой и временем |
| [math и random](./06-math-i-random/README.md) | Математические операции, генерация случайных чисел |
| [re (регулярные выражения)](./07-re-regulyarnye-vyrazheniya/README.md) | Поиск/замена по шаблону в тексте |
| [collections](./08-collections/README.md) | Продвинутые структуры данных (Counter, defaultdict, deque) |
| [itertools и functools](./09-itertools-i-functools/README.md) | Инструменты для циклов и функций |
| [pathlib](./10-pathlib/README.md) | Современная объектная работа с путями файлов |
| [logging](./11-logging/README.md) | Профессиональное логирование |
| [threading](./12-threading/README.md) | Многопоточность (задачи с ожиданием ввода-вывода) |
| [multiprocessing](./13-multiprocessing/README.md) | Многопроцессность (задачи, нагружающие CPU) |
| [asyncio](./14-asyncio/README.md) | Асинхронное программирование |
| [sqlite3](./15-sqlite3/README.md) | Встроенная лёгкая база данных |
| [queue](./27-queue/README.md) | Потокобезопасная очередь данных |
| [tempfile](./28-tempfile/README.md) | Управление временными файлами/папками |
| [hashlib](./30-hashlib/README.md) | Хэш-функции |
| [shutil](./31-shutil/README.md) | Высокоуровневые операции с файлами/папками, архивирование |
| [subprocess](./32-subprocess/README.md) | Запуск внешних команд/программ |
| [enum](./33-enum/README.md) | Читаемые именованные константы (перечисления) |
| [dataclasses](./34-dataclasses/README.md) | Написание классов данных с меньшим количеством кода |
| [typing](./35-typing/README.md) | Аннотации типов |
| [argparse](./36-argparse/README.md) | Профессиональные интерфейсы командной строки |
| [unittest и pytest](./26-unittest-i-pytest/README.md) | Автоматизированное тестирование |

## 🔵 Популярные сторонние библиотеки (нужен `pip install`)

| Модуль | Для чего нужен |
|---|---|
| [requests](./16-requests/README.md) | HTTP-запросы, работа с внешними API |
| [Flask и FastAPI](./17-flask-i-fastapi/README.md) | Разработка веб-сервера / API |
| [numpy](./18-numpy/README.md) | Быстрые операции с числовыми массивами |
| [pandas](./19-pandas/README.md) | Анализ табличных данных |
| [matplotlib](./20-matplotlib/README.md) | Графики и визуализация данных |
| [tkinter](./21-tkinter/README.md) | Стандартная библиотека для настольного GUI |
| [PyQt6](./22-PyQt6/README.md) | Профессиональная библиотека для настольного GUI |
| [selenium](./23-selenium/README.md) | Автоматизация браузера |
| [socket](./24-socket/README.md) | Низкоуровневое сетевое программирование |
| [cryptography](./25-cryptography/README.md) | Шифрование и безопасность данных |
| [qrcode](./29-qrcode/README.md) | Генерация QR-кодов |

Не забудь про [Этика и безопасность](../Python-Etika-i-Bezopasnost-RU/README.md) — правовые и этические границы.

⬅️ [Концепции данных](../Python-Kontseptsii-Dannykh-RU/README.md) &nbsp;|&nbsp; ➡️ [Этика и безопасность](../Python-Etika-i-Bezopasnost-RU/README.md)
