# Модуль `threading`

## Что это и как работает?

`threading` запускает несколько потоков. Из-за GIL в CPython
реального параллелизма для CPU-задач нет, но для задач ожидания
(I/O) потоки эффективны.

## ✅ Рабочие примеры

```python
import threading, time
def zadacha():
    time.sleep(1)
    print("готово")
t = threading.Thread(target=zadacha)
t.start(); t.join()
```

```python
import threading
lock = threading.Lock()
schetchik = 0
def uvelichit():
    global schetchik
    with lock:
        schetchik += 1
```

## ❌ Неправильные примеры

### Неправильный пример 1 — забыт `join()`

```python
import threading, time
def zadacha():
    time.sleep(2)
    print("готово")
t = threading.Thread(target=zadacha)
t.start()
print("конец программы")   # может напечататься раньше!
```
- **Почему неправильно?** `start()` не ждёт завершения потока.
- **Где ошибка?** Отсутствует `t.join()`.
- **Что вместо?** Добавь `t.join()`.

### Неправильный пример 2 — изменение общих данных без Lock

```python
import threading
schetchik = 0
def uvelichit():
    global schetchik
    schetchik += 1   # не атомарно!
threads = [threading.Thread(target=uvelichit) for _ in range(100000)]
```
- **Почему неправильно?** Race condition — потери инкрементов.
- **Где ошибка?** Нет `threading.Lock()`.
- **Что вместо?** Оберни в `with lock:`.

## 🔗 Связанные модули
[multiprocessing](../13-multiprocessing/README.md), [asyncio](../14-asyncio/README.md)

---
⬅️ [Главная страница модулей](../README.md)
