# Модуль `subprocess`

## Что это и как работает?

Запускает внешние программы/команды из Python.

## ✅ Рабочие примеры

```python
import subprocess
r = subprocess.run(["python", "--version"], capture_output=True, text=True)
print(r.stdout)
```

## ❌ Неправильные примеры

### Неправильный пример 1 — `shell=True` с пользовательским вводом

```python
imya_fayla = input("Файл: ")
subprocess.run(f"del {imya_fayla}", shell=True)
```
- **Почему неправильно?** Инъекция команд — серьёзная уязвимость.
- **Где ошибка?** Пользовательский ввод напрямую в shell-команде.
- **Что вместо?** `subprocess.run(["del", imya_fayla])` без shell=True.

### Неправильный пример 2 — огромный вывод в память

```python
subprocess.run(["find", "/", "-name", "*.log"], capture_output=True)
```
- **Почему неправильно?** Весь вывод загружается в память сразу.
- **Где ошибка?** Возможна нехватка памяти.
- **Что вместо?** Используй `Popen` для потокового чтения построчно.

## 🔗 Связанные модули
[os](../01-os/README.md)

---
⬅️ [Главная страница модулей](../README.md)
