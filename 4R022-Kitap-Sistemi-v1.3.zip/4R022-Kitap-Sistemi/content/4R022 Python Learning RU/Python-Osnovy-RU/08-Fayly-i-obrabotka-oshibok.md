# 8. Работа с файлами и обработка ошибок

## Чтение и запись файлов

```python
# ✅ Этот код работает — записывает в файл (создаёт, если его нет)
with open("zametki.txt", "w", encoding="utf-8") as f:
    f.write("Привет, 4R022!\n")
    f.write("Изучаю Python.\n")

# ✅ Этот код работает — читает файл
with open("zametki.txt", "r", encoding="utf-8") as f:
    soderzhimoe = f.read()
    print(soderzhimoe)
```

Использование `with` гарантирует, что файл **автоматически
закроется** по завершении блока — не нужно вручную вызывать `f.close()`.

```python
# ❌ Этот код НЕ РАБОТАЕТ — попытка прочитать несуществующий файл
with open("nesushchestvuyushchiy.txt", "r") as f:
    print(f.read())
```

Возникнет `FileNotFoundError: [Errno 2] No such file or directory`.

## Обработка ошибок: `try / except`

Подобные ошибки «роняют» программу. Чтобы этого избежать, их
«перехватывают»:

```python
# ✅ Этот код работает — ошибка перехвачена, программа не падает
try:
    with open("nesushchestvuyushchiy.txt", "r") as f:
        print(f.read())
except FileNotFoundError:
    print("Файл не найден, создаём новый...")
```

```python
# ✅ Этот код работает — можно перехватывать несколько типов ошибок
try:
    chislo = int(input("Введите число: "))
    print(10 / chislo)
except ValueError:
    print("Вы ввели не число.")
except ZeroDivisionError:
    print("На ноль делить нельзя.")
```

```python
# ❌ Этот код содержит ЛОГИЧЕСКУЮ ошибку — блок 'except' указывает
# НЕПРАВИЛЬНЫЙ тип ошибки, поэтому программа всё равно падает:
try:
    chislo = int("abc")
except ZeroDivisionError:   # указан неверный тип ошибки
    print("ошибка перехвачена")
# На самом деле возникает ValueError, а НЕ ZeroDivisionError.
# Python не перехватывает этот ValueError, и программа падает.
```

## `finally` и `else`

```python
# ✅ Этот код работает — 'finally' выполняется всегда (была ошибка или нет)
try:
    x = 10 / 2
except ZeroDivisionError:
    print("Произошла ошибка")
else:
    print("Ошибок нет, результат:", x)
finally:
    print("Операция завершена.")
```

## Вызов собственной ошибки: `raise`

```python
# ✅ Этот код работает
def proverit_vozrast(vozrast):
    if vozrast < 0:
        raise ValueError("Возраст не может быть отрицательным!")
    return vozrast

try:
    proverit_vozrast(-5)
except ValueError as oshibka:
    print("Ошибка перехвачена:", oshibka)
```

### 🎯 Мини-упражнение
Попроси у пользователя имя файла и текст для записи; обработай
возможные ошибки (включая `PermissionError`) с помощью `try/except`.

---
⬅️ [Структуры данных](./07-Struktury-dannykh.md) &nbsp;|&nbsp; ➡️ [Введение в ООП](./09-Vvedenie-v-OOP.md)
