# 9. Введение в объектно-ориентированное программирование (ООП)

## Класс (`class`) и объект (`object`)

**Класс** — это «шаблон». **Объект (экземпляр)** — это реальный
экземпляр, созданный по этому шаблону.

```python
# ✅ Этот код работает
class Student:
    def __init__(self, imya, vozrast):
        self.imya = imya       # атрибут
        self.vozrast = vozrast

    def predstavitsya(self):   # метод
        print(f"Меня зовут {self.imya}, мне {self.vozrast} лет.")

student1 = Student("Каан", 25)
student2 = Student("Айше", 22)

student1.predstavitsya()   # "Меня зовут Каан, мне 25 лет."
student2.predstavitsya()   # "Меня зовут Айше, мне 22 лет."
```

`__init__` — специальный метод, который **автоматически** выполняется
при создании объекта (конструктор). `self` представляет сам объект.

```python
# ❌ Этот код НЕ РАБОТАЕТ — параметр 'self' забыт
class Student:
    def __init__(imya, vozrast):     # 'self' отсутствует!
        imya = imya
        vozrast = vozrast

student1 = Student("Каан", 25)
```

Возникнет `TypeError: __init__() takes 2 positional arguments but 3
were given`. Python автоматически передаёт объект как первый
параметр каждого метода; забыть об этом — классическая ошибка ООП.

## Наследование

```python
# ✅ Этот код работает
class Zhivotnoe:
    def __init__(self, imya):
        self.imya = imya

    def izdat_zvuk(self):
        print(f"{self.imya} издаёт звук.")

class Sobaka(Zhivotnoe):          # наследуется от Zhivotnoe
    def izdat_zvuk(self):         # переопределяет метод
        print(f"{self.imya}: Гав-гав!")

zhivotnoe = Zhivotnoe("Неизвестное")
sobaka = Sobaka("Шарик")

zhivotnoe.izdat_zvuk()   # "Неизвестное издаёт звук."
sobaka.izdat_zvuk()      # "Шарик: Гав-гав!"
```

## Инкапсуляция — простое введение

```python
# ✅ Этот код работает — атрибуты с _ в начале считаются "приватными"
# (в Python это лишь соглашение, а не реальное ограничение доступа)
class BankovskiySchet:
    def __init__(self, balans):
        self._balans = balans

    def polozhit(self, summa):
        if summa > 0:
            self._balans += summa

    def pokazat_balans(self):
        return self._balans

schet = BankovskiySchet(100)
schet.polozhit(50)
print(schet.pokazat_balans())   # 150
```

## Зачем нужно ООП?

Когда программа растёт, объединение связанных данных (атрибутов) и
логики, работающей с этими данными (методов), делает код понятным
и управляемым. Разделение `core/` и `ui/` в настольных приложениях
4R022 на PyQt6 — это та же идея, только в увеличенном масштабе.

### 🎯 Мини-упражнение
Напиши класс `Transportnoe_Sredstvo` (с атрибутами `marka`,
`skorost`), затем создай унаследованный от него класс
`SportivnyyAvtomobil` и переопредели метод `uskoritsya()`.

---
⬅️ [Файлы и обработка ошибок](./08-Fayly-i-obrabotka-oshibok.md) &nbsp;|&nbsp; ➡️ [Перейти к среднему уровню](../Python-Sredniy-Uroven-RU/README.md)

🎉 **Поздравляем — ты завершил базовый уровень!**
