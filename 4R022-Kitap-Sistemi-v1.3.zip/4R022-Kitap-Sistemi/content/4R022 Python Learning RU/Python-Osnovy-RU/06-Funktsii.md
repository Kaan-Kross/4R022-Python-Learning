# 6. Функции

## Зачем нужны функции?

Вместо того чтобы повторять один и тот же код, можно «упаковать»
его под именем и вызывать когда нужно — это основа принципа DRY
(Don't Repeat Yourself).

```python
# ✅ Этот код работает
def privet(imya):
    print(f"Привет, {imya}!")

privet("Каан")
privet("4R022")
```

```python
# ❌ Этот код НЕ РАБОТАЕТ — функция вызвана до её определения
privet("Каан")

def privet(imya):
    print(f"Привет, {imya}!")
```

Возникнет `NameError: name 'privet' is not defined`. Python
выполняет код сверху вниз; функцию нужно определить до её вызова.

## Возврат значения через `return`

```python
# ✅ Этот код работает
def kvadrat(chislo):
    return chislo ** 2

rezultat = kvadrat(5)
print(rezultat)   # 25
```

> ⚠️ `print()` выводит на экран, но не **возвращает** значение;
> `return` передаёт значение за пределы функции, где его можно
> сохранить в переменной.

## Параметры по умолчанию

```python
# ✅ Этот код работает
def privet(imya, soobshchenie="Добро пожаловать"):
    print(f"{soobshchenie}, {imya}!")

privet("Каан")               # "Добро пожаловать, Каан!"
privet("Каан", "Здравствуй") # "Здравствуй, Каан!"
```

## `*args` и `**kwargs`

```python
# ✅ Этот код работает — принимает любое количество аргументов
def summa(*chisla):
    return sum(chisla)

print(summa(1, 2, 3, 4))   # 10
```

```python
# ✅ Этот код работает — принимает любое количество именованных аргументов
def vyvesti_info(**info):
    for klyuch, znachenie in info.items():
        print(f"{klyuch}: {znachenie}")

vyvesti_info(imya="Каан", professiya="Разработчик")
```

## Область видимости переменных

```python
# ❌ Этот код ведёт себя НЕОЖИДАННО — переменная 'x' внутри функции
# не влияет на 'x' снаружи:
x = 10

def izmenit():
    x = 20   # это НОВАЯ локальная переменная x

izmenit()
print(x)   # всё ещё 10, а не 20
```

```python
# ✅ Этот код работает — ключевое слово global изменяет внешнюю x
x = 10

def izmenit():
    global x
    x = 20

izmenit()
print(x)   # 20
```

### 🎯 Мини-упражнение
Напиши функцию `naibolshiy(spisok)`, которая находит наибольшее
число в списке (без использования встроенной `max()`, с помощью
цикла `for`).

---
⬅️ [Циклы](./05-Tsikly.md) &nbsp;|&nbsp; ➡️ [Структуры данных](./07-Struktury-dannykh.md)
