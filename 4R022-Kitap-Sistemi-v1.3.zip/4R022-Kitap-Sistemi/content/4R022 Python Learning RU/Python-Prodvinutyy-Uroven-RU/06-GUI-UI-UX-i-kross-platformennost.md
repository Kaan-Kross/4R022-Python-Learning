# 6. GUI, UI/UX и кроссплатформенность

## Что такое UI и UX и в чём разница?

**UI (User Interface)** — всё, что пользователь видит и трогает:
кнопки, цвета, шрифты, иконки. **UX (User Experience)** — это то, что
пользователь **чувствует**, используя интерфейс: насколько легко он
всё понял, за сколько кликов выполнил задачу, как легко исправил
ошибку. Красиво выглядящее приложение (хороший UI) всё равно может
быть неудобным (плохой UX) — это связанные, но разные понятия.

### Основные принципы UX (кратко)

- **Согласованность:** одно и то же действие всегда должно быть на
  одном месте и выполняться одинаково.
- **Обратная связь:** пользователь должен **видеть**, что что-то
  произошло после нажатия (анимация загрузки, смена цвета, сообщение).
- **Терпимость к ошибкам:** пользователь должен уметь отменить
  ошибку; разрушительные действия (удаление) должны запрашивать подтверждение.
- **Простота:** несколько чётких вариантов лучше множества
  разрозненных.

## Получение размера и разрешения экрана (кроссплатформенно)

```python
# ✅ Этот код работает — РАБОТАЕТ на Windows, Linux и macOS
import tkinter as tk
temp = tk.Tk()
shirina = temp.winfo_screenwidth()
vysota = temp.winfo_screenheight()
temp.destroy()
print(f"Экран: {shirina}x{vysota}")
```

```python
# ✅ Этот код работает — ТОЛЬКО на Windows (специфично для платформы, через ctypes)
import ctypes
user32 = ctypes.windll.user32
shirina = user32.GetSystemMetrics(0)
vysota = user32.GetSystemMetrics(1)
print(f"Экран: {shirina}x{vysota}")
```

```python
# ❌ Этот код НЕ РАБОТАЕТ (работает ТОЛЬКО на Windows, падает на Linux/macOS)
import ctypes
shirina = ctypes.windll.user32.GetSystemMetrics(0)   # 'windll' специфичен для Windows!
```

- **Почему это неправильно?** `ctypes.windll` существует только на
  Windows; в Linux или macOS такого модуля/атрибута нет.
- **Где ошибка?** Возникает `AttributeError: module 'ctypes' has no
  attribute 'windll'` (на Linux/macOS).
- **Что использовать вместо?** Для кроссплатформенного приложения
  предпочтительнее платформонезависимый метод —
  `tkinter.winfo_screenwidth()/height()`; `ctypes.windll` используй
  только для инструмента, специфичного для Windows.

## Окно выбора файла

```python
# ✅ Этот код работает — выбор файла через Tkinter
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()   # скрыть главное окно, показать только диалог
put_k_faylu = filedialog.askopenfilename(
    title="Выберите изображение",
    filetypes=[("Файлы изображений", "*.png *.jpg *.jpeg")]
)
print("Выбранный файл:", put_k_faylu)
```

```python
# ✅ Этот код работает — выбор файла через PyQt6
from PyQt6.QtWidgets import QApplication, QFileDialog
import sys

app = QApplication(sys.argv)
put_k_faylu, _ = QFileDialog.getOpenFileName(
    None, "Выберите изображение", "", "Файлы изображений (*.png *.jpg *.jpeg)"
)
print("Выбранный файл:", put_k_faylu)
```

## Общие советы по кроссплатформенной разработке

- Если нужен специфичный для платформы код, всегда проверяй через
  `sys.platform`:
  ```python
  import sys
  if sys.platform.startswith("win"):
      pass   # код для Windows
  else:
      pass   # альтернатива для Linux/macOS
  ```
- По возможности используй собственные платформонезависимые API
  библиотек `tkinter`/`PyQt6`; опускайся до `ctypes`/`pywin32`
  только для действительно специфичных вещей.
- **Реально тестируй** на разных ОС — то, что работает на Windows,
  не гарантирует работу на Linux/macOS.

### 🎯 Мини-упражнение
Напиши небольшое приложение на Tkinter или PyQt6, открывающееся по
центру экрана пользователя, с кнопкой «Выбрать файл», показывающей
выбранное изображение.

---
⬅️ [Разработка настольных приложений](./05-Razrabotka-nastolnykh-prilozheniy.md) &nbsp;|&nbsp; ➡️ [Перейти к концепциям данных](../Python-Kontseptsii-Dannykh-RU/README.md)

🎉 **Поздравляем — ты завершил продвинутый уровень!**
