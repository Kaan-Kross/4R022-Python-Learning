# 4. Паттерны проектирования

Паттерны проектирования — это проверенные шаблоны решения задач,
которые часто повторяются в разработке ПО. Здесь рассмотрим три
паттерна, особенно полезных в настольных приложениях в стиле 4R022.

## 1. Singleton — «только один объект»

Гарантирует, что от класса будет создан **только один** экземпляр
(единый объект настроек, единое соединение с базой данных).

```python
# ✅ Этот код работает
class Nastroyki:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.tema = "tyomnaya"
        return cls._instance

n1 = Nastroyki()
n2 = Nastroyki()
print(n1 is n2)   # True — это ОДИН и тот же объект
```

```python
# ❌ Этот код даёт НЕВЕРНЫЙ результат — использование обычного __init__
# вместо __new__ создаёт НОВЫЙ объект при каждом вызове:
class NastroykiNepravilno:
    def __init__(self):
        self.tema = "tyomnaya"

n1 = NastroykiNepravilno()
n2 = NastroykiNepravilno()
print(n1 is n2)   # False — это ДВА разных объекта, не Singleton!
```

## 2. Factory — «производитель объектов»

Централизует логику создания объектов; конкретный класс выбирается
во время выполнения программы.

```python
# ✅ Этот код работает
class Sobaka:
    def zvuk(self):
        return "Гав"

class Koshka:
    def zvuk(self):
        return "Мяу"

def sozdat_zhivotnoe(tip):
    if tip == "sobaka":
        return Sobaka()
    elif tip == "koshka":
        return Koshka()
    raise ValueError(f"Неизвестный тип: {tip}")

zhivotnoe = sozdat_zhivotnoe("koshka")
print(zhivotnoe.zvuk())   # "Мяу"
```

## 3. Observer — «наблюдатель»

Автоматически уведомляет другие объекты об изменении. Система
сигналов/слотов (signal/slot) в PyQt6 — это готовая реализация
данного паттерна.

```python
# ✅ Этот код работает — реализация Observer на чистом Python
class Izdatel:
    def __init__(self):
        self._slushateli = []

    def dobavit_slushatelya(self, funktsiya):
        self._slushateli.append(funktsiya)

    def uvedomit(self, dannye):
        for slushatel in self._slushateli:
            slushatel(dannye)

def vyvesti_na_ekran(dannye):
    print("Пришли новые данные:", dannye)

izdatel = Izdatel()
izdatel.dobavit_slushatelya(vyvesti_na_ekran)
izdatel.uvedomit("Привет!")   # "Пришли новые данные: Привет!"
```

Аналог в PyQt6:

```python
# ✅ Этот код работает (если установлен PyQt6)
from PyQt6.QtCore import QObject, pyqtSignal

class Izdatel(QObject):
    dannye_prishli = pyqtSignal(str)   # определение сигнала

izdatel = Izdatel()
izdatel.dannye_prishli.connect(lambda dannye: print("Новые данные:", dannye))
izdatel.dannye_prishli.emit("Привет, PyQt6!")
```

### 🎯 Мини-упражнение
Напиши класс-Singleton `Loggery`, который пишет в один и тот же
лог-файл из любой точки приложения.

---
⬅️ [Производительность и оптимизация](./03-Proizvoditelnost-i-optimizatsiya.md) &nbsp;|&nbsp; ➡️ [Разработка настольных приложений](./05-Razrabotka-nastolnykh-prilozheniy.md)
