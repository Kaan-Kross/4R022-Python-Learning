# 1. Многопоточность: Threading, Multiprocessing, Asyncio

## Зачем это нужно?

Некоторые задачи требуют **ожидания** (сетевой запрос, файловый
ввод-вывод), другие — **интенсивных вычислений** (обработка
изображений, математика). Эти два случая решаются разными
инструментами.

## `threading` — для задач, зависящих от ввода-вывода

```python
# ✅ Этот код работает
import threading, time

def zagruzit(nomer_fayla):
    print(f"Загружается файл {nomer_fayla}...")
    time.sleep(2)
    print(f"Файл {nomer_fayla} готов.")

potoki = [threading.Thread(target=zagruzit, args=(i,)) for i in range(3)]
for t in potoki: t.start()
for t in potoki: t.join()
print("Все загрузки завершены.")
```

## GIL (Global Interpreter Lock) — важное ограничение

```python
# ❌ Этот код работает МЕДЛЕННЕЕ ОЖИДАЕМОГО — из-за GIL в CPython
# threading не даёт реального параллелизма для вычислительно тяжёлых
# задач (в один момент времени код Python выполняет только один поток):
import threading

def tyazhelye_vychisleniya():
    total = 0
    for i in range(50_000_000):
        total += i

potoki = [threading.Thread(target=tyazhelye_vychisleniya) for _ in range(4)]
for t in potoki: t.start()
for t in potoki: t.join()
# Это едва ли быстрее, чем выполнить в одном потоке!
```

Для вычислительно тяжёлых задач правильный инструмент —
`multiprocessing`, потому что у каждого процесса свой собственный
интерпретатор Python (и свой GIL).

```python
# ✅ Этот код работает — реальный параллелизм (несколько ядер процессора)
import multiprocessing

def vychislit(predel):
    return sum(range(predel))

if __name__ == "__main__":
    with multiprocessing.Pool(4) as pool:
        rezultaty = pool.map(vychislit, [10_000_000] * 4)
    print(rezultaty)
```

## `asyncio` — для множества задач ожидания

```python
# ✅ Этот код работает — эффективно управляет сотнями сетевых запросов
import asyncio

async def poluchit_dannye(id_no):
    print(f"Запрос {id_no} начался")
    await asyncio.sleep(1)   # имитирует реальный сетевой запрос
    print(f"Запрос {id_no} завершён")
    return id_no

async def main():
    zadachi = [poluchit_dannye(i) for i in range(5)]
    rezultaty = await asyncio.gather(*zadachi)
    print(rezultaty)

asyncio.run(main())
```

```python
# ❌ Этот код НЕ РАБОТАЕТ — 'await' использован вне async-функции
def obychnaya_funktsiya():
    await asyncio.sleep(1)   # SyntaxError: 'await' outside async function
```

## Что использовать и когда?

| Сценарий | Правильный инструмент |
|---|---|
| Скачивание файла, API-запрос (ожидание, мало задач) | `threading` |
| Сотни одновременных сетевых запросов | `asyncio` |
| Обработка изображений, тяжёлая математика (нагрузка на CPU) | `multiprocessing` |

---
⬅️ [Назад](./README.md) &nbsp;|&nbsp; ➡️ [Продвинутые концепции ООП](./02-Prodvinutye-kontseptsii-OOP.md)
