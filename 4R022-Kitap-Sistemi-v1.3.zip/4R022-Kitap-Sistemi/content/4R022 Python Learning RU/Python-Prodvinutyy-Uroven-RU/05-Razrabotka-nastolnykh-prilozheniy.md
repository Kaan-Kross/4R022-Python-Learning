# 5. Профессиональная разработка настольных приложений (PyQt6)

## Почему PyQt6, а не Tkinter?

`tkinter` идёт в стандартной библиотеке, подходит для быстрых
небольших инструментов. `PyQt6` предлагает более современный вид,
архитектуру сигнал/слот и более прочную основу для крупных
приложений — поэтому большинство настольных продуктов 4R022 написаны
именно на нём.

## Минимальное приложение на PyQt6

```python
# ✅ Этот код работает (если установлен PyQt6: pip install PyQt6)
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout

class GlavnoeOkno(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Пример 4R022")
        self.resize(400, 200)

        layout = QVBoxLayout()
        label = QLabel("Привет, 4R022 Python Learning!")
        layout.addWidget(label)
        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    okno = GlavnoeOkno()
    okno.show()
    sys.exit(app.exec())
```

```python
# ❌ Этот код НЕ РАБОТАЕТ — попытка показать окно до создания QApplication
okno = GlavnoeOkno()
okno.show()
# RuntimeError: Please create QApplication before QWidget
```

Каждое приложение PyQt6 должно **сначала** создать `QApplication`,
и только потом — окна.

## Рекомендуемая архитектура: `core/` + `ui/`

```
proekt/
├── main.py
├── core/              # бизнес-логика, обработка данных (независима от интерфейса)
│   ├── __init__.py
│   └── data_manager.py
└── ui/                # только отображение и взаимодействие с пользователем
    ├── __init__.py
    └── main_window.py
```

Цель такого разделения: держать бизнес-логику (`core/`) независимой
от интерфейса (`ui/`), чтобы тестировать логику можно было без
открытия окон.

## Сигнал/слот для нажатия кнопки

```python
# ✅ Этот код работает
from PyQt6.QtWidgets import QPushButton

button = QPushButton("Нажми")
button.clicked.connect(lambda: print("Кнопка нажата!"))
```

## Упаковка через PyInstaller (кратко)

```bash
# ✅ Эта команда работает — превращает .py файл в один .exe
pip install pyinstaller
pyinstaller --onefile --windowed main.py
```

Для доступа к встроенным ресурсам (иконки, изображения) в
упакованном PyInstaller приложении стандартной практикой в проектах
4R022 является вспомогательная функция `resource_path()`:

```python
# ✅ Этот код работает
import sys, os

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS   # временная папка PyInstaller
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
```

### 🎯 Мини-упражнение
Напиши небольшое приложение на PyQt6 с текстовым полем
(`QLineEdit`) и кнопкой (`QPushButton`), которая при нажатии
показывает текст из поля в `QLabel`.

---
⬅️ [Паттерны проектирования](./04-Patterny-proektirovaniya.md) &nbsp;|&nbsp; ➡️ [GUI, UI/UX и кроссплатформенность](./06-GUI-UI-UX-i-kross-platformennost.md)
