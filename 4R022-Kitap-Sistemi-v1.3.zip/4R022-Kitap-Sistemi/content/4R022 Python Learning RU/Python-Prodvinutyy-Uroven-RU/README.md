# Python: Продвинутый уровень (RU)

Этот уровень для тех, кто хочет создавать настоящие,
производительные, профессиональные программы. Мы больше не изучаем
сам язык — мы учимся создавать на нём **профессиональное ПО**.

## Разделы

1. [Многопоточность: Threading, Multiprocessing, Asyncio](./01-Mnogopotochnost.md)
2. [Продвинутое ООП: контекстные менеджеры, `__slots__`, метаклассы](./02-Prodvinutye-kontseptsii-OOP.md)
3. [Производительность и оптимизация](./03-Proizvoditelnost-i-optimizatsiya.md)
4. [Паттерны проектирования](./04-Patterny-proektirovaniya.md)
5. [Профессиональная разработка настольных приложений (PyQt6)](./05-Razrabotka-nastolnykh-prilozheniy.md)
6. [GUI, UI/UX и кроссплатформенные интерфейсы](./06-GUI-UI-UX-i-kross-platformennost.md)

Далее ➡️ [Концепции данных](../Python-Kontseptsii-Dannykh-RU/README.md)
