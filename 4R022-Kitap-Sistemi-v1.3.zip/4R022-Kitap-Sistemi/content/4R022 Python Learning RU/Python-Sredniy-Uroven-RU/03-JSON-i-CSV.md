# 3. Форматы данных: JSON и CSV

## JSON — обмен структурированными данными

JSON (JavaScript Object Notation) — самый распространённый формат
данных для веб-API и файлов конфигурации; он очень похож на
структуру `dict` в Python.

```python
# ✅ Этот код работает — записывает Python dict в JSON-файл
import json

nastroyki = {"tema": "tyomnaya", "yazyk": "ru", "versiya": 2}

with open("nastroyki.json", "w", encoding="utf-8") as f:
    json.dump(nastroyki, f, ensure_ascii=False, indent=4)

# ✅ Этот код работает — читает JSON-файл обратно в dict
with open("nastroyki.json", "r", encoding="utf-8") as f:
    zagruzhennye = json.load(f)
    print(zagruzhennye["tema"])
```

```python
# ❌ Этот код НЕ РАБОТАЕТ — разбор некорректной "JSON"-строки
# (одинарные кавычки недопустимы в JSON!)
import json
data = json.loads("{'tema': 'tyomnaya'}")   # одинарные кавычки некорректны!
```

Возникнет `json.decoder.JSONDecodeError`. Стандарт JSON требует
**двойных кавычек** — не путай с синтаксисом словаря Python.

Этот подход лежит в основе принципа **атомарной записи JSON** (с
резервной копией `.bak`), используемого в системах архивации и
настроек 4R022.

## CSV — табличные данные

```python
# ✅ Этот код работает — запись в CSV
import csv
with open("otsenki.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["imya", "otsenka"])
    writer.writerow(["Каан", 95])
    writer.writerow(["Айше", 88])
```

```python
# ✅ Этот код работает — чтение CSV
import csv
with open("otsenki.csv", "r", encoding="utf-8") as f:
    for row in csv.reader(f):
        print(row)
```

```python
# ❌ Этот код НЕ РАБОТАЕТ (на Windows) — забыт параметр 'newline=""',
# из-за чего между строками CSV появляются лишние пустые строки
# (это коварная ошибка формата, а не сбой программы):
with open("otsenki.csv", "w", encoding="utf-8") as f:   # newline="" отсутствует!
    writer = csv.writer(f)
    writer.writerows([["imya", "otsenka"], ["Каан", 95]])
```

### 🎯 Мини-упражнение
Напиши программу, которая сохраняет список студентов (`имя`,
`оценка`) как в JSON, так и в CSV, затем считывает их обратно и
вычисляет среднее значение.

---
⬅️ [Декораторы и генераторы](./02-Dekoratory-i-generatory.md) &nbsp;|&nbsp; ➡️ [Модули, пакеты и виртуальные окружения](./04-Moduli-pakety-virtualnye-okruzheniya.md)
