# 2. Декораторы и генераторы

## Что такое декоратор?

Декоратор — это функция, которая «оборачивает» другую функцию,
расширяя или изменяя её поведение.

```python
# ✅ Этот код работает
import time

def zamerit_vremya(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} заняла {end - start:.4f} секунд")
        return result
    return wrapper

@zamerit_vremya
def dolgaya_zadacha():
    time.sleep(1)
    return "готово"

dolgaya_zadacha()
```

`@zamerit_vremya` — это короткая запись
`dolgaya_zadacha = zamerit_vremya(dolgaya_zadacha)`.

```python
# ❌ Этот код НЕ РАБОТАЕТ — внутренняя функция не возвращает значение,
# поэтому реальный результат декорируемой функции теряется:
def logger(func):
    def wrapper(*args, **kwargs):
        func(*args, **kwargs)   # 'return' забыли!
    return wrapper

@logger
def umnozhit(a, b):
    return a * b

rezultat = umnozhit(3, 4)
print(rezultat)   # выведет None, а НЕ 12
```

## Что такое генератор (`yield`)?

Обычная функция завершается через `return` и сразу помещает весь
результат в память. **Генератор** производит значения **по одному, по
запросу**, с помощью `yield` — это экономит память при работе с
большими наборами данных.

```python
# ✅ Этот код работает
def generirovat_kvadraty(n):
    for i in range(n):
        yield i * i

for kvadrat in generirovat_kvadraty(5):
    print(kvadrat)   # 0, 1, 4, 9, 16 — производятся по одному
```

```python
# ✅ Этот код работает — генераторное выражение, круглые скобки вместо квадратных
kvadraty = (x * x for x in range(1_000_000))
print(next(kvadraty))   # 0 — вычисляется только запрошенное значение
print(next(kvadraty))   # 1
```

```python
# ❌ Этот код СРАЗУ загружает миллионы элементов в память —
# гораздо более затратно по памяти, чем генератор выше:
kvadraty_spisok = [x * x for x in range(10_000_000)]  # весь список в памяти!
```

Этот код «работает», но может вызвать серьёзные проблемы с памятью
при больших или бесконечных потоках данных — поэтому для них
предпочтительны генераторы.

### 🎯 Мини-упражнение
Напиши генераторную функцию `fibonacci(n)`, которая через `yield`
выдаёт первые `n` чисел Фибоначчи по одному.

---
⬅️ [Продвинутое ООП](./01-Prodvinutoe-OOP.md) &nbsp;|&nbsp; ➡️ [JSON и CSV](./03-JSON-i-CSV.md)
