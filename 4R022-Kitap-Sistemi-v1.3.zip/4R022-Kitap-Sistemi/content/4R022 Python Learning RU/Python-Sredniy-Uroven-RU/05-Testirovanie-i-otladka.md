# 5. Тестирование и отладка

## Зачем писать тесты?

По мере роста кода вручную проверять, что изменение ничего не
сломало, становится невозможно. Тесты автоматизируют эту проверку.

## `unittest` (стандартная библиотека)

```python
# ✅ Этот код работает — kalkulyator.py
def slozhit(a, b):
    return a + b

def razdelit(a, b):
    if b == 0:
        raise ValueError("Нельзя делить на ноль")
    return a / b
```

```python
# ✅ Этот код работает — test_kalkulyator.py
import unittest
from kalkulyator import slozhit, razdelit

class TestKalkulyator(unittest.TestCase):
    def test_slozhit(self):
        self.assertEqual(slozhit(2, 3), 5)

    def test_razdelit_na_nol(self):
        with self.assertRaises(ValueError):
            razdelit(10, 0)

if __name__ == "__main__":
    unittest.main()
```

```bash
python -m unittest test_kalkulyator.py
```

```python
# ❌ Этот тест НЕ ПРОХОДИТ (неверное ожидание, а не сбой) —
# 2 + 3 действительно равно 5, а не 6:
self.assertEqual(slozhit(2, 3), 6)   # AssertionError: 5 != 6
```

## `pytest` (популярная сторонняя библиотека)

```bash
pip install pytest
```

```python
# ✅ Этот код работает — pytest не требует даже unittest.TestCase
# test_calc.py
from kalkulyator import slozhit

def test_slozhit():
    assert slozhit(2, 3) == 5

def test_slozhit_otritsatelnye():
    assert slozhit(-1, -1) == -2
```

```bash
pytest test_calc.py -v
```

## Советы по отладке

```python
# ✅ Этот код работает — использование print для отслеживания "что где"
def vychislit(dannye):
    print("DEBUG: входные данные ->", dannye)   # временная отладочная строка
    return sum(dannye) / len(dannye)
```

```python
# ✅ Этот код работает — встроенный отладчик Python
def vychislit(dannye):
    breakpoint()   # выполнение останавливается здесь для просмотра переменных
    return sum(dannye) / len(dannye)
```

> 🧑‍🏫 **Заметка преподавателя:** отладка через `print()` — не
> «непрофессионально»; настоящие разработчики часто используют её
> для быстрой проверки. Но в больших проектах модуль `logging` и
> настоящий отладчик (например, встроенный в VS Code) гораздо мощнее.

### 🎯 Мини-упражнение
Добавь в `kalkulyator.py` функцию `vychest(a, b)`, затем напиши для
неё тесты и с `unittest`, и с `pytest`.

---
⬅️ [Модули, пакеты, виртуальные окружения](./04-Moduli-pakety-virtualnye-okruzheniya.md) &nbsp;|&nbsp; ➡️ [Перейти к продвинутому уровню](../Python-Prodvinutyy-Uroven-RU/README.md)

🎉 **Поздравляем — ты завершил средний уровень!**
