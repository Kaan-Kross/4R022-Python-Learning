# 4. Модули, пакеты и виртуальные окружения

## Что такое модуль?

Любой файл `.py` — это **модуль**. Разделение кода на файлы делает
проект организованным и переиспользуемым.

```python
# ✅ Этот код работает — файл matematika.py
def slozhit(a, b):
    return a + b

def umnozhit(a, b):
    return a * b
```

```python
# ✅ Этот код работает — импорт модуля в основном файле
import matematika
print(matematika.slozhit(3, 4))     # 7

from matematika import slozhit
print(slozhit(1, 2))                # 3
```

```python
# ❌ Этот код НЕ РАБОТАЕТ — опечатка в имени файла
import matematikaa
```

Возникнет `ModuleNotFoundError: No module named 'matematikaa'`.

## Что такое пакет?

**Пакет** — это папка с файлом `__init__.py`, объединяющая
несколько модулей.

```
proekt/
├── main.py
└── pomoshchniki/
    ├── __init__.py
    ├── matematika.py
    └── tekst.py
```

```python
# ✅ Этот код работает
from pomoshchniki import matematika
from pomoshchniki.tekst import v_verkhniy_registr
```

Эта структура лежит в основе модульной архитектуры `core/` + `ui/`,
используемой в проектах 4R022 на PyQt6.

## Управление пакетами через pip

```bash
# ✅ Эти команды работают
pip install requests
pip freeze > requirements.txt
pip install -r requirements.txt
```

## Зачем нужны виртуальные окружения?

Виртуальное окружение даёт каждому проекту собственный независимый
набор установленных пакетов — чтобы `flask==2.0` в одном проекте не
конфликтовал с `flask==3.0` в другом.

```bash
# ✅ Эти команды работают (в папке проекта)
python -m venv venv

# Активация на Windows:
venv\Scripts\activate

# Активация на macOS / Linux:
source venv/bin/activate

pip install requests   # теперь влияет только на это окружение
```

```bash
# ❌ Этот код НЕ РАБОТАЕТ — использована команда активации для другой ОС
source venv/bin/activate    # это команда Linux/macOS, в Windows cmd не распознаётся
```

В Windows `cmd` правильная команда — `venv\Scripts\activate` (или
`venv\Scripts\Activate.ps1` в PowerShell).

### 🎯 Мини-упражнение
Создай модуль `figury.py` (с функциями вычисления площади круга и
квадрата), затем импортируй и используй его из `main.py`. После
этого создай виртуальное окружение и установи в него `requests`.

---
⬅️ [JSON и CSV](./03-JSON-i-CSV.md) &nbsp;|&nbsp; ➡️ [Тестирование и отладка](./05-Testirovanie-i-otladka.md)
