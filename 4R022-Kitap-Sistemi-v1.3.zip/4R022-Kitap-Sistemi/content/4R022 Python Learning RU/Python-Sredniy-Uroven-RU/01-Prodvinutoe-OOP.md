# 1. Продвинутое объектно-ориентированное программирование

## `@property` для контролируемого доступа

```python
# ✅ Этот код работает
class Pryamougolnik:
    def __init__(self, shirina, vysota):
        self._shirina = shirina
        self._vysota = vysota

    @property
    def ploshchad(self):
        return self._shirina * self._vysota

p = Pryamougolnik(4, 5)
print(p.ploshchad)   # 20 — определено как метод, но вызывается как атрибут (без скобок!)
```

```python
# ❌ Этот код НЕ РАБОТАЕТ — property нельзя вызывать со скобками
print(p.ploshchad())
```

Возникнет `TypeError: 'int' object is not callable`, потому что
`p.ploshchad` — это уже вычисленное значение, а не функция.

## Специальные методы (dunder-методы)

```python
# ✅ Этот код работает — __str__ и __eq__ настраивают поведение объекта
class Tochka:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __str__(self):
        return f"Tochka({self.x}, {self.y})"

    def __eq__(self, drugoy):
        return self.x == drugoy.x and self.y == drugoy.y

t1 = Tochka(1, 2)
t2 = Tochka(1, 2)
print(t1)          # Tochka(1, 2) — благодаря __str__
print(t1 == t2)    # True — благодаря __eq__
```

```python
# ❌ Этот код ведёт себя ИНАЧЕ — без __eq__ Python по умолчанию
# сравнивает "это один и тот же объект в памяти?", поэтому ниже
# получится False (логическая неожиданность, а не синтаксическая ошибка):
class ProstayaTochka:
    def __init__(self, x, y):
        self.x, self.y = x, y

a = ProstayaTochka(1, 2)
b = ProstayaTochka(1, 2)
print(a == b)   # False! (__eq__ не определён)
```

## Множественное наследование и `super()`

```python
# ✅ Этот код работает
class Sotrudnik:
    def __init__(self, imya, zarplata):
        self.imya = imya
        self.zarplata = zarplata

class Razrabotchik(Sotrudnik):
    def __init__(self, imya, zarplata, yazyk):
        super().__init__(imya, zarplata)   # вызывает __init__ родителя
        self.yazyk = yazyk

r = Razrabotchik("Каан", 50000, "Python")
print(r.imya, r.zarplata, r.yazyk)
```

## Абстрактные базовые классы

```python
# ✅ Этот код работает
from abc import ABC, abstractmethod

class Figura(ABC):
    @abstractmethod
    def ploshchad(self):
        pass

class Kvadrat(Figura):
    def __init__(self, storona):
        self.storona = storona

    def ploshchad(self):
        return self.storona ** 2

print(Kvadrat(4).ploshchad())   # 16
```

```python
# ❌ Этот код НЕ РАБОТАЕТ — абстрактный класс нельзя создать напрямую
figura = Figura()
```

Возникнет `TypeError: Can't instantiate abstract class Figura with
abstract method ploshchad`. В этом и есть смысл `ABC`: он заставляет
подклассы реализовывать определённые методы.

---
⬅️ [Назад](./README.md) &nbsp;|&nbsp; ➡️ [Декораторы и генераторы](./02-Dekoratory-i-generatory.md)
