# Modul `os`

## Was ist es und wie funktioniert es?

Das Modul `os` lässt dein Python-Programm mit dem **Betriebssystem**
kommunizieren. Es umhüllt Systemaufrufe des OS in Python-Funktionen.
Teil der Standardbibliothek — **keine Installation nötig.**

## Wann/wo wird es verwendet?

Dateien/Ordner erstellen/löschen, Umgebungsvariablen abrufen,
plattformübergreifende Pfade bauen.

## ✅ Funktionierende Beispiele

```python
import os
print(os.getcwd())
os.makedirs("ausgabe/taeglich", exist_ok=True)
pfad = os.path.join("projekt", "daten", "config.json")
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — nicht existierenden Ordner löschen

```python
os.rmdir("nicht_vorhandener_ordner")
```
- **Warum ist das falsch?** Der Ordner existiert nicht.
- **Wo ist der Fehler?** `os.rmdir()` schlägt fehl.
- **Was stattdessen?** Vorher mit `os.path.isdir()` prüfen.

### Fehlerhaftes Beispiel 2 — `rmdir()` bei nicht leerem Ordner

```python
os.rmdir("voller_ordner")
```
- **Warum ist das falsch?** `rmdir()` löscht nur leere Ordner.
- **Wo ist der Fehler?** `OSError: [Errno 39] Directory not empty`
- **Was stattdessen?** `shutil.rmtree()` verwenden.

## 🔗 Verwandte Module
[pathlib](../10-pathlib/README.md), [sys](../02-sys/README.md)

---
⬅️ [Modul-Startseite](../README.md)
