# Modul `matplotlib`

## Was ist es und wie funktioniert es?

Die Standardbibliothek für Diagramme und Datenvisualisierung in Python.

## ✅ Funktionierende Beispiele

```python
import matplotlib.pyplot as plt
plt.plot([1,2,3], [10,20,30])
plt.savefig("diagramm.png")
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `plt.show()` ohne Bildschirm (Server)

```python
plt.plot([1,2,3])
plt.show()
```
- **Warum ist das falsch?** Fehler/Blockade ohne grafische Umgebung.
- **Wo ist der Fehler?** `plt.show()` setzt einen Bildschirm voraus.
- **Was stattdessen?** `plt.savefig("diagramm.png")`

### Fehlerhaftes Beispiel 2 — Zeichnen auf derselben Figur

```python
plt.plot([1,2,3], [1,4,9])
plt.savefig("d1.png")
plt.plot([1,2,3], [3,2,1])   # zur GLEICHEN Figur hinzugefügt!
plt.savefig("d2.png")         # d2.png enthält BEIDE Linien
```
- **Warum ist das falsch?** matplotlib zeichnet weiter auf derselben Figur.
- **Wo ist der Fehler?** Kein `plt.figure()`/`plt.clf()` dazwischen.
- **Was stattdessen?** `plt.figure()` vor jedem neuen Diagramm aufrufen.

## 🔗 Verwandte Module
[numpy](../18-numpy/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Modul-Startseite](../README.md)
