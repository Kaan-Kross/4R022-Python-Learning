# Modul `qrcode`

## Was ist es und wie funktioniert es?

Wandelt Text in ein QR-Code-Bild um, mit Fehlerkorrektur-Algorithmen.

## ✅ Funktionierende Beispiele

```python
import qrcode
img = qrcode.make("https://github.com/4R022")
img.save("qr.png")
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Installation ohne `[pil]`

```bash
pip install qrcode
```
- **Warum ist das falsch?** Bilderzeugung hängt von Pillow ab.
- **Wo ist der Fehler?** `ImportError`
- **Was stattdessen?** `pip install "qrcode[pil]"`

### Fehlerhaftes Beispiel 2 — zu langer Text

```python
img = qrcode.make("A" * 5000)
```
- **Warum ist das falsch?** Überschreitet die Kapazität des QR-Standards.
- **Wo ist der Fehler?** `DataOverflowError`
- **Was stattdessen?** `version=None` für automatische Größenanpassung.

## 🔗 Verwandte Module
[hashlib](../30-hashlib/README.md)

---
⬅️ [Modul-Startseite](../README.md)
