# Modul `multiprocessing`

## Was ist es und wie funktioniert es?

Startet unabhängige Prozesse mit eigenem Speicher und GIL — echte
Parallelität für CPU-Aufgaben.

## ✅ Funktionierende Beispiele

```python
import multiprocessing
def quadrat(n): return n*n
if __name__ == "__main__":
    with multiprocessing.Pool(4) as p:
        print(p.map(quadrat, [1,2,3,4]))
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `if __name__ == "__main__":` vergessen (Windows)

```python
pool = multiprocessing.Pool(4)
print(pool.map(quadrat, [1,2,3]))
```
- **Warum ist das falsch?** Windows reimportiert das Skript pro Prozess.
- **Wo ist der Fehler?** Kein `__main__`-Schutz.
- **Was stattdessen?** In `if __name__ == "__main__":` einbetten.

### Fehlerhaftes Beispiel 2 — normale Variable zwischen Prozessen teilen

```python
zaehler = 0
def erhoehen():
    global zaehler
    zaehler += 1
if __name__ == "__main__":
    p = multiprocessing.Process(target=erhoehen)
    p.start(); p.join()
    print(zaehler)   # immer noch 0!
```
- **Warum ist das falsch?** Jeder Prozess hat eigenen Speicher.
- **Wo ist der Fehler?** `global` betrifft nur die Prozesskopie.
- **Was stattdessen?** `multiprocessing.Queue` oder `Manager()`.

## 🔗 Verwandte Module
[threading](../12-threading/README.md)

---
⬅️ [Modul-Startseite](../README.md)
