# `unittest` und `pytest`

## Was ist es und wie funktioniert es?

`unittest` ist das eingebaute Test-Framework; `pytest` eine
beliebtere Alternative mit einfachem `assert`.

## ✅ Funktionierende Beispiele

```python
def addieren(a, b): return a + b
def test_addieren():
    assert addieren(2, 3) == 5
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — falscher Datei-/Funktionsname für pytest

```python
# Datei: pruefungen.py (ohne test_-Präfix!)
def pruefe_multiplikation():
    assert 2*2 == 4
```
- **Warum ist das falsch?** pytest sucht nach `test_`-Präfixen.
- **Wo ist der Fehler?** Weder Datei noch Funktion folgen der Regel.
- **Was stattdessen?** In `test_pruefungen.py` / `test_multiplikation()` umbenennen.

### Fehlerhaftes Beispiel 2 — geteilter Zustand zwischen Tests

```python
warenkorb = []
def test_eins():
    warenkorb.append("a")
    assert len(warenkorb) == 1
def test_zwei():
    warenkorb.append("b")
    assert len(warenkorb) == 1   # FALSCH! jetzt 2 Elemente
```
- **Warum ist das falsch?** Tests müssen unabhängig sein.
- **Wo ist der Fehler?** Gemeinsame Liste `warenkorb` zwischen Tests.
- **Was stattdessen?** Zustand bei jedem Test zurücksetzen.

## 🔗 Verwandte Module
[logging](../11-logging/README.md)

---
⬅️ [Modul-Startseite](../README.md)
