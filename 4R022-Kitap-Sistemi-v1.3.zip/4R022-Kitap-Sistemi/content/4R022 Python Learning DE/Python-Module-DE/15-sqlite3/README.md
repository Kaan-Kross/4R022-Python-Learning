# Modul `sqlite3`

## Was ist es und wie funktioniert es?

Leichte relationale Datenbank, alles in einer Datei, kein Server nötig.

## ✅ Funktionierende Beispiele

```python
import sqlite3
conn = sqlite3.connect("app.db")
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS s (id INTEGER PRIMARY KEY, name TEXT)")
c.execute("INSERT INTO s (name) VALUES (?)", ("Kaan",))
conn.commit()
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — SQL-Injection durch String-Verkettung

```python
name = "Kaan"
c.execute(f"SELECT * FROM s WHERE name = '{name}'")
```
- **Warum ist das falsch?** SQL-Injection-Schwachstelle.
- **Wo ist der Fehler?** Benutzereingabe direkt eingefügt.
- **Was stattdessen?** `c.execute("SELECT * FROM s WHERE name = ?", (name,))`

### Fehlerhaftes Beispiel 2 — `commit()` vergessen

```python
c.execute("INSERT INTO s (name) VALUES (?)", ("Ayse",))
conn.close()   # commit() vergessen!
```
- **Warum ist das falsch?** Änderungen werden nicht gespeichert.
- **Wo ist der Fehler?** `conn.commit()` nie aufgerufen.
- **Was stattdessen?** Immer `conn.commit()` nach dem Schreiben.

## 🔗 Verwandte Module
[threading](../12-threading/README.md)

---
⬅️ [Modul-Startseite](../README.md)
