# Modul `json`

## Was ist es und wie funktioniert es?

Wandelt Python-Objekte in JSON-Text um und zurück — die gemeinsame
Sprache von Web-APIs und Konfigurationsdateien.

## ✅ Funktionierende Beispiele

```python
import json
config = {"thema": "dunkel", "sprache": "de"}
with open("config.json", "w", encoding="utf-8") as f:
    json.dump(config, f, ensure_ascii=False, indent=4)
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — einfache Anführungszeichen

```python
data = json.loads("{'thema': 'dunkel'}")
```
- **Warum ist das falsch?** JSON erfordert doppelte Anführungszeichen.
- **Wo ist der Fehler?** `json.decoder.JSONDecodeError`
- **Was stattdessen?** `json.loads('{"thema": "dunkel"}')`

### Fehlerhaftes Beispiel 2 — Lesen ohne Absicherung

```python
with open("kaputt.json", "r") as f:
    data = json.load(f)   # stürzt ab, wenn Datei leer/beschädigt ist
```
- **Warum ist das falsch?** Keine Fehlerbehandlung.
- **Wo ist der Fehler?** Kein `try/except`.
- **Was stattdessen?** `try/except (json.JSONDecodeError, FileNotFoundError)`

## 🔗 Verwandte Module
[csv](../04-csv/README.md)

---
⬅️ [Modul-Startseite](../README.md)
