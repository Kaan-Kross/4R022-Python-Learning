# Modul `argparse`

## Was ist es und wie funktioniert es?

Gibt Skripten eine professionelle Kommandozeilen-Schnittstelle:
`--help`, Typumwandlung, Pflicht-/optionale Argumente.

## ✅ Funktionierende Beispiele

```python
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("datei")
parser.add_argument("--ausfuehrlich", action="store_true")
args = parser.parse_args()
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Ausführung ohne Pflichtargument

```bash
python tool.py
```
- **Warum ist das falsch?** `datei` ist ein Pflicht-Positionsargument.
- **Wo ist der Fehler?** `error: the following arguments are required: datei`
- **Was stattdessen?** `python tool.py notizen.txt`

### Fehlerhaftes Beispiel 2 — Wert für `store_true`-Flag

```bash
python tool.py --ausfuehrlich ja
```
- **Warum ist das falsch?** `store_true` nimmt keinen Wert.
- **Wo ist der Fehler?** `error: unrecognized arguments: ja`
- **Was stattdessen?** `python tool.py --ausfuehrlich` ohne Wert.

## 🔗 Verwandte Module
[sys](../02-sys/README.md)

---
⬅️ [Modul-Startseite](../README.md)
