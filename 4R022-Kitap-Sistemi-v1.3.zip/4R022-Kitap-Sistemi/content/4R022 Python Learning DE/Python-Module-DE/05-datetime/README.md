# Modul `datetime`

## Was ist es und wie funktioniert es?

Stellt Datum und Uhrzeit korrekt dar, vergleicht und formatiert sie —
Grundlage für Erinnerungen/Alarme (4R022 SAAT-Projekt).

## ✅ Funktionierende Beispiele

```python
from datetime import datetime, timedelta
jetzt = datetime.now()
print(jetzt.strftime("%d.%m.%Y %H:%M"))
erinnerung = jetzt + timedelta(hours=2)
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — nicht passendes Format

```python
datum = datetime.strptime("2026-09-15", "%d/%m/%Y")
```
- **Warum ist das falsch?** Format passt nicht zum String.
- **Wo ist der Fehler?** Falscher Trenner/Reihenfolge.
- **Was stattdessen?** `datetime.strptime("2026-09-15", "%Y-%m-%d")`

### Fehlerhaftes Beispiel 2 — datetime mit String vergleichen

```python
d1 = datetime.now()
d2 = "2026-09-15"
print(d1 > d2)
```
- **Warum ist das falsch?** Inkompatible Typen.
- **Wo ist der Fehler?** `d2` nicht umgewandelt.
- **Was stattdessen?** `d2` zuerst mit `strptime` umwandeln.

## 🔗 Verwandte Module
[os](../01-os/README.md), [logging](../11-logging/README.md)

---
⬅️ [Modul-Startseite](../README.md)
