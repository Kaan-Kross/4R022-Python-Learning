# Modul `enum`

## Was ist es und wie funktioniert es?

Definiert eine feste Menge benannter Konstanten statt Strings/Zahlen.

## ✅ Funktionierende Beispiele

```python
from enum import Enum
class Status(Enum):
    WARTEND = 1
    FERTIG = 2
print(Status.WARTEND.name)
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Vergleich mit normaler Zahl

```python
if Status.WARTEND == 1:
    print("wartend")
```
- **Warum ist das falsch?** Ein Enum-Mitglied ist keiner normalen Zahl gleich.
- **Wo ist der Fehler?** Gibt `False` zurück, ohne Fehler.
- **Was stattdessen?** `Status.WARTEND == Status.WARTEND`

### Fehlerhaftes Beispiel 2 — zwei Mitglieder mit gleichem Wert

```python
class Farbe(Enum):
    ROT = 1
    KARMESIN = 1   # gleicher Wert!
print(Farbe.ROT is Farbe.KARMESIN)   # True, unerwartet
```
- **Warum ist das falsch?** Gleiche Werte erzeugen einen Alias, kein neues Mitglied.
- **Wo ist der Fehler?** `KARMESIN` ist nur ein anderer Name für `ROT`.
- **Was stattdessen?** Unterschiedliche Werte geben oder `@enum.unique` verwenden.

## 🔗 Verwandte Module
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Modul-Startseite](../README.md)
