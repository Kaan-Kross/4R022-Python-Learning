# Modul `re` (reguläre Ausdrücke)

## Was ist es und wie funktioniert es?

Sucht **Muster** in Text durch eine Mini-Sprache, die zu einem
Zustandsautomaten kompiliert wird.

## ✅ Funktionierende Beispiele

```python
import re
m = re.search(r"[\w.]+@[\w.]+", "Kontakt: kaan@4r022.com")
print(m.group())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — ohne Raw-String

```python
pattern = re.compile("\d+")   # ohne 'r'!
```
- **Warum ist das falsch?** Konflikt zwischen Python- und Regex-Escapes möglich.
- **Wo ist der Fehler?** Präfix `r` fehlt.
- **Was stattdessen?** `r"\d+"`

### Fehlerhaftes Beispiel 2 — Verwechslung `match()`/`search()`

```python
m = re.match(r"\d+", "Hallo, Nummer 12345")
print(m.group())
```
- **Warum ist das falsch?** `match()` sucht nur am Anfang.
- **Wo ist der Fehler?** `m` ist `None`, `AttributeError`.
- **Was stattdessen?** `re.search(r"\d+", text)`

## 🔗 Verwandte Module
[collections](../08-collections/README.md)

---
⬅️ [Modul-Startseite](../README.md)
