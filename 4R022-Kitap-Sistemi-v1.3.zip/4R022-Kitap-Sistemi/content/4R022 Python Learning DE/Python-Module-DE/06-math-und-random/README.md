# Module `math` und `random`

## Was ist es und wie funktioniert es?

`math` bietet fortgeschrittene mathematische Funktionen; `random`
erzeugt pseudozufällige Zahlen (nicht sicherheitstauglich).

## ✅ Funktionierende Beispiele

```python
import math, random
print(math.sqrt(16))
print(random.randint(1, 6))
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Wurzel einer negativen Zahl

```python
math.sqrt(-16)
```
- **Warum ist das falsch?** Für reelle Zahlen nicht definiert.
- **Wo ist der Fehler?** `ValueError: math domain error`
- **Was stattdessen?** `cmath.sqrt(-16)` für komplexe Zahlen.

### Fehlerhaftes Beispiel 2 — `random` für Passwörter

```python
passwort = "".join(random.choice("abc123") for _ in range(8))
```
- **Warum ist das falsch?** `random` ist nicht kryptografisch sicher.
- **Wo ist der Fehler?** Falsches Modul für Sicherheitskontext.
- **Was stattdessen?** `secrets.token_urlsafe(16)` verwenden.

## 🔗 Verwandte Module
[cryptography](../25-cryptography/README.md)

---
⬅️ [Modul-Startseite](../README.md)
