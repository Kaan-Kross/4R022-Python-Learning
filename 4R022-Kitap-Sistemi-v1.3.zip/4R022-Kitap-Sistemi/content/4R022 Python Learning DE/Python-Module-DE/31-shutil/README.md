# Modul `shutil`

## Was ist es und wie funktioniert es?

Hochlevel-Datei-/Ordneroperationen: Kopieren, Verschieben, komplettes
Löschen, Archivierung.

## ✅ Funktionierende Beispiele

```python
import shutil
shutil.copy("a.txt", "b.txt")
shutil.rmtree("voller_ordner")
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Ordner mit `copy()` kopieren

```python
shutil.copy("ordner1", "ordner2")
```
- **Warum ist das falsch?** `copy()` ist nur für Dateien.
- **Wo ist der Fehler?** `IsADirectoryError`
- **Was stattdessen?** `shutil.copytree()`

### Fehlerhaftes Beispiel 2 — `rmtree()` für umkehrbar halten

```python
shutil.rmtree("wichtige_daten")
```
- **Warum ist das falsch?** Löschung ist dauerhaft, kein Papierkorb.
- **Wo ist der Fehler?** Kein Rückgängig-Mechanismus.
- **Was stattdessen?** Vorher Sicherungskopie erstellen.

## 🔗 Verwandte Module
[os](../01-os/README.md)

---
⬅️ [Modul-Startseite](../README.md)
