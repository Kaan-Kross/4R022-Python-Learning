# Modul `selenium`

> ⚠️ Siehe [Ethik und Sicherheit](../../Python-Ethik-und-Sicherheit-DE/README.md) — nur legale Nutzung.

## Was ist es und wie funktioniert es?

Steuert einen echten Browser programmatisch über das WebDriver Protocol.

## ✅ Funktionierende Beispiele

```python
from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://example.com")
print(driver.title)
driver.quit()
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Zugriff auf Element vor vollständigem Laden

```python
driver.get("https://langsame-seite.com")
el = driver.find_element(By.ID, "ergebnisse")
```
- **Warum ist das falsch?** JS-Inhalte laden möglicherweise später.
- **Wo ist der Fehler?** `NoSuchElementException`
- **Was stattdessen?** `WebDriverWait` verwenden.

### Fehlerhaftes Beispiel 2 — `driver.quit()` vergessen

```python
driver = webdriver.Chrome()
driver.get("https://example.com")
# driver.quit() nie aufgerufen
```
- **Warum ist das falsch?** Der Browserprozess bleibt offen.
- **Wo ist der Fehler?** Keine Ressourcenbereinigung.
- **Was stattdessen?** `try/finally` mit `driver.quit()`.

## 🔗 Verwandte Module
[requests](../16-requests/README.md)

---
⬅️ [Modul-Startseite](../README.md)
