# Modul `pathlib`

## Was ist es und wie funktioniert es?

Stellt Pfade als **Objekte** dar statt als Strings, mit dem `/`-Operator.

## ✅ Funktionierende Beispiele

```python
from pathlib import Path
p = Path("projekt") / "daten" / "config.json"
f = Path("notizen.txt")
if f.exists():
    print(f.read_text(encoding="utf-8"))
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Verwechslung `Path.replace()` mit Textersetzung

```python
p = Path("datei.txt")
print(p.replace(".txt", ".csv"))
```
- **Warum ist das falsch?** `Path.replace()` verschiebt/benennt die Datei um.
- **Wo ist der Fehler?** Kann `FileNotFoundError` auslösen.
- **Was stattdessen?** `p.with_suffix(".csv")`

### Fehlerhaftes Beispiel 2 — Schreiben in nicht existierenden Ordner

```python
f = Path("fehlender_ordner/notizen.txt")
f.write_text("hallo")
```
- **Warum ist das falsch?** Übergeordneter Ordner muss existieren.
- **Wo ist der Fehler?** `FileNotFoundError`
- **Was stattdessen?** `f.parent.mkdir(parents=True, exist_ok=True)`

## 🔗 Verwandte Module
[os](../01-os/README.md)

---
⬅️ [Modul-Startseite](../README.md)
