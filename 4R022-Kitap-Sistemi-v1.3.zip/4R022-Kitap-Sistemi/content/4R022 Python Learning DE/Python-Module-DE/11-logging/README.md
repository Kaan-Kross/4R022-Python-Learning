# Modul `logging`

## Was ist es und wie funktioniert es?

Professioneller Ersatz für `print()`: Schweregrade, gleichzeitiges
Schreiben in Datei und Bildschirm, automatische Zeitstempel.

## ✅ Funktionierende Beispiele

```python
import logging
logging.basicConfig(level=logging.INFO)
logging.info("Anwendung gestartet")
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `basicConfig()` mehrfach aufrufen

```python
logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.ERROR)   # wird ignoriert!
```
- **Warum ist das falsch?** Nur der erste Aufruf wirkt.
- **Wo ist der Fehler?** Zweiter Aufruf hat keine Wirkung.
- **Was stattdessen?** Einmal korrekt konfigurieren.

### Fehlerhaftes Beispiel 2 — Passwort loggen

```python
logging.info(f"Login: password={passwort}")
```
- **Warum ist das falsch?** Schwerwiegende Sicherheitslücke.
- **Wo ist der Fehler?** Passwort direkt im Log.
- **Was stattdessen?** Niemals sensible Daten loggen.

## 🔗 Verwandte Module
[datetime](../05-datetime/README.md)

---
⬅️ [Modul-Startseite](../README.md)
