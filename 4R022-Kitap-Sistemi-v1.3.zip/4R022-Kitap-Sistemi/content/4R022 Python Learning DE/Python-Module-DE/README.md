# Python: Module und ihre Verwendung (DE)

Eine Referenzbibliothek, die beantwortet: „Welches Modul verwende
ich für diese Aufgabe?" — **ein Ordner pro Modul.** Jeder Ordner enthält:

- 📖 Was das Modul ist und sein **Funktionsprinzip**
- 🎯 Wofür, wann und wo es verwendet wird
- ✅ Mehrere funktionierende Codebeispiele
- ❌ Mehrere **fehlerhafte** Beispiele — jedes mit: **„Warum ist das
  falsch? Wo ist der Fehler? Was stattdessen verwenden?"**
- 🔗 Links zu verwandten Modulen

## 🟢 Standardbibliothek (keine Installation nötig)

| Modul | Zweck |
|---|---|
| [os](./01-os/README.md) | Betriebssystem-Interaktion, Dateien/Ordner |
| [sys](./02-sys/README.md) | Interpreter-Interaktion, Kommandozeilenargumente |
| [json](./03-json/README.md) | JSON-Daten lesen/schreiben |
| [csv](./04-csv/README.md) | CSV-Daten lesen/schreiben |
| [datetime](./05-datetime/README.md) | Datum und Uhrzeit |
| [math und random](./06-math-und-random/README.md) | Mathematik, Zufallszahlen |
| [re (reguläre Ausdrücke)](./07-re-regulaere-ausdruecke/README.md) | Mustersuche/-ersetzung |
| [collections](./08-collections/README.md) | Erweiterte Datenstrukturen |
| [itertools und functools](./09-itertools-und-functools/README.md) | Werkzeuge für Schleifen/Funktionen |
| [pathlib](./10-pathlib/README.md) | Moderne Dateipfad-Verwaltung |
| [logging](./11-logging/README.md) | Professionelles Logging |
| [threading](./12-threading/README.md) | Multithreading (E/A-gebunden) |
| [multiprocessing](./13-multiprocessing/README.md) | Multiprocessing (CPU-gebunden) |
| [asyncio](./14-asyncio/README.md) | Asynchrone Programmierung |
| [sqlite3](./15-sqlite3/README.md) | Eingebaute leichte Datenbank |
| [queue](./27-queue/README.md) | Thread-sichere Warteschlange |
| [tempfile](./28-tempfile/README.md) | Temporäre Dateien/Ordner |
| [hashlib](./30-hashlib/README.md) | Hash-Funktionen |
| [shutil](./31-shutil/README.md) | Hochlevel-Datei-/Ordneroperationen |
| [subprocess](./32-subprocess/README.md) | Externe Programme ausführen |
| [enum](./33-enum/README.md) | Lesbare benannte Konstanten |
| [dataclasses](./34-dataclasses/README.md) | Datenklassen mit weniger Code |
| [typing](./35-typing/README.md) | Typ-Annotationen |
| [argparse](./36-argparse/README.md) | Professionelle Kommandozeilen-Interfaces |
| [unittest und pytest](./26-unittest-und-pytest/README.md) | Automatisiertes Testen |

## 🔵 Beliebte Drittanbieter-Bibliotheken (`pip install` nötig)

| Modul | Zweck |
|---|---|
| [requests](./16-requests/README.md) | HTTP-Anfragen, externe APIs |
| [Flask und FastAPI](./17-flask-und-fastapi/README.md) | Webserver / API |
| [numpy](./18-numpy/README.md) | Schnelle numerische Arrays |
| [pandas](./19-pandas/README.md) | Tabellarische Datenanalyse |
| [matplotlib](./20-matplotlib/README.md) | Diagramme und Visualisierung |
| [tkinter](./21-tkinter/README.md) | Standard-GUI-Bibliothek |
| [PyQt6](./22-PyQt6/README.md) | Professionelle GUI-Bibliothek |
| [selenium](./23-selenium/README.md) | Browser-Automatisierung |
| [socket](./24-socket/README.md) | Low-Level-Netzwerkprogrammierung |
| [cryptography](./25-cryptography/README.md) | Verschlüsselung und Datensicherheit |
| [qrcode](./29-qrcode/README.md) | QR-Code-Erstellung |

Vergiss nicht [Ethik und Sicherheit](../Python-Ethik-und-Sicherheit-DE/README.md) für rechtliche/ethische Grenzen.

⬅️ [Datenkonzepte](../Python-Datenkonzepte-DE/README.md) &nbsp;|&nbsp; ➡️ [Ethik und Sicherheit](../Python-Ethik-und-Sicherheit-DE/README.md)
