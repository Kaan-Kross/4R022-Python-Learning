# Modul `dataclasses`

## Was ist es und wie funktioniert es?

Generiert automatisch `__init__`, `__repr__`, `__eq__` für Klassen,
die hauptsächlich Daten halten.

## ✅ Funktionierende Beispiele

```python
from dataclasses import dataclass
@dataclass
class Punkt:
    x: int
    y: int
p = Punkt(1, 2)
print(p)   # Punkt(x=1, y=2)
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — veränderlicher Standardwert direkt

```python
@dataclass
class Student:
    noten: list = []   # leere Liste direkt!
```
- **Warum ist das falsch?** Veränderliche Standardwerte sind verboten.
- **Wo ist der Fehler?** `ValueError: mutable default ... is not allowed`
- **Was stattdessen?** `field(default_factory=list)`

### Fehlerhaftes Beispiel 2 — Typ-Annotationen für geprüft halten

```python
@dataclass
class Punkt:
    x: int
p = Punkt("eins")   # String statt int, kein Fehler!
```
- **Warum ist das falsch?** Typ-Annotationen werden zur Laufzeit nicht überprüft.
- **Wo ist der Fehler?** Falsche Annahme automatischer Validierung.
- **Was stattdessen?** `pydantic` für echte Validierung verwenden.

## 🔗 Verwandte Module
[typing](../35-typing/README.md)

---
⬅️ [Modul-Startseite](../README.md)
