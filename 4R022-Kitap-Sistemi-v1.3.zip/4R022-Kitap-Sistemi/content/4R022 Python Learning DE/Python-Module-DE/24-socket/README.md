# Modul `socket`

> ⚠️ Grundlage der Netzwerkprogrammierung — nur legale Nutzung.

## Was ist es und wie funktioniert es?

Direkter Zugriff auf die Netzwerkschicht des OS — rohe TCP/UDP-Verbindungen.

## ✅ Funktionierende Beispiele

```python
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("localhost", 5000))
s.listen(1)
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Port erfordert Admin-Rechte

```python
s.bind(("localhost", 80))
```
- **Warum ist das falsch?** Ports < 1024 erfordern Berechtigungen.
- **Wo ist der Fehler?** `PermissionError`
- **Was stattdessen?** Port über 1024 verwenden (z. B. 8080).

### Fehlerhaftes Beispiel 2 — Verwechslung str/bytes

```python
conn.send("Hallo")   # str, keine bytes!
```
- **Warum ist das falsch?** `send()` akzeptiert nur bytes.
- **Wo ist der Fehler?** `TypeError`
- **Was stattdessen?** `conn.send("Hallo".encode())`

## 🔗 Verwandte Module
[threading](../12-threading/README.md)

---
⬅️ [Modul-Startseite](../README.md)
