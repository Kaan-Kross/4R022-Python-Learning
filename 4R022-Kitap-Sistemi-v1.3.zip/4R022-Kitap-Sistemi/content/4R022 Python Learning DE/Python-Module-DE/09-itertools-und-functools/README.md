# Module `itertools` und `functools`

## Was ist es und wie funktioniert es?

`itertools` bietet speichereffiziente Werkzeuge für Schleifen;
`functools` Werkzeuge für Funktionen (Caching, Reduktion).

## ✅ Funktionierende Beispiele

```python
from itertools import chain
from functools import reduce
for x in chain([1,2],[3,4]): print(x)
print(reduce(lambda a,b: a*b, [1,2,3,4]))
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — unendliches `count()` ohne Abbruch

```python
from itertools import count
for i in count(1):
    print(i)   # stoppt nie!
```
- **Warum ist das falsch?** `count()` ist unendlich.
- **Wo ist der Fehler?** Keine Abbruchbedingung.
- **Was stattdessen?** `if i > 10: break` hinzufügen.

### Fehlerhaftes Beispiel 2 — `lru_cache` mit veränderlichem Argument

```python
from functools import lru_cache
@lru_cache(maxsize=None)
def summe(liste): return sum(liste)
summe([1,2,3])
```
- **Warum ist das falsch?** `list` ist nicht hashbar.
- **Wo ist der Fehler?** `TypeError: unhashable type: 'list'`
- **Was stattdessen?** `summe((1,2,3))` mit Tuple.

## 🔗 Verwandte Module
[collections](../08-collections/README.md)

---
⬅️ [Modul-Startseite](../README.md)
