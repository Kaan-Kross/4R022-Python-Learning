# Modul `numpy`

## Was ist es und wie funktioniert es?

In C geschriebene Bibliothek für schnelle Operationen auf
numerischen Arrays durch Vektorisierung.

## ✅ Funktionierende Beispiele

```python
import numpy as np
arr = np.array([1,2,3,4,5])
print(arr * 2)
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — gleiches Verhalten wie bei Liste erwarten

```python
lst = [1,2,3]
print(lst * 2)   # [1,2,3,1,2,3] — keine Multiplikation!
```
- **Warum ist das falsch?** `*` wiederholt die Liste, statt Elemente zu multiplizieren.
- **Wo ist der Fehler?** Python-Liste mit numpy-Array verwechselt.
- **Was stattdessen?** `np.array(lst) * 2`

### Fehlerhaftes Beispiel 2 — unzureichender Datentyp

```python
arr = np.array([200, 100], dtype=np.int8)
print(arr + 100)   # stiller Überlauf!
```
- **Warum ist das falsch?** `int8` reicht von -128 bis 127.
- **Wo ist der Fehler?** Typ passt nicht zum Wertebereich.
- **Was stattdessen?** `dtype=np.int32` verwenden.

## 🔗 Verwandte Module
[pandas](../19-pandas/README.md)

---
⬅️ [Modul-Startseite](../README.md)
