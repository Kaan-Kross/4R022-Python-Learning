# Modul `queue`

## Was ist es und wie funktioniert es?

Thread-sichere FIFO-Warteschlange für sichere Datenübertragung
zwischen Threads.

## ✅ Funktionierende Beispiele

```python
import queue
q = queue.Queue()
q.put("aufgabe-1")
print(q.get())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `get_nowait()` bei leerer Warteschlange

```python
q.get_nowait()
```
- **Warum ist das falsch?** Kein Warten, sofortiger Fehler.
- **Wo ist der Fehler?** `queue.Empty`
- **Was stattdessen?** `q.get()` oder `try/except queue.Empty`.

### Fehlerhaftes Beispiel 2 — normale Liste zwischen Threads

```python
data = []
threading.Thread(target=lambda: data.append(1)).start()
```
- **Warum ist das falsch?** `list.append()` ist nicht atomar.
- **Wo ist der Fehler?** Risiko von Datenkorruption.
- **Was stattdessen?** `queue.Queue()` verwenden.

## 🔗 Verwandte Module
[threading](../12-threading/README.md)

---
⬅️ [Modul-Startseite](../README.md)
