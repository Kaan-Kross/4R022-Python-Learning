# Modul `asyncio`

## Was ist es und wie funktioniert es?

Verwaltet viele Wartezeit-Aufgaben in einem Thread — bei `await`
pausiert die Aufgabe, eine andere läuft.

## ✅ Funktionierende Beispiele

```python
import asyncio
async def hallo():
    await asyncio.sleep(1)
    print("Hallo!")
asyncio.run(hallo())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Aufruf ohne `await`

```python
async def hallo(): print("Hallo!")
hallo()   # wird nicht wirklich ausgeführt!
```
- **Warum ist das falsch?** Erstellt nur ein Coroutine-Objekt.
- **Wo ist der Fehler?** `RuntimeWarning: coroutine was never awaited`
- **Was stattdessen?** `asyncio.run(hallo())`

### Fehlerhaftes Beispiel 2 — blockierender Code in async

```python
import time
async def aufgabe():
    time.sleep(3)   # blockiert die GESAMTE Event-Loop!
```
- **Warum ist das falsch?** `time.sleep()` ist synchron.
- **Wo ist der Fehler?** `await asyncio.sleep(3)` wäre nötig gewesen.
- **Was stattdessen?** Immer async-kompatible Funktionen verwenden.

## 🔗 Verwandte Module
[threading](../12-threading/README.md)

---
⬅️ [Modul-Startseite](../README.md)
