# Modul `collections`

## Was ist es und wie funktioniert es?

Spezialisierte Versionen von `list`/`dict`: `Counter`, `deque`,
`defaultdict`, `namedtuple`.

## ✅ Funktionierende Beispiele

```python
from collections import Counter, defaultdict
c = Counter("apfel birne apfel".split())
g = defaultdict(list)
g["fruechte"].append("apfel")
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Hinzufügen zu fehlendem Schlüssel in normalem dict

```python
g = {}
g["fruechte"].append("apfel")
```
- **Warum ist das falsch?** Schlüssel existiert noch nicht.
- **Wo ist der Fehler?** `KeyError: 'fruechte'`
- **Was stattdessen?** `defaultdict(list)` verwenden.

### Fehlerhaftes Beispiel 2 — `namedtuple` ändern

```python
from collections import namedtuple
Punkt = namedtuple("Punkt", ["x", "y"])
p = Punkt(1, 2)
p.x = 5
```
- **Warum ist das falsch?** namedtuples sind unveränderlich.
- **Wo ist der Fehler?** `AttributeError: can't set attribute`
- **Was stattdessen?** `p._replace(x=5)` erstellt ein neues Objekt.

## 🔗 Verwandte Module
[itertools und functools](../09-itertools-und-functools/README.md)

---
⬅️ [Modul-Startseite](../README.md)
