# Modul `tempfile`

## Was ist es und wie funktioniert es?

Erstellt automatisch eindeutig benannte temporäre Dateien/Ordner,
meist am Programmende gelöscht.

## ✅ Funktionierende Beispiele

```python
import tempfile
with tempfile.NamedTemporaryFile(mode="w") as f:
    f.write("daten")
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Zugriff nach dem Schließen (delete=True)

```python
f = tempfile.NamedTemporaryFile(mode="w", delete=True)
f.close()
open(f.name)   # bereits gelöscht!
```
- **Warum ist das falsch?** Datei wird sofort beim Schließen gelöscht.
- **Wo ist der Fehler?** `FileNotFoundError`
- **Was stattdessen?** `delete=False` verwenden.

### Fehlerhaftes Beispiel 2 — Zugriff von anderem Prozess unter Windows

```python
f = tempfile.NamedTemporaryFile(mode="w")
open(f.name, "r")   # kann unter Windows fehlschlagen
```
- **Warum ist das falsch?** Windows blockiert gleichzeitigen Zugriff.
- **Wo ist der Fehler?** `PermissionError`
- **Was stattdessen?** `delete=False` für Kreuzzugriff.

## 🔗 Verwandte Module
[os](../01-os/README.md)

---
⬅️ [Modul-Startseite](../README.md)
