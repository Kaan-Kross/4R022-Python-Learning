# Modul `threading`

## Was ist es und wie funktioniert es?

Führt mehrere Threads aus. Wegen des GIL keine echte CPU-Parallelität,
aber effizient für Wartezeit-Aufgaben (I/O).

## ✅ Funktionierende Beispiele

```python
import threading, time
def aufgabe():
    time.sleep(1)
t = threading.Thread(target=aufgabe)
t.start(); t.join()
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `join()` vergessen

```python
t = threading.Thread(target=aufgabe)
t.start()
print("Ende")   # kann vor Aufgabenende ausgegeben werden!
```
- **Warum ist das falsch?** `start()` wartet nicht auf das Ende.
- **Wo ist der Fehler?** `t.join()` fehlt.
- **Was stattdessen?** `t.join()` hinzufügen.

### Fehlerhaftes Beispiel 2 — geteilte Daten ohne Lock

```python
zaehler = 0
def erhoehen():
    global zaehler
    zaehler += 1   # nicht atomar!
```
- **Warum ist das falsch?** Race Condition.
- **Wo ist der Fehler?** Kein `threading.Lock()`.
- **Was stattdessen?** Mit `with lock:` schützen.

## 🔗 Verwandte Module
[multiprocessing](../13-multiprocessing/README.md)

---
⬅️ [Modul-Startseite](../README.md)
