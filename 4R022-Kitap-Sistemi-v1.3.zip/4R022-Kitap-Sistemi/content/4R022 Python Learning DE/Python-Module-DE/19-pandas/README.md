# Modul `pandas`

## Was ist es und wie funktioniert es?

Arbeitet mit Tabellendaten über das **DataFrame**-Objekt — wie ein
Excel-Blatt.

## ✅ Funktionierende Beispiele

```python
import pandas as pd
df = pd.read_csv("noten.csv")
print(df["note"].mean())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — nicht existierende Spalte

```python
df = pd.DataFrame({"name": ["Kaan"], "note": [95]})
print(df["noten"])
```
- **Warum ist das falsch?** Die Spalte heißt `"note"`.
- **Wo ist der Fehler?** `KeyError: 'noten'`
- **Was stattdessen?** Vorher `df.columns` prüfen.

### Fehlerhaftes Beispiel 2 — unbehandelte fehlende Werte (NaN)

```python
df = pd.read_csv("unvollstaendige_daten.csv")
durchschnitt = df["note"].sum() / len(df)
```
- **Warum ist das falsch?** `len(df)` zählt auch Zeilen mit NaN.
- **Wo ist der Fehler?** Berechnung wird verfälscht.
- **Was stattdessen?** `df["note"].mean()` ignoriert NaN automatisch.

## 🔗 Verwandte Module
[numpy](../18-numpy/README.md), [csv](../04-csv/README.md)

---
⬅️ [Modul-Startseite](../README.md)
