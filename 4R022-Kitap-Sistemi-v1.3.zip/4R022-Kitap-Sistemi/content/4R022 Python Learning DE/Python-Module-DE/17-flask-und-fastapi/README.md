# Flask und FastAPI

## Was ist es und wie funktioniert es?

Beide ermöglichen einen Webserver/API in Python. Flask ist minimal;
FastAPI fügt automatische Validierung und Dokumentation über
Typ-Annotationen hinzu.

## ✅ Funktionierende Beispiele

```python
from flask import Flask, jsonify
app = Flask(__name__)
@app.route("/studenten")
def studenten():
    return jsonify([{"name": "Kaan", "note": 95}])
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `debug=True` in Produktion

```python
app.run(debug=True, host="0.0.0.0")
```
- **Warum ist das falsch?** Öffnet eine ausnutzbare interaktive Konsole.
- **Wo ist der Fehler?** Entwicklungseinstellung in Produktion.
- **Was stattdessen?** `debug=False`, `gunicorn` verwenden.

### Fehlerhaftes Beispiel 2 — Daten passen nicht zum Pydantic-Modell

```python
requests.post(url, json={"name": "Kaan", "note": "fünfundneunzig"})
```
- **Warum ist das falsch?** `note` erwartet `int`.
- **Wo ist der Fehler?** FastAPI gibt `422 Unprocessable Entity` zurück.
- **Was stattdessen?** `{"name": "Kaan", "note": 95}` senden.

## 🔗 Verwandte Module
[requests](../16-requests/README.md)

---
⬅️ [Modul-Startseite](../README.md)
