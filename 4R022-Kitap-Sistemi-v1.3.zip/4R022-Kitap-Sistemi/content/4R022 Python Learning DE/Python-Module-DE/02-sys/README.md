# Modul `sys`

## Was ist es und wie funktioniert es?

`sys` interagiert direkt mit dem **Python-Interpreter selbst**:
Kommandozeilenargumente, Version, Exit-Code.

## ✅ Funktionierende Beispiele

```python
import sys
print(sys.argv)
if len(sys.argv) > 1:
    print("Erstes Argument:", sys.argv[1])
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `sys.argv[0]` verwechseln

```python
name = sys.argv[0]
```
- **Warum ist das falsch?** `sys.argv[0]` ist der Skriptname selbst.
- **Wo ist der Fehler?** Index `1` wäre richtig gewesen.
- **Was stattdessen?** `sys.argv[1]` mit Längenprüfung.

### Fehlerhaftes Beispiel 2 — `sys.exit()` versehentlich abfangen

```python
try:
    sys.exit(1)
except Exception:
    print("trotzdem weiter")
```
- **Warum ist das falsch?** `sys.exit()` löst `SystemExit` aus, das
  von einem breiten `except Exception` gefangen wird.
- **Wo ist der Fehler?** Zu weit gefasster except-Block.
- **Was stattdessen?** Spezifischere Ausnahmetypen verwenden.

## 🔗 Verwandte Module
[os](../01-os/README.md)

---
⬅️ [Modul-Startseite](../README.md)
