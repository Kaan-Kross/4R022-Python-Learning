# Modul `PyQt6`

## Was ist es und wie funktioniert es?

Python-Anbindung für Qt6, mit Signal/Slot-Architektur: ein Ereignis
(Signal) löst automatisch eine verbundene Funktion (Slot) aus.

## ✅ Funktionierende Beispiele

```python
import sys
from PyQt6.QtWidgets import QApplication, QWidget
app = QApplication(sys.argv)
window = QWidget()
window.show()
sys.exit(app.exec())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Widget vor QApplication

```python
window = QWidget()   # QApplication noch nicht erstellt!
app = QApplication(sys.argv)
```
- **Warum ist das falsch?** QApplication muss zuerst erstellt werden.
- **Wo ist der Fehler?** Falsche Reihenfolge der Aufrufe.
- **Was stattdessen?** `app` zuerst erstellen.

### Fehlerhaftes Beispiel 2 — Signal mit Klammern

```python
button.clicked.connect(klick())   # Klammern!
```
- **Warum ist das falsch?** Die Funktion wird sofort ausgeführt.
- **Wo ist der Fehler?** `None` wird statt der Funktion übergeben.
- **Was stattdessen?** `button.clicked.connect(klick)`

## 🔗 Verwandte Module
[tkinter](../21-tkinter/README.md)

---
⬅️ [Modul-Startseite](../README.md)
