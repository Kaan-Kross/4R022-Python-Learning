# Modul `requests`

## Was ist es und wie funktioniert es?

Sendet HTTP-Anfragen an Webserver/APIs — viel lesbarer als `urllib`.

## ✅ Funktionierende Beispiele

```python
import requests
r = requests.get("https://api.github.com", timeout=5)
print(r.status_code, r.json())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — ohne `timeout`

```python
r = requests.get("https://sehr-langsamer-server.com")
```
- **Warum ist das falsch?** Das Programm kann ewig warten.
- **Wo ist der Fehler?** `timeout` fehlt.
- **Was stattdessen?** `requests.get(url, timeout=5)`

### Fehlerhaftes Beispiel 2 — API-Schlüssel im Quellcode

```python
API_SCHLUESSEL = "sk-echter-schluessel"
r = requests.get(f"https://api.example.com/data?key={API_SCHLUESSEL}")
```
- **Warum ist das falsch?** Leck bei Veröffentlichung auf GitHub.
- **Wo ist der Fehler?** Schlüssel im Quellcode fest codiert.
- **Was stattdessen?** Umgebungsvariablen verwenden.

## 🔗 Verwandte Module
[Flask und FastAPI](../17-flask-und-fastapi/README.md)

---
⬅️ [Modul-Startseite](../README.md)
