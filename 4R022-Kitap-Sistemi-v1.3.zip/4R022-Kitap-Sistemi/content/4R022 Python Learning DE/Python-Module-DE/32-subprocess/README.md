# Modul `subprocess`

## Was ist es und wie funktioniert es?

Führt externe Programme/Befehle von Python aus.

## ✅ Funktionierende Beispiele

```python
import subprocess
r = subprocess.run(["python", "--version"], capture_output=True, text=True)
print(r.stdout)
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `shell=True` mit Benutzereingabe

```python
dateiname = input("Datei: ")
subprocess.run(f"del {dateiname}", shell=True)
```
- **Warum ist das falsch?** Command-Injection — schwere Sicherheitslücke.
- **Wo ist der Fehler?** Benutzereingabe direkt in Shell-Befehl.
- **Was stattdessen?** `subprocess.run(["del", dateiname])` ohne shell=True.

### Fehlerhaftes Beispiel 2 — riesige Ausgabe im Speicher

```python
subprocess.run(["find", "/", "-name", "*.log"], capture_output=True)
```
- **Warum ist das falsch?** Gesamte Ausgabe wird sofort in den Speicher geladen.
- **Wo ist der Fehler?** Möglicher Speichermangel.
- **Was stattdessen?** `Popen` für zeilenweises Lesen verwenden.

## 🔗 Verwandte Module
[os](../01-os/README.md)

---
⬅️ [Modul-Startseite](../README.md)
