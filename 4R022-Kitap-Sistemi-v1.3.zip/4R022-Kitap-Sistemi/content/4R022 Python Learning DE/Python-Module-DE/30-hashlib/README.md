# Modul `hashlib`

## Was ist es und wie funktioniert es?

Wandelt Daten in einen unumkehrbaren Hash fester Länge um
(MD5, SHA-256 usw.).

## ✅ Funktionierende Beispiele

```python
import hashlib
print(hashlib.sha256("text".encode()).hexdigest())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Passwörter mit MD5 speichern

```python
h = hashlib.md5("123456".encode()).hexdigest()
```
- **Warum ist das falsch?** MD5 ist schnell und geknackt — schlecht für Passwörter.
- **Wo ist der Fehler?** Falsches Werkzeug für Sicherheitskontext.
- **Was stattdessen?** `bcrypt`/`argon2` verwenden.

### Fehlerhaftes Beispiel 2 — String direkt hashen

```python
hashlib.sha256("hallo")
```
- **Warum ist das falsch?** Funktionen akzeptieren nur bytes.
- **Wo ist der Fehler?** `TypeError`
- **Was stattdessen?** `.encode()` vor dem Hashen.

## 🔗 Verwandte Module
[cryptography](../25-cryptography/README.md)

---
⬅️ [Modul-Startseite](../README.md)
