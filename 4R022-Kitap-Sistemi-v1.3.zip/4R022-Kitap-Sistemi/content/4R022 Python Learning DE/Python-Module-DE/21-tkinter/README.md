# Modul `tkinter`

## Was ist es und wie funktioniert es?

Standard-GUI-Bibliothek von Python, basierend auf einer
Ereignisschleife, die mit `mainloop()` startet.

## ✅ Funktionierende Beispiele

```python
import tkinter as tk
root = tk.Tk()
tk.Label(root, text="Hallo!").pack()
root.mainloop()
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `mainloop()` vergessen

```python
root = tk.Tk()
tk.Label(root, text="Erscheint nicht").pack()
```
- **Warum ist das falsch?** Ohne `mainloop()` startet die Ereignisschleife nicht.
- **Wo ist der Fehler?** `root.mainloop()` fehlt.
- **Was stattdessen?** Immer als letzte Zeile hinzufügen.

### Fehlerhaftes Beispiel 2 — Funktion mit Klammern in `command=`

```python
def klick(): print("Klick")
tk.Button(root, text="Knopf", command=klick()).pack()   # Klammern!
```
- **Warum ist das falsch?** Die Funktion wird sofort beim Erstellen ausgeführt.
- **Wo ist der Fehler?** Überflüssige Klammern nach `klick`.
- **Was stattdessen?** `command=klick` ohne Klammern.

## 🔗 Verwandte Module
[PyQt6](../22-PyQt6/README.md)

---
⬅️ [Modul-Startseite](../README.md)
