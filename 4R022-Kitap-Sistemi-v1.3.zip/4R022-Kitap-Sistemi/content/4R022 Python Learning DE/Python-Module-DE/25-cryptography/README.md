# Modul `cryptography`

## Was ist es und wie funktioniert es?

Zuverlässige Verschlüsselungsbibliothek mit bewährten Algorithmen
(AES, Fernet) statt Eigenentwicklung.

## ✅ Funktionierende Beispiele

```python
from cryptography.fernet import Fernet
schluessel = Fernet.generate_key()
f = Fernet(schluessel)
verschluesselt = f.encrypt(b"geheim")
print(f.decrypt(verschluesselt).decode())
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — neuer Schlüssel bei jedem Start

```python
f2 = Fernet(Fernet.generate_key())   # anderer Schlüssel!
f2.decrypt(verschluesselt)
```
- **Warum ist das falsch?** Ver- und Entschlüsselungsschlüssel müssen identisch sein.
- **Wo ist der Fehler?** `InvalidToken`
- **Was stattdessen?** Schlüssel speichern und wiederverwenden.

### Fehlerhaftes Beispiel 2 — Schlüssel im Quellcode

```python
SCHLUESSEL = b"gAAAAA...(echter Schlüssel)..."
```
- **Warum ist das falsch?** Leck bei Veröffentlichung auf GitHub.
- **Wo ist der Fehler?** Schlüssel im Code eingebettet.
- **Was stattdessen?** In Umgebungsvariable speichern.

## 🔗 Verwandte Module
[hashlib](../30-hashlib/README.md)

---
⬅️ [Modul-Startseite](../README.md)
