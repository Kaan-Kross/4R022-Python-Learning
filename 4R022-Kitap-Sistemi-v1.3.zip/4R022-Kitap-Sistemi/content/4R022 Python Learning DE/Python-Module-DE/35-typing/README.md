# Modul `typing`

## Was ist es und wie funktioniert es?

Fügt Typ-Annotationen hinzu; werden zur Laufzeit NICHT überprüft —
dienen hauptsächlich Editoren und `mypy`.

## ✅ Funktionierende Beispiele

```python
def begruessen(name: str) -> str:
    return f"Hallo, {name}!"
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — Typprüfung erwarten

```python
def addieren(a: int, b: int) -> int:
    return a + b
print(addieren("5", "3"))   # funktioniert, ergibt aber "53", nicht 8!
```
- **Warum ist das falsch?** Typ-Annotationen garantieren keine Validierung.
- **Wo ist der Fehler?** Falsche Annahme automatischer Validierung.
- **Was stattdessen?** `mypy` oder `isinstance()` verwenden.

### Fehlerhaftes Beispiel 2 — neue Syntax auf alter Python-Version

```python
def f(x: list[int]) -> int:   # funktioniert nicht vor Python 3.9!
    return x[0]
```
- **Warum ist das falsch?** `list[int]` wurde in 3.9 eingeführt.
- **Wo ist der Fehler?** `TypeError` auf älteren Versionen.
- **Was stattdessen?** `from typing import List` -> `List[int]`

## 🔗 Verwandte Module
[dataclasses](../34-dataclasses/README.md)

---
⬅️ [Modul-Startseite](../README.md)
