# Modul `csv`

## Was ist es und wie funktioniert es?

Liest und schreibt tabellarische Daten mit korrekter Behandlung von
Trennzeichen, Anführungszeichen und Zeilenenden.

## ✅ Funktionierende Beispiele

```python
import csv
with open("noten.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "note"])
    writer.writerow(["Kaan", 95])
```

## ❌ Fehlerhafte Beispiele

### Fehlerhaftes Beispiel 1 — `newline=""` vergessen (Windows)

```python
with open("noten.csv", "w", encoding="utf-8") as f:
    writer = csv.writer(f)
```
- **Warum ist das falsch?** Zusätzliche Leerzeilen unter Windows.
- **Wo ist der Fehler?** `newline=""` fehlt.
- **Was stattdessen?** `open("noten.csv", "w", newline="", encoding="utf-8")`

### Fehlerhaftes Beispiel 2 — manuelles `split(",")` mit internen Kommas

```python
zeile = 'Kaan,"Berlin, Deutschland",95'
teile = zeile.split(",")   # in 4 statt 3 Teile zerlegt!
```
- **Warum ist das falsch?** Komma in Anführungszeichen wird auch als Trenner behandelt.
- **Wo ist der Fehler?** Keine Behandlung von Anführungszeichen.
- **Was stattdessen?** `csv.reader()` verwenden.

## 🔗 Verwandte Module
[json](../03-json/README.md), [pandas](../19-pandas/README.md)

---
⬅️ [Modul-Startseite](../README.md)
