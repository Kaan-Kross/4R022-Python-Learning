# 1. Ethische Nutzung und Verantwortung

## Code ist neutral, Absicht nicht

Alles, was du hier gelernt hast — Datei lesen/schreiben,
Netzwerkprogrammierung (`socket`), Browser-Automatisierung
(`selenium`), Verschlüsselung (`cryptography`) — ist **an sich weder
gut noch schlecht.** Derselbe `socket`-Code kann in einer
Studentenaufgabe oder in einem bösartigen Tool verwendet werden. Der
Unterschied liegt darin, **wer es mit wessen Erlaubnis und zu
welchem Zweck verwendet.**

## Drei einfache Fragen

Bevor du ein Skript ausführst, frage dich:

1. **Habe ich die Erlaubnis?** Habe ich die ausdrückliche Erlaubnis
   des Eigentümers erhalten?
2. **Verursacht es Schaden?** Könnte dieser Code jemandem schaden?
3. **Bin ich transparent?** Könnte ich offen erklären, was dieser
   Code tut?

## Reale Beispiele legitimer Nutzung

| Technik | Legitime Nutzung | Wo die Grenze überschritten wird |
|---|---|---|
| Web-Scraping | Eigene Website-Daten sammeln, `robots.txt` respektieren | Persönliche Daten unter Verletzung der AGB sammeln |
| Automatisierungs-Bots | Wiederkehrende Aufgaben im eigenen Konto automatisieren | Plattformregeln mit gefälschten Konten verletzen |
| Netzwerk-Scan-Tools | Eigenes Netzwerk mit schriftlicher Genehmigung testen | Fremdes System ohne Erlaubnis scannen |

## Verantwortung

Rechtliche Verantwortung liegt bei dir; ethische Verantwortung
umfasst auch Grauzonen; Verantwortung gegenüber der Community beim
Teilen von Wissen.

### 🎯 Denkübung
Wenn ein Freund dich bäte, „nur mal zu versuchen", das Passwort in
den sozialen Medien seiner Ex zu knacken — wie wären die Antworten
auf die obigen drei Fragen?

---
⬅️ [Zurück](./README.md) &nbsp;|&nbsp; ➡️ [White/Grey/Black Hat Hacker](./02-White-Grey-Black-Hat-Hacker.md)
