# 2. Wer sind White / Grey / Black Hat Hacker?

> Dieses Kapitel ist rein **beschreibend und informativ**; es lehrt
> keine Angriffstechniken.

## Die gemeinsame Wurzel: Was bedeutet „Hacker" wirklich?

Obwohl die Populärkultur „Hacker" oft mit „Computerkrimineller"
gleichsetzt, bedeutet es ursprünglich **eine Person, die ein System
tief versteht, seine Grenzen auslotet und kreative Lösungen
schafft.** In der MIT-Kultur der 1960er war „Hacker" ein positives
Prädikat. Mit der Zeit verband die Presse das Wort fast vollständig
mit „Cyberkriminellem" — daher die „Hutfarben" zur Unterscheidung.

## ⚪ White Hat

**Wer sind sie?** Personen, die Systeme **mit schriftlicher
Genehmigung des Eigentümers** auf Schwachstellen testen, um sie zu
beheben.

**Was tun sie?** Penetrationstests, Bug-Bounty-Programme,
Sicherheitsberatung, Aufbau von Verteidigungssystemen.

## ⚫ Black Hat

**Wer sind sie?** Personen, die ohne Erlaubnis, mit böswilliger
Absicht in Systeme eindringen.

**Was tun sie?** (informativ, ohne technische Details) Verbreitung
von Ransomware, Datendiebstahl, Phishing, DDoS-Angriffe — alles
**illegale** Aktivitäten.

## ⚪⚫ Grey Hat

**Wer sind sie?** Dazwischen — finden meist eine Schwachstelle
**ohne Erlaubnis**, melden sie aber statt sie auszunutzen.

## Vergleichstabelle

| | White Hat | Grey Hat | Black Hat |
|---|---|---|---|
| Erlaubnis | Ja | Nein | Nein |
| Absicht | Gut | Meist gut | Schlecht |
| Legalität | Legal | Zweideutig | Illegal |

## Andere Farben (kurz)

**Red Hat:** aggressiver Gegenangriff; **Blue Team:** kontinuierliche
Verteidigung; **Script Kiddie:** unerfahrene Personen mit
Fertig-Tools ohne Verständnis.

## Warum ist diese Unterscheidung wichtig?

Die hier gelernten Werkzeuge — `socket`, `requests`, `selenium`,
`cryptography` — können technisch von beiden Seiten genutzt werden.
**Erlaubnis und Absicht** bestimmen die Seite, nicht der Code selbst.

---
⬅️ [Ethische Nutzung und Verantwortung](./01-Ethische-Nutzung-und-Verantwortung.md) &nbsp;|&nbsp; ➡️ [Rechtliche Grenzen und Haftungsausschluss](./03-Rechtliche-Grenzen-und-Haftungsausschluss.md)
