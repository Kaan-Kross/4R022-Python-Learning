# 2. Was sind CSV-Daten?

## Herkunft und Wesen

CSV (Comma-Separated Values) ist eines der ältesten und einfachsten
Formate für Tabellendaten als **reiner Text**, seit den 1970er
Jahren im Einsatz. Es gibt keinen strengen verbindlichen Standard
(RFC 4180 ist eine Empfehlung).

## Wie sieht die Struktur aus?

```csv
name,alter,stadt
Kaan,25,Sakarya
Ayse,22,Istanbul
"Müller, Hans",30,Berlin
```

Der Name in der dritten Zeile enthält ein Komma und steht daher in
**Anführungszeichen**.

## Warum ist es immer noch so verbreitet?

- **Universelles Austauschformat für Excel/Google Sheets.**
- **Mit bloßem Auge lesbar** bei kleinen Dateien.
- **Standard-Exportformat für Datenbanken.**

## Wie integrieren Systeme CSV?

Buchhaltungs-/ERP-Systeme exportieren Verkaufsberichte als CSV;
Data-Science-Workflows sammeln Rohdaten oft als CSV; Massenimporte
verwenden ausgefüllte CSV-Vorlagen.

## Wie wird es aktualisiert / automatisiert?

Geplante Exporte stempeln jede Nacht/Woche automatisch aktuelle
Daten in eine CSV-Datei; Überwachungsskripte verarbeiten automatisch
neu erschienene CSV-Dateien.

## Was sind seine Grenzen?

- **Trägt keine Typinformationen.**
- **Kann keine verschachtelten Daten darstellen.**
- **Inkonsistenz des Standards** — Trennzeichen, Zeilenendezeichen
  und Kodierung unterscheiden sich zwischen Systemen.

---
⬅️ [Was sind JSON-Daten?](./01-Was-sind-JSON-Daten.md) &nbsp;|&nbsp; ➡️ [Datenbanken und SQLite](./03-Datenbanken-und-SQLite.md)
