# 1. Was sind JSON-Daten?

## Herkunft und Wesen von JSON

JSON (JavaScript Object Notation) entstand aus der Objektsyntax von
JavaScript, ist aber zu einem **sprachunabhängigen, universellen
Datenaustauschformat** geworden. Popularisiert um 2001 von Douglas
Crockford, heute durch den Standard RFC 8259 definiert.

## Wie sieht die Struktur aus?

JSON besteht aus nur **6 Grundbausteinen**: Objekt, Array, String,
Zahl, Boolean, null-Wert.

```json
{
  "benutzer": "Kaan",
  "aktiv": true,
  "alter": 25,
  "rollen": ["entwickler", "student"],
  "adresse": {"stadt": "Sakarya", "land": "Türkei"},
  "zweites_telefon": null
}
```

## Warum ist es so weit verbreitet?

- **Die gemeinsame Sprache von Web-APIs.**
- **Für Menschen lesbar** — viel einfacher als XML.
- **Leichtgewichtig.**

## Wie integrieren Systeme JSON?

1. **API-Kommunikation:** Eine mobile App sendet eine Anfrage an den
   Server, der JSON-Daten zurückgibt.
2. **Konfigurationsdateien:** Viele Anwendungen speichern ihre
   Einstellungen in `.json`-Dateien.
3. **Logs/Datenspeichersysteme:** Server-Logs werden oft als
   „JSON Lines" gespeichert.

## Wie wird es aktualisiert?

- **Polling:** Der Client fragt periodisch neue Daten ab.
- **Push (Webhook/Websocket):** Der Server sendet neue Daten selbst.
- **Dateibasiert:** Eine lokale Anwendung schreibt ihre JSON-
  Einstellungsdatei bei jeder Änderung neu (mit atomarem Schreiben,
  um Datenverlust zu vermeiden).

## Automatisierung und Export/Import

Export: Ein gesamtes Backup wird oft in eine einzige JSON-Datei
geschrieben. Import: Ein Quellsystem exportiert seine Daten als
JSON, das Zielsystem liest und importiert sie.

## Was sind seine Grenzen?

- **Keine Kommentare** im offiziellen Standard.
- **Kann bei riesigen Datenmengen ineffizient sein.**
- **Kein erzwungenes Schema.**

---
⬅️ [Zurück](./README.md) &nbsp;|&nbsp; ➡️ [Was sind CSV-Daten?](./02-Was-sind-CSV-Daten.md)
