# Python: Datenkonzepte (DE)

Dieser Abschnitt ist bewusst getrennt von
[Modulen](../Python-Module-DE/README.md). Während jener beantwortet,
„wie verwende ich dieses Modul in Python?", beantwortet dieser eine
grundlegendere Frage: **„Was ist dieses Datenformat/-system
eigentlich, wie funktioniert es, und wie wird es in echten Systemen
integriert, automatisiert, exportiert und importiert?"**

## Kapitel

1. [Was sind JSON-Daten?](./01-Was-sind-JSON-Daten.md)
2. [Was sind CSV-Daten?](./02-Was-sind-CSV-Daten.md)
3. [Was sind Datenbanken und SQLite?](./03-Datenbanken-und-SQLite.md)

⬅️ [Fortgeschrittene Stufe](../Python-Fortgeschrittene-Stufe-DE/README.md) &nbsp;|&nbsp; ➡️ [Module](../Python-Module-DE/README.md)
