# 3. Was sind Datenbanken und SQLite?

## Was ist eine Datenbank, und warum braucht man sie?

Eine Datenbank speichert Daten **organisiert, abfragbar und
konsistent.** Mit wachsenden Daten (Tausende/Millionen Einträge)
werden einfache Dateien **langsam bei der Suche**, **schwierig für
sicheres gleichzeitiges Schreiben** und können **Konsistenzregeln
nicht garantieren.**

## Logik relationaler Datenbanken (kurz)

Der häufigste Typ ist die **relationale** Datenbank — Daten werden
in verknüpften **Tabellen** gespeichert, abgefragt in **SQL
(Structured Query Language)**.

## Was ist SQLite, und wie unterscheidet es sich von anderen Datenbanken?

SQLite ist eine **serverlose**, leichtgewichtige relationale
Datenbank-Engine, bei der **die gesamte Datenbank in einer einzigen
Datei** liegt. Im Gegensatz zu PostgreSQL oder MySQL ist kein
separater Datenbankserver nötig.

| Kriterium | SQLite | PostgreSQL / MySQL |
|---|---|---|
| Installation | Keine (dateibasiert) | Server-Setup erforderlich |
| Gleichzeitiger Mehrbenutzerzugriff | Begrenzt | Stark |
| Typische Verwendung | Desktop-Apps, mobil, Prototypen | Websites, große Systeme |

## Wie integrieren Systeme Datenbanken?

Desktop-Anwendungen wie 4R022 Arşiv speichern Benutzerdaten direkt
in einer lokalen SQLite-Datei. Web-Anwendungen speichern
Benutzerkonten oft in einer serverbasierten Datenbank.

## Wie werden Daten aktualisiert, gesichert?

CRUD-Operationen (`INSERT`, `SELECT`, `UPDATE`, `DELETE`);
Schema-Migrationen werden über kontrollierte Skripte angewendet;
Backups bei SQLite sind oft so einfach wie das Kopieren der `.db`-Datei.

## Was sind seine Grenzen?

SQLite eignet sich nicht für große Webanwendungen mit **vielen
gleichzeitigen Schreibvorgängen**. Relationale Datenbanken können für
flexible Datenstrukturen zu starr sein — daher „NoSQL"-Datenbanken
(MongoDB).

---
⬅️ [Was sind CSV-Daten?](./02-Was-sind-CSV-Daten.md) &nbsp;|&nbsp; ⬆️ [Abschnitt-Startseite](./README.md)

🎓 Als Nächstes: [Module](../Python-Module-DE/README.md) für die
Code-Seite (`json`, `csv`, `sqlite3`).
