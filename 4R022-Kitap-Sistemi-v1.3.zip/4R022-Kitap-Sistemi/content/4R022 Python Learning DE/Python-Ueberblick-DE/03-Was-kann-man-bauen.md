# Was kann man mit Python bauen?

## 1. Webentwicklung (Backend)
**Werkzeuge:** Django, Flask, FastAPI

```python
# ✅ Dieser Code funktioniert (wenn Flask installiert ist): ein minimaler Webserver
from flask import Flask
app = Flask(__name__)

@app.route("/")
def startseite():
    return "Willkommen bei 4R022 Python Learning!"
```

## 2. Data Science und Analyse
**Werkzeuge:** pandas, numpy, matplotlib

```python
# ✅ Dieser Code funktioniert (wenn pandas installiert ist)
import pandas as pd
daten = {"name": ["Anna", "Max"], "alter": [23, 30]}
df = pd.DataFrame(daten)
print(df)
```

## 3. Künstliche Intelligenz und maschinelles Lernen
**Werkzeuge:** TensorFlow, PyTorch, scikit-learn

Python ist die De-facto-Standardsprache der KI — fast alle großen
Sprachmodelle und ML-Bibliotheken bieten eine Python-Schnittstelle.

## 4. Automatisierung und Skripte
**Werkzeuge:** os, shutil, pyautogui, selenium

```python
# ✅ Dieser Code funktioniert — listet alle Dateien in einem Ordner auf
import os
for datei in os.listdir("."):
    print(datei)
```

## 5. Desktop-Anwendungsentwicklung
**Werkzeuge:** Tkinter (Standardbibliothek), PyQt6, Kivy

Viele Projekte der Marke 4R022 (Desktop-Tools) fallen genau in diese
Kategorie — professionelle Windows-Anwendungen, gebaut mit Python +
PyQt6/Tkinter.

## 6. Cybersicherheit und Netzwerkprogrammierung
**Werkzeuge:** socket, scapy, cryptography, requests

Sicherheitsforscher nutzen Python häufig für Netzwerkverkehrsanalyse,
Verschlüsselung und automatisierte Sicherheitsscans. Die **ethische**
Seite behandeln wir in
[Ethik und Sicherheit](../Python-Ethik-und-Sicherheit-DE/README.md).

## 7. Spieleentwicklung (leichtgewichtig)
**Werkzeuge:** Pygame

## 8. „Klebe"-Sprache
Python wird auch häufig verwendet, um verschiedene Systeme
miteinander zu verbinden (C-Bibliotheken, Datenbanken, APIs) — daher
der Spitzname „Klebesprache".

## Zusammenfassungstabelle

| Bereich | Beliebte Bibliotheken |
|---|---|
| Web (Backend) | Django, Flask, FastAPI |
| Data Science | pandas, numpy, matplotlib |
| KI | TensorFlow, PyTorch, scikit-learn |
| Automatisierung | os, selenium, pyautogui |
| Desktop-Anwendungen | Tkinter, PyQt6, Kivy |
| Netzwerk / Sicherheit | socket, scapy, cryptography |
| Spiele | Pygame |

---
⬅️ Zurück: [Python im Vergleich](./02-Python-im-Vergleich.md) &nbsp;|&nbsp; ➡️ Weiter: [Grundstufe beginnen](../Python-Grundlagen-DE/README.md)
