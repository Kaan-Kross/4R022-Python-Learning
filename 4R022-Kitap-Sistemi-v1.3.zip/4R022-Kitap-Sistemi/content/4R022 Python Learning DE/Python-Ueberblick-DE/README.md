# Python: Überblick (DE)

Bevor wir in den Code eintauchen, beantwortet dieser Abschnitt: Was
ist Python, wie unterscheidet es sich von anderen Sprachen, und was
kann man damit tatsächlich bauen?

## Inhalt

1. [Was ist Python?](./01-Was-ist-Python.md)
2. [Python im Vergleich zu anderen Programmiersprachen](./02-Python-im-Vergleich.md)
3. [Was kann man mit Python bauen?](./03-Was-kann-man-bauen.md)

Weiter ➡️ [Python Grundlagen](../Python-Grundlagen-DE/README.md)
