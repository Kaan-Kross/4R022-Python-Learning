# Was ist Python?

> 🧑‍🏫 **Hinweis des Lehrers:** Betrachte diesen Abschnitt als ein
> Gespräch, nicht als eine Definition zum Auswendiglernen. Das Ziel
> ist es, wirklich zu verstehen, warum diese Sprache existiert und
> warum sie so beliebt ist.

## Kurz gesagt

Python ist eine **interpretierte**, **hochsprachliche**
Programmiersprache für **allgemeine Zwecke**, entwickelt von **Guido
van Rossum** im Jahr 1991. „Hochsprachlich" bedeutet, dass sie sich
fast wie normales Englisch liest statt wie rohe Maschinenbefehle.

Die Philosophie von Python passt in einen Satz:

> **„Lesbarkeit des Codes geht über alles."**

```python
# ✅ Dieser Code funktioniert — und liest sich fast wie ein normaler Satz
name = "Kaan"
if name == "Kaan":
    print("Hallo, 4R022!")
```

## Warum „interpretiert"?

Python-Code wird nicht direkt in Maschinencode kompiliert; er wird
Zeile für Zeile von einem **Interpreter** ausgeführt (CPython ist
der gebräuchlichste). Das beschleunigt die Entwicklung, geht aber
etwas zulasten der Ausführungsgeschwindigkeit im Vergleich zu
kompilierten Sprachen wie C/C++ — ein bewusster Kompromiss zugunsten
von Entwicklungsgeschwindigkeit und Lesbarkeit.

## Wichtige Eigenschaften

| Eigenschaft | Beschreibung |
|---|---|
| Dynamische Typisierung | Kein vorheriges Deklarieren des Variablentyps nötig |
| Lesbare Syntax | Codeblöcke basieren auf Einrückung |
| Riesige Standardbibliothek | Philosophie „Batterien inklusive" |
| Multi-Paradigma | Prozedural, objektorientiert und funktional möglich |
| Plattformübergreifend | Derselbe Code läuft auf Windows, Linux, macOS |
| Riesige Community | Über 500.000 Pakete auf PyPI |

```python
# ✅ Dieser Code funktioniert
x = 5        # x ist gerade eine Ganzzahl (int)
x = "fünf"   # jetzt enthält dieselbe Variable einen String — kein Fehler
print(x)
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — das ist C/Java-Syntax, kein Python.
# Wenn man dies in eine Python-Datei einfügt, gibt es einen SyntaxError:
int x = 5;
```

## Warum ist Einrückung so wichtig?

Python verwendet **Einrückung** (keine `{}`), um Blöcke zu
definieren. Das ist gleichzeitig das markanteste Merkmal der Sprache
und der häufigste Anfängerfehler.

```python
# ✅ Dieser Code funktioniert — korrekte Einrückung
def begruessen():
    print("Hallo")
    print("Willkommen bei 4R022 Python Learning")

begruessen()
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — wirft einen IndentationError
def begruessen():
print("Hallo")   # diese Zeile hätte eingerückt sein müssen
```

## Zusammenfassung

- Python ist lesbar, dynamisch typisiert, interpretiert und vielseitig.
- Es trennt Codeblöcke durch Einrückung — seine größte Stärke und
  häufigste Anfängerfalle.
- Es besitzt eine riesige Standardbibliothek und ein Community-
  Paket-Ökosystem (PyPI).

### 🎯 Mini-Übung

Finde und behebe den Fehler in diesem Code:

```python
def addieren(a, b):
return a + b

print(addieren(3, 4))
```

<details>
<summary>Antwort anzeigen</summary>

`return a + b` ist nicht eingerückt, was einen `IndentationError`
verursacht. Korrigierte Version:

```python
def addieren(a, b):
    return a + b

print(addieren(3, 4))
```

</details>

---
⬅️ [Zurück](./README.md) &nbsp;|&nbsp; ➡️ Weiter: [Python im Vergleich](./02-Python-im-Vergleich.md)
