# Python im Vergleich zu anderen Programmiersprachen

## Python vs. C / C++

C und C++ sind **kompilierte** Sprachen mit **statischer Typisierung**.
Sie laufen sehr nah an der Hardware und sind daher schnell, aber die
Speicherverwaltung liegt meist beim Entwickler.

```c
// C — Typen sind zwingend erforderlich
int addieren(int a, int b) {
    return a + b;
}
```

```python
# ✅ Python — keine Typdeklaration nötig
def addieren(a, b):
    return a + b
```

**Unterschied:** C wird wegen Geschwindigkeit und systemnaher
Kontrolle gewählt (Betriebssysteme, Spiele-Engines, eingebettete
Systeme); Python wegen Entwicklungsgeschwindigkeit und Lesbarkeit
(Automatisierung, Data Science, Backend).

## Python vs. Java

Java ist ebenfalls statisch typisiert und kompiliert zu Bytecode;
„alles muss in einer Klasse leben" ist zwingend.

```java
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
```

```python
# ✅ Python — keine Klasse nötig, eine Zeile genügt
print("Hello World")
```

**Unterschied:** Java ist stark für große Unternehmenssysteme und
Android-Entwicklung; Python ist besser für schnelles Prototyping und
Skripte.

## Python vs. JavaScript

JavaScript ist dynamisch typisiert und läuft im Browser (und über
Node.js auf dem Server) — vom Gefühl her näher an Python.

```javascript
function addieren(a, b) {
    return a + b;
}
```

```python
def addieren(a, b):
    return a + b
```

**Unterschied:** JavaScript ist die native Sprache des Browsers
(nichts anderes läuft dort); Python hat keine Rolle im Browser, ist
aber viel komfortabler für Backend, Automatisierung, Data Science
und Desktop-Anwendungen.

## Python vs. C#

C# ist Microsofts statisch typisierte Sprache für das .NET-
Ökosystem, im Stil sehr nah an Java — verbreitet für Windows-
Desktop-Anwendungen (WPF, WinForms) und Spieleentwicklung (Unity).

**Unterschied:** C# integriert sich tief in Windows/.NET; Python
punktet mit plattformübergreifender Portabilität und
Entwicklungsgeschwindigkeit.

## Welche Sprache wählen?

| Bedarf | Empfohlene Sprache |
|---|---|
| Datenanalyse, KI, Automatisierung | **Python** |
| Browser-Oberfläche | JavaScript (+ HTML/CSS) |
| Hochleistungs-Spiele-Engine / OS | C / C++ |
| Großes Unternehmens-Backend / Android | Java |
| Windows-Desktop / Unity-Spiele | C# |
| Schnelle Skripte, Prototypen, Lernen | **Python** |

## Zusammenfassung

Keine Sprache ist universell „die beste" — jede existiert aus einem
Grund. Was Python auszeichnet, ist nicht rohe Geschwindigkeit,
sondern **Entwicklerproduktivität und eine niedrige Lernkurve.**
Genau deshalb beginnen wir hier.

---
⬅️ Zurück: [Was ist Python?](./01-Was-ist-Python.md) &nbsp;|&nbsp; ➡️ Weiter: [Was kann man mit Python bauen?](./03-Was-kann-man-bauen.md)
