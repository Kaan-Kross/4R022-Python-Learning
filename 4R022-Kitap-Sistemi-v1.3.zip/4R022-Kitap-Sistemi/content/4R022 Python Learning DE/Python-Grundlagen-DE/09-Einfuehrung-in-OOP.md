# 9. Einführung in die objektorientierte Programmierung (OOP)

## Klasse und Objekt

Eine **Klasse** ist ein „Bauplan". Ein **Objekt (Instanz)** ist ein
reales, konkretes Ding, das nach diesem Bauplan erstellt wurde.

```python
# ✅ Dieser Code funktioniert
class Student:
    def __init__(self, name, alter):
        self.name = name        # Attribut
        self.alter = alter

    def vorstellen(self):       # Methode
        print(f"Ich bin {self.name}, {self.alter} Jahre alt.")

student1 = Student("Kaan", 25)
student2 = Student("Ayse", 22)

student1.vorstellen()   # "Ich bin Kaan, 25 Jahre alt."
student2.vorstellen()   # "Ich bin Ayse, 22 Jahre alt."
```

`__init__` ist eine spezielle Methode, die **automatisch** beim
Erstellen eines Objekts ausgeführt wird (der Konstruktor). `self`
repräsentiert das Objekt selbst.

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — der Parameter 'self' fehlt
class Student:
    def __init__(name, alter):     # 'self' fehlt!
        name = name
        alter = alter

student1 = Student("Kaan", 25)
```

Das wirft `TypeError: __init__() takes 2 positional arguments but 3
were given`. Python übergibt automatisch das Objekt selbst (`self`)
als ersten Parameter jeder Methode; das zu vergessen ist der
klassische erste OOP-Fehler.

## Vererbung

```python
# ✅ Dieser Code funktioniert
class Tier:
    def __init__(self, name):
        self.name = name

    def laut_machen(self):
        print(f"{self.name} macht ein Geräusch.")

class Hund(Tier):                 # erbt von Tier
    def laut_machen(self):        # überschreibt die Methode
        print(f"{self.name}: Wuff!")

tier = Tier("Unbekannt")
hund = Hund("Rex")

tier.laut_machen()   # "Unbekannt macht ein Geräusch."
hund.laut_machen()   # "Rex: Wuff!"
```

## Kapselung — eine einfache Einführung

```python
# ✅ Dieser Code funktioniert — ein führender Unterstrich markiert
# ein Attribut per Konvention als „privat" (Python hat hier keine
# echte Zugriffsbeschränkung)
class Bankkonto:
    def __init__(self, kontostand):
        self._kontostand = kontostand

    def einzahlen(self, betrag):
        if betrag > 0:
            self._kontostand += betrag

    def kontostand_anzeigen(self):
        return self._kontostand

konto = Bankkonto(100)
konto.einzahlen(50)
print(konto.kontostand_anzeigen())   # 150
```

## Warum OOP?

Wenn ein Programm wächst, hält das Zusammenfassen zusammengehöriger
Daten (Attribute) und des darauf wirkenden Verhaltens (Methoden) den
Code lesbar und wartbar. Die `core/` + `ui/`-Trennung in 4R022s
PyQt6-Projekten ist genau diese Idee, nur in größerem Maßstab.

### 🎯 Mini-Übung
Schreibe eine Klasse `Fahrzeug` (mit den Attributen `marke`,
`geschwindigkeit`), dann eine davon erbende Unterklasse
`Sportwagen`, die eine Methode `beschleunigen()` überschreibt.

---
⬅️ [Dateiverarbeitung und Fehlerbehandlung](./08-Dateiverarbeitung-und-Fehlerbehandlung.md) &nbsp;|&nbsp; ➡️ [Weiter zur Mittelstufe](../Python-Mittelstufe-DE/README.md)

🎉 **Glückwunsch — du hast die Grundstufe abgeschlossen!**
