# 6. Funktionen

## Warum Funktionen?

Statt denselben Code zu wiederholen, verpackt man ihn unter einem
Namen, den man bei Bedarf aufrufen kann — die Grundlage des DRY-
Prinzips (Don't Repeat Yourself).

```python
# ✅ Dieser Code funktioniert
def begruessen(name):
    print(f"Hallo, {name}!")

begruessen("Kaan")
begruessen("4R022")
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Funktion vor ihrer Definition aufgerufen
begruessen("Kaan")

def begruessen(name):
    print(f"Hallo, {name}!")
```

Das wirft `NameError: name 'begruessen' is not defined`. Python
führt Code von oben nach unten aus; eine Funktion muss vor dem
Aufruf definiert werden.

## Werte zurückgeben mit `return`

```python
# ✅ Dieser Code funktioniert
def quadrat(n):
    return n ** 2

ergebnis = quadrat(5)
print(ergebnis)   # 25
```

> ⚠️ `print()` zeigt etwas auf dem Bildschirm an, gibt aber keinen
> Wert **zurück**; `return` transportiert einen Wert aus der
> Funktion heraus, damit er gespeichert werden kann.

## Standardparameter

```python
# ✅ Dieser Code funktioniert
def begruessen(name, nachricht="Willkommen"):
    print(f"{nachricht}, {name}!")

begruessen("Kaan")               # "Willkommen, Kaan!"
begruessen("Kaan", "Hallo")      # "Hallo, Kaan!"
```

## `*args` und `**kwargs`

```python
# ✅ Dieser Code funktioniert — akzeptiert beliebig viele Argumente
def summe(*zahlen):
    return sum(zahlen)

print(summe(1, 2, 3, 4))   # 10
```

```python
# ✅ Dieser Code funktioniert — akzeptiert beliebig viele benannte Argumente
def info_ausgeben(**info):
    for schluessel, wert in info.items():
        print(f"{schluessel}: {wert}")

info_ausgeben(name="Kaan", beruf="Entwickler")
```

## Variablenbereich (Scope)

```python
# ❌ Dieses Verhalten ist UNERWARTET — das 'x' innerhalb der Funktion
# beeinflusst nicht das äußere 'x':
x = 10

def aendern():
    x = 20   # dies erstellt ein NEUES lokales x

aendern()
print(x)   # immer noch 10, nicht 20
```

```python
# ✅ Dieser Code funktioniert — 'global' ändert das äußere x
x = 10

def aendern():
    global x
    x = 20

aendern()
print(x)   # 20
```

### 🎯 Mini-Übung
Schreibe eine Funktion `groesstes(liste)`, die die größte Zahl in
einer Liste findet, ohne `max()` zu verwenden, mit einer `for`-Schleife.

---
⬅️ [Schleifen](./05-Schleifen.md) &nbsp;|&nbsp; ➡️ [Datenstrukturen](./07-Datenstrukturen.md)
