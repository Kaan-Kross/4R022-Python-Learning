# 1. Installation und erste Schritte

## Python installieren

1. Lade die passende Version von
   [python.org/downloads](https://python.org/downloads) herunter
   (unter Windows unbedingt **„Add Python to PATH"** ankreuzen).
2. Überprüfe die Installation im Terminal:

```bash
python --version
```

3. Installiere einen Code-Editor: **VS Code** (empfohlen), PyCharm
   oder das eingebaute IDLE.

## Dein erstes Programm

```python
# ✅ Dieser Code funktioniert — speichere als "hallo.py" und führe ihn aus
print("Hallo, 4R022 Python Learning!")
```

```bash
python hallo.py
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — "print" ist falsch geschrieben
prnt("Hallo")
```

Das wirft `NameError: name 'prnt' is not defined`. Python meldet so
jeden unbekannten Namen — Fehlermeldungen zu lesen ist viel
nützlicher, als sie zu fürchten.

## Die interaktive Shell

Nur `python` im Terminal einzugeben öffnet eine interaktive Shell
(du siehst eine `>>>`-Eingabeaufforderung), in der du Code Zeile für
Zeile ausführen kannst — ideal für schnelle Experimente.

```python
>>> 2 + 2
4
>>> print("test")
test
```

## Kommentare

```python
# Dies ist ein einzeiliger Kommentar, Python ignoriert ihn
print("Diese Zeile läuft")  # Kommentare können auch nach Code stehen

"""
Dies ist ein mehrzeiliger Kommentar
(auch als Docstring verwendet).
"""
```

### 🎯 Mini-Übung
Schreibe ein zweizeiliges Programm, das deinen Namen ausgibt und
dann „Ich lerne Python!" in der nächsten Zeile ausgibt.

---
⬅️ [Zurück](./README.md) &nbsp;|&nbsp; ➡️ [Variablen und Datentypen](./02-Variablen-und-Datentypen.md)
