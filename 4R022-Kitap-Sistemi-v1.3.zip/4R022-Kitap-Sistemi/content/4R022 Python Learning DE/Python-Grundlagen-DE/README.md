# Python Grundlagen (DE) — Grundstufe

Diese Stufe bringt jemanden, der noch nie programmiert hat, dazu,
kleine, echte Python-Programme zu schreiben.

## Kapitel (in dieser Reihenfolge)

1. [Installation und erste Schritte](./01-Installation-und-erste-Schritte.md)
2. [Variablen und Datentypen](./02-Variablen-und-Datentypen.md)
3. [Operatoren](./03-Operatoren.md)
4. [Bedingte Anweisungen (if / elif / else)](./04-Bedingte-Anweisungen.md)
5. [Schleifen (for / while)](./05-Schleifen.md)
6. [Funktionen](./06-Funktionen.md)
7. [Datenstrukturen: Liste, Tupel, Dictionary, Set](./07-Datenstrukturen.md)
8. [Dateiverarbeitung und Fehlerbehandlung](./08-Dateiverarbeitung-und-Fehlerbehandlung.md)
9. [Einführung in OOP](./09-Einfuehrung-in-OOP.md)

Weiter ➡️ [Mittelstufe](../Python-Mittelstufe-DE/README.md)
