# 8. Dateiverarbeitung und Fehlerbehandlung

## Dateien lesen / schreiben

```python
# ✅ Dieser Code funktioniert — schreibt in eine Datei (erstellt sie, falls sie fehlt)
with open("notizen.txt", "w", encoding="utf-8") as f:
    f.write("Hallo 4R022!\n")
    f.write("Ich lerne Python.\n")

# ✅ Dieser Code funktioniert — liest die Datei
with open("notizen.txt", "r", encoding="utf-8") as f:
    inhalt = f.read()
    print(inhalt)
```

Die Verwendung von `with` garantiert, dass die Datei am Ende des
Blocks **automatisch geschlossen** wird — kein Risiko, `f.close()`
zu vergessen.

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Versuch, eine nicht existierende Datei zu lesen
with open("nicht_vorhanden.txt", "r") as f:
    print(f.read())
```

Das wirft `FileNotFoundError: [Errno 2] No such file or directory`.

## Fehlerbehandlung: `try / except`

Solche Fehler lassen das Programm abstürzen. Wir „fangen" sie stattdessen ab:

```python
# ✅ Dieser Code funktioniert — Fehler abgefangen, Programm läuft weiter
try:
    with open("nicht_vorhanden.txt", "r") as f:
        print(f.read())
except FileNotFoundError:
    print("Datei nicht gefunden, erstelle eine neue...")
```

```python
# ✅ Dieser Code funktioniert — mehrere Fehlertypen können abgefangen werden
try:
    zahl = int(input("Gib eine Zahl ein: "))
    print(10 / zahl)
except ValueError:
    print("Das war keine gültige Zahl.")
except ZeroDivisionError:
    print("Man kann nicht durch Null teilen.")
```

```python
# ❌ Dieser Code hat einen LOGIKFEHLER — der 'except'-Block fängt den
# FALSCHEN Typ ab, daher stürzt das Programm trotzdem ab:
try:
    zahl = int("abc")
except ZeroDivisionError:   # falscher Fehlertyp abgefangen
    print("Fehler abgefangen")
# Der tatsächliche Fehler ist ValueError, NICHT ZeroDivisionError,
# daher fängt Python ihn nicht ab und das Programm stürzt ab.
```

## `finally` und `else`

```python
# ✅ Dieser Code funktioniert — 'finally' läuft immer (Fehler oder nicht)
try:
    x = 10 / 2
except ZeroDivisionError:
    print("Ein Fehler ist aufgetreten")
else:
    print("Kein Fehler, Ergebnis:", x)
finally:
    print("Fertig.")
```

## Eigenen Fehler auslösen: `raise`

```python
# ✅ Dieser Code funktioniert
def alter_pruefen(alter):
    if alter < 0:
        raise ValueError("Alter kann nicht negativ sein!")
    return alter

try:
    alter_pruefen(-5)
except ValueError as e:
    print("Fehler abgefangen:", e)
```

### 🎯 Mini-Übung
Frage den Benutzer nach einem Dateinamen und einem zu schreibenden
Text; behandle mögliche Fehler (einschließlich `PermissionError`)
mit `try/except`.

---
⬅️ [Datenstrukturen](./07-Datenstrukturen.md) &nbsp;|&nbsp; ➡️ [Einführung in OOP](./09-Einfuehrung-in-OOP.md)
