# 7. Datenstrukturen: Liste, Tupel, Dictionary, Set

## Liste (`list`) — geordnet, veränderbar

```python
# ✅ Dieser Code funktioniert
fruechte = ["Apfel", "Birne", "Banane"]
fruechte.append("Erdbeere")    # fügt am Ende hinzu
fruechte[0] = "Aprikose"       # ändert das erste Element
print(fruechte)                # ['Aprikose', 'Birne', 'Banane', 'Erdbeere']
print(fruechte[1])             # 'Birne'
print(fruechte[-1])            # letztes Element: 'Erdbeere'
print(fruechte[0:2])           # Slicing: die ersten zwei Elemente
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Zugriff außerhalb der Listengrenzen
fruechte = ["Apfel", "Birne"]
print(fruechte[5])
```

Das wirft `IndexError: list index out of range`. Eine Liste mit 2
Elementen hat nur die gültigen Indizes `0` und `1`.

## Tupel (`tuple`) — geordnet, UNVERÄNDERLICH

```python
# ✅ Dieser Code funktioniert
koordinate = (10, 20)
print(koordinate[0])   # 10
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Tupel können nach der Erstellung nicht geändert werden
koordinate = (10, 20)
koordinate[0] = 99
```

Das wirft `TypeError: 'tuple' object does not support item
assignment`. Tupel sind ideal, wenn man eine Garantie „das ändert
sich nicht" braucht (z. B. eine feste Koordinate, ein RGB-Farbwert).

## Dictionary (`dict`) — Schlüssel-Wert-Paare

```python
# ✅ Dieser Code funktioniert
student = {"name": "Kaan", "alter": 25, "fach": "Informatik"}
print(student["name"])       # 'Kaan'
student["alter"] = 26        # Wert aktualisieren
student["stadt"] = "Sakarya" # neuen Schlüssel hinzufügen

for schluessel, wert in student.items():
    print(schluessel, "->", wert)
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Zugriff auf einen nicht existierenden Schlüssel
student = {"name": "Kaan"}
print(student["nachname"])
```

Das wirft `KeyError: 'nachname'`. Sicherer Zugriff über `.get()`:

```python
# ✅ Dieser Code funktioniert — kein Fehler, wenn der Schlüssel fehlt, gibt None zurück
print(student.get("nachname"))          # None
print(student.get("nachname", "N/A"))   # "N/A" (Standardwert)
```

## Set (`set`) — ungeordnet, keine Duplikate

```python
# ✅ Dieser Code funktioniert — Sets entfernen Duplikate automatisch
zahlen = {1, 2, 2, 3, 3, 3}
print(zahlen)   # {1, 2, 3}

a = {1, 2, 3}
b = {2, 3, 4}
print(a & b)   # Schnittmenge: {2, 3}
print(a | b)   # Vereinigung: {1, 2, 3, 4}
print(a - b)   # Differenz: {1}
```

## Vergleichstabelle

| Struktur | Geordnet? | Veränderbar? | Duplikate? | Syntax |
|---|---|---|---|---|
| `list` | ✅ | ✅ | ✅ | `[1, 2, 3]` |
| `tuple` | ✅ | ❌ | ✅ | `(1, 2, 3)` |
| `dict` | ✅ (3.7+) | ✅ | Schlüssel eindeutig | `{"a": 1}` |
| `set` | ❌ | ✅ | ❌ | `{1, 2, 3}` |

### 🎯 Mini-Übung
Erstelle eine `list` mit Studentennamen, dann ein `dict`, das jeden
Namen einer Note zuordnet (`{"name": note}`), und berechne den
Durchschnitt.

---
⬅️ [Funktionen](./06-Funktionen.md) &nbsp;|&nbsp; ➡️ [Dateiverarbeitung und Fehlerbehandlung](./08-Dateiverarbeitung-und-Fehlerbehandlung.md)
