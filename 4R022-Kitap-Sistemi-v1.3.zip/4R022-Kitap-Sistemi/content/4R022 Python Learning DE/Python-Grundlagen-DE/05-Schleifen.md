# 5. Schleifen (for / while)

## `for`-Schleife

```python
# ✅ Dieser Code funktioniert — zählt von 0 bis 4 (5 ausgeschlossen)
for i in range(5):
    print(i)
```

```python
# ✅ Dieser Code funktioniert — durchläuft eine Liste
fruechte = ["Apfel", "Birne", "Banane"]
for frucht in fruechte:
    print(frucht)
```

```python
# ❌ Dieser Code tut nicht das Erwartete — range() SCHLIESST die
# letzte Zahl AUS, ein häufiges Missverständnis (kein Syntaxfehler,
# sondern ein Logikfehler — läuft, liefert aber ein unerwartetes Ergebnis):
for i in range(1, 5):
    print(i)   # gibt 1,2,3,4 aus — 5 ist NICHT enthalten
```

## `while`-Schleife

```python
# ✅ Dieser Code funktioniert
zaehler = 0
while zaehler < 5:
    print(zaehler)
    zaehler += 1
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT (Endlosschleife!)
zaehler = 0
while zaehler < 5:
    print(zaehler)
    # zaehler += 1 wurde vergessen, die Bedingung bleibt für immer True
```

> ⚠️ Wenn du in eine Endlosschleife gerätst, stoppe sie im Terminal
> mit **Strg + C**.

## `break` und `continue`

```python
# ✅ Dieser Code funktioniert — stoppt die Schleife bei 3 vollständig
for i in range(10):
    if i == 3:
        break
    print(i)   # gibt 0, 1, 2 aus
```

```python
# ✅ Dieser Code funktioniert — überspringt nur 3, Schleife läuft weiter
for i in range(5):
    if i == 3:
        continue
    print(i)   # gibt 0, 1, 2, 4 aus (3 wird übersprungen)
```

## Verschachtelte Schleifen

```python
# ✅ Dieser Code funktioniert — ein 3x3-Raster wie eine Einmaleins-Tabelle
for i in range(1, 4):
    for j in range(1, 4):
        print(i * j, end=" ")
    print()  # neue Zeile nach jeder äußeren Iteration
```

### 🎯 Mini-Übung
Summiere alle Zahlen zwischen 1 und 100, die durch 3 oder 5 teilbar
sind, mit einer `for`-Schleife.

---
⬅️ [Bedingte Anweisungen](./04-Bedingte-Anweisungen.md) &nbsp;|&nbsp; ➡️ [Funktionen](./06-Funktionen.md)
