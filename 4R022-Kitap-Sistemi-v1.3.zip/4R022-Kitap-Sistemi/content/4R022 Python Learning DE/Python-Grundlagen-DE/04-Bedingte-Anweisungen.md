# 4. Bedingte Anweisungen (if / elif / else)

## Grundstruktur

```python
# ✅ Dieser Code funktioniert
alter = 20

if alter >= 18:
    print("Du bist volljährig.")
else:
    print("Du bist minderjährig.")
```

## Mehrere Bedingungen: `elif`

```python
# ✅ Dieser Code funktioniert
note = 75

if note >= 85:
    print("Sehr gut")
elif note >= 70:
    print("Gut")
elif note >= 50:
    print("Ausreichend")
else:
    print("Nicht ausreichend")
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — "else if" statt "elif"
# (das ist C/Java/JavaScript-Syntax, in Python ungültig)
if note >= 85:
    print("Sehr gut")
else if note >= 70:
    print("Gut")
```

Python hat kein Schlüsselwort `else if`; richtig ist das einzelne
Wort `elif`.

## Verschachtelte Bedingungen

```python
# ✅ Dieser Code funktioniert
alter = 20
hat_fuehrerschein = True

if alter >= 18:
    if hat_fuehrerschein:
        print("Du darfst Auto fahren.")
    else:
        print("Du brauchst einen Führerschein.")
else:
    print("Du darfst noch nicht Auto fahren.")
```

## Ternärer Ausdruck (einzeilig)

```python
# ✅ Dieser Code funktioniert
alter = 16
status = "volljährig" if alter >= 18 else "minderjährig"
print(status)
```

## Truthy / Falsy Werte

Python betrachtet viele Werte automatisch als „wahr" oder „falsch"
in einer Bedingung, nicht nur `True`/`False`:

```python
# ✅ Dieser Code funktioniert
if "":        # leerer String -> Falsy
    print("wird nicht angezeigt")
if "hallo":   # nicht leerer String -> Truthy
    print("wird angezeigt")
if 0:         # Null -> Falsy
    print("wird nicht angezeigt")
if []:        # leere Liste -> Falsy
    print("wird nicht angezeigt")
```

### 🎯 Mini-Übung
Frage den Benutzer nach einer Note (0-100); gib „Sehr gut" für 85+,
„Gut" für 70-84, „Ausreichend" für 50-69, sonst „Nicht ausreichend" aus.

---
⬅️ [Operatoren](./03-Operatoren.md) &nbsp;|&nbsp; ➡️ [Schleifen](./05-Schleifen.md)
