# 3. Operatoren

## Arithmetische Operatoren

```python
# ✅ Dieser Code funktioniert
print(5 + 3)   # 8   Addition
print(5 - 3)   # 2   Subtraktion
print(5 * 3)   # 15  Multiplikation
print(5 / 3)   # 1.666... Division (liefert immer einen Float)
print(5 // 3)  # 1   Ganzzahldivision
print(5 % 3)   # 2   Modulo (Rest)
print(5 ** 3)  # 125 Potenz
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Division durch Null ist nicht definiert
print(5 / 0)
```

Das wirft `ZeroDivisionError: division by zero`. Python rät nicht,
sondern stoppt das Programm — im Kapitel zur Fehlerbehandlung lernen
wir, das abzufangen.

## Vergleichsoperatoren

```python
# ✅ Dieser Code funktioniert — alle liefern True/False
print(5 == 5)   # True
print(5 != 3)   # True
print(5 > 3)    # True
print(5 < 3)    # False
print(5 >= 5)   # True
print(5 <= 4)   # False
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Zuweisung (=) mit Vergleich (==) verwechselt
if x = 5:
    print("fünf")
```

Das wirft einen `SyntaxError`. Ein einzelnes `=` **weist zu**, ein
doppeltes `==` **vergleicht** — ein klassischer Anfängerfehler.

## Logische Operatoren

```python
# ✅ Dieser Code funktioniert
alter = 20
ist_student = True

print(alter >= 18 and ist_student)   # True — beides muss wahr sein
print(alter >= 18 or ist_student)    # True — eines reicht
print(not ist_student)               # False — kehrt den Wert um
```

## Zusammengesetzte Zuweisungsoperatoren

```python
# ✅ Dieser Code funktioniert
zaehler = 0
zaehler += 1   # zaehler = zaehler + 1 -> 1
zaehler -= 1   # -> 0
zaehler *= 5   # -> 0
zaehler += 10  # -> 10
print(zaehler)
```

### 🎯 Mini-Übung
Schreibe einen Ausdruck mit `%` und `and`, der prüft, ob eine Zahl
sowohl durch 2 als auch durch 3 teilbar ist.

---
⬅️ [Variablen und Datentypen](./02-Variablen-und-Datentypen.md) &nbsp;|&nbsp; ➡️ [Bedingte Anweisungen](./04-Bedingte-Anweisungen.md)
