# 2. Variablen und Datentypen

## Was ist eine Variable?

Eine Variable speichert einen Wert im Speicher unter einem
wiederverwendbaren Namen.

```python
# ✅ Dieser Code funktioniert
alter = 25
name = "Kaan"
groesse = 1.80
ist_student = True

print(name, alter, groesse, ist_student)
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — ein Variablenname darf nicht
# mit einer Ziffer beginnen
1alter = 25
```

Das wirft `SyntaxError: invalid decimal literal`. Namen müssen mit
einem Buchstaben oder Unterstrich (`_`) beginnen, niemals mit einer Ziffer.

## Grundlegende Datentypen

| Typ | Beispiel | Bedeutung |
|---|---|---|
| `int` | `5`, `-12` | Ganzzahl |
| `float` | `3.14`, `-0.5` | Dezimalzahl |
| `str` | `"hallo"` | Text (String) |
| `bool` | `True`, `False` | Wahrheitswert |
| `NoneType` | `None` | „Kein Wert" |

```python
# ✅ Dieser Code funktioniert
print(type(5))        # <class 'int'>
print(type(5.0))      # <class 'float'>
print(type("5"))      # <class 'str'>
print(type(True))     # <class 'bool'>
```

## Typumwandlung

```python
# ✅ Dieser Code funktioniert
text_zahl = "42"
echte_zahl = int(text_zahl)     # str -> int
print(echte_zahl + 8)           # 50
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — "zweiundvierzig" kann nicht zu einer Zahl werden
zahl = int("zweiundvierzig")
```

Das wirft `ValueError: invalid literal for int()`. `int()` kann nur
Strings umwandeln, die ausschließlich aus Ziffern bestehen.

## Eingabe abrufen: `input()`

```python
# ✅ Dieser Code funktioniert
name = input("Wie heißt du? ")
print("Hallo " + name + "!")
```

> ⚠️ **Achtung:** `input()` liefert immer einen **String**. Für
> numerische Operationen musst du mit `int()` oder `float()` umwandeln:

```python
# ✅ Dieser Code funktioniert
alter = int(input("Wie alt bist du? "))
print("In 5 Jahren wirst du", alter + 5, "sein")
```

### 🎯 Mini-Übung
Frage den Benutzer nach zwei Zahlen mit `input()`, wandle sie mit
`int()` um, addiere sie und gib das Ergebnis aus.

---
⬅️ [Installation](./01-Installation-und-erste-Schritte.md) &nbsp;|&nbsp; ➡️ [Operatoren](./03-Operatoren.md)
