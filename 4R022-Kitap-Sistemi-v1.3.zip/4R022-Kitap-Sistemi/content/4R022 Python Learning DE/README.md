<img src="./assets/4r022-logo.png" alt="4R022 Python Learning Logo" width="220"/>

# 4R022 Python Learning (DE)

Marke: **4R022** | Autor: **Kaan Kross**

Dies ist das deutsche Paket des Projekts **4R022 Python Learning** —
ein umfassender, originaler, mehrstufiger Python-Lehrgang.

## 📌 Projektstatus

| Abschnitt | Status |
|---|---|
| Überblick | ✅ Abgeschlossen |
| Grundstufe | ✅ Abgeschlossen |
| Mittelstufe | ✅ Abgeschlossen |
| Fortgeschrittene Stufe (+ GUI/UX) | ✅ Abgeschlossen |
| Datenkonzepte | ✅ Abgeschlossen |
| Module (36 Module) | ✅ Abgeschlossen |
| Ethik und Sicherheit | ✅ Abgeschlossen |

Die deutsche Ausgabe ist jetzt vollständig — im gleichen Umfang und
in der gleichen Tiefe wie die türkische, englische, russische und
französische Ausgabe.

## Paketinhalt
- `Python-Ueberblick-DE/`
- `Python-Grundlagen-DE/`
- `Python-Mittelstufe-DE/`
- `Python-Fortgeschrittene-Stufe-DE/`
- `Python-Datenkonzepte-DE/`
- `Python-Module-DE/`
- `Python-Ethik-und-Sicherheit-DE/`

## Lizenz
Siehe [`LICENSE.txt`](./LICENSE.txt) — freie Nutzung zu
Bildungszwecken; kommerzieller Weiterverkauf ohne Nennung der Marke
"4R022" ist nicht gestattet.
