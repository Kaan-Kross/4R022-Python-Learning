# 3. Datenformate: JSON und CSV

## JSON — strukturierter Datenaustausch

JSON (JavaScript Object Notation) ist das gebräuchlichste Datenformat
für Web-APIs und Konfigurationsdateien; es entspricht eng einem
Python-`dict`.

```python
# ✅ Dieser Code funktioniert — schreibt ein Python-dict in eine JSON-Datei
import json

einstellungen = {"thema": "dunkel", "sprache": "de", "version": 2}

with open("einstellungen.json", "w", encoding="utf-8") as f:
    json.dump(einstellungen, f, ensure_ascii=False, indent=4)
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Parsen eines ungültigen "JSON"-Strings
# (einfache Anführungszeichen sind in JSON ungültig!)
import json
daten = json.loads("{'thema': 'dunkel'}")
```

Das wirft `json.decoder.JSONDecodeError`. Der JSON-Standard verlangt
**doppelte Anführungszeichen**.

## CSV — Tabellendaten

```python
# ✅ Dieser Code funktioniert — Schreiben in CSV
import csv
with open("noten.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "note"])
    writer.writerow(["Kaan", 95])
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT (unter Windows) — 'newline=""'
# vergessen führt zu zusätzlichen Leerzeilen in der CSV-Datei:
with open("noten.csv", "w", encoding="utf-8") as f:   # newline="" fehlt!
    writer = csv.writer(f)
    writer.writerows([["name", "note"], ["Kaan", 95]])
```

### 🎯 Mini-Übung
Schreibe ein Programm, das eine Liste von Studenten (`name`, `note`)
sowohl als JSON als auch als CSV speichert, sie dann zurückliest und
den Durchschnitt berechnet.

---
⬅️ [Dekoratoren und Generatoren](./02-Dekoratoren-und-Generatoren.md) &nbsp;|&nbsp; ➡️ [Module, Pakete, virtuelle Umgebungen](./04-Module-Pakete-virtuelle-Umgebungen.md)
