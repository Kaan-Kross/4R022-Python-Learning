# 4. Module, Pakete und virtuelle Umgebungen

## Was ist ein Modul?

Jede `.py`-Datei ist ein **Modul**. Code auf mehrere Dateien
aufzuteilen hält ein Projekt organisiert und wiederverwendbar.

```python
# ✅ Dieser Code funktioniert — Datei mathe.py
def addieren(a, b):
    return a + b
```

```python
# ✅ Dieser Code funktioniert — Import in main.py
import mathe
print(mathe.addieren(3, 4))     # 7
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Tippfehler im Dateinamen
import mathee
```

Das wirft `ModuleNotFoundError: No module named 'mathee'`.

## Was ist ein Paket?

Ein **Paket** ist ein Ordner mit einer `__init__.py`-Datei, der
mehrere Module zusammenfasst.

```
projekt/
├── main.py
└── hilfsmittel/
    ├── __init__.py
    ├── mathe.py
    └── text.py
```

Diese Struktur liegt der `core/` + `ui/`-Architektur in 4R022s
PyQt6-Projekten zugrunde.

## Pakete mit pip verwalten

```bash
# ✅ Diese Befehle funktionieren
pip install requests
pip freeze > requirements.txt
pip install -r requirements.txt
```

## Warum virtuelle Umgebungen?

Eine virtuelle Umgebung gibt jedem Projekt seinen eigenen isolierten
Satz installierter Pakete — damit `flask==2.0` in einem Projekt nicht
mit `flask==3.0` in einem anderen kollidiert.

```bash
# ✅ Diese Befehle funktionieren (im Projektordner)
python -m venv venv

# Aktivierung unter Windows:
venv\Scripts\activate

# Aktivierung unter macOS / Linux:
source venv/bin/activate
```

```bash
# ❌ Dies FUNKTIONIERT NICHT — falscher Aktivierungsbefehl für das Betriebssystem
source venv/bin/activate    # Linux/macOS-Befehl, in Windows cmd nicht erkannt
```

Unter Windows `cmd` lautet der richtige Befehl `venv\Scripts\activate`.

### 🎯 Mini-Übung
Erstelle ein Modul `formen.py` (mit Funktionen zur Berechnung der
Fläche eines Kreises und eines Quadrats), importiere und verwende es
dann aus `main.py`.

---
⬅️ [JSON und CSV](./03-JSON-und-CSV.md) &nbsp;|&nbsp; ➡️ [Testen und Debuggen](./05-Testen-und-Debuggen.md)
