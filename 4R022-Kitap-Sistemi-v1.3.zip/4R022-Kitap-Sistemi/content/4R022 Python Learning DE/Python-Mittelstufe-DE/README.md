# Python Mittelstufe (DE)

Nach der Grundstufe geht es näher an echte Projekte: fortgeschrittenes
OOP, Dekoratoren/Generatoren, Datenformate, Paketverwaltung und Testen.

## Kapitel

1. [Fortgeschrittenes OOP](./01-Fortgeschrittenes-OOP.md)
2. [Dekoratoren und Generatoren](./02-Dekoratoren-und-Generatoren.md)
3. [Datenformate: JSON und CSV](./03-JSON-und-CSV.md)
4. [Module, Pakete und virtuelle Umgebungen](./04-Module-Pakete-virtuelle-Umgebungen.md)
5. [Testen und Debuggen](./05-Testen-und-Debuggen.md)

Weiter ➡️ [Fortgeschrittene Stufe](../Python-Fortgeschrittene-Stufe-DE/README.md)
