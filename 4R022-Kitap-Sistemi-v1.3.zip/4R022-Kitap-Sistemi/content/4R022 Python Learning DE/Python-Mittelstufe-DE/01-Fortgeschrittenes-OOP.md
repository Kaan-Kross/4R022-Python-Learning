# 1. Fortgeschrittenes objektorientiertes Programmieren

## `@property` für kontrollierten Zugriff

```python
# ✅ Dieser Code funktioniert
class Rechteck:
    def __init__(self, breite, hoehe):
        self._breite = breite
        self._hoehe = hoehe

    @property
    def flaeche(self):
        return self._breite * self._hoehe

r = Rechteck(4, 5)
print(r.flaeche)   # 20 — als Methode definiert, aber wie ein Attribut aufgerufen (ohne Klammern!)
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — eine property kann nicht mit Klammern aufgerufen werden
print(r.flaeche())
```

Das wirft `TypeError: 'int' object is not callable`, weil `r.flaeche`
bereits ein berechneter Wert ist, keine Funktion.

## Spezielle Methoden (Dunder-Methoden)

```python
# ✅ Dieser Code funktioniert — __str__ und __eq__ passen das Verhalten an
class Punkt:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __str__(self):
        return f"Punkt({self.x}, {self.y})"

    def __eq__(self, andere):
        return self.x == andere.x and self.y == andere.y

p1 = Punkt(1, 2)
p2 = Punkt(1, 2)
print(p1)          # Punkt(1, 2) — dank __str__
print(p1 == p2)    # True — dank __eq__
```

## Mehrfachvererbung und `super()`

```python
# ✅ Dieser Code funktioniert
class Mitarbeiter:
    def __init__(self, name, gehalt):
        self.name = name
        self.gehalt = gehalt

class Entwickler(Mitarbeiter):
    def __init__(self, name, gehalt, sprache):
        super().__init__(name, gehalt)
        self.sprache = sprache

e = Entwickler("Kaan", 50000, "Python")
print(e.name, e.gehalt, e.sprache)
```

## Abstrakte Basisklassen

```python
# ✅ Dieser Code funktioniert
from abc import ABC, abstractmethod

class Form(ABC):
    @abstractmethod
    def flaeche(self):
        pass

class Quadrat(Form):
    def __init__(self, seite):
        self.seite = seite

    def flaeche(self):
        return self.seite ** 2

print(Quadrat(4).flaeche())   # 16
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — eine abstrakte Klasse kann nicht direkt instanziiert werden
form = Form()
```

Das wirft `TypeError: Can't instantiate abstract class Form with
abstract method flaeche`. Genau das ist der Sinn von `ABC`: es zwingt
Unterklassen, bestimmte Methoden zu implementieren.

---
⬅️ [Zurück](./README.md) &nbsp;|&nbsp; ➡️ [Dekoratoren und Generatoren](./02-Dekoratoren-und-Generatoren.md)
