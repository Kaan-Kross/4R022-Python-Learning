# 5. Testen und Debuggen

## Warum Tests schreiben?

Mit wachsendem Code wird es unmöglich, manuell zu prüfen, ob eine
Änderung etwas kaputt gemacht hat. Tests automatisieren das.

## `unittest` (Standardbibliothek)

```python
# ✅ Dieser Code funktioniert — rechner.py
def addieren(a, b):
    return a + b

def teilen(a, b):
    if b == 0:
        raise ValueError("Kann nicht durch Null teilen")
    return a / b
```

```python
# ✅ Dieser Code funktioniert — test_rechner.py
import unittest
from rechner import addieren, teilen

class TestRechner(unittest.TestCase):
    def test_addieren(self):
        self.assertEqual(addieren(2, 3), 5)

    def test_teilen_durch_null(self):
        with self.assertRaises(ValueError):
            teilen(10, 0)

if __name__ == "__main__":
    unittest.main()
```

## `pytest` (beliebte Drittanbieter-Bibliothek)

```bash
pip install pytest
```

```python
# ✅ Dieser Code funktioniert
from rechner import addieren

def test_addieren():
    assert addieren(2, 3) == 5
```

## Debugging-Tipps

```python
# ✅ Dieser Code funktioniert — print() zum Nachverfolgen von "was wo"
def berechnen(daten):
    print("DEBUG: eingehende Daten ->", daten)
    return sum(daten) / len(daten)
```

```python
# ✅ Dieser Code funktioniert — Pythons eingebauter Debugger
def berechnen(daten):
    breakpoint()   # die Ausführung pausiert hier zur Variableninspektion
    return sum(daten) / len(daten)
```

### 🎯 Mini-Übung
Füge `rechner.py` eine Funktion `subtrahieren(a, b)` hinzu und
schreibe dafür Tests mit `unittest` und mit `pytest`.

---
⬅️ [Module, Pakete, virtuelle Umgebungen](./04-Module-Pakete-virtuelle-Umgebungen.md) &nbsp;|&nbsp; ➡️ [Weiter zur fortgeschrittenen Stufe](../Python-Fortgeschrittene-Stufe-DE/README.md)

🎉 **Glückwunsch — du hast die Mittelstufe abgeschlossen!**
