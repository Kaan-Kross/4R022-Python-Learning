# 2. Dekoratoren und Generatoren

## Was ist ein Dekorator?

Ein Dekorator ist eine Funktion, die eine andere Funktion „umhüllt"
und deren Verhalten erweitert oder verändert.

```python
# ✅ Dieser Code funktioniert
import time

def zeit_messen(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        ergebnis = func(*args, **kwargs)
        ende = time.time()
        print(f"{func.__name__} dauerte {ende - start:.4f} Sekunden")
        return ergebnis
    return wrapper

@zeit_messen
def lange_aufgabe():
    time.sleep(1)
    return "fertig"

lange_aufgabe()
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — die innere Funktion gibt keinen
# Wert zurück, daher geht das eigentliche Ergebnis verloren:
def logger(func):
    def wrapper(*args, **kwargs):
        func(*args, **kwargs)   # 'return' wurde vergessen!
    return wrapper

@logger
def multiplizieren(a, b):
    return a * b

ergebnis = multiplizieren(3, 4)
print(ergebnis)   # gibt None aus, NICHT 12
```

## Was ist ein Generator (`yield`)?

Eine normale Funktion endet mit `return` und legt das gesamte
Ergebnis sofort im Speicher ab. Ein **Generator** erzeugt Werte
**einzeln, auf Anfrage**, mit `yield` — das spart Speicher bei
großen Datenmengen.

```python
# ✅ Dieser Code funktioniert
def quadrate_erzeugen(n):
    for i in range(n):
        yield i * i

for quadrat in quadrate_erzeugen(5):
    print(quadrat)   # 0, 1, 4, 9, 16 — einzeln erzeugt
```

```python
# ✅ Dieser Code funktioniert — Generatorausdruck, runde statt eckige Klammern
quadrate = (x * x for x in range(1_000_000))
print(next(quadrate))   # 0 — nur der angeforderte Wert wird berechnet
```

```python
# ❌ Dieser Code lädt SOFORT Millionen Elemente in den Speicher —
# viel speicherhungriger als der Generator oben:
quadrate_liste = [x * x for x in range(10_000_000)]
```

### 🎯 Mini-Übung
Schreibe eine Generatorfunktion `fibonacci(n)`, die die ersten `n`
Fibonacci-Zahlen einzeln mit `yield` erzeugt.

---
⬅️ [Fortgeschrittenes OOP](./01-Fortgeschrittenes-OOP.md) &nbsp;|&nbsp; ➡️ [JSON und CSV](./03-JSON-und-CSV.md)
