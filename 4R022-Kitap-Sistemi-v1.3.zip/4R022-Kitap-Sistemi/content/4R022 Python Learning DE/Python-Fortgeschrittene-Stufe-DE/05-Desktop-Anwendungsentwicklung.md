# 5. Professionelle Desktop-Anwendungsentwicklung (PyQt6)

## Warum PyQt6 statt Tkinter?

`tkinter` gehört zur Standardbibliothek und ist schnell für kleine
Tools. `PyQt6` bietet ein moderneres Aussehen, eine Signal/Slot-
Architektur und eine solidere Grundlage für große Anwendungen —
deshalb werden die meisten 4R022-Desktop-Produkte damit gebaut.

## Eine minimale PyQt6-Anwendung

```python
# ✅ Dieser Code funktioniert (wenn PyQt6 installiert ist)
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout

class Hauptfenster(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4R022 Beispiel")
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Hallo, 4R022 Python Learning!"))
        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    fenster = Hauptfenster()
    fenster.show()
    sys.exit(app.exec())
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Fenster vor QApplication anzeigen
fenster = Hauptfenster()
fenster.show()
# RuntimeError: Please create QApplication before QWidget
```

## Empfohlene Architektur: `core/` + `ui/`

```
projekt/
├── main.py
├── core/     # Geschäftslogik, unabhängig von der Oberfläche
└── ui/       # nur Anzeige und Interaktion
```

## Verpacken mit PyInstaller

```bash
pip install pyinstaller
pyinstaller --onefile --windowed main.py
```

### 🎯 Mini-Übung
Schreibe eine kleine PyQt6-Anwendung mit einem Textfeld
(`QLineEdit`) und einem Button, der den eingegebenen Text in einem
`QLabel` anzeigt.

---
⬅️ [Entwurfsmuster](./04-Entwurfsmuster.md) &nbsp;|&nbsp; ➡️ [GUI, UI/UX und plattformübergreifend](./06-GUI-UI-UX-und-Plattformuebergreifend.md)
