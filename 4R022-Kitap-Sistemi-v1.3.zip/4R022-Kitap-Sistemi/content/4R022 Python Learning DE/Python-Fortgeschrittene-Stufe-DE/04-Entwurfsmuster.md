# 4. Entwurfsmuster

## 1. Singleton — „nur ein Objekt"

```python
# ✅ Dieser Code funktioniert
class Einstellungen:
    _instanz = None

    def __new__(cls):
        if cls._instanz is None:
            cls._instanz = super().__new__(cls)
            cls._instanz.thema = "dunkel"
        return cls._instanz

e1 = Einstellungen()
e2 = Einstellungen()
print(e1 is e2)   # True — dasselbe Objekt
```

## 2. Factory — „Objektproduzent"

```python
# ✅ Dieser Code funktioniert
class Hund:
    def laut(self): return "Wuff"

class Katze:
    def laut(self): return "Miau"

def tier_erstellen(art):
    if art == "hund":
        return Hund()
    elif art == "katze":
        return Katze()
    raise ValueError(f"Unbekannte Art: {art}")
```

## 3. Observer — „Beobachter"

```python
# ✅ Dieser Code funktioniert
class Herausgeber:
    def __init__(self):
        self._abonnenten = []

    def abonnent_hinzufuegen(self, funktion):
        self._abonnenten.append(funktion)

    def benachrichtigen(self, daten):
        for abonnent in self._abonnenten:
            abonnent(daten)
```

Das Signal/Slot-System von PyQt6 ist eine fertige Implementierung
dieses Musters.

### 🎯 Mini-Übung
Schreibe eine Singleton-Klasse `Logger`, die von überall in der
Anwendung in dieselbe Log-Datei schreibt.

---
⬅️ [Performance und Optimierung](./03-Performance-und-Optimierung.md) &nbsp;|&nbsp; ➡️ [Desktop-Anwendungsentwicklung](./05-Desktop-Anwendungsentwicklung.md)
