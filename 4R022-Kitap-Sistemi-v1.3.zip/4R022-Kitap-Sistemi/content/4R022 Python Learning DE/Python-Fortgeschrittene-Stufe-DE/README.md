# Python Fortgeschrittene Stufe (DE)

Diese Stufe richtet sich an alle, die echte, performante,
professionelle Software bauen wollen.

## Kapitel

1. [Nebenläufigkeit: Threading, Multiprocessing, Asyncio](./01-Nebenlaeufigkeit.md)
2. [Fortgeschrittenes OOP: Kontextmanager, `__slots__`, Metaklassen](./02-Fortgeschrittene-OOP-Konzepte.md)
3. [Performance und Optimierung](./03-Performance-und-Optimierung.md)
4. [Entwurfsmuster](./04-Entwurfsmuster.md)
5. [Professionelle Desktop-Anwendungsentwicklung (PyQt6)](./05-Desktop-Anwendungsentwicklung.md)
6. [GUI, UI/UX und plattformübergreifende Oberflächen](./06-GUI-UI-UX-und-Plattformuebergreifend.md)

Weiter ➡️ [Datenkonzepte](../Python-Datenkonzepte-DE/README.md)
