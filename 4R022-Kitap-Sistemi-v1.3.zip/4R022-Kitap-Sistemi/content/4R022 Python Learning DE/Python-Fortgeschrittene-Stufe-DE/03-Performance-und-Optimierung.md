# 3. Performance und Optimierung

## Nicht ohne Messen optimieren!

> 🧑‍🏫 **Goldene Regel:** „Erst messen, dann optimieren."

```python
import timeit
dauer = timeit.timeit("sum(range(1000))", number=10000)
```

## Caching mit `functools.lru_cache`

```python
# ❌ Dieser Code FUNKTIONIERT, ist aber SEHR LANGSAM
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
```

```python
# ✅ Dieser Code funktioniert — Ergebnisse werden zwischengespeichert
from functools import lru_cache

@lru_cache(maxsize=None)
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
```

## `join()` zum Verketten von Strings

```python
# ❌ Dieser Code FUNKTIONIERT, ist aber LANGSAM in großen Schleifen
ergebnis = ""
for wort in ["Python", "ist", "schnell"]:
    ergebnis += wort + " "
```

```python
# ✅ Dieser Code funktioniert — viel bessere Performance
ergebnis = " ".join(["Python", "ist", "schnell"])
```

### 🎯 Mini-Übung
Schreibe `fibonacci` sowohl mit `@lru_cache` als auch mit einer
klassischen `for`-Schleife, vergleiche die Geschwindigkeit mit `timeit`.

---
⬅️ [Fortgeschrittene OOP-Konzepte](./02-Fortgeschrittene-OOP-Konzepte.md) &nbsp;|&nbsp; ➡️ [Entwurfsmuster](./04-Entwurfsmuster.md)
