# 1. Nebenläufigkeit: Threading, Multiprocessing, Asyncio

## Warum ist das nötig?

Manche Aufgaben erfordern **Warten** (Netzwerkanfragen, Datei-E/A),
andere sind **rechenintensiv** (Bildverarbeitung, Mathematik). Diese
beiden Situationen erfordern unterschiedliche Werkzeuge.

## `threading` — für E/A-gebundene Arbeit

```python
# ✅ Dieser Code funktioniert
import threading, time

def herunterladen(dateinummer):
    print(f"Datei {dateinummer} wird heruntergeladen...")
    time.sleep(2)
    print(f"Datei {dateinummer} fertig.")

threads = [threading.Thread(target=herunterladen, args=(i,)) for i in range(3)]
for t in threads: t.start()
for t in threads: t.join()
```

## Der GIL (Global Interpreter Lock) — eine wichtige Einschränkung

```python
# ❌ Dies ist LANGSAMER ALS ERWARTET — wegen des GIL in CPython
# bietet threading keine echte Parallelität für CPU-intensive Arbeit:
import threading

def schwere_berechnung():
    total = 0
    for i in range(50_000_000):
        total += i

threads = [threading.Thread(target=schwere_berechnung) for _ in range(4)]
```

Für CPU-intensive Arbeit ist `multiprocessing` das richtige Werkzeug
— jeder Prozess hat seinen eigenen Python-Interpreter (und seinen
eigenen GIL).

```python
# ✅ Dieser Code funktioniert — echte Parallelität (mehrere CPU-Kerne)
import multiprocessing

def berechnen(grenze):
    return sum(range(grenze))

if __name__ == "__main__":
    with multiprocessing.Pool(4) as pool:
        ergebnisse = pool.map(berechnen, [10_000_000] * 4)
```

## `asyncio` — für viele Wartezeit-Aufgaben

```python
# ✅ Dieser Code funktioniert — verwaltet effizient hunderte Netzwerkanfragen
import asyncio

async def abrufen(id_nr):
    await asyncio.sleep(1)
    return id_nr

async def main():
    aufgaben = [abrufen(i) for i in range(5)]
    ergebnisse = await asyncio.gather(*aufgaben)
    print(ergebnisse)

asyncio.run(main())
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — 'await' außerhalb einer async-Funktion
def normale_funktion():
    await asyncio.sleep(1)   # SyntaxError: 'await' outside async function
```

## Was wann verwenden?

| Szenario | Richtiges Werkzeug |
|---|---|
| Dateidownload, API-Anfrage (Wartezeit, wenige Aufgaben) | `threading` |
| Hunderte gleichzeitige Netzwerkanfragen | `asyncio` |
| Bildverarbeitung, schwere Mathematik (CPU-gebunden) | `multiprocessing` |

---
⬅️ [Zurück](./README.md) &nbsp;|&nbsp; ➡️ [Fortgeschrittene OOP-Konzepte](./02-Fortgeschrittene-OOP-Konzepte.md)
