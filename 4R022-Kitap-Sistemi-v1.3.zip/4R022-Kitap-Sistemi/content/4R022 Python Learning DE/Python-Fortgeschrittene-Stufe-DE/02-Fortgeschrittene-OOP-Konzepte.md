# 2. Fortgeschrittene OOP-Konzepte

## Einen eigenen Kontextmanager schreiben

```python
# ✅ Dieser Code funktioniert
class DatenbankVerbindung:
    def __enter__(self):
        print("Verbindung geöffnet")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        print("Verbindung geschlossen")
        return False

with DatenbankVerbindung() as conn:
    print("Abfrage wird ausgeführt...")
```

Kürzer mit `contextlib`:

```python
# ✅ Dieser Code funktioniert
from contextlib import contextmanager

@contextmanager
def db_verbindung():
    print("Verbindung geöffnet")
    yield "verbindungsobjekt"
    print("Verbindung geschlossen")
```

## Speicheroptimierung mit `__slots__`

```python
# ✅ Dieser Code funktioniert
class Punkt:
    __slots__ = ("x", "y")

    def __init__(self, x, y):
        self.x = x
        self.y = y
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT — Zuweisung zu einem nicht in __slots__ aufgeführten Attribut
p = Punkt(1, 2)
p.z = 5
```

Das wirft `AttributeError: 'Punkt' object has no attribute 'z'`.

## Metaklassen — die Klasse einer Klasse

```python
# ✅ Dieser Code funktioniert
class LogMeta(type):
    def __new__(mcs, name, bases, namespace):
        print(f"Erstelle neue Klasse: {name}")
        return super().__new__(mcs, name, bases, namespace)

class Beispiel(metaclass=LogMeta):
    pass
```

> 🧑‍🏫 **Hinweis des Lehrers:** Metaklassen werden im Alltagscode
> selten benötigt — sie werden intensiv in großen Frameworks wie
> Django und SQLAlchemy verwendet.

### 🎯 Mini-Übung
Schreibe deinen eigenen Kontextmanager, der das Öffnen und Schließen
einer Datei automatisiert.

---
⬅️ [Nebenläufigkeit](./01-Nebenlaeufigkeit.md) &nbsp;|&nbsp; ➡️ [Performance und Optimierung](./03-Performance-und-Optimierung.md)
