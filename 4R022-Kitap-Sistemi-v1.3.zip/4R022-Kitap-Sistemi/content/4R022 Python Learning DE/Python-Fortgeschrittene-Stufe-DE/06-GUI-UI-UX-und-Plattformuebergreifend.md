# 6. GUI, UI/UX und plattformübergreifende Oberflächen

## Was sind UI und UX, und wo liegt der Unterschied?

**UI (User Interface)** ist alles, was der Benutzer sieht und
berührt. **UX (User Experience)** ist das, was der Benutzer bei der
Nutzung **fühlt**. Eine hübsch aussehende App (gutes UI) kann trotzdem
schwer zu bedienen sein (schlechtes UX).

## Bildschirmgröße und Auflösung ermitteln (plattformübergreifend)

```python
# ✅ Dieser Code funktioniert — auf Windows, Linux UND macOS
import tkinter as tk
temp = tk.Tk()
breite = temp.winfo_screenwidth()
hoehe = temp.winfo_screenheight()
temp.destroy()
```

```python
# ✅ Dieser Code funktioniert — NUR auf Windows (über ctypes)
import ctypes
user32 = ctypes.windll.user32
breite = user32.GetSystemMetrics(0)
hoehe = user32.GetSystemMetrics(1)
```

```python
# ❌ Dieser Code FUNKTIONIERT NICHT (nur auf Windows, stürzt auf Linux/macOS ab)
import ctypes
breite = ctypes.windll.user32.GetSystemMetrics(0)   # 'windll' ist Windows-spezifisch!
```

- **Warum ist das falsch?** `ctypes.windll` existiert nur unter Windows.
- **Wo ist der Fehler?** `AttributeError: module 'ctypes' has no
  attribute 'windll'` unter Linux/macOS.
- **Was stattdessen verwenden?** Eine plattformunabhängige Methode
  wie `tkinter.winfo_screenwidth()` bevorzugen.

## Dateiauswahlfenster

```python
# ✅ Dieser Code funktioniert — Tkinter
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()
dateipfad = filedialog.askopenfilename(
    title="Bild auswählen",
    filetypes=[("Bilddateien", "*.png *.jpg *.jpeg")]
)
```

```python
# ✅ Dieser Code funktioniert — PyQt6
from PyQt6.QtWidgets import QApplication, QFileDialog
import sys

app = QApplication(sys.argv)
dateipfad, _ = QFileDialog.getOpenFileName(None, "Bild auswählen", "", "Bilder (*.png *.jpg)")
```

## Allgemeine Tipps für plattformübergreifende Entwicklung

- Immer `sys.platform` prüfen, bevor plattformspezifischer Code
  verwendet wird.
- Plattformunabhängige APIs von `tkinter`/`PyQt6` bevorzugen.
- **Tatsächlich auf mehreren Betriebssystemen testen.**

### 🎯 Mini-Übung
Schreibe eine kleine Tkinter- oder PyQt6-Anwendung, die zentriert auf
dem Bildschirm des Benutzers öffnet, mit einem „Datei auswählen"-
Button, der das ausgewählte Bild anzeigt.

---
⬅️ [Desktop-Anwendungsentwicklung](./05-Desktop-Anwendungsentwicklung.md) &nbsp;|&nbsp; ➡️ [Weiter zu den Datenkonzepten](../Python-Datenkonzepte-DE/README.md)

🎉 **Glückwunsch — du hast die fortgeschrittene Stufe abgeschlossen!**
