"""
4R022 Kitap Sistemi - İçerik yükleyici.

``content/`` klasörü altındaki her alt klasör bir "dil paketi"dir
(örn. "4R022 Python Öğrenme TR"). Bu modül:

1. Mevcut dil paketlerini keşfeder (dil seçim penceresi için),
2. Seçilen bir dil paketinin klasör/dosya yapısını, önceden bilinen
   bölüm sırasına göre (Genel Bakış -> Temel -> Orta -> Üst Düzey ->
   Veri Kavramları -> Modüller -> Etik) gezip bir İçindekiler (TOC)
   ağacı ve düz sayfa listesi üretir.

Sayfa anahtarı (page key), dil kökünden itibaren "/" ile ayrılmış
göreli yoldur, örn. "Python-Temel-Egitim-TR/02-Degiskenler-ve-Veri-Tipleri.md".
Bu anahtar; gezinme, kaldığı yerden devam etme ve not/çizim
kayıtlarının anahtarlanması için tek referans noktasıdır.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import List, Optional


PAGE_EXTENSIONS = (".md", ".txt")
SKIP_DIR_NAMES = {"assets", "licenses", ".git", "__pycache__"}
SKIP_FILE_NAMES = {"license.txt"}

# Bölüm sırasını belirleyen anahtar kelimeler (5 dilin tamamını kapsar).
_SECTION_KEYWORDS = [
    ("nedir", 0), ("genel-bakis", 0), ("overview", 0), ("obzor", 0),
    ("apercu", 0), ("ueberblick", 0),
    ("temel-egitim", 1), ("first-education", 1), ("osnovy", 1),
    ("education-base", 1), ("grundlagen", 1),
    ("orta-kademe", 2), ("intermediate", 2), ("sredniy", 2),
    ("intermediaire", 2), ("mittelstufe", 2),
    ("ust-duzey", 3), ("advanced", 3), ("prodvinutyy", 3),
    ("niveau-avance", 3), ("fortgeschrittene", 3),
    ("veri-kavramlari", 4), ("data-concepts", 4), ("kontseptsii-dannykh", 4),
    ("concepts-de-donnees", 4), ("datenkonzepte", 4),
    ("moduller", 5), ("modules", 5), ("moduli", 5), ("module-", 5),
    ("module-de", 5),
    ("etik", 6), ("ethics", 6), ("etika", 6), ("ethique", 6), ("ethik", 6),
]


def _section_rank(folder_name: str) -> int:
    lower = folder_name.lower()
    for keyword, rank in _SECTION_KEYWORDS:
        if keyword in lower:
            return rank
    return 99


def _natural_key(name: str):
    """'2' < '10' gibi doğal (insan gibi) sıralama için anahtar üretir."""
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


@dataclass
class TocNode:
    title: str
    page_key: Optional[str]  # None ise bu bir klasördür (sayfası yok)
    is_folder: bool
    children: List["TocNode"] = field(default_factory=list)


@dataclass
class LanguagePackage:
    display_name: str
    root_path: str


def discover_language_packages(content_dir: str) -> List[LanguagePackage]:
    """``content/`` klasörü altındaki her dil paketini bulur."""
    from core import i18n
    packages = []
    if not os.path.isdir(content_dir):
        return packages
    for entry in sorted(os.listdir(content_dir)):
        full = os.path.join(content_dir, entry)
        if os.path.isdir(full) and any(
            os.path.isfile(os.path.join(full, f)) or os.path.isdir(os.path.join(full, f))
            for f in os.listdir(full)
        ):
            packages.append(LanguagePackage(display_name=entry, root_path=full))
    # Sabit sıra: English, Türkçe, Русский, Deutsch, Français
    order = {code: i for i, code in enumerate(i18n.SUPPORTED)}
    packages.sort(key=lambda p: (order.get(i18n.lang_code_for_package(p.display_name), 99), p.display_name))
    return packages


_TITLE_CACHE: dict = {}


def _extract_title(file_path: str, fallback: str) -> str:
    cached = _TITLE_CACHE.get(file_path)
    if cached is not None:
        return cached
    title = _extract_title_uncached(file_path, fallback)
    _TITLE_CACHE[file_path] = title
    return title


def _extract_title_uncached(file_path: str, fallback: str) -> str:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for _ in range(20):
                line = f.readline()
                if not line:
                    break
                stripped = line.strip().lstrip("#").strip()
                if line.strip().startswith("#") and stripped:
                    # Emoji/markdown süslemelerini olabildiğince sadeleştir
                    stripped = re.sub(r"[*_`]", "", stripped)
                    return stripped
    except OSError:
        pass
    return fallback


def _humanize(name: str) -> str:
    name = re.sub(r"^\d+[-_.]?", "", name)
    name = os.path.splitext(name)[0]
    name = name.replace("-", " ").replace("_", " ")
    return name.strip() or name


def _build_folder_node(folder_path: str, rel_prefix: str) -> TocNode:
    title = _humanize(os.path.basename(folder_path))
    node = TocNode(title=title, page_key=None, is_folder=True)

    entries = [e for e in os.listdir(folder_path) if e.lower() not in SKIP_FILE_NAMES]
    entries = [e for e in entries if e.lower() not in SKIP_DIR_NAMES]

    # Önce README.md (varsa) klasörün kendi sayfası olarak eklenir.
    readme_names = [e for e in entries if e.lower() == "readme.md"]
    other_files = sorted(
        [e for e in entries if os.path.isfile(os.path.join(folder_path, e))
         and e.lower() != "readme.md"
         and os.path.splitext(e)[1].lower() in PAGE_EXTENSIONS],
        key=_natural_key,
    )
    subfolders = sorted(
        [e for e in entries if os.path.isdir(os.path.join(folder_path, e))],
        key=lambda n: (_section_rank(n), _natural_key(n)),
    )

    if readme_names:
        readme_path = os.path.join(folder_path, readme_names[0])
        page_key = f"{rel_prefix}/{readme_names[0]}" if rel_prefix else readme_names[0]
        node.page_key = page_key
        node.title = _extract_title(readme_path, title)

    for fname in other_files:
        fpath = os.path.join(folder_path, fname)
        page_key = f"{rel_prefix}/{fname}" if rel_prefix else fname
        child_title = _extract_title(fpath, _humanize(fname))
        node.children.append(
            TocNode(title=child_title, page_key=page_key, is_folder=False)
        )

    for sub in subfolders:
        sub_path = os.path.join(folder_path, sub)
        sub_rel = f"{rel_prefix}/{sub}" if rel_prefix else sub
        node.children.append(_build_folder_node(sub_path, sub_rel))

    return node


def build_toc(language_root: str) -> TocNode:
    """Bir dil paketinin kökünden başlayarak tam İçindekiler ağacını üretir."""
    return _build_folder_node(language_root, rel_prefix="")


def flatten_pages(node: TocNode) -> List[TocNode]:
    """TOC ağacını, okuma sırasına göre düz bir sayfa listesine çevirir."""
    pages: List[TocNode] = []

    def _walk(n: TocNode):
        if n.page_key:
            pages.append(n)
        for child in n.children:
            _walk(child)

    _walk(node)
    return pages


def read_page_source(language_root: str, page_key: str) -> str:
    full_path = os.path.join(language_root, *page_key.split("/"))
    with open(full_path, "r", encoding="utf-8") as f:
        return f.read()


def page_dir(language_root: str, page_key: str) -> str:
    """Bir sayfanın bulunduğu klasörün mutlak yolu (bağıl bağlantı/görsel çözümü için)."""
    parts = page_key.split("/")[:-1]
    return os.path.join(language_root, *parts) if parts else language_root
