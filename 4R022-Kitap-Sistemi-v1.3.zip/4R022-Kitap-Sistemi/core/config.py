"""
4R022 Python Learning - Merkezi yapılandırma.

Uygulama genelinde kullanılan yollar, marka renkleri ve ekran boyutuna
duyarlı boyutlandırma yardımcıları burada toplanır.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass


APP_NAME = "4R022 Python Learning"
APP_ORG = "4R022"
APP_AUTHOR = "Kaan Kross"
APP_VERSION = "1.3.0"


def resource_path(relative_path: str) -> str:
    """PyInstaller ile paketlenmiş uygulamalarda da doğru çalışan kaynak yolu.

    Geliştirme ortamında bu dosyanın bulunduğu klasöre göre, PyInstaller
    ile paketlenmiş --onefile modunda ise geçici çıkarma klasörüne (
    ``sys._MEIPASS``) göre yol üretir.
    """
    try:
        base_path = sys._MEIPASS  # type: ignore[attr-defined]
    except AttributeError:
        base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    return os.path.join(base_path, relative_path)


def get_user_data_dir() -> str:
    """Kullanıcıya özel, yazılabilir veri klasörünü döndürür (platforma göre).

    - Windows: %APPDATA%/4R022/KitapSistemi
    - macOS:   ~/Library/Application Support/4R022/KitapSistemi
    - Linux:   ~/.local/share/4R022/KitapSistemi
    """
    if sys.platform.startswith("win"):
        base = os.getenv("APPDATA") or os.path.expanduser("~")
        path = os.path.join(base, "4R022", "KitapSistemi")
    elif sys.platform == "darwin":
        path = os.path.join(
            os.path.expanduser("~"), "Library", "Application Support",
            "4R022", "KitapSistemi",
        )
    else:
        base = os.getenv("XDG_DATA_HOME") or os.path.join(
            os.path.expanduser("~"), ".local", "share"
        )
        path = os.path.join(base, "4R022", "KitapSistemi")
    os.makedirs(path, exist_ok=True)
    return path


CONTENT_DIR = resource_path("content")
ASSETS_DIR = resource_path("assets")
LOGO_PATH = os.path.join(ASSETS_DIR, "4r022-logo.png")
STATE_FILE = os.path.join(get_user_data_dir(), "durum.json")


@dataclass(frozen=True)
class Palette:
    """4R022 marka renk paleti: siyah, bordo, gri + Python mavisi/sarısı."""

    bg: str = "#0c0c0e"
    bg_panel: str = "#141416"
    bg_elevated: str = "#1c1c20"
    border: str = "#2a2a2e"
    text: str = "#e8e8ea"
    text_dim: str = "#9a9aa0"
    bordo: str = "#7a1f2b"
    bordo_bright: str = "#a52a37"
    blue: str = "#3776ab"
    yellow: str = "#ffd43b"
    gray: str = "#4a4a50"


PALETTE = Palette()


def screen_geometry_fraction(app, width_frac: float = 0.82, height_frac: float = 0.86):
    """Birincil ekranın kullanılabilir alanına göre pencere boyutu/konumu hesaplar.

    ``app`` bir ``QApplication`` örneğidir. Sonuç ``(x, y, genislik, yukseklik)``
    şeklinde döner; pencere ekranın ortasına yerleştirilecek şekilde hesaplanır.
    """
    screen = app.primaryScreen()
    geo = screen.availableGeometry()
    width = int(geo.width() * width_frac)
    height = int(geo.height() * height_frac)
    x = geo.x() + (geo.width() - width) // 2
    y = geo.y() + (geo.height() - height) // 2
    return x, y, width, height


def base_font_point_size(app) -> int:
    """Ekran DPI'sine göre makul bir taban yazı tipi boyutu hesaplar."""
    screen = app.primaryScreen()
    dpi = screen.logicalDotsPerInch() if screen else 96.0
    if dpi >= 168:
        return 12
    if dpi >= 132:
        return 11
    return 10
