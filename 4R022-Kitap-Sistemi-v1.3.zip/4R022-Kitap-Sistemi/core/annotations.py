"""
4R022 Kitap Sistemi - Not/çizim veri modeli.

Kalem, vurgulama kalemi, şeffaf kalem ve silgi ile yapılan çizimler
ile yapışkan notlar, her sayfanın kendi HTML belgesi içinde bir
<canvas> ve konumlandırılmış <div> öğeleri olarak tutulur; bu modül
yalnızca JavaScript tarafından üretilen JSON'ı Python tarafında
saklamak/geri yüklemek için ince bir sarmalayıcıdır. Format,
web/bridge.js dosyasındaki JavaScript temsili ile birebir eşleşir.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class PageAnnotations:
    """Bir sayfaya ait tüm çizim/not verisi (ham JSON olarak saklanır)."""

    raw: Dict[str, Any] = field(default_factory=lambda: {"strokes": [], "notes": []})

    def is_empty(self) -> bool:
        return not self.raw.get("strokes") and not self.raw.get("notes")

    def to_dict(self) -> Dict[str, Any]:
        return self.raw

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PageAnnotations":
        if not isinstance(data, dict):
            data = {"strokes": [], "notes": []}
        data.setdefault("strokes", [])
        data.setdefault("notes", [])
        return cls(raw=data)


class AnnotationStore:
    """Dil + sayfa anahtarına göre tüm not/çizim verisini tutan depo."""

    def __init__(self, initial: Dict[str, Dict[str, Any]] | None = None):
        self._data: Dict[str, Dict[str, Any]] = initial or {}

    @staticmethod
    def _key(language: str, page_key: str) -> str:
        return f"{language}::{page_key}"

    def get(self, language: str, page_key: str) -> PageAnnotations:
        raw = self._data.get(self._key(language, page_key))
        return PageAnnotations.from_dict(raw or {"strokes": [], "notes": []})

    def set(self, language: str, page_key: str, annotations: PageAnnotations) -> None:
        key = self._key(language, page_key)
        if annotations.is_empty():
            self._data.pop(key, None)
        else:
            self._data[key] = annotations.to_dict()

    def clear(self, language: str, page_key: str) -> None:
        self._data.pop(self._key(language, page_key), None)

    def to_dict(self) -> Dict[str, Dict[str, Any]]:
        return self._data

    @classmethod
    def from_dict(cls, data: Dict[str, Dict[str, Any]] | None) -> "AnnotationStore":
        return cls(initial=data or {})
