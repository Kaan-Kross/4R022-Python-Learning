"""
4R022 Python Learning - Durum yöneticisi.

Kullanıcının kaldığı yeri (dil, sayfa, kaydırma oranı, yakınlaştırma),
pencere boyutunu ve tüm not/çizim verisini diske **atomik** biçimde
yazar: önce ``.tmp`` dosyasına yazılır, ardından varsa eski dosya
``.bak`` olarak yedeklenir ve en son ``.tmp`` asıl dosyanın üzerine
taşınır. Bu sırada bir kesinti (elektrik kesintisi, çökme) olsa bile
ya eski dosya ya da tamamen yazılmış yeni dosya diskte kalır; asla
yarım/bozuk bir durum dosyası oluşmaz.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from core.annotations import AnnotationStore
from core.i18n import LEGACY_PACKAGE_NAMES


@dataclass
class ReadingState:
    last_language: Optional[str] = None
    last_page_key: Optional[str] = None
    scroll_fraction: float = 0.0
    zoom_factor: float = 1.0
    window_geometry: Optional[list] = None
    toc_visible: bool = True
    theme: str = "koyu"
    annotations: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "last_language": self.last_language,
            "last_page_key": self.last_page_key,
            "scroll_fraction": self.scroll_fraction,
            "zoom_factor": self.zoom_factor,
            "window_geometry": self.window_geometry,
            "toc_visible": self.toc_visible,
            "theme": self.theme,
            "annotations": self.annotations,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ReadingState":
        if not isinstance(data, dict):
            data = {}
        # Eski klasör adlarını (Öğrenme/Обучение/Lernen/Apprentissage) yeni adlara taşı.
        last_lang = data.get("last_language")
        last_lang = LEGACY_PACKAGE_NAMES.get(last_lang, last_lang)
        data["last_language"] = last_lang
        ann = data.get("annotations") or {}
        migrated = {}
        for key, value in ann.items():
            lang, sep, rest = key.partition("::")
            migrated[f"{LEGACY_PACKAGE_NAMES.get(lang, lang)}{sep}{rest}"] = value
        data["annotations"] = migrated
        return cls(
            last_language=data.get("last_language"),
            last_page_key=data.get("last_page_key"),
            scroll_fraction=float(data.get("scroll_fraction", 0.0) or 0.0),
            zoom_factor=float(data.get("zoom_factor", 1.0) or 1.0),
            window_geometry=data.get("window_geometry"),
            toc_visible=bool(data.get("toc_visible", True)),
            theme=data.get("theme", "koyu"),
            annotations=data.get("annotations", {}) or {},
        )


class StateManager:
    """Durum dosyasını okur/yazar; not/çizim deposunu (AnnotationStore) yönetir."""

    def __init__(self, state_file_path: str):
        self.path = state_file_path
        self.state = self._load()
        self.annotation_store = AnnotationStore.from_dict(self.state.annotations)

    def _load(self) -> ReadingState:
        if os.path.isfile(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    return ReadingState.from_dict(json.load(f))
            except (json.JSONDecodeError, OSError):
                # Bozuk durum dosyası: sessizce sıfırdan başla, eskiyi .bozuk olarak sakla
                try:
                    os.replace(self.path, self.path + ".bozuk")
                except OSError:
                    pass
        return ReadingState()

    def save(self) -> None:
        """Mevcut durumu diske atomik olarak yazar."""
        self.state.annotations = self.annotation_store.to_dict()
        payload = json.dumps(self.state.to_dict(), ensure_ascii=False, separators=(",", ":"))
        if payload == getattr(self, "_last_payload", None):
            return                                    # değişiklik yok: diske yazma
        self._last_payload = payload

        directory = os.path.dirname(self.path)
        os.makedirs(directory, exist_ok=True)
        tmp_path = self.path + ".tmp"

        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(payload)

        if not getattr(self, "_bak_done", False) and os.path.isfile(self.path):
            try:
                os.replace(self.path, self.path + ".bak")   # oturum başına yalnızca bir yedek
            except OSError:
                pass
            self._bak_done = True

        os.replace(tmp_path, self.path)

    # -- Kolaylık erişimcileri -------------------------------------------------

    def remember_position(self, language: str, page_key: str, scroll_fraction: float) -> None:
        self.state.last_language = language
        self.state.last_page_key = page_key
        self.state.scroll_fraction = max(0.0, min(1.0, scroll_fraction))

    def has_saved_position(self) -> bool:
        return bool(self.state.last_language and self.state.last_page_key)
