"""
4R022 Python Learning - Markdown -> HTML dönüştürücü.

Her sayfa, tek bir bağımsız HTML belgesine dönüştürülür ve
``QWebEngineView.setHtml(html, base_url)`` ile gösterilir. ``base_url``,
sayfanın bulunduğu klasörü gösterir; böylece markdown içindeki bağıl
görsel ve bağlantı yolları (``../Python-Etik-ve-Guvenlik-TR/README.md``
gibi) doğru şekilde çözümlenir.

Bu modül ayrıca web/bridge.js dosyasının içeriğini doğrudan HTML'e
gömer (harici dosya yükleme zamanlaması sorunlarını önlemek için) ve
o sayfaya ait kaydedilmiş not/çizim verisiyle kaydırma oranını
JavaScript tarafına aktarır.
"""
from __future__ import annotations

import json
import re
import os


from core.config import PALETTE, resource_path


_BRIDGE_JS_CACHE: str | None = None


def _load_bridge_js() -> str:
    global _BRIDGE_JS_CACHE
    if _BRIDGE_JS_CACHE is None:
        js_path = resource_path(os.path.join("web", "bridge.js"))
        with open(js_path, "r", encoding="utf-8") as f:
            _BRIDGE_JS_CACHE = f.read()
    return _BRIDGE_JS_CACHE


_CSS_CACHE: "str | None" = None


def _page_css() -> str:
    global _CSS_CACHE
    if _CSS_CACHE is None:
        _CSS_CACHE = _PAGE_CSS_TEMPLATE.format(
            bg=PALETTE.bg, bg_panel=PALETTE.bg_panel, bg_elevated=PALETTE.bg_elevated,
            border=PALETTE.border, text=PALETTE.text, text_dim=PALETTE.text_dim,
            bordo=PALETTE.bordo, bordo_bright=PALETTE.bordo_bright,
            blue=PALETTE.blue, yellow=PALETTE.yellow, gray=PALETTE.gray,
        )
    return _CSS_CACHE


_FRAGMENT_CACHE: "dict" = {}
_FRAGMENT_CACHE_MAX = 40


def markdown_to_html_fragment(source: str, is_plain_text: bool) -> str:
    key = (hash(source), is_plain_text)
    cached = _FRAGMENT_CACHE.get(key)
    if cached is not None:
        return cached
    html = _markdown_to_html_fragment_uncached(source, is_plain_text)
    if len(_FRAGMENT_CACHE) >= _FRAGMENT_CACHE_MAX:
        _FRAGMENT_CACHE.pop(next(iter(_FRAGMENT_CACHE)))
    _FRAGMENT_CACHE[key] = html
    return html


def _markdown_to_html_fragment_uncached(source: str, is_plain_text: bool) -> str:
    if is_plain_text:
        escaped = (
            source.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        )
        return f"<pre class='duz-metin'>{escaped}</pre>"

    import markdown as md   # ağır modül: ilk sayfa gösterilirken yüklenir (açılış hızlanır)
    return md.markdown(
        _enable_md_in_html(source),
        extensions=["extra", "md_in_html", "sane_lists", "toc", "admonition"],
        output_format="html5",
    )


_BLOCK_OPEN_RE = re.compile(
    r"^([ \t]*)<(div|details|section|center|blockquote)\b((?:(?!markdown=)[^>])*)>",
    re.IGNORECASE | re.MULTILINE,
)


def _enable_md_in_html(source: str) -> str:
    """<div align="center"> ve <details> bloklarının İÇİNDEKİ markdown'un da işlenmesini sağlar.

    Python-Markdown varsayılan olarak ham HTML bloklarının içini işlemez; bu yüzden
    ENG/TR kapak sayfasındaki "# Başlık" ve "**kalın**" işaretleri ham yazı olarak
    görünüyordu, <details> içindeki kod blokları da bozuk çıkıyordu.
    Kod çitlerinin (```) içine dokunulmaz.
    """
    parts = re.split(r"(^[ \t]*```.*?^[ \t]*```[ \t]*$)", source, flags=re.MULTILINE | re.DOTALL)
    for i in range(0, len(parts), 2):          # çift indeksler = çit dışı metin
        parts[i] = _BLOCK_OPEN_RE.sub(
            lambda m: f'{m.group(1)}<{m.group(2)}{m.group(3)} markdown="1">', parts[i]
        )
    return "".join(parts)


_PAGE_CSS_TEMPLATE = """
:root {{
  --bg: {bg};
  --bg-panel: {bg_panel};
  --bg-elevated: {bg_elevated};
  --border: {border};
  --text: {text};
  --text-dim: {text_dim};
  --bordo: {bordo};
  --bordo-bright: {bordo_bright};
  --blue: {blue};
  --yellow: {yellow};
  --gray: {gray};
}}
* {{ box-sizing: border-box; }}
html, body {{
  background: var(--bg);
  color: var(--text);
  margin: 0;
  padding: 0;
  font-family: "Segoe UI", "Noto Sans", "Helvetica Neue", Arial, sans-serif;
  font-size: 17px;
  line-height: 1.7;
  -webkit-font-smoothing: antialiased;
}}
.kitap-sayfa-icerik {{
  max-width: 880px;
  margin: 0 auto;
  padding: 56px 48px 140px 48px;
  position: relative;
  animation: kitapFadeIn 180ms ease-out;
}}
@keyframes kitapFadeIn {{ from {{ opacity: 0; }} to {{ opacity: 1; }} }}
h1, h2, h3, h4 {{
  color: var(--yellow);
  font-weight: 700;
  line-height: 1.3;
  scroll-margin-top: 24px;
}}
h1 {{ font-size: 2.05em; border-bottom: 2px solid var(--bordo); padding-bottom: 0.35em; }}
h2 {{ font-size: 1.55em; color: var(--blue); margin-top: 2em; }}
h3 {{ font-size: 1.22em; color: var(--text); margin-top: 1.6em; }}
a {{ color: var(--blue); text-decoration: none; border-bottom: 1px dotted var(--blue); }}
a:hover {{ color: var(--yellow); border-bottom-color: var(--yellow); }}
p, li {{ color: var(--text); }}
strong {{ color: var(--yellow); }}
code {{
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: 4px;
  padding: 2px 6px;
  font-family: "Cascadia Code", "Fira Code", Consolas, monospace;
  font-size: 0.92em;
  color: #ffd8a8;
}}
pre {{
  background: var(--bg-elevated) !important;
  border: 1px solid var(--border);
  border-left: 3px solid var(--bordo-bright);
  border-radius: 8px;
  padding: 18px 20px;
  overflow-x: auto;
}}
pre code {{
  background: none;
  border: none;
  padding: 0;
  color: #d7e3ea;
}}
pre.duz-metin {{
  white-space: pre-wrap;
  font-family: "Cascadia Code", "Fira Code", Consolas, monospace;
}}
blockquote {{
  border-left: 4px solid var(--yellow);
  margin: 1.2em 0;
  padding: 0.4em 1.2em;
  background: var(--bg-panel);
  color: var(--text-dim);
  border-radius: 0 8px 8px 0;
}}
[align="center"] {{ text-align: center; }}
p, li, td, th, h1, h2, h3, h4 {{ overflow-wrap: anywhere; }}
table {{
  display: block;
  overflow-x: auto;
  border-collapse: collapse;
  max-width: 100%;
  margin: 1.4em 0;
  font-size: 0.95em;
}}
th, td {{
  border: 1px solid var(--border);
  padding: 8px 12px;
  text-align: left;
}}
th {{ background: var(--bg-elevated); color: var(--yellow); }}
tr:nth-child(even) td {{ background: rgba(255,255,255,0.02); }}
img {{ max-width: 100%; border-radius: 8px; }}
hr {{ border: none; border-top: 1px solid var(--border); margin: 2.2em 0; }}
details {{
  background: var(--bg-panel);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 10px 16px;
  margin: 1em 0;
}}
summary {{ cursor: pointer; color: var(--blue); font-weight: 600; }}
::selection {{ background: var(--bordo-bright); color: white; }}

/* Kaydırma çubuğu */
::-webkit-scrollbar {{ width: 12px; }}
::-webkit-scrollbar-track {{ background: var(--bg); }}
::-webkit-scrollbar-thumb {{ background: var(--gray); border-radius: 6px; }}
::-webkit-scrollbar-thumb:hover {{ background: var(--bordo); }}

/* Not/çizim katmanı */
.kitap-sticky-note {{
  position: absolute;
  z-index: 9500;
  width: 230px;
  min-height: 100px;
  border-radius: 6px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.45);
  color: #1c1c1c;
  font-size: 14px;
  line-height: 1.45;
}}
.kitap-sticky-note-bar {{
  height: 20px;
  cursor: move;
  background: rgba(0,0,0,0.12);
  border-radius: 6px 6px 0 0;
  position: relative;
  touch-action: none;
}}
.kitap-sticky-note-close {{
  position: absolute;
  top: 0;
  right: 6px;
  cursor: pointer;
  font-weight: bold;
  line-height: 20px;
  opacity: 0.6;
  font-size: 16px;
}}
.kitap-sticky-note-close:hover {{ opacity: 1; }}
.kitap-sticky-note-body {{
  padding: 8px 10px 10px 10px;
  outline: none;
  min-height: 70px;
  white-space: pre-wrap;
  word-break: break-word;
  cursor: text;
  user-select: text;
}}
.kitap-sticky-note-body:empty::before {{
  content: attr(data-placeholder);
  opacity: 0.45;
}}
"""


def render_page_html(
    *,
    source_text: str,
    is_plain_text: bool,
    language: str,
    page_key: str,
    annotations_json: dict,
    initial_scroll_fraction: float,
    lang_code: str = "en",
    i18n_strings: "dict | None" = None,
) -> str:
    """Bir sayfa için tam, bağımsız bir HTML belgesi üretir."""
    body_fragment = markdown_to_html_fragment(source_text, is_plain_text)
    css = _page_css()
    bridge_js = _load_bridge_js()

    annotations_js = json.dumps(annotations_json, ensure_ascii=False)
    page_key_js = json.dumps(page_key, ensure_ascii=False)
    language_js = json.dumps(language, ensure_ascii=False)
    i18n_js = json.dumps(i18n_strings or {}, ensure_ascii=False)
    # </script> kaçışı (JSON içinde güvenli gömme)
    annotations_js = annotations_js.replace("</", "<\\/")

    return f"""<!DOCTYPE html>
<html lang="{lang_code}">
<head>
<meta charset="utf-8"/>
<title>4R022 Python Learning</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<style>{css}</style>
</head>
<body>
<div class="kitap-sayfa-icerik">
{body_fragment}
</div>
<script>
  window.__PAGE_KEY__ = {page_key_js};
  window.__LANGUAGE__ = {language_js};
  window.__ANNOTATIONS__ = {annotations_js};
  window.__INITIAL_SCROLL_FRACTION__ = {initial_scroll_fraction};
  window.__I18N__ = {i18n_js};
</script>
<script>
{bridge_js}
</script>
</body>
</html>"""
