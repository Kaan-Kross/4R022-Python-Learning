"""
4R022 Python Learning - Çok dilli arayüz metinleri (i18n).

Seçilen dile göre arayüzdeki TÜM metinler (butonlar, ipuçları, onay
pencereleri, menüler, not/çizim araçları) bu tablodan gelir.
Desteklenen diller: tr, en, ru, fr, de.  İlk açılışta dil seçimi
İngilizce sorulur (``DEFAULT_LANG``).
"""
from __future__ import annotations

from typing import Dict, Optional

DEFAULT_LANG = "en"
SUPPORTED = ("en", "tr", "ru", "de", "fr")

# Klasör sonekinden dil koduna eşleme (örn. "4R022 Python Learning TR").
_SUFFIX_TO_CODE = {"TR": "tr", "ENG": "en", "EN": "en", "RU": "ru", "FR": "fr", "DE": "de"}

NATIVE_NAMES = {
    "en": ("🇬🇧", "English"),
    "tr": ("🇹🇷", "Türkçe"),
    "ru": ("🇷🇺", "Русский"),
    "de": ("🇩🇪", "Deutsch"),
    "fr": ("🇫🇷", "Français"),
}

# Eski (anlamsız kelimeler içeren) klasör adları -> yeni adlar.
LEGACY_PACKAGE_NAMES = {
    "4R022 Python Öğrenme TR": "4R022 Python Learning TR",
    "4R022 Python Обучение RU": "4R022 Python Learning RU",
    "4R022 Python Lernen DE": "4R022 Python Learning DE",
    "4R022 Python Apprentissage FR": "4R022 Python Learning FR",
}

_STRINGS: Dict[str, Dict[str, str]] = {
    "en": {
        "book_system": "Book System",
        "toc_header": "CONTENTS",
        "tip_toc": "Table of contents",
        "tip_prev": "Previous page",
        "tip_next": "Next page",
        "tip_zoom_out": "Zoom out",
        "tip_zoom_in": "Zoom in",
        "tip_zoom_reset": "Reset zoom",
        "tool_select": "Select / Scroll",
        "tool_pen": "Pen",
        "tool_highlighter": "Highlighter",
        "tool_transparent": "Transparent pen",
        "tool_eraser": "Eraser",
        "tool_note": "Sticky note",
        "tip_color": "Choose color",
        "tip_clear": "Clear notes and drawings on this page",
        "tip_save": "Save page",
        "btn_language": "🌐 Change Language",
        "saved_msg": "✔ Saved",
        "color_dialog_title": "Choose Color",
        "lang_title": "Select Language",
        "lang_prompt": "Which language would you like to learn in?",
        "btn_cancel": "Cancel",
        "btn_continue": "Continue",
        "clear_title": "Clear",
        "clear_text": "All notes and drawings on this page will be deleted. Are you sure?",
        "btn_yes": "Yes",
        "btn_no": "No",
        "err_no_packages": "No language packs were found in the content/ folder.\nPlace at least one language pack in the 'content' folder next to the application.",
        "note_delete": "Delete note",
        "note_placeholder": "Write your note…",
    },
    "tr": {
        "book_system": "Kitap Sistemi",
        "toc_header": "İÇİNDEKİLER",
        "tip_toc": "İçindekiler",
        "tip_prev": "Önceki sayfa",
        "tip_next": "Sonraki sayfa",
        "tip_zoom_out": "Uzaklaştır",
        "tip_zoom_in": "Yakınlaştır",
        "tip_zoom_reset": "Yakınlaştırmayı sıfırla",
        "tool_select": "Seç / Kaydır",
        "tool_pen": "Kalem",
        "tool_highlighter": "Vurgulayıcı",
        "tool_transparent": "Şeffaf kalem",
        "tool_eraser": "Silgi",
        "tool_note": "Yapışkan not",
        "tip_color": "Renk seç",
        "tip_clear": "Bu sayfadaki not ve çizimleri temizle",
        "tip_save": "Sayfayı kaydet",
        "btn_language": "🌐 Dil Değiştir",
        "saved_msg": "✔ Kaydedildi",
        "color_dialog_title": "Renk Seç",
        "lang_title": "Dil Seç",
        "lang_prompt": "Hangi dille öğrenmek istersin?",
        "btn_cancel": "Vazgeç",
        "btn_continue": "Devam Et",
        "clear_title": "Temizle",
        "clear_text": "Bu sayfadaki tüm not ve çizimler silinecek. Emin misin?",
        "btn_yes": "Evet",
        "btn_no": "Hayır",
        "err_no_packages": "content/ klasöründe hiç dil paketi bulunamadı.\nUygulamanın yanındaki 'content' klasörüne en az bir dil paketi yerleştirin.",
        "note_delete": "Notu sil",
        "note_placeholder": "Notunu yaz…",
    },
    "ru": {
        "book_system": "Электронная книга",
        "toc_header": "СОДЕРЖАНИЕ",
        "tip_toc": "Содержание",
        "tip_prev": "Предыдущая страница",
        "tip_next": "Следующая страница",
        "tip_zoom_out": "Уменьшить",
        "tip_zoom_in": "Увеличить",
        "tip_zoom_reset": "Сбросить масштаб",
        "tool_select": "Выбор / Прокрутка",
        "tool_pen": "Ручка",
        "tool_highlighter": "Маркер",
        "tool_transparent": "Прозрачная ручка",
        "tool_eraser": "Ластик",
        "tool_note": "Стикер-заметка",
        "tip_color": "Выбрать цвет",
        "tip_clear": "Очистить заметки и рисунки на этой странице",
        "tip_save": "Сохранить страницу",
        "btn_language": "🌐 Сменить язык",
        "saved_msg": "✔ Сохранено",
        "color_dialog_title": "Выбор цвета",
        "lang_title": "Выбор языка",
        "lang_prompt": "На каком языке вы хотите учиться?",
        "btn_cancel": "Отмена",
        "btn_continue": "Продолжить",
        "clear_title": "Очистить",
        "clear_text": "Все заметки и рисунки на этой странице будут удалены. Вы уверены?",
        "btn_yes": "Да",
        "btn_no": "Нет",
        "err_no_packages": "В папке content/ не найдено ни одного языкового пакета.\nПоместите хотя бы один языковой пакет в папку 'content' рядом с приложением.",
        "note_delete": "Удалить заметку",
        "note_placeholder": "Напишите заметку…",
    },
    "de": {
        "book_system": "Buchsystem",
        "toc_header": "INHALT",
        "tip_toc": "Inhaltsverzeichnis",
        "tip_prev": "Vorherige Seite",
        "tip_next": "Nächste Seite",
        "tip_zoom_out": "Verkleinern",
        "tip_zoom_in": "Vergrößern",
        "tip_zoom_reset": "Zoom zurücksetzen",
        "tool_select": "Auswählen / Scrollen",
        "tool_pen": "Stift",
        "tool_highlighter": "Textmarker",
        "tool_transparent": "Transparenter Stift",
        "tool_eraser": "Radiergummi",
        "tool_note": "Haftnotiz",
        "tip_color": "Farbe wählen",
        "tip_clear": "Notizen und Zeichnungen auf dieser Seite löschen",
        "tip_save": "Seite speichern",
        "btn_language": "🌐 Sprache ändern",
        "saved_msg": "✔ Gespeichert",
        "color_dialog_title": "Farbe wählen",
        "lang_title": "Sprache wählen",
        "lang_prompt": "In welcher Sprache möchten Sie lernen?",
        "btn_cancel": "Abbrechen",
        "btn_continue": "Weiter",
        "clear_title": "Löschen",
        "clear_text": "Alle Notizen und Zeichnungen auf dieser Seite werden gelöscht. Sind Sie sicher?",
        "btn_yes": "Ja",
        "btn_no": "Nein",
        "err_no_packages": "Im Ordner content/ wurde kein Sprachpaket gefunden.\nLegen Sie mindestens ein Sprachpaket in den Ordner 'content' neben der Anwendung.",
        "note_delete": "Notiz löschen",
        "note_placeholder": "Notiz schreiben…",
    },
    "fr": {
        "book_system": "Livre numérique",
        "toc_header": "SOMMAIRE",
        "tip_toc": "Sommaire",
        "tip_prev": "Page précédente",
        "tip_next": "Page suivante",
        "tip_zoom_out": "Zoom arrière",
        "tip_zoom_in": "Zoom avant",
        "tip_zoom_reset": "Réinitialiser le zoom",
        "tool_select": "Sélection / Défilement",
        "tool_pen": "Stylo",
        "tool_highlighter": "Surligneur",
        "tool_transparent": "Stylo transparent",
        "tool_eraser": "Gomme",
        "tool_note": "Note autocollante",
        "tip_color": "Choisir la couleur",
        "tip_clear": "Effacer les notes et dessins de cette page",
        "tip_save": "Enregistrer la page",
        "btn_language": "🌐 Changer de langue",
        "saved_msg": "✔ Enregistré",
        "color_dialog_title": "Choisir la couleur",
        "lang_title": "Choisir la langue",
        "lang_prompt": "Dans quelle langue souhaitez-vous apprendre ?",
        "btn_cancel": "Annuler",
        "btn_continue": "Continuer",
        "clear_title": "Effacer",
        "clear_text": "Toutes les notes et tous les dessins de cette page seront supprimés. Êtes-vous sûr ?",
        "btn_yes": "Oui",
        "btn_no": "Non",
        "err_no_packages": "Aucun pack de langue n'a été trouvé dans le dossier content/.\nPlacez au moins un pack de langue dans le dossier 'content' à côté de l'application.",
        "note_delete": "Supprimer la note",
        "note_placeholder": "Écrivez votre note…",
    },
}

_current = DEFAULT_LANG


def lang_code_for_package(display_name: Optional[str]) -> str:
    """'4R022 Python Learning TR' -> 'tr' (bilinmiyorsa 'en')."""
    if not display_name:
        return DEFAULT_LANG
    suffix = display_name.strip().split(" ")[-1].upper()
    return _SUFFIX_TO_CODE.get(suffix, DEFAULT_LANG)


def set_language(code: str) -> None:
    global _current
    _current = code if code in _STRINGS else DEFAULT_LANG


def current_language() -> str:
    return _current


def tr(key: str, lang: Optional[str] = None) -> str:
    table = _STRINGS.get(lang or _current) or _STRINGS[DEFAULT_LANG]
    return table.get(key) or _STRINGS[DEFAULT_LANG].get(key, key)


def js_strings(lang: Optional[str] = None) -> Dict[str, str]:
    """Sayfa içi JavaScript'in ihtiyaç duyduğu metinler."""
    return {"note_delete": tr("note_delete", lang),
            "note_placeholder": tr("note_placeholder", lang)}
