"""
4R022 Python Learning - Açılış (Splash) Ekranı.

Uygulama başlarken 4R022 logosunu yumuşak bir belirme/büyüme
animasyonuyla gösterir, kısa bir süre bekler, sonra solarak kaybolup
ana pencereye geçiş sinyali (``finished``) yayınlar.
"""
from __future__ import annotations

import os

from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, pyqtSignal, QRect
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout

from core import i18n
from core.config import LOGO_PATH, PALETTE, APP_AUTHOR


class SplashScreen(QWidget):
    finished = pyqtSignal()

    def __init__(self, app, screen_geometry: tuple[int, int, int, int], lang_code: str = "en"):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._app = app

        width, height = 460, 360
        sx, sy, sw, sh = screen_geometry
        x = sx + (sw - width) // 2
        y = sy + (sh - height) // 2
        self.setGeometry(QRect(x, y, width, height))

        container = QWidget(self)
        container.setGeometry(0, 0, width, height)
        container.setStyleSheet(f"""
            background: {PALETTE.bg};
            border: 1px solid {PALETTE.bordo};
            border-radius: 18px;
        """)

        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 36, 0, 28)
        layout.setSpacing(10)

        self.logo_label = QLabel()
        self.logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        if os.path.isfile(LOGO_PATH):
            pixmap = QPixmap(LOGO_PATH).scaledToWidth(
                190, Qt.TransformationMode.SmoothTransformation
            )
            self.logo_label.setPixmap(pixmap)
        else:
            self.logo_label.setText("4R022")
            self.logo_label.setStyleSheet(f"color: {PALETTE.yellow}; font-size: 42px; font-weight: 800;")
        layout.addWidget(self.logo_label)

        layout.addStretch(1)

        subtitle = QLabel(f"Python Learning — {i18n.tr('book_system', lang_code)}")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet(f"color: {PALETTE.text}; font-size: 14px; font-weight: 600;")
        layout.addWidget(subtitle)

        credit = QLabel(f"{APP_AUTHOR} — 4R022")
        credit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        credit.setStyleSheet(f"color: {PALETTE.text_dim}; font-size: 11px;")
        layout.addWidget(credit)

        self.setWindowOpacity(0.0)

    def run(self, hold_ms: int = 1400) -> None:
        self.show()
        fade_in = QPropertyAnimation(self, b"windowOpacity", self)
        fade_in.setDuration(260)
        fade_in.setStartValue(0.0)
        fade_in.setEndValue(1.0)
        fade_in.setEasingCurve(QEasingCurve.Type.OutCubic)

        def start_hold():
            QTimer.singleShot(hold_ms, start_fade_out)

        def start_fade_out():
            fade_out = QPropertyAnimation(self, b"windowOpacity", self)
            fade_out.setDuration(200)
            fade_out.setStartValue(1.0)
            fade_out.setEndValue(0.0)
            fade_out.setEasingCurve(QEasingCurve.Type.InCubic)
            fade_out.finished.connect(self._on_finished)
            self._fade_out = fade_out
            fade_out.start()

        fade_in.finished.connect(start_hold)
        self._fade_in = fade_in
        fade_in.start()

    def _on_finished(self) -> None:
        self.close()
        self.finished.emit()
