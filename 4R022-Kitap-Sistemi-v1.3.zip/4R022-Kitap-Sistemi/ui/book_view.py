"""
4R022 Python Learning - Kitap Görünümü (BookView).

v1.1 değişiklikleri:
- QGraphicsOpacityEffect kaldırıldı (QWebEngineView üzerinde scroll'u
  yavaşlatıp donduruyordu); geçiş efekti sayfa içi CSS ile yapılıyor.
- QWebChannel kaldırıldı. Sayfa, değişiklik olunca belge başlığını değiştirerek
  haber verir (``titleChanged``); Python yalnızca o zaman ``kitapPoll()`` çağırır.
  Boşta sürekli sorgu YOK (CPU ~0); yalnızca seyrek bir güvenlik zamanlayıcısı var. Sayfa
  değişmeden / uygulama kapanmadan önce ayrıca zorunlu bir "flush" yapılır;
  böylece çizimler sayfa yenilense de silinmez.
- Diske yazma sıklığı sınırlandı (kaydırma için en fazla ~3 sn'de bir).
"""
from __future__ import annotations

import json
import os
import time
from typing import Callable, List, Optional

from PyQt6.QtCore import QEventLoop, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import QVBoxLayout, QWidget

from core import content_loader, i18n
from core.annotations import PageAnnotations
from core.markdown_renderer import render_page_html
from core.state_manager import StateManager


class _InterceptingPage(QWebEnginePage):
    """Yerel içerik bağlantılarını uygulama içinde açar, dış bağlantıları tarayıcıya yollar."""

    def __init__(self, on_internal_link: Callable[[str], bool], parent=None):
        super().__init__(parent)
        self._on_internal_link = on_internal_link

    def acceptNavigationRequest(self, url: QUrl, nav_type, is_main_frame: bool) -> bool:  # noqa: N802
        if nav_type == QWebEnginePage.NavigationType.NavigationTypeLinkClicked:
            if url.isLocalFile():
                if self._on_internal_link(url.toLocalFile()):
                    return False
                # Sayfa içi #bağlantı dışında yerel gezinmeyi engelle (sayfanın boşalmasını önler).
                if not url.hasFragment():
                    return False
            else:
                QDesktopServices.openUrl(url)
                return False
        return super().acceptNavigationRequest(url, nav_type, is_main_frame)


class BookView(QWidget):
    pageChanged = pyqtSignal(str, str)   # (page_key, title)
    zoomChanged = pyqtSignal(float)
    saved = pyqtSignal()                 # elle/otomatik kayıt tamamlandı (yalnızca elle kayıtta yayınlanır)

    MIN_ZOOM = 0.6
    MAX_ZOOM = 2.4
    SAFETY_POLL_MS = 15000      # olay kaçarsa diye seyrek güvenlik ağı
    EVENT_DEBOUNCE_MS = 120
    SCROLL_SAVE_EVERY_S = 5.0

    def __init__(self, state: StateManager, parent=None):
        super().__init__(parent)
        self.state = state

        self.language_pkg: Optional[content_loader.LanguagePackage] = None
        self.toc_root: Optional[content_loader.TocNode] = None
        self.flat_pages: List[content_loader.TocNode] = []
        self.current_page_key: Optional[str] = None
        self.zoom_factor = state.state.zoom_factor or 1.0

        self._page_ready = False
        self._active: Optional[tuple] = None        # (language, page_key) şu an yüklü sayfa
        self._last_scroll_save = 0.0
        self._scroll_dirty = False
        self._nav_token = 0

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.web = QWebEngineView(self)
        page = _InterceptingPage(self._handle_internal_link, self.web)
        self.web.setPage(page)
        self._tune_web_engine()
        self.web.loadFinished.connect(self._on_load_finished)
        self.web.titleChanged.connect(self._on_title_changed)
        layout.addWidget(self.web)

        # Olay tabanlı kayıt: sayfadan gelen "değişti" haberini biraz biriktirip tek sorgu yap.
        self._event_timer = QTimer(self)
        self._event_timer.setSingleShot(True)
        self._event_timer.setInterval(self.EVENT_DEBOUNCE_MS)
        self._event_timer.timeout.connect(self._poll)

        # Seyrek güvenlik ağı (yalnızca pencere etkinken çalışır).
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(self.SAFETY_POLL_MS)
        self._poll_timer.timeout.connect(self._safety_poll)
        self._poll_timer.start()

    def _tune_web_engine(self) -> None:
        """Gereksiz Chromium özelliklerini kapatarak CPU/bellek kullanımını düşürür."""
        W = QWebEngineSettings.WebAttribute
        wanted = {
            "ScrollAnimatorEnabled": True,       # yumuşak kaydırma
            "Accelerated2dCanvasEnabled": True,
            "PluginsEnabled": False,
            "LocalStorageEnabled": False,
            "WebGLEnabled": False,
            "DnsPrefetchEnabled": False,
            "HyperlinkAuditingEnabled": False,
            "ErrorPageEnabled": False,
            "AutoLoadIconsForPage": False,
            "JavascriptCanOpenWindows": False,
            "JavascriptCanAccessClipboard": False,
            "FullScreenSupportEnabled": False,
            "ScreenCaptureEnabled": False,
            "WebRTCPublicInterfacesOnly": True,
            "SpatialNavigationEnabled": False,
        }
        settings = self.web.settings()
        for name, value in wanted.items():
            attr = getattr(W, name, None)
            if attr is not None:
                try:
                    settings.setAttribute(attr, value)
                except Exception:
                    pass
        try:
            from PyQt6.QtWebEngineCore import QWebEngineProfile
            profile = self.web.page().profile()
            profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.NoCache)
            profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies)
        except Exception:
            pass

    def _on_title_changed(self, _title: str) -> None:
        if self._page_ready:
            self._event_timer.start()

    def _safety_poll(self) -> None:
        window = self.window()
        if window is not None and window.isActiveWindow():
            self._poll()

    # -- Dil paketi / TOC ----------------------------------------------------

    def load_language(self, package: content_loader.LanguagePackage) -> None:
        self.language_pkg = package
        self.toc_root = content_loader.build_toc(package.root_path)
        self.flat_pages = content_loader.flatten_pages(self.toc_root)

    def find_page_title(self, page_key: str) -> str:
        for node in self.flat_pages:
            if node.page_key == page_key:
                return node.title
        return page_key

    def _handle_internal_link(self, local_file_path: str) -> bool:
        if not self.language_pkg:
            return False
        root = os.path.normpath(self.language_pkg.root_path)
        target = os.path.normpath(local_file_path)
        if not target.startswith(root):
            return False
        if os.path.isdir(target):                       # klasör bağlantısı -> README
            readme = os.path.join(target, "README.md")
            if not os.path.isfile(readme):
                return False
            target = readme
        if not os.path.isfile(target):
            return False
        ext = os.path.splitext(target)[1].lower()
        if ext not in (".md", ".txt"):
            QDesktopServices.openUrl(QUrl.fromLocalFile(target))
            return True
        rel = os.path.relpath(target, root).replace(os.sep, "/")
        self.navigate_to(rel)
        return True

    # -- Sayfa gösterimi -------------------------------------------------------

    def navigate_to(self, page_key: str, *, animate: bool = True,
                    initial_scroll_fraction: float = 0.0) -> None:
        if not self.language_pkg:
            return
        full_path = os.path.join(self.language_pkg.root_path, *page_key.split("/"))
        if not os.path.isfile(full_path):
            return
        self._nav_token += 1
        token = self._nav_token
        pkg = self.language_pkg

        def go():
            if token != self._nav_token or pkg is not self.language_pkg:
                return
            self.current_page_key = page_key
            self._load_html(page_key, full_path, initial_scroll_fraction)

        # Gitmeden önce mevcut sayfanın çizim/notlarını kaydet.
        self.flush(go)

    def _load_html(self, page_key: str, full_path: str, initial_scroll_fraction: float) -> None:
        with open(full_path, "r", encoding="utf-8") as f:
            source = f.read()
        lang_name = self.language_pkg.display_name
        annotations = self.state.annotation_store.get(lang_name, page_key).to_dict()
        code = i18n.lang_code_for_package(lang_name)
        html = render_page_html(
            source_text=source,
            is_plain_text=full_path.lower().endswith(".txt"),
            language=lang_name,
            page_key=page_key,
            annotations_json=annotations,
            initial_scroll_fraction=initial_scroll_fraction,
            lang_code=code,
            i18n_strings=i18n.js_strings(code),
        )
        base_dir = content_loader.page_dir(self.language_pkg.root_path, page_key)
        self._page_ready = False
        self._active = (lang_name, page_key)
        self.web.setHtml(html, QUrl.fromLocalFile(base_dir + os.sep))
        self.web.setZoomFactor(self.zoom_factor)
        self.state.remember_position(lang_name, page_key, initial_scroll_fraction)
        self.pageChanged.emit(page_key, self.find_page_title(page_key))

    def _on_load_finished(self, ok: bool) -> None:
        self._page_ready = bool(ok)

    # -- Gezinme yardımcıları ---------------------------------------------------

    def go_next(self) -> None:
        idx = self._current_index()
        if idx is not None and idx + 1 < len(self.flat_pages):
            self.navigate_to(self.flat_pages[idx + 1].page_key)

    def go_previous(self) -> None:
        idx = self._current_index()
        if idx is not None and idx > 0:
            self.navigate_to(self.flat_pages[idx - 1].page_key)

    def has_next(self) -> bool:
        idx = self._current_index()
        return idx is not None and idx + 1 < len(self.flat_pages)

    def has_previous(self) -> bool:
        idx = self._current_index()
        return idx is not None and idx > 0

    def _current_index(self) -> Optional[int]:
        for i, node in enumerate(self.flat_pages):
            if node.page_key == self.current_page_key:
                return i
        return None

    # -- Yakınlaştırma -----------------------------------------------------

    def zoom_in(self) -> None:
        self.set_zoom(round(self.zoom_factor + 0.1, 2))

    def zoom_out(self) -> None:
        self.set_zoom(round(self.zoom_factor - 0.1, 2))

    def reset_zoom(self) -> None:
        self.set_zoom(1.0)

    def set_zoom(self, factor: float) -> None:
        factor = max(self.MIN_ZOOM, min(self.MAX_ZOOM, factor))
        self.zoom_factor = factor
        self.state.state.zoom_factor = factor
        self.web.setZoomFactor(factor)
        self.zoomChanged.emit(factor)

    # -- Not/çizim araçları -----------------------------------------------------

    def set_tool(self, tool: Optional[str], color: str = "#ffd43b",
                 width: int = 3, opacity: float = 1.0) -> None:
        tool_js = "null" if tool is None else json.dumps(tool)
        self.web.page().runJavaScript(
            f"window.kitapSetTool && window.kitapSetTool({tool_js}, {json.dumps(color)}, {width}, {opacity});"
        )

    def clear_current_page_annotations(self) -> None:
        if not self._active:
            return
        self.web.page().runJavaScript("window.kitapClearAnnotations && window.kitapClearAnnotations();")
        # Temizlemeyi hemen kalıcı yap.
        lang, key = self._active
        self.state.annotation_store.clear(lang, key)
        self.state.save()

    # -- Durum kalıcılığı -----------------------------------------------------

    def _apply_poll_result(self, active: tuple, raw, force_save: bool = False) -> bool:
        """JS'ten gelen kitapPoll() sonucunu işler. Diske yazıldıysa True döner."""
        if not raw or not isinstance(raw, str):
            return False
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            return False
        lang, key = active
        wrote = False
        ann = data.get("ann")
        if ann is not None:
            self.state.annotation_store.set(lang, key, PageAnnotations.from_dict(ann))
            self.state.save()
            wrote = True
        scroll = data.get("scroll")
        if isinstance(scroll, (int, float)):
            before = self.state.state.scroll_fraction
            self.state.remember_position(lang, key, float(scroll))
            if abs(before - float(scroll)) > 0.002:
                self._scroll_dirty = True
        now = time.monotonic()
        if not wrote and self._scroll_dirty and (
            force_save or now - self._last_scroll_save >= self.SCROLL_SAVE_EVERY_S
        ):
            self.state.save()
            self._scroll_dirty = False
            self._last_scroll_save = now
            wrote = True
        return wrote

    def _poll(self) -> None:
        if not self._page_ready or not self._active or not self.isVisible():
            return
        window = self.window()
        if window is not None and window.isMinimized():
            return
        active = self._active
        self.web.page().runJavaScript(
            "window.kitapPoll ? window.kitapPoll(false) : '';",
            lambda raw, a=active: self._apply_poll_result(a, raw),
        )

    def flush(self, then: Optional[Callable[[], None]] = None, force: bool = False) -> None:
        """Sayfadaki bekleyen çizim/not/kaydırma verisini hemen alır, sonra ``then`` çağrılır."""
        if not self._page_ready or not self._active:
            if then:
                then()
            return
        active = self._active
        script = f"window.kitapPoll ? window.kitapPoll({'true' if force else 'false'}) : '';"

        def done(raw):
            self._apply_poll_result(active, raw, force_save=True)
            if then:
                then()

        self.web.page().runJavaScript(script, done)

    def save_now(self) -> None:
        """Elle 'Sayfayı kaydet': tüm sayfa verisini zorla yazar."""
        def finished():
            self.state.save()
            self.saved.emit()
        self.flush(finished, force=True)

    def flush_blocking(self, timeout_ms: int = 1200) -> None:
        """Kapanışta: verinin gerçekten alınmasını (kısa süre) bekler."""
        loop = QEventLoop()
        done = {"v": False}

        def finish():
            done["v"] = True
            loop.quit()

        self.flush(finish, force=True)
        if not done["v"]:
            QTimer.singleShot(timeout_ms, loop.quit)
            loop.exec()
        self.state.save()
