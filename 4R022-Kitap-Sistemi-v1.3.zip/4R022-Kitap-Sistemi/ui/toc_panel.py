"""
4R022 Python Learning - İçindekiler (TOC) Paneli.

Seçili dil paketinin klasör/bölüm yapısını bir ağaç olarak gösterir.
Bir sayfaya tıklanınca ``pageSelected`` sinyali yayınlanır.
"""
from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import QTreeWidget, QTreeWidgetItem, QWidget, QVBoxLayout, QLabel

from core import content_loader, i18n
from core.config import PALETTE


class TocPanel(QWidget):
    pageSelected = pyqtSignal(str)  # page_key

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("tocPanel")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.header = QLabel()
        self.header.setObjectName("tocHeader")
        self.header.setFixedHeight(38)
        layout.addWidget(self.header)
        self.retranslate()

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(14)
        self.tree.setUniformRowHeights(True)
        self.tree.itemClicked.connect(self._on_item_clicked)
        layout.addWidget(self.tree)

        self.setStyleSheet(f"""
            #tocPanel {{ background: {PALETTE.bg_panel}; border-right: 1px solid {PALETTE.border}; }}
            #tocHeader {{
                background: {PALETTE.bg_elevated};
                color: {PALETTE.yellow};
                font-weight: 700;
                font-size: 11px;
                letter-spacing: 1px;
                border-bottom: 1px solid {PALETTE.border};
            }}
            QTreeWidget {{
                background: {PALETTE.bg_panel};
                color: {PALETTE.text};
                border: none;
                font-size: 13px;
                outline: none;
            }}
            QTreeWidget::item {{ padding: 5px 4px; border-radius: 4px; }}
            QTreeWidget::item:selected {{ background: {PALETTE.bordo}; color: white; }}
            QTreeWidget::item:hover:!selected {{ background: {PALETTE.bg_elevated}; }}
        """)

    def retranslate(self) -> None:
        self.header.setText("  " + i18n.tr("toc_header"))

    def load(self, toc_root: content_loader.TocNode) -> None:
        self.tree.clear()
        for child in toc_root.children:
            self._add_node(self.tree.invisibleRootItem(), child, depth=0)
        self.tree.expandToDepth(0)

    def _add_node(self, parent_item, node: content_loader.TocNode, depth: int) -> None:
        item = QTreeWidgetItem([node.title])
        item.setData(0, Qt.ItemDataRole.UserRole, node.page_key)
        if node.is_folder:
            font = item.font(0)
            font.setBold(True)
            item.setFont(0, font)
        parent_item.addChild(item)
        for child in node.children:
            self._add_node(item, child, depth + 1)

    def _on_item_clicked(self, item: QTreeWidgetItem, _column: int) -> None:
        page_key = item.data(0, Qt.ItemDataRole.UserRole)
        if page_key:
            self.pageSelected.emit(page_key)

    def select_page(self, page_key: str) -> None:
        """Belirtilen sayfa anahtarına karşılık gelen ağaç öğesini vurgular."""
        iterator_stack = [self.tree.topLevelItem(i) for i in range(self.tree.topLevelItemCount())]
        while iterator_stack:
            item = iterator_stack.pop()
            if item is None:
                continue
            if item.data(0, Qt.ItemDataRole.UserRole) == page_key:
                self.tree.setCurrentItem(item)
                self.tree.scrollToItem(item)
                return
            for i in range(item.childCount()):
                iterator_stack.append(item.child(i))
