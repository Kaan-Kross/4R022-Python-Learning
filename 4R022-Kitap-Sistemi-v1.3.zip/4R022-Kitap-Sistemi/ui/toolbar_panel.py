"""
4R022 Python Learning - Araç Çubuğu.

Tüm tooltip/etiket metinleri ``core.i18n`` üzerinden gelir ve dil
değişince ``retranslate()`` ile anında güncellenir.
"""
from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QButtonGroup, QColorDialog, QFrame, QHBoxLayout, QLabel, QToolButton, QWidget,
)

from core import i18n
from core.config import PALETTE


class _Separator(QFrame):
    def __init__(self):
        super().__init__()
        self.setFrameShape(QFrame.Shape.VLine)
        self.setStyleSheet(f"color: {PALETTE.border};")


class ToolbarPanel(QWidget):
    tocToggled = pyqtSignal()
    prevRequested = pyqtSignal()
    nextRequested = pyqtSignal()
    zoomInRequested = pyqtSignal()
    zoomOutRequested = pyqtSignal()
    zoomResetRequested = pyqtSignal()
    toolSelected = pyqtSignal(object)  # str veya None
    colorChanged = pyqtSignal(str)
    clearPageRequested = pyqtSignal()
    savePageRequested = pyqtSignal()
    languageChangeRequested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("toolbarPanel")
        self.setFixedHeight(52)
        self._current_color = "#ffd43b"

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 6, 12, 6)
        layout.setSpacing(6)

        self.toc_btn = self._make_button("☰")
        self.toc_btn.clicked.connect(self.tocToggled.emit)
        layout.addWidget(self.toc_btn)
        layout.addWidget(_Separator())

        self.prev_btn = self._make_button("◀")
        self.prev_btn.clicked.connect(self.prevRequested.emit)
        self.next_btn = self._make_button("▶")
        self.next_btn.clicked.connect(self.nextRequested.emit)
        layout.addWidget(self.prev_btn)
        layout.addWidget(self.next_btn)
        layout.addWidget(_Separator())

        self.zoom_out_btn = self._make_button("－")
        self.zoom_out_btn.clicked.connect(self.zoomOutRequested.emit)
        self.zoom_in_btn = self._make_button("＋")
        self.zoom_in_btn.clicked.connect(self.zoomInRequested.emit)
        self.zoom_label = QLabel("100%")
        self.zoom_label.setObjectName("zoomLabel")
        self.zoom_label.setFixedWidth(46)
        self.zoom_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.zoom_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.zoom_label.mousePressEvent = lambda _e: self.zoomResetRequested.emit()
        layout.addWidget(self.zoom_out_btn)
        layout.addWidget(self.zoom_label)
        layout.addWidget(self.zoom_in_btn)
        layout.addWidget(_Separator())

        self.tool_group = QButtonGroup(self)
        self.tool_group.setExclusive(True)
        self.select_btn = self._make_tool_button("🖱", None, checked=True)
        self.pen_btn = self._make_tool_button("✏", "pen")
        self.highlighter_btn = self._make_tool_button("🖍", "highlighter")
        self.transparent_btn = self._make_tool_button("🩶", "transparent")
        self.eraser_btn = self._make_tool_button("🧹", "eraser")
        self.note_btn = self._make_tool_button("🗒", "note")
        for b in (self.select_btn, self.pen_btn, self.highlighter_btn,
                  self.transparent_btn, self.eraser_btn, self.note_btn):
            layout.addWidget(b)
        layout.addWidget(_Separator())

        self.color_btn = self._make_button("🎨")
        self.color_btn.clicked.connect(self._pick_color)
        layout.addWidget(self.color_btn)

        self.clear_btn = self._make_button("🗑")
        self.clear_btn.clicked.connect(self.clearPageRequested.emit)
        layout.addWidget(self.clear_btn)

        self.save_btn = self._make_button("💾")
        self.save_btn.clicked.connect(self.savePageRequested.emit)
        layout.addWidget(self.save_btn)

        self.status_label = QLabel("")
        self.status_label.setObjectName("statusLabel")
        layout.addWidget(self.status_label)

        layout.addStretch(1)

        self.language_btn = QToolButton()
        self.language_btn.setObjectName("languageButton")
        self.language_btn.clicked.connect(self.languageChangeRequested.emit)
        layout.addWidget(self.language_btn)

        self._status_timer = QTimer(self)
        self._status_timer.setSingleShot(True)
        self._status_timer.timeout.connect(lambda: self.status_label.setText(""))

        self.setStyleSheet(f"""
            #toolbarPanel {{ background: {PALETTE.bg_elevated}; border-bottom: 1px solid {PALETTE.border}; }}
            QToolButton {{
                background: transparent; color: {PALETTE.text};
                border: 1px solid transparent; border-radius: 6px;
                padding: 6px 10px; font-size: 15px;
            }}
            QToolButton:hover {{ background: {PALETTE.bg_panel}; border-color: {PALETTE.border}; }}
            QToolButton:checked {{ background: {PALETTE.bordo}; color: white; }}
            QToolButton:disabled {{ color: {PALETTE.gray}; }}
            #zoomLabel {{ color: {PALETTE.text_dim}; font-size: 12px; }}
            #statusLabel {{ color: #3ddc84; font-size: 12px; font-weight: 600; padding-left: 6px; }}
            #languageButton {{
                background: {PALETTE.bg_panel}; border: 1px solid {PALETTE.border};
                padding: 7px 14px; font-weight: 600; font-size: 13px;
            }}
            #languageButton:hover {{ background: {PALETTE.bordo}; color: white; }}
        """)
        self.retranslate()

    # -- i18n ------------------------------------------------------------------

    def retranslate(self) -> None:
        t = i18n.tr
        self.toc_btn.setToolTip(t("tip_toc"))
        self.prev_btn.setToolTip(t("tip_prev"))
        self.next_btn.setToolTip(t("tip_next"))
        self.zoom_out_btn.setToolTip(t("tip_zoom_out"))
        self.zoom_in_btn.setToolTip(t("tip_zoom_in"))
        self.zoom_label.setToolTip(t("tip_zoom_reset"))
        self.select_btn.setToolTip(t("tool_select"))
        self.pen_btn.setToolTip(t("tool_pen"))
        self.highlighter_btn.setToolTip(t("tool_highlighter"))
        self.transparent_btn.setToolTip(t("tool_transparent"))
        self.eraser_btn.setToolTip(t("tool_eraser"))
        self.note_btn.setToolTip(t("tool_note"))
        self.color_btn.setToolTip(t("tip_color"))
        self.clear_btn.setToolTip(t("tip_clear"))
        self.save_btn.setToolTip(t("tip_save"))
        self.language_btn.setText(t("btn_language"))

    def flash_saved(self) -> None:
        self.status_label.setText(i18n.tr("saved_msg"))
        self._status_timer.start(1800)

    # -- yardımcılar -----------------------------------------------------------

    def _make_button(self, text: str) -> QToolButton:
        btn = QToolButton()
        btn.setText(text)
        return btn

    def _make_tool_button(self, text: str, tool_value: Optional[str], checked: bool = False) -> QToolButton:
        btn = QToolButton()
        btn.setText(text)
        btn.setCheckable(True)
        btn.setChecked(checked)
        btn.clicked.connect(lambda: self.toolSelected.emit(tool_value))
        self.tool_group.addButton(btn)
        return btn

    def _pick_color(self) -> None:
        color = QColorDialog.getColor(QColor(self._current_color), self, i18n.tr("color_dialog_title"))
        if color.isValid():
            self._current_color = color.name()
            self.colorChanged.emit(self._current_color)

    def set_zoom_label(self, factor: float) -> None:
        self.zoom_label.setText(f"{int(round(factor * 100))}%")

    def set_navigation_enabled(self, has_prev: bool, has_next: bool) -> None:
        self.prev_btn.setEnabled(has_prev)
        self.next_btn.setEnabled(has_next)

    def reset_tool_to_select(self) -> None:
        self.select_btn.setChecked(True)

    def current_color(self) -> str:
        return self._current_color
