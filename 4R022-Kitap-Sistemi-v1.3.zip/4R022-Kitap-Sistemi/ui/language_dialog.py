"""
4R022 Python Learning - Dil Seçim Penceresi.

Listede anlamsız klasör adları yerine ana dildeki adlar gösterilir
(English, Türkçe, Русский, Deutsch, Français). Pencere metinleri
``ui_lang`` ile verilen dilde çıkar; ilk açılışta bu dil İngilizcedir.
"""
from __future__ import annotations

from typing import List, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QPushButton, QVBoxLayout,
)

from core import content_loader, i18n
from core.config import APP_NAME, PALETTE


class LanguageDialog(QDialog):
    def __init__(self, packages: List[content_loader.LanguagePackage],
                 current: Optional[str] = None, ui_lang: str = i18n.DEFAULT_LANG, parent=None):
        super().__init__(parent)
        t = lambda k: i18n.tr(k, ui_lang)  # noqa: E731
        self.setWindowTitle(f"{t('lang_title')} — {APP_NAME}")
        self.setModal(True)
        self.resize(440, 420)
        self._selected: Optional[content_loader.LanguagePackage] = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        title = QLabel(t("lang_prompt"))
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        layout.addWidget(title)

        self.list_widget = QListWidget()
        self.list_widget.setSpacing(4)
        first_item = None
        for pkg in packages:
            code = i18n.lang_code_for_package(pkg.display_name)
            flag, native = i18n.NATIVE_NAMES.get(code, ("📘", pkg.display_name))
            item = QListWidgetItem(f"{flag}   {native}")
            item.setToolTip(pkg.display_name)
            item.setData(Qt.ItemDataRole.UserRole, pkg)
            self.list_widget.addItem(item)
            if first_item is None:
                first_item = item
            if pkg.display_name == current:
                first_item = item
        if first_item is not None:
            self.list_widget.setCurrentItem(first_item)
        self.list_widget.itemDoubleClicked.connect(lambda _: self._accept())
        layout.addWidget(self.list_widget)

        row = QHBoxLayout()
        row.addStretch(1)
        cancel_btn = QPushButton(t("btn_cancel"))
        cancel_btn.clicked.connect(self.reject)
        ok_btn = QPushButton(t("btn_continue"))
        ok_btn.setObjectName("primaryButton")
        ok_btn.setDefault(True)
        ok_btn.clicked.connect(self._accept)
        row.addWidget(cancel_btn)
        row.addWidget(ok_btn)
        layout.addLayout(row)

        self.setStyleSheet(f"""
            QDialog {{ background: {PALETTE.bg_panel}; }}
            #dialogTitle {{ color: {PALETTE.text}; font-size: 15px; font-weight: 600; }}
            QListWidget {{
                background: {PALETTE.bg}; color: {PALETTE.text};
                border: 1px solid {PALETTE.border}; border-radius: 8px;
                font-size: 16px; padding: 6px;
            }}
            QListWidget::item {{ padding: 10px 8px; border-radius: 6px; }}
            QListWidget::item:selected {{ background: {PALETTE.bordo}; color: white; }}
            QPushButton {{
                background: {PALETTE.bg_elevated}; color: {PALETTE.text};
                border: 1px solid {PALETTE.border}; border-radius: 6px;
                padding: 9px 18px; font-size: 13px;
            }}
            QPushButton:hover {{ background: {PALETTE.gray}; }}
            #primaryButton {{ background: {PALETTE.bordo}; border: none; font-weight: 600; }}
            #primaryButton:hover {{ background: {PALETTE.bordo_bright}; }}
        """)

    def _accept(self) -> None:
        item = self.list_widget.currentItem()
        if item is None:
            return
        self._selected = item.data(Qt.ItemDataRole.UserRole)
        self.accept()

    def selected_package(self) -> Optional[content_loader.LanguagePackage]:
        return self._selected
