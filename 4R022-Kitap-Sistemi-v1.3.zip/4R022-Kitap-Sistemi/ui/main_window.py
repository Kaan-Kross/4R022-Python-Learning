"""
4R022 Python Learning - Ana Pencere.

Üst marka şeridi (sol üstte 4R022 / Kaan Kross), araç çubuğu,
katlanabilir İçindekiler paneli ve kitap görünümünü bir araya
getirir. Ayrıca dil seçimi akışını ve "kaldığın yerden devam et"
mantığını yönetir.
"""
from __future__ import annotations

import os
from typing import Optional

from PyQt6.QtCore import QCoreApplication, QLibraryInfo, QLocale, QRect, QTranslator, Qt
from PyQt6.QtGui import QPixmap, QCloseEvent
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QSplitter,
    QMessageBox,
)

from core import content_loader, i18n
from core.config import (
    APP_AUTHOR, APP_NAME, LOGO_PATH, PALETTE, CONTENT_DIR,
    screen_geometry_fraction,
)
from core.state_manager import StateManager
from ui.book_view import BookView
from ui.toc_panel import TocPanel
from ui.toolbar_panel import ToolbarPanel
from ui.language_dialog import LanguageDialog


class _BrandBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(48)
        self.setObjectName("brandBar")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(10)

        logo_label = QLabel()
        if os.path.isfile(LOGO_PATH):
            pixmap = QPixmap(LOGO_PATH).scaledToHeight(
                30, Qt.TransformationMode.SmoothTransformation
            )
            logo_label.setPixmap(pixmap)
        layout.addWidget(logo_label)

        brand_label = QLabel("4R022  ·  Kaan Kross")
        brand_label.setObjectName("brandLabel")
        layout.addWidget(brand_label)

        layout.addSpacing(18)

        self.title_label = QLabel("")
        self.title_label.setObjectName("chapterTitleLabel")
        layout.addWidget(self.title_label, stretch=1)

        self.app_label = QLabel()
        self.app_label.setObjectName("appNameLabel")
        layout.addWidget(self.app_label)
        self.retranslate()

        self.setStyleSheet(f"""
            #brandBar {{ background: {PALETTE.bg}; border-bottom: 1px solid {PALETTE.bordo}; }}
            #brandLabel {{ color: {PALETTE.yellow}; font-weight: 800; font-size: 13px; }}
            #chapterTitleLabel {{ color: {PALETTE.text}; font-size: 13px; }}
            #appNameLabel {{ color: {PALETTE.text_dim}; font-size: 11px; }}
        """)

    def retranslate(self) -> None:
        self.app_label.setText(f"Python Learning — {i18n.tr('book_system')}")

    def set_chapter_title(self, title: str) -> None:
        self.title_label.setText(title)


class MainWindow(QMainWindow):
    def __init__(self, app):
        super().__init__()
        self._app = app
        self.setWindowTitle(APP_NAME)
        if os.path.isfile(LOGO_PATH):
            self.setWindowIcon(__import__("PyQt6.QtGui", fromlist=["QIcon"]).QIcon(LOGO_PATH))

        from core.config import STATE_FILE
        self.state = StateManager(STATE_FILE)

        self.packages = content_loader.discover_language_packages(CONTENT_DIR)
        self._translator: Optional[QTranslator] = None
        # Kayıtlı dil varsa onunla, yoksa İngilizce başla.
        i18n.set_language(i18n.lang_code_for_package(self.state.state.last_language)
                          if self.state.state.last_language else i18n.DEFAULT_LANG)
        self._install_qt_translator(i18n.current_language())

        self._build_ui()
        self._apply_geometry()
        self._wire_signals()
        self._bootstrap_content()

    # -- Arayüz kurulumu -------------------------------------------------------

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.brand_bar = _BrandBar()
        outer.addWidget(self.brand_bar)

        self.toolbar = ToolbarPanel()
        outer.addWidget(self.toolbar)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.toc_panel = TocPanel()
        self.toc_panel.setMinimumWidth(220)
        self.toc_panel.setMaximumWidth(420)
        self.book_view = BookView(self.state)
        self.splitter.addWidget(self.toc_panel)
        self.splitter.addWidget(self.book_view)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([260, 900])
        outer.addWidget(self.splitter, stretch=1)

        self.setStyleSheet(f"QMainWindow {{ background: {PALETTE.bg}; }}")

        if not self.state.state.toc_visible:
            self.toc_panel.hide()

    def _apply_geometry(self) -> None:
        geo = self.state.state.window_geometry
        if geo and len(geo) == 4 and self._geometry_on_screen(QRect(*geo)):
            self.setGeometry(QRect(*geo))
        else:
            x, y, w, h = screen_geometry_fraction(self._app)
            self.setGeometry(QRect(x, y, w, h))

    def _geometry_on_screen(self, rect: QRect) -> bool:
        """Kayıtlı pencere konumu artık bağlı olmayan bir ekranda kalmışsa kullanma."""
        if rect.width() < 400 or rect.height() < 300:
            return False
        for screen in self._app.screens():
            inter = screen.availableGeometry().intersected(rect)
            if inter.width() >= 200 and inter.height() >= 150:
                return True
        return False

    def _wire_signals(self) -> None:
        from PyQt6.QtGui import QKeySequence, QShortcut
        for seq, fn in (("Ctrl+S", self.book_view.save_now),
                        ("Alt+Left", self.book_view.go_previous),
                        ("Alt+Right", self.book_view.go_next),
                        ("Ctrl+B", self._toggle_toc),
                        ("Ctrl+=", self.book_view.zoom_in),
                        ("Ctrl+-", self.book_view.zoom_out),
                        ("Ctrl+0", self.book_view.reset_zoom)):
            QShortcut(QKeySequence(seq), self, activated=fn)
        self.toolbar.tocToggled.connect(self._toggle_toc)
        self.toolbar.prevRequested.connect(self.book_view.go_previous)
        self.toolbar.nextRequested.connect(self.book_view.go_next)
        self.toolbar.zoomInRequested.connect(self.book_view.zoom_in)
        self.toolbar.zoomOutRequested.connect(self.book_view.zoom_out)
        self.toolbar.zoomResetRequested.connect(self.book_view.reset_zoom)
        self.toolbar.toolSelected.connect(self._on_tool_selected)
        self.toolbar.colorChanged.connect(self._on_color_changed)
        self.toolbar.clearPageRequested.connect(self._on_clear_page)
        self.toolbar.savePageRequested.connect(self.book_view.save_now)
        self.book_view.saved.connect(self.toolbar.flash_saved)
        self.toolbar.languageChangeRequested.connect(self._open_language_dialog)

        self.toc_panel.pageSelected.connect(
            lambda key: self.book_view.navigate_to(key)
        )

        self.book_view.pageChanged.connect(self._on_page_changed)
        self.book_view.zoomChanged.connect(self.toolbar.set_zoom_label)

    # -- Başlangıç: kaldığın yerden devam et / dil seçimi ------------------------

    def _bootstrap_content(self) -> None:
        if not self.packages:
            QMessageBox.critical(self, APP_NAME, i18n.tr("err_no_packages"))
            return

        target_pkg: Optional[content_loader.LanguagePackage] = None
        target_page: Optional[str] = None
        initial_scroll = 0.0

        saved_lang = self.state.state.last_language
        if saved_lang:
            for pkg in self.packages:
                if pkg.display_name == saved_lang:
                    target_pkg = pkg
                    break

        if target_pkg is None:
            dialog = LanguageDialog(self.packages, ui_lang=i18n.DEFAULT_LANG, parent=self)
            if dialog.exec():
                target_pkg = dialog.selected_package()
            if target_pkg is None:
                target_pkg = self.packages[0]
            self._apply_ui_language(target_pkg)
        else:
            saved_page = self.state.state.last_page_key
            candidate_full = os.path.join(target_pkg.root_path, *saved_page.split("/")) if saved_page else None
            if candidate_full and os.path.isfile(candidate_full):
                target_page = saved_page
                initial_scroll = self.state.state.scroll_fraction

        self.book_view.load_language(target_pkg)
        self.toc_panel.load(self.book_view.toc_root)

        if target_page is None and self.book_view.flat_pages:
            target_page = self.book_view.flat_pages[0].page_key

        if target_page:
            self.book_view.navigate_to(
                target_page, animate=False, initial_scroll_fraction=initial_scroll
            )
            self.toc_panel.select_page(target_page)

    # -- Sinyal işleyicileri ---------------------------------------------------

    def _toggle_toc(self) -> None:
        visible = not self.toc_panel.isVisible()
        self.toc_panel.setVisible(visible)
        self.state.state.toc_visible = visible
        self.state.save()

    def _on_tool_selected(self, tool) -> None:
        color = self.toolbar.current_color()
        self.book_view.set_tool(tool, color=color)

    def _on_color_changed(self, color: str) -> None:
        self.book_view.set_tool(self._active_tool_or_none(), color=color)

    def _active_tool_or_none(self):
        checked = self.toolbar.tool_group.checkedButton()
        if checked is self.toolbar.select_btn or checked is None:
            return None
        mapping = {
            self.toolbar.pen_btn: "pen",
            self.toolbar.highlighter_btn: "highlighter",
            self.toolbar.transparent_btn: "transparent",
            self.toolbar.eraser_btn: "eraser",
            self.toolbar.note_btn: "note",
        }
        return mapping.get(checked)

    def _on_clear_page(self) -> None:
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Question)
        box.setWindowTitle(i18n.tr("clear_title"))
        box.setText(i18n.tr("clear_text"))
        yes_btn = box.addButton(i18n.tr("btn_yes"), QMessageBox.ButtonRole.YesRole)
        box.addButton(i18n.tr("btn_no"), QMessageBox.ButtonRole.NoRole)
        box.exec()
        if box.clickedButton() is yes_btn:
            self.book_view.clear_current_page_annotations()

    def _on_page_changed(self, page_key: str, title: str) -> None:
        self.brand_bar.set_chapter_title(title)
        self.toc_panel.select_page(page_key)
        self.toolbar.set_navigation_enabled(
            self.book_view.has_previous(), self.book_view.has_next()
        )
        self.toolbar.reset_tool_to_select()
        self.state.save()

    def _open_language_dialog(self) -> None:
        current_name = self.book_view.language_pkg.display_name if self.book_view.language_pkg else None
        dialog = LanguageDialog(self.packages, current=current_name,
                                ui_lang=i18n.current_language(), parent=self)
        if not dialog.exec():
            return
        new_pkg = dialog.selected_package()
        if new_pkg is None or (self.book_view.language_pkg and new_pkg.root_path == self.book_view.language_pkg.root_path):
            return

        previous_page_key = self.book_view.current_page_key
        old_pages = [n.page_key for n in self.book_view.flat_pages if not n.page_key.endswith(".txt")]
        old_index = old_pages.index(previous_page_key) if previous_page_key in old_pages else None
        self.book_view.flush_blocking()
        self._apply_ui_language(new_pkg)
        self.book_view.load_language(new_pkg)
        self.toc_panel.load(self.book_view.toc_root)

        target_page = None
        if old_index is not None:
            # Dil paketleri birebir paralel: aynı sıradaki sayfaya geç (.txt hariç sayılır).
            new_pages = [n for n in self.book_view.flat_pages if not n.page_key.endswith(".txt")]
            if 0 <= old_index < len(new_pages):
                target_page = new_pages[old_index].page_key
        if target_page is None and self.book_view.flat_pages:
            target_page = self.book_view.flat_pages[0].page_key

        if target_page:
            self.book_view.navigate_to(target_page)

    # -- Dil (arayüz metinleri) -------------------------------------------------

    def _install_qt_translator(self, code: str) -> None:
        """Qt'nin kendi pencerelerini (renk seçici vb.) da seçilen dile çevirir."""
        app = QCoreApplication.instance()
        if self._translator is not None:
            app.removeTranslator(self._translator)
            self._translator = None
        if code == "en":
            return
        tr_ = QTranslator(self)
        path = QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)
        if tr_.load(QLocale(code), "qtbase", "_", path):
            app.installTranslator(tr_)
            self._translator = tr_

    def _apply_ui_language(self, pkg: content_loader.LanguagePackage) -> None:
        code = i18n.lang_code_for_package(pkg.display_name)
        i18n.set_language(code)
        self._install_qt_translator(code)
        self.toolbar.retranslate()
        self.toc_panel.retranslate()
        self.brand_bar.retranslate()

    # -- Kapanış -----------------------------------------------------------

    def closeEvent(self, event: QCloseEvent) -> None:
        try:
            self.book_view.flush_blocking()
        except Exception:
            pass
        geo = self.geometry()
        self.state.state.window_geometry = [geo.x(), geo.y(), geo.width(), geo.height()]
        self.state.save()
        super().closeEvent(event)
