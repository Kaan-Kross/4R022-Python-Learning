/* 4R022 Python Learning - web/bridge.js  (v1.1)
 *
 * Sayfa içi çizim / not motoru.  Python tarafı bu betiği her sayfaya gömer.
 *
 * Tasarım (v1.1):
 *  - Çizimler, ekranı kaplayan SABİT (viewport boyutlu) tek bir canvas'a
 *    çizilir; kaydırmada yalnızca görünen bölge yeniden çizilir. Böylece
 *    uzun sayfalarda dev canvas oluşmaz (takılma / scroll donması biter).
 *  - Tüm koordinatlar içerik kutusuna (.kitap-sayfa-icerik) GÖRELİDİR.
 *    Sol menü açılıp kapanınca ya da pencere boyutu değişince içerik
 *    kaydığında çizim/notlar içerikle birlikte kayar (kalem sapması biter).
 *  - QWebChannel'a bağımlılık yok: Python, kitapPoll() çağırarak değişen
 *    çizim/not verisini ve kaydırma oranını alır; sayfa yenilense de
 *    kapansa da veri kaybolmaz.
 *
 * Python'un enjekte ettiği globaller:
 *   __PAGE_KEY__, __LANGUAGE__, __ANNOTATIONS__, __INITIAL_SCROLL_FRACTION__, __I18N__
 */
(function () {
  "use strict";

  var content, canvas, ctx, dpr = 1;
  var currentTool = null;          // null | pen | highlighter | transparent | eraser | note
  var currentColor = "#ffd43b";
  var currentWidth = 3;
  var currentOpacity = 1.0;
  var drawing = false;
  var activeStroke = null;
  var dirty = false;
  var rafPending = false;
  var I18N = window.__I18N__ || {};

  var saved = window.__ANNOTATIONS__ || {};
  var strokes = Array.isArray(saved.strokes) ? saved.strokes : [];
  var notes = Array.isArray(saved.notes) ? saved.notes : [];
  var noteSeq = 1;

  var baseTitle = document.title;
  var pingSeq = 0;
  var pingTimer = null;
  var scrollTimer = null;

  // Python'a "bir şey değişti" haberi: başlık değişimi (titleChanged sinyali).
  // Böylece Python tarafında sürekli sorgu (polling) gerekmez -> boşta CPU ~0.
  function ping() {
    if (pingTimer) clearTimeout(pingTimer);
    pingTimer = setTimeout(function () {
      pingTimer = null;
      pingSeq = (pingSeq + 1) % 2;
      document.title = baseTitle + (pingSeq ? "\u200b" : "");
    }, 300);
  }

  function markDirty() { dirty = true; updateCanvasState(); ping(); }

  function onScrollSettled() {
    if (scrollTimer) clearTimeout(scrollTimer);
    scrollTimer = setTimeout(ping, 700);
  }

  // Çizim yoksa ve araç kapalıysa canvas tamamen devre dışı (sıfır kompozit maliyeti).
  function updateCanvasState() {
    if (!canvas) return;
    var need = strokes.length > 0 || !!currentTool;
    canvas.style.display = need ? "block" : "none";
  }

  // ---- Koordinatlar --------------------------------------------------------
  function origin() {
    var r = content.getBoundingClientRect();
    return { x: r.left, y: r.top };
  }
  function toContent(evt) {
    var o = origin();
    return [Math.round((evt.clientX - o.x) * 10) / 10, Math.round((evt.clientY - o.y) * 10) / 10];
  }

  // ---- Canvas --------------------------------------------------------------
  function sizeCanvas() {
    dpr = window.devicePixelRatio || 1;
    var w = window.innerWidth, h = window.innerHeight;
    var pw = Math.max(1, Math.round(w * dpr)), ph = Math.max(1, Math.round(h * dpr));
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    ctx = canvas.getContext("2d");
  }

  function applyStrokeStyle(s) {
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.lineWidth = s.width;
    ctx.globalAlpha = s.opacity;
    if (s.tool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.strokeStyle = "rgba(0,0,0,1)";
    } else {
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = s.color;
    }
  }

  function strokeBounds(s) {
    if (s._b) return s._b;
    var minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9, p = s.points;
    for (var i = 0; i < p.length; i++) {
      if (p[i][0] < minX) minX = p[i][0];
      if (p[i][0] > maxX) maxX = p[i][0];
      if (p[i][1] < minY) minY = p[i][1];
      if (p[i][1] > maxY) maxY = p[i][1];
    }
    var pad = s.width + 2;
    s._b = [minX - pad, minY - pad, maxX + pad, maxY + pad];
    return s._b;
  }

  function drawStroke(s, o) {
    var p = s.points;
    if (!p || p.length === 0) return;
    ctx.save();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    applyStrokeStyle(s);
    ctx.beginPath();
    ctx.moveTo(p[0][0] + o.x, p[0][1] + o.y);
    if (p.length === 1) ctx.lineTo(p[0][0] + o.x + 0.01, p[0][1] + o.y);
    for (var i = 1; i < p.length; i++) ctx.lineTo(p[i][0] + o.x, p[i][1] + o.y);
    ctx.stroke();
    ctx.restore();
  }

  function redraw() {
    rafPending = false;
    if (!ctx || (strokes.length === 0 && !drawing)) return;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    var o = origin();
    var vw = window.innerWidth, vh = window.innerHeight;
    for (var i = 0; i < strokes.length; i++) {
      var b = strokeBounds(strokes[i]);
      var sx1 = b[0] + o.x, sy1 = b[1] + o.y, sx2 = b[2] + o.x, sy2 = b[3] + o.y;
      if (sx2 < 0 || sy2 < 0 || sx1 > vw || sy1 > vh) continue;   // ekran dışı: atla
      drawStroke(strokes[i], o);
    }
  }

  function scheduleRedraw() {
    if (rafPending || strokes.length === 0) return;
    rafPending = true;
    window.requestAnimationFrame(redraw);
  }

  // ---- Çizim ---------------------------------------------------------------
  function toolStyle(tool) {
    switch (tool) {
      case "highlighter": return { width: currentWidth * 6, opacity: 0.35 };
      case "transparent": return { width: currentWidth * 2, opacity: 0.5 };
      case "eraser":      return { width: currentWidth * 8, opacity: 1.0 };
      default:            return { width: currentWidth, opacity: currentOpacity };
    }
  }

  function onPointerDown(evt) {
    if (evt.button !== undefined && evt.button !== 0) return;
    if (!currentTool) return;
    var pt = toContent(evt);
    if (currentTool === "note") {
      var n = { id: "n" + Date.now() + "-" + (noteSeq++), x: pt[0], y: pt[1], text: "", color: currentColor };
      notes.push(n);
      var el = buildNote(n);
      markDirty();
      var body = el.querySelector(".kitap-sticky-note-body");
      if (body) setTimeout(function () { body.focus(); }, 0);
      evt.preventDefault();
      return;
    }
    var st = toolStyle(currentTool);
    activeStroke = { tool: currentTool, color: currentColor, width: st.width, opacity: st.opacity, points: [pt] };
    strokes.push(activeStroke);
    drawing = true;
    try { canvas.setPointerCapture(evt.pointerId); } catch (e) {}
    drawStroke({ tool: activeStroke.tool, color: activeStroke.color, width: activeStroke.width,
                 opacity: activeStroke.opacity, points: [pt] }, origin());
    evt.preventDefault();
  }

  function onPointerMove(evt) {
    if (!drawing || !activeStroke) return;
    var pt = toContent(evt);
    var last = activeStroke.points[activeStroke.points.length - 1];
    if (Math.abs(pt[0] - last[0]) + Math.abs(pt[1] - last[1]) < 1.5) return;
    activeStroke.points.push(pt);
    activeStroke._b = null;
    drawStroke({ tool: activeStroke.tool, color: activeStroke.color, width: activeStroke.width,
                 opacity: activeStroke.opacity, points: [last, pt] }, origin());
    evt.preventDefault();
  }

  function onPointerUp(evt) {
    if (!drawing) return;
    drawing = false;
    activeStroke = null;
    try { canvas.releasePointerCapture(evt.pointerId); } catch (e) {}
    markDirty();
  }

  // ---- Yapışkan notlar -----------------------------------------------------
  function buildNote(n) {
    var el = document.createElement("div");
    el.className = "kitap-sticky-note";
    el.style.left = n.x + "px";
    el.style.top = n.y + "px";
    el.style.background = n.color || "#ffd43b";

    var bar = document.createElement("div");
    bar.className = "kitap-sticky-note-bar";

    var closeBtn = document.createElement("div");
    closeBtn.className = "kitap-sticky-note-close";
    closeBtn.textContent = "\u00d7";
    closeBtn.title = I18N.note_delete || "Delete note";
    closeBtn.addEventListener("pointerdown", function (e) { e.stopPropagation(); });
    closeBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      el.remove();
      notes = notes.filter(function (x) { return x.id !== n.id; });
      markDirty();
    });
    bar.appendChild(closeBtn);

    var body = document.createElement("div");
    body.className = "kitap-sticky-note-body";
    body.contentEditable = "true";
    body.spellcheck = false;
    body.setAttribute("data-placeholder", I18N.note_placeholder || "");
    body.textContent = n.text || "";
    body.addEventListener("input", function () { n.text = body.innerText; markDirty(); });
    body.addEventListener("pointerdown", function (e) { e.stopPropagation(); });

    el.appendChild(bar);
    el.appendChild(body);
    content.appendChild(el);

    // Sürükleme (yalnızca üst çubuktan)
    var down = false, sx = 0, sy = 0, ox = 0, oy = 0;
    bar.addEventListener("pointerdown", function (e) {
      down = true; sx = e.clientX; sy = e.clientY; ox = n.x; oy = n.y;
      try { bar.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
    });
    bar.addEventListener("pointermove", function (e) {
      if (!down) return;
      n.x = ox + (e.clientX - sx);
      n.y = Math.max(0, oy + (e.clientY - sy));
      el.style.left = n.x + "px";
      el.style.top = n.y + "px";
    });
    function endDrag(e) {
      if (!down) return;
      down = false;
      try { bar.releasePointerCapture(e.pointerId); } catch (err) {}
      markDirty();
    }
    bar.addEventListener("pointerup", endDrag);
    bar.addEventListener("pointercancel", endDrag);
    return el;
  }

  // ---- Python'a açık fonksiyonlar -------------------------------------------
  window.kitapSetTool = function (tool, color, width, opacity) {
    currentTool = tool || null;
    if (color) currentColor = color;
    if (width) currentWidth = width;
    if (typeof opacity === "number") currentOpacity = opacity;
    var active = !!currentTool;
    canvas.style.pointerEvents = active ? "auto" : "none";
    canvas.style.cursor = !active ? "default" : (currentTool === "note" ? "copy" : "crosshair");
    canvas.style.touchAction = active ? "none" : "auto";
    updateCanvasState();
    if (active) scheduleRedraw();
  };

  window.kitapClearAnnotations = function () {
    strokes = [];
    notes = [];
    var els = content.querySelectorAll(".kitap-sticky-note");
    for (var i = 0; i < els.length; i++) els[i].remove();
    ctx && ctx.clearRect(0, 0, canvas.width, canvas.height);
    markDirty();
  };

  function currentFraction() {
    var max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    return Math.max(0, Math.min(1, window.scrollY / max));
  }

  function annotationPayload() {
    var clean = strokes.map(function (s) {
      return { tool: s.tool, color: s.color, width: s.width, opacity: s.opacity, points: s.points };
    });
    return { strokes: clean, notes: notes };
  }

  // Değişiklik varsa tam veri, yoksa null; her zaman kaydırma oranı.
  window.kitapPoll = function (force) {
    var out = { ann: null, scroll: currentFraction() };
    if (dirty || force) { out.ann = annotationPayload(); dirty = false; }
    return JSON.stringify(out);
  };

  window.kitapScrollToFraction = function (f) {
    var max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    window.scrollTo(0, f * max);
  };

  // ---- Kurulum -------------------------------------------------------------
  function init() {
    content = document.querySelector(".kitap-sayfa-icerik") || document.body;

    canvas = document.createElement("canvas");
    canvas.id = "kitap-annotation-canvas";
    canvas.style.cssText = "position:fixed;left:0;top:0;pointer-events:none;z-index:9000;display:none;";
    document.body.appendChild(canvas);
    sizeCanvas();

    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerup", onPointerUp);
    canvas.addEventListener("pointercancel", onPointerUp);

    notes.forEach(function (n) { buildNote(n); });

    window.addEventListener("scroll", function () { scheduleRedraw(); onScrollSettled(); }, { passive: true });
    window.addEventListener("resize", function () { sizeCanvas(); scheduleRedraw(); });
    if (window.ResizeObserver) {
      new ResizeObserver(function () { scheduleRedraw(); }).observe(content);
    }

    updateCanvasState();
    scheduleRedraw();

    var f = window.__INITIAL_SCROLL_FRACTION__;
    if (typeof f === "number" && f > 0) {
      var apply = function () { window.kitapScrollToFraction(f); scheduleRedraw(); };
      setTimeout(apply, 40);
      window.addEventListener("load", function () { setTimeout(apply, 40); });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
